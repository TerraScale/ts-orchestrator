from pathlib import Path
import hashlib,json,re,urllib.parse,ipaddress,datetime,subprocess
D=Path(__file__).resolve().parent
R=Path('/tmp/ts-terrabase-nsg-first-runtime-e502eed6-lkrfgaqf')
S=Path('/tmp/ts-terrabase-nsg-sdk-socket-source-7e297694-aa2f8ca1')
W=Path('/tmp/ts-terrabase-nsg-sdk-socket')
def sha(b):return hashlib.sha256(b).hexdigest()
def fi(p):
 b=Path(p).read_bytes();return {'path':str(p),'sha256':sha(b),'size':len(b)}
def write(name,b):
 with (D/name).open('xb') as f:f.write(b)
def wjson(name,value):write(name,(json.dumps(value,indent=2)+'\n').encode())
receipt=json.loads((R/'receipt.json').read_text()); manifest=json.loads((R/'artifact-manifest.json').read_text())
for a in manifest['artifacts']:
 b=Path(a['path']).read_bytes(); assert len(b)==a['size'] and sha(b)==a['sha256']
assert receipt['exit_code']==0 and receipt['state']=='RUNTIME_TERMINAL_SUCCESS_PENDING_RAW_JSON_AUDIT'
assert receipt['pre']==receipt['post'] and receipt['identity_clean_source_and_12_bound_files_unchanged']
assert receipt['predecessors_pre']==receipt['predecessors_post']
raw=(R/'raw.jsonl').read_bytes(); events=[(i,json.loads(line)) for i,line in enumerate(raw.splitlines(),1)]
contract=json.loads((S/'reviewed-request-outcome-contract.json').read_text()); root=contract['root']; cases=contract['cases']; leaves=[c['leaf'] for c in cases]; tests=[root]+[root+'/'+x for x in leaves]
assert leaves==['cidr','nsg','destination_miss','sender_nsg_miss','sender_cidr_miss']
assert {e['Package'] for _,e in events}=={'github.com/TerraScale/ts-orchestrator/internal/terrabase'}
assert {e['Test'] for _,e in events if 'Test' in e}==set(tests)
assert [e['Test'] for _,e in events if e['Action']=='run']==tests
assert not [e for _,e in events if e['Action'] in ['skip','fail','pause','cont']]
assert set(e['Action'] for _,e in events)<= {'start','run','output','pass'}
for t in tests:
 assert len([e for _,e in events if e.get('Test')==t and e['Action']=='run'])==1
 assert len([e for _,e in events if e.get('Test')==t and e['Action']=='pass'])==1
assert len([e for _,e in events if e['Action']=='start' and 'Test' not in e])==1
assert len([e for _,e in events if e['Action']=='pass' and 'Test' not in e])==1
pat=re.compile(r'^\s+oci_live_test.go:\d+: SDK request (?P<ordinal>\d+): (?P<method>\S+) host=(?P<host>\S+) uri=(?P<uri>\S+) uri_sha256=(?P<uri_sha256>[0-9a-f]{64}) request_bytes=(?P<request_bytes>\d+) request_sha256=(?P<request_sha256>[0-9a-f]{64}) status=(?P<status>\d+) response_bytes=(?P<response_bytes>\d+) response_sha256=(?P<response_sha256>[0-9a-f]{64}) content_type=(?P<content_type>\S+) next_page=(?P<next_page>".*?") complete=(?P<complete>true|false)\n$')
source=(W/'internal/terrabase/oci_live_test.go').read_bytes(); assert sha(source)=='da7665e5f1e8ab5a73f7e5735dd29423712bef6ad8e739193ef017240d298c22'
checks=['matching instances','observed members','peer serialization','parsed peers','decoded ingress rules','ordered pair assessments']
for name in checks: assert ('{"'+name+'",').encode() in source
reports=[]; hosts=[]; prior_pass_index=0; service_counts={'Compute':0,'VirtualNetwork':0}
for c in cases:
 t=root+'/'+c['leaf']; selected=[(i,e) for i,e in events if e.get('Test')==t]; outputs=[(i,e['Output']) for i,e in selected if e['Action']=='output']; run_i=next(i for i,e in selected if e['Action']=='run'); pass_i=next(i for i,e in selected if e['Action']=='pass'); assert run_i>prior_pass_index;prior_pass_index=pass_i
 requests=[]
 for i,out in outputs:
  if 'SDK request ' not in out: continue
  m=pat.fullmatch(out); assert m,out; r=m.groupdict(); r['raw_json_line']=i
  for k in ['ordinal','request_bytes','status','response_bytes']:r[k]=int(r[k])
  r['next_page']=json.loads(r['next_page']);r['complete']=r['complete']=='true';requests.append(r)
 assert len(requests)==7 and [r['ordinal'] for r in requests]==list(range(1,8))
 assert len(set(r['host'] for r in requests))==1
 host=requests[0]['host']; split=urllib.parse.urlsplit('http://'+host); assert ipaddress.ip_address(split.hostname).is_loopback and split.port>0;hosts.append(host)
 for r,want in zip(requests,c['requests']):
  uri=urllib.parse.urlsplit(r['uri']); q=urllib.parse.parse_qs(uri.query,keep_blank_values=True)
  assert r['method']==want['method']=='GET' and uri.path==want['path'] and q==want['query']
  assert r['uri_sha256']==sha(r['uri'].encode())
  assert r['request_bytes']==want['request_body_bytes']==0 and r['request_sha256']==sha(b'')
  response=want['response']; body=response['body_utf8'].encode(); assert len(body)==response['body_bytes'] and sha(body)==response['body_sha256']
  assert r['status']==response['status']==200 and r['response_bytes']==len(body) and r['response_sha256']==sha(body)
  assert r['content_type']==response['content_type']=='application/json' and r['next_page']=='' and response['opc_next_page'] is None and r['complete']
  service='Compute' if r['ordinal'] in [1,2,4] else 'VirtualNetwork';r['service']=service;service_counts[service]+=1
  r['query']=q;r['path']=uri.path;r['contract_response_body_sha256']=sha(body);r['contract_match']=True
 summaries=[(i,out) for i,out in outputs if 'TERRABASE_PEERS=' in out and 'ordered_pairs=' in out];assert len(summaries)==1
 summary_i,summary=summaries[0]; expected_pairs=c['assessments_receiver_major']
 pair_string='['+' '.join('{sender:'+p['sender']+' receiver:'+p['receiver']+' allowed:'+str(p['allowed']).lower()+'}' for p in expected_pairs)+']'
 assert summary.rstrip().endswith('TERRABASE_PEERS='+c['peer_string']+'; members=2 ordered_pairs='+pair_string)
 metadata={'matching_instances':[json.loads(c['requests'][0]['response']['body_utf8'])], 'attachments':[json.loads(c['requests'][i]['response']['body_utf8']) for i in [1,3]],'vnics':[json.loads(c['requests'][i]['response']['body_utf8']) for i in [2,4]],'ingress_rules':[json.loads(c['requests'][i]['response']['body_utf8']) for i in [5,6]],'parsed_peers':[{'Name':name,'Address':address+':9443'} for name,address in zip(c['member_names'],c['private_ips'])]}
 reports.append({'leaf':c['leaf'],'result':'PASS','run_json_line':run_i,'pass_json_line':pass_i,'elapsed_seconds':next(e['Elapsed'] for _,e in selected if e['Action']=='pass'),'loopback_host':host,'request_count':7,'requests':requests,'peer_summary_json_line':summary_i,'peer_summary_output':summary,'peer_string':c['peer_string'],'ordered_assessments':expected_pairs,'full_decoded_metadata_checks':{'fields':checks,'status':'All six reflect.DeepEqual checks reached and succeeded, inferred from exact pinned source and leaf PASS without failure output. Raw logs print peer/pair summary and exchanges, not full decoded structs.','expected_fixture_decoded_values':metadata,'sdk_normalization':'Expected omitted licensingConfigs normalized to nonnil empty []core.LicensingConfig, asserted in pinned source.'},'successful_observation_before_denial':True})
assert len(set(hosts))==5
assert service_counts=={'Compute':15,'VirtualNetwork':20}
assert sum(len(c['requests']) for c in reports)==35
assert sum(len(c['ordered_assessments']) for c in reports)==10
assert sum('SDK request ' in e.get('Output','') for _,e in events)==35
assert sum('ordered_pairs=' in e.get('Output','') for _,e in events)==5
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip();assert head==receipt['commit'];assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=W)==b''
report={'state':'FIRST_DEFAULT_NSG_RUNTIME_PASS; HOLD_NO_REPEAT_OR_INTEGRATION','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':receipt['commit'],'tree':receipt['tree'],'parent':receipt['parent'],'runtime_packet':str(R),'runtime_receipt':fi(R/'receipt.json'),'runtime_manifest':fi(R/'artifact-manifest.json'),'raw_json':fi(R/'raw.jsonl'),'source':fi(W/'internal/terrabase/oci_live_test.go'),'reviewed_contract':fi(S/'reviewed-request-outcome-contract.json'),'fixture_source_proof':fi(S/'fixture-response-source-proof.json'),'terminal_exit':receipt['exit_code'],'runtime_wall_seconds':receipt['runtime_wall_seconds'],'root_elapsed_seconds':next(e['Elapsed'] for _,e in events if e['Action']=='pass' and e.get('Test')==root),'package_elapsed_seconds':next(e['Elapsed'] for _,e in events if e['Action']=='pass' and 'Test' not in e),'raw_json_records':len(events),'exact_test_scope':tests,'no_skips_failures_extra_roots_or_cases':True,'leaf_order_serial':leaves,'distinct_loopback_hosts':hosts,'total_successful_GETs':35,'service_counts':service_counts,'total_ordered_assessments':10,'cases':reports,'fresh_factory_listener_envelope':'Five serial t.Run bodies each create fresh factory/server, RSA signer and dedicated transport. Raw log proves five distinct localhost endpoints and nonoverlapping leaves; source cleanup closes each server before leaf terminal PASS. No external OS listener sampler used.','prepost_exact_identity_clean_source_and_12_bindings':True,'previous_setup_and_compile_packets_preserved':True,'only_granted_runtime_invocations':1,'retry_count':0,'not_qualified':['cryptographic signature verification','live OCI or real host acceptance','actual peer TCP/egress/routing/security-list/listener or replication','pagination/source-port/Direction/IsValid/IsStateless fixes','F3 witness','original isolated test removal or central closure','short/tagged/race/full-package executions'],'next':'HOLD for parent QA; no further execution or integration granted.'}
wjson('runtime-audit.json',report)
write('reviewed-contract.json',(S/'reviewed-request-outcome-contract.json').read_bytes())
write('fixture-source-proof.json',(S/'fixture-response-source-proof.json').read_bytes())
handoff='Review the one-run default NSG runtime audit; no repeat or integration grant.\n\n'
handoff+=f"Commit `{report['commit']}`, tree `{report['tree']}`, sole parent `{report['parent']}`. Exactly one granted Go runtime invocation exited 0 in {report['runtime_wall_seconds']} seconds; root 0.9s, package 0.913s. Five leaves passed in serial order with no skip/failure/extra root or leaf.\n\n"
for idx,c in enumerate(reports,1):
 outcomes=', '.join(p['sender']+' -> '+p['receiver']+' '+('ALLOW' if p['allowed'] else 'DENY') for p in c['ordered_assessments'])
 handoff+=f"{idx}. `{c['leaf']}` PASS ({c['elapsed_seconds']}s), endpoint `{c['loopback_host']}`: seven exact successful signed-header-structure GET exchanges; {outcomes}.\n"
handoff+='\nAll 35 logged status/response bytes/hashes/content types/no-page/completion records match the reviewed fixed response bodies; 15 Compute +20 Network. Exact per-case request paths/queries/URI hashes/response bytes and hashes/raw JSON line numbers are in runtime-audit.json. Ten receiver-major pair assessments and canonical peers match. All six full decoded metadata/peers/rules/pair DeepEqual checks succeeded by pinned-source path and leaf PASS; full decoded structs are not printed in raw logs.\n\n'
handoff+='Five distinct localhost endpoints and serial terminal/run events support five fresh factories/listeners and max one active by source cleanup ordering. Source, all 12 bound files, compiler and exact clean identity remain unchanged; prior zero-Go setup failure and compile binary/packets preserved and rehashed. Raw execution packet is sealed separately, with wrapper/argv/environment/lock/limits/prepost/terminal/log provenance. No repeats, other roots, tagged/short/race runs, cloud, NATS, native binaries, source/Git changes, integration or push. No live/F3/real peer TCP/replication/original removal or central closure claim.\n\nNext: parent independently reviews raw log and audit; HOLD.\n'
write('HANDOFF.md',handoff.encode())
wjson('artifact-manifest.json',{'state':report['state'],'artifacts':[fi(p) for p in sorted(D.iterdir()) if p.is_file()]})
print(json.dumps({'state':report['state'],'directory':str(D),'audit':fi(D/'runtime-audit.json'),'handoff':fi(D/'HANDOFF.md'),'manifest':fi(D/'artifact-manifest.json'),'raw':fi(R/'raw.jsonl'),'cases':[{'leaf':c['leaf'],'elapsed_seconds':c['elapsed_seconds'],'requests':len(c['requests']),'allowed_receiver_major':[p['allowed'] for p in c['ordered_assessments']]} for c in reports]},indent=2))
