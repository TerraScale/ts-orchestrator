from pathlib import Path
import os,sys,subprocess,hashlib,json,time,datetime,fcntl,traceback
D=Path(__file__).resolve().parent
W=Path('/tmp/ts-terrabase-nsg-sdk-socket')
GO=Path('/home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go')
HEAD='e502eed69cd2c020448b94c6970d9bacd8942cd8'
TREE='31d1fd6d1811db28dfa86b1207ab492b02aab2c8'
PARENT='7512c426670cef4558c94ee62350fd1f29b850e9'
SOURCE='internal/terrabase/oci_live_test.go'
SH='da7665e5f1e8ab5a73f7e5735dd29423712bef6ad8e739193ef017240d298c22'
GOHASH='30969f97169d7f43fe6a085873d75613adc21e30818a8c61d95bd27275df4624'
LOCK=Path('/tmp/ts-orch-refactor-gate-check.lock')
REVIEW=Path('/tmp/ts-qa-nsg-adoption-review-e502eed6-20261017T003240Z-b45aa092.json')
BINDINGS=json.loads(Path('/tmp/ts-terrabase-nsg-sdk-socket-source-7e297694-aa2f8ca1/source-review.json').read_text())['unchanged_bound_files']
def sha(b): return hashlib.sha256(b).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write_json(name,value):
 with (D/name).open('x') as f: json.dump(value,f,indent=2); f.write('\n')
def git(*args): return subprocess.check_output(['git',*args],cwd=W)
def fileinfo(p):
 data=Path(p).read_bytes(); return {'path':str(p),'sha256':sha(data),'size':len(data)}
def snapshot():
 head=git('rev-parse','HEAD').decode().strip(); tree=git('rev-parse','HEAD^{tree}').decode().strip(); parent=git('show','-s','--format=%P','HEAD').decode().strip(); status=git('status','--porcelain=v1').decode()
 assert (head,tree,parent,status)==(HEAD,TREE,PARENT,'')
 source=(W/SOURCE).read_bytes(); assert sha(source)==SH and source==git('show',HEAD+':'+SOURCE)
 checked=[]
 for b in BINDINGS:
  data=(W/b['path']).read_bytes(); blob=git('rev-parse',HEAD+':'+b['path']).decode().strip()
  assert sha(data)==b['sha256'] and blob==b['git_blob'] and data==git('show',HEAD+':'+b['path'])
  checked.append({'path':b['path'],'sha256':sha(data),'size':len(data),'git_blob':blob})
 assert len(checked)==12
 compiler=fileinfo(GO); assert compiler['sha256']==GOHASH
 return {'head':head,'tree':tree,'sole_parent':parent,'status_porcelain':status,'source':{'path':SOURCE,'sha256':sha(source),'size':len(source)},'bound_repository_files':checked,'compiler':compiler}
ENV={'HOME':os.environ['HOME'],'PATH':str(GO.parent)+os.pathsep+os.environ['PATH'],'GOMAXPROCS':'2','GOFLAGS':'-p=2','LANG':'C.UTF-8'}
assert 'GOROOT' not in ENV
BINARY=D/'terrabase-default.test'
GOARGV=[str(GO),'test','-c','-p','1','-mod=readonly','-o',str(BINARY),'./internal/terrabase']
ARGV=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','180s','/usr/bin/nice','-n','19',*GOARGV]
receipt={'kind':'FIRST_DEFAULT_TERRABASE_COMPILE_ONLY','created_utc':now(),'commit':HEAD,'tree':TREE,'parent':PARENT,'worktree':str(W),'artifact_directory':str(D),'wrapper':fileinfo(__file__),'wrapper_python':str(Path(sys.executable).resolve()),'argv':ARGV,'go_argv':GOARGV,'cwd':str(W),'environment':ENV,'environment_policy':'Minimal explicit environment; GOROOT absent; pinned compiler bin first PATH. No secret environment variables inherited.','lock':{'path':str(LOCK),'mode':'exclusive nonblocking flock','acquired':False},'limits':{'outer_seconds':180,'termination':'TERM, then KILL after 5 seconds','nice':19,'GOMAXPROCS':2,'GOFLAGS':'-p=2','package_compile_parallelism':1},'binary_executed':False,'runtime_server_test_execution':False,'other_go_commands':False,'review':fileinfo(REVIEW)}
started=time.monotonic(); lock=None
try:
 assert receipt['review']['sha256']=='30e06e7590254efea2332c2c68015c099b70c41d4f61285ffddec7ea27f7203b'
 assert not BINARY.exists()
 lock=LOCK.open('a+b'); fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB); receipt['lock']['acquired']=True
 receipt['pre']=snapshot(); write_json('pre-state.json',receipt['pre'])
 receipt['executables']=[fileinfo('/usr/bin/timeout'),fileinfo('/usr/bin/nice'),fileinfo(GO)]
 write_json('invocation.json',{k:receipt[k] for k in ['kind','commit','tree','parent','wrapper','wrapper_python','argv','go_argv','cwd','environment','environment_policy','limits','review','executables']})
 receipt['compile_started_utc']=now(); compile_start=time.monotonic()
 with (D/'compile.log').open('xb') as log:
  result=subprocess.run(ARGV,cwd=W,env=ENV,stdout=log,stderr=subprocess.STDOUT,check=False)
 receipt['compile_wall_seconds']=round(time.monotonic()-compile_start,6); receipt['compile_finished_utc']=now(); receipt['exit_code']=result.returncode
 receipt['post']=snapshot(); write_json('post-state.json',receipt['post']); assert receipt['post']==receipt['pre']
 receipt['identity_clean_source_and_12_bound_files_unchanged']=True
 receipt['log']=fileinfo(D/'compile.log')
 if BINARY.is_file(): receipt['binary']=fileinfo(BINARY)
 receipt['state']='COMPILE_PASS_RUNTIME_UNQUALIFIED' if result.returncode==0 and BINARY.is_file() else 'COMPILE_FAILED_RUNTIME_UNQUALIFIED'
except BlockingIOError:
 receipt['state']='NOT_RUN_LOCK_BUSY'; receipt['exit_code']=None
except BaseException as exc:
 receipt['state']='WRAPPER_OR_IDENTITY_FAILURE'; receipt['error_type']=type(exc).__name__; receipt['error']=str(exc); receipt['traceback']=traceback.format_exc()
finally:
 if lock is not None: lock.close()
 receipt['total_wrapper_wall_seconds']=round(time.monotonic()-started,6); receipt['completed_utc']=now()
 write_json('receipt.json',receipt)
 manifest={'state':receipt['state'],'artifacts':[fileinfo(p) for p in sorted(D.iterdir()) if p.is_file()]}
 write_json('artifact-manifest.json',manifest)
 print(json.dumps({'state':receipt['state'],'directory':str(D),'exit_code':receipt.get('exit_code'),'compile_wall_seconds':receipt.get('compile_wall_seconds'),'binary':receipt.get('binary'),'log':receipt.get('log'),'receipt':fileinfo(D/'receipt.json'),'manifest':fileinfo(D/'artifact-manifest.json')},indent=2),flush=True)
 if receipt['state']!='COMPILE_PASS_RUNTIME_UNQUALIFIED': sys.exit(1)
