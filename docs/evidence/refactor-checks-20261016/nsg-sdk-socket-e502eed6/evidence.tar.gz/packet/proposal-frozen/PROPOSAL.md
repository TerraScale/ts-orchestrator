Review the one-file additive NSG proposal before authorizing implementation or a runner.

# Frozen F2 NSG migration proposal

This is an exact source-only proposal for PLAN.md section 3. No Go patch, runner, localhost listener, cloud request, implementation qualification, deletion, commit or push was performed. Source-bindings.json records full c466da0d commit/tree, every referenced Git blob/SHA256 and cached SDK v65.126.0 file hashes. The relevant terrabase, ociclient and ociresourcetest files are identical at c748d540; source-bindings.json records equality individually, without claiming unrelated files are identical. All new evidence uses exclusive creation. The original reviewed plan is copied and hashed. The main working tree's unrelated changes are excluded.

## 1. Minimum file claim and extraction boundary

Claim only internal/terrabase/oci_live_test.go. Add the untagged root TestPeerPortOpenThroughSDKObservedHosts, its fixed fixtures/audit and minimal private observation structs/helper in this existing test file. Do not add a package, production seam, interface-based fake, production endpoint option, configuration key, dependency, build tag, CI edit or shared transport framework. Reuse ociresourcetest.Server, factory.Compute/Network and ociclient.PinHost unchanged. Keep peerPortOpen and TestPeerPortOpen byte-identical to the preserved source spans. Keep liveEnv unchanged. Deletion review is separate and needs qualified evidence.

The shared test-only observePeerIngress helper accepts context.Context, concrete core.ComputeClient and core.VirtualNetworkClient values, compartment, prefix and port. It performs exactly the existing ListInstances -> per matching instance ListVnicAttachments -> eligible GetVnic -> unique attached-group ListNetworkSecurityGroupSecurityRules traversal. It uses the current request filters/limits, existing matching and primary-VNIC conditions and peerPortOpen implementation. Both the existing live test and the offline root call this helper; the offline root never constructs a rule map and invokes peerPortOpen as its replacement path.

Return a partial observation plus a stage-wrapped error: all encountered prefix-matching instance metadata (including any matching host with no usable primary), observed members containing instance/VNIC IDs, name, fault domain, parsed address and NSGs, the canonical peer string and ParsePeers result, decoded rule map, and receiver-major ordered assessments with sender/receiver identities and allowed bool. Append a matching instance to metadata before its attachment read; return accumulated metadata even on failure. The live owner checks the A1 Shape assertion for each returned matching instance before handling an error. This preserves the assertion on hosts omitted from members; filtering those rows out would weaken the original. Error/report timing can move when consolidating the helper; no success condition is relaxed, and transport failure stays fatal. Do not add a requested/returned identity-validation rule to the live implementation under this migration; the synthetic test asserts expected identity readback separately.

With zero members, the helper returns successfully without ParsePeers, NSG reads or pair assessments. With members, it builds entries in observed order using name=AddrPortFrom(address,uint16(port)), joins with commas and calls unchanged ParsePeers before NSG reads. A ParsePeers failure is an error, never an NSG denial. It reads each attached group once, in member/group encounter order. It returns both ordered peer assessments for distinct names, including allowed pairs, without turning a policy denial into a transport/parse error. Do not introduce pagination loops or broaden the existing observation algorithm here.

## 2. Preserve the live owner and existing checks

| Existing live behavior | Exact retained owner/check |
| --- | --- |
| Credentials, region and fixture gate | Existing tier.Qualification, profile/operator factory and environment parsing remain in TestLiveOCITerraBaseHostsReadOnly. No offline tier gate or live fixture guesses. |
| Regional A1/profile | ListShapes compartment/limit100; require VM.Standard.A1.Flex, Ampere processor, minimum OCPU <=1 and maximum GB/OCPU >=6. These assertions stay in live owner. |
| Quota and image | Existing tenancy ListAvailabilityDomains and per-domain standard-a1-core-count GetResourceAvailability sum >=1; Canonical Ubuntu/A1 ListImages limit20 nonempty. Same clients/configuration and live ownership. |
| Returned host shape, empty cell, fault domains | Assert A1 for every matching encountered instance even without a usable primary. Preserve regional-only zero-member log/return; keep duplicate fault-domain t.Errorf when members<=3, with the same condition and no new live host-count requirement. |
| Peer serialization and ingress | Retain unchanged ParsePeers validation, name/address uniqueness and EnvPeers logging. Apply each returned denied ordered pair as the existing live t.Errorf with sender/receiver/port. Keep both directions; helper calls the unchanged peerPortOpen. |

The live caller must apply returned host-shape/fault-domain assertions before fatal handling of a later-stage error when their observations exist. Preserve ParsePeers validation as a fatal result rather than substituting an unvalidated peer string. Exact diagnostic order is not replacement coverage. F3's required target witnesses and live-count requirements are deliberately outside this proposal.

## 3. Five serial leaves through genuine SDK/socket observation

request-outcome-contract.json supplies fixed proposed response bytes, body lengths/SHA256, exact request path/query maps, identities, peers and ordered outcomes. These values are synthetic offline fixture values, not owner-supplied OCI targets. The two peers are offline-db-a (10.251.0.11, FAULT-DOMAIN-1) and offline-db-b (10.251.0.22 normally, FAULT-DOMAIN-2). Each has a different instance ID, one ATTACHED VNIC, isPrimary=true and one attached NSG. Every instance is RUNNING/A1. Port=9443, prefix=offline-db-. Only sender_cidr_miss changes B to 10.9.0.1. Every reverse A->B rule allows A's exact /32 on 9443.

| Leaf | Receiver A rule / sender B observation | B->A | A->B |
| --- | --- | --- | --- |
| cidr | CIDR_BLOCK 10.251.0.0/24, TCP destination9443; B inside CIDR | allow | allow |
| nsg | NETWORK_SECURITY_GROUP members, destination9000..9500; B attached members | allow | allow |
| destination_miss | Same CIDR, destination9465 only; B unchanged | deny | allow |
| sender_nsg_miss | Same members NSG rule/range as nsg; B attached foreign instead of members; list foreign as second attached group | deny | allow |
| sender_cidr_miss | Same CIDR/range as cidr; B observed address10.9.0.1 | deny | allow |

All leaves have fresh server/factory/clients, independent immutable response material and fresh audit state. Run sequentially with no t.Parallel; leaf cleanup closes its server before the next leaf. Assert exactly two observed members, distinct nonempty instance/VNIC/name/address identities, exact attached NSGs, exact fault domains, all matching instance A1 metadata, exact serialized peer string, ParsePeers's two decoded entries and exact two receiver-major assessments including identity and bool. Assert all decoded rule fields: direction INGRESS, source/sourceType, protocol6, destination min/max, isValid=true and isStateless=false. This demonstrates decode fidelity; it does not imply peerPortOpen consults every field.

Keep the live fault-domain duplicate condition. Existing ParsePeers rejection tests in terrabase_test.go remain intact; this new root does not claim new duplicate-name/address or same-fault-domain negative coverage. No extra roots or fixture mutations are needed to preserve those existing checks.

## 4. Socket/client and exact request contract

Each leaf calls existing ociresourcetest.Server, which creates a genuine httptest.NewServer TCP listener, generates one RSA2048 key and builds the actual shared factory from common.NewRawConfigurationProvider. Build actual Compute and VirtualNetwork clients with the factory, PinHost both BaseClients to the returned local endpoint, and install a dedicated http.Client/Transport for this leaf. Use no proxy, reject redirects, and admit a dial only to the exact returned localhost address; do not change global HTTP clients/transports/environment. Use fixed test bounds (proposed per-leaf context15s and http.Client timeout5s, to be reviewed with the patch); cleanup cancel and CloseIdleConnections. A local exact-address DialContext guard is sufficient; no external forwarding or simulator rewrite is needed.

Install the leaf HTTP client after factory construction, then reapply existing ociclient.ConfigureReadCancellation on each BaseClient because replacement would otherwise discard its readDispatcher. Do not call factory.Configure twice (which would stack limiters). The shared helper keeps its incoming context unchanged, preserving existing live cancellation semantics; this slice does not claim to add ReadContext or validate the production SDK retry-race fix.

The SDK has BasePath20160918 on both clients. Each leaf issues exactly:

| # | Operation | Exact query keys |
| --- | --- | --- |
| 1 | GET /20160918/instances | compartmentId=C, lifecycleState=RUNNING, limit=100 |
| 2 | GET /20160918/vnicAttachments | compartmentId=C, instanceId=A |
| 3 | GET /20160918/vnics/VA | none |
| 4 | GET /20160918/vnicAttachments | compartmentId=C, instanceId=B |
| 5 | GET /20160918/vnics/VB | none |
| 6 | GET /20160918/networkSecurityGroups/GA/securityRules | direction=INGRESS, limit=100 |
| 7 | GET /20160918/networkSecurityGroups/GB/securityRules | direction=INGRESS, limit=100; use GX in sender_nsg_miss |

Require exact method/path, URL/Host equal to the local endpoint, complete query multimap equality, empty body, no Page or extra filters, Authorization presence and SDK Signature structure. Compare parsed query maps so URI encoding order does not become a false contract; retain the actual raw RequestURI and SHA256 in the audit. No GetInstance, GetSubnet, ListNSGs, regional/profile/quota/image request or credential discovery request belongs to this offline root.

Handler state is protected by a mutex and checks the next exact ordinal. Reject unknown/extra/out-of-order/malformed calls with HTTP400 and a recorded audit failure (not retryable); do not Fatal from the handler goroutine. Record ordinal/method/host/raw URI hash, request-body length/hash, expected route match, status, JSON content type, response-body length/hash, actual Write length/error and completion. Hash the exact fixed response bytes and the successfully written bytes; require a complete write, HTTP200, no OpcNextPage, no audit overflow, exactly seven successful records and zero unexpected calls/retries. The client must successfully decode the expected full observation. Transport, signer, route, non200, JSON or audit failure fails every leaf, including expected-denial leaves. A false bool alone never passes a negative leaf.

Existing Server rejects an empty Authorization header but does not cryptographically verify signatures. This proves real SDK signing construction/header presence and socket decode, not a signature-verifying simulator, instance-principal federation, production TLS/DNS or live OCI authentication. Do not log the private key or full Authorization values.

## 5. Selectors, reachability, resources and limits

The additive root is untagged in ./internal/terrabase, with exact selector ^TestPeerPortOpenThroughSDKObservedHosts$ and five leaves: cidr, nsg, destination_miss, sender_nsg_miss, sender_cidr_miss. It has no testing.Short, tier.Qualification, skip or environment dependency. Default, -short and fixturetest package selection compile/run the same root. Existing ^TestPeerPortOpen$ remains independently selectable; the live selector keeps its current fixture gate and is not selected by the new exact selector.

Makefile test reaches default ./...; test-fast reaches -short ./...; race-test's ordinary package scheduling reaches untagged tests. fixturetest-check vets ./... but runs tests only in tests/firecracker/production/fixturegen, so that target does NOT execute this NSG root. qualify-image.sh's terrabase-binary suite selects only TestTerraBaseBinaryPeerMesh and does NOT reach either NSG root or live owner. No routing/CI change is proposed. These are static reachability statements, not executed receipts.

The future qualified command needs a separate parent/broker grant on the exact patch. It should select the additive root and verify one root/five leaves, no skips/extras and the full request/body/identity assertions; run the old isolated root separately or with an exact anchored union when granted. No command was executed or runner file created for this proposal.

| Resource | Source-derived proposal |
| --- | --- |
| HTTP/crypto | Five serial server starts/factories, at most one active listener; five RSA2048 generations; 35 GET attempts=15 Compute+20 Network; ten ordered assessments. |
| Rate limits and pagination | Each fresh factory uses 3 Compute/4 Network requests, below each service burst16; no expected limiter sleeps. These counts require exactly two single-page instances/one eligible VNIC each/two unique NSGs and success without retries. |
| Processes and cloud | One future Go test process plus compilation lane. No child go run, TerraBase binary, NATS startup, VM, KVM, container, cloud resource or external request. Importing ociresourcetest does not call Store or start its NATS helper. |
| Bounds | Proposed fixed15s leaf context/5s request timeout, one compiler lane, pinned Go1.27.1 and GOMAXPROCS2 if granted; all local builds/tests/lints must use nice -n19. Parent/broker owns actual outer/test timeout and memory/disk/FD reserve; none was measured here. |
| Effort | Estimated45-75min implementation/review; warm test runtime estimated5-20s, cold build/cache cost unmeasured. Estimates are not receipts or allocated resources. |

The general request count for this unchanged one-page traversal is one ListInstances + one ListVnicAttachments per matched instance + one GetVnic per eligible attachment + one rules list per unique observed attached group. SDK list methods perform one request/page and do not auto-follow OpcNextPage; ListInstances, ListVnicAttachments and ListNetworkSecurityGroupSecurityRules have no caller pagination loop. Preserve/report those gaps, not synthetic full-inventory claims.

peerPortOpen ignores SourcePortRange, Direction, IsValid and IsStateless; direction relies on the INGRESS query. Protocol all bypasses TCP destination checks. This migration neither fixes nor conceals those limitations. Static ingress allowance proves no actual peer TCP connection, egress, route, security list, service listener, TerraBase runtime or replication. No F3 live witness or full replacement/removal qualification is supplied.
