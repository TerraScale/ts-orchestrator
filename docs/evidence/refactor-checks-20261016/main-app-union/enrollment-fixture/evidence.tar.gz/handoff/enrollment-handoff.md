# APP lower enrollment source handoff

Frozen clean commit: d34fcb90abf55949e0d6870e82d065fc220f4c95
Worktree: /tmp/ts-refactor-app-integration; branch refactor/qa-app.
Complete diff: /tmp/ts-app-d34fcb90-enrollment.diff (against passing 582a39920cf2e486306579c9a66ceefb17cb013d).
Footprint: 2 fixturetest-tagged files, 561 insertions; new selected APP test549 lines plus12-line bootstrap fixture retention/method. No production source changes. No main checkout, AGENTS.md or REFACTOR.md edits; no push.

## Source result; uncompiled and unexecuted

New selector: ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$

- Reuses newAuthenticatedNATS, testHostEnrollmentTLSMaterial, jetStreamObserverDialer, existing signed bootstrap factory and existing managerStartupFoundation/FoundationResolver/Vault/executor helpers without changing any existing helper behavior. Prior startup test/helper file is byte-identical to582a3992.
- Test creates a signed canonical request with actual Agent Ed25519/NATS keys and an empty-scope P256 CSR. Public GrantStore.Claim -> actual ordered Controller.Register receipt -> scoped Issuer.Issue -> signed/verified Response -> GrantStore.Finish CAS. Leader readback must have later revision and exact request/response bytes plus completed association. No manually completed grant or preinserted response.
- Root-signed cellspec controller-c grant is verified through existing private readControllerHostRecipient, using the fixture's original concrete SDK observer, signed/CAS ledger and baked trust store. Current ordered registration is read independently, completed Pending=false is mandatory, controllerHostRegistration and proof.VerifyRegistration run, then current registration is re-read and compared.
- A separately signed response with a changed expiry must fail that same completed-grant/current-source composition. This does not rely on JSON whitespace differences (completed matcher intentionally canonicalizes fields).
- Actual Agent connects directly using Issuer.Issue's scoped JWT and issued client certificate, its request CSR private key and actual NATS user nonce signer. auth.config is deliberately not called for this connection, because it would replace the issued token. Agent.VerifyOwnRegistration checks the independently read actual registration both through current controller state and recipient composition. One session is canceled and joined.
- Actual grant Disable CAS must make the same recipient read refuse. This is a current-source revocation assertion, not an automatic live-session-disconnect claim. Manager is paused before enrollment and after session exit; material and registry providers are repeatedly checked closed. No source.bind or production observer/factory injection.
- Temporary fixture broker trust includes its original server CA and the reused enrollment helper's client CA. Agent verifies broker with the exact original PublicBundle CA. Separate fixture server/client roots are an explicit lower-boundary limit; no production regional-CA installation claim.

## Checks performed

Cached Modern Go CLI list --go-version1.27 read fully; gofmt and git diff --check/staged whitespace checks PASS. Source preservation diff against582a3992 PASS for the entire prior startup/helper file. No compile, test binary, runtime, cloud/host network/mount/credential operation executed. No APP runner or lease active. No new agents.

## Proposed bounded resources; QA grant required before execution

Compile: whole internal/app with fixturetest, Go1.27.1, unsetGOROOT, GOMAXPROCS2, GOFLAGS=-p=2, nice19, modreadonly/internal-only-e; nonblocking /tmp/ts-orch-refactor-gate-check.lock; outer180s. Separate runtime grant only after compile PASS and binary hash, exact one selector above; retain prior582 startup PASS without repeating it.

Runtime source footprint: parent test process and one same-binary child through sudo-n unshare --net --fork --kill-child=SIGKILL; fresh child namespace raises only lo and adds10.44.0.10/32 (same existing startup pattern). No mount namespace or host-network modification. Fixed Swarm listener10.44.0.10:2377 stays inside child network namespace. Two existing HTTP SDK fixture servers use ephemeral127.0.0.1 ports (combined ObjectStorage/Compute/VNIC and Vault). One embedded NATS broker plus TLS bridge uses temporary file-backed JetStream and ephemeral loopback listener. One host Controller and one actual Agent; no other nodes or task execution. Temporary manager/Raft/control.sock, broker/claims/TLS files, fixture baked trust/markers/ledger store, install/state dirs only. Cleanup joins Agent and Controller, stops real manager, closes broker and HTTP servers, and removes testing temp dirs. Test ctx90s; child timeout110s; proposed outer runtime180s; GOMAXPROCS2/nice19 inherited. NATS quotas are logical maxima (256MiB memory/8GiB disk account,64MiB enrollment bucket), not preallocation; no native containerd needed.

## Full RunManagedRuntime blockers retained

1. Fixed markers/config/baked roots/floors, RestoreMaterial tmpfs/Vault restoration and same-binary native bootstrap-admit-restart binary/material/live-credential admission remain outside. The existing factory's explicit non-native Gate checkers remain.
2. Production runManagedRuntimeHostSession -> setupRuntimeWorker/runHostSetup requires real IMDS, fixed /etc public/config/transport and memory/Vault identity installation; serviceUID source child reloads installed config/currentControllerHostReader. Not invoked here; no HTTP-handler boundary claim.
3. ReadControllerHostBinding requires fixed accepted launch files, actual serviceUID runtime-controller-host-admission-source child and RuntimeInstanceObserver/newOCIAdmissionProvider. No approved production SDK injection exists. Fixture private-source recipient verifier is a lower boundary only.
4. Production StartAcceptedNode requires NewRuntimeHomeIAMAuthority/VerifyRuntimeIAM/GuardedFactory/full BootstrapMaterial and real home namespace/bucket/KMS. Minimal fixture foundation does not supply that boundary.
5. Native NewExecutor requires /run/containerd/containerd.sock plus fixed manager state, production management socket/serviceUID/cgroup checks. No native/live/CLI/image/systemd acceptance claim.

Fail-closed authority, all-static/pool worker refusal, DATA holds and full current registry reauthorization unchanged. Existing earlier focused, CAP25 and startup receipts retained without repeat.


## Exactd34fcb90 compile-only PASS

QA GATE compile-only grant exercised on clean frozen d34fcb90abf55949e0d6870e82d065fc220f4c95 after exact-source QA/Security review clear. Session40390 terminal exit0; nonblocking GATE released. No tests or other runner executed. Log /tmp/ts-app-coherent-d34fcb90-fixture.log is0bytes. Binary /tmp/ts-app-coherent-d34fcb90-fixture.test SHA256541da78dda6d0011e5c6c77d65a23ac5e65663ab5193242d35b64c573c61f310. Source remains clean/frozen and prior582 startup/helper bytes unchanged; earlier582 PASS retained without repetition.

Exact argv (cwd /tmp/ts-refactor-app-integration): timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go test -mod=readonly -tags=fixturetest -c '-gcflags=github.com/TerraScale/ts-orchestrator/internal/...=-e' -o /tmp/ts-app-coherent-d34fcb90-fixture.test ./internal/app > /tmp/ts-app-coherent-d34fcb90-fixture.log 2>&1.

Runtime remains unapproved and unexecuted; only new selector ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$ would run under a distinct same-binary grant. Full RunManagedRuntime blockers and two-fixture-CA limit remain.


## Exactd34fcb90 one-selector runtime FAIL; no retry or source edit

QA's distinct SAME-BINARY runtime grant executed ONLY ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$. Session57352 terminal exit1; no skips; child1.57s/outer1.68s. Raw log /tmp/ts-app-coherent-d34fcb90-enrollment.log (line79 failure,101/103 FAIL). GATE released. Binary SHA256541da78dda6d0011e5c6c77d65a23ac5e65663ab5193242d35b64c573c61f310 verified before and after, unchanged. Source clean/frozen d34fcb90abf55949e0d6870e82d065fc220f4c95 before and after. No rebuild, retry, source mutation, prior582 test repeat or other runner.

Exact argv (cwd /tmp/ts-refactor-app-integration/internal/app): timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /tmp/ts-app-coherent-d34fcb90-fixture.test -test.v '-test.run=^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$' -test.timeout=120s > /tmp/ts-app-coherent-d34fcb90-enrollment.log 2>&1.

Failure at controller_enrollment_integration_test.go260: descriptor.CanonicalBytes rejects ts-gru-c: managed host boot descriptor is invalid: static host must name one database, controller, node or pool server of its cell and nothing else. Genuine manager and NATS started, then cleanly shut down. Failure precedes enrollment Claim/Register/Issue/Sign/Finish/recipient/Agent; no lower enrollment milestone credited. Prior582 startup PASS remains retained.

Read-only diagnosis: hostboot.Descriptor.validateFields also calls naming.Validate; ts-gru-c has a letter suffix and is not a genuine regional controller node. Production hostenroll.ReadControllerHostMetadata uses naming.RegionCell(region).ControllerSlot(bootstrap.Slot). For GRU/controller-c this returns gru-1-ctl-3, confirmed naming/naming_test.go19 and the bootstrap fixture's existing accepted store ServerName at controller_manager_startup_fixture.go355/362. The private recipient donor used arbitrary grant names without creating a host descriptor, which this composition now does.

Proposed minimum source-only correction FOR REVIEW, NOT APPLIED: change the new test's HostGrant.Node at line226 from "ts-gru-c" to "gru-1-ctl-3". Descriptor, signed spec, ordered registration, response/issued identities and Agent all already derive from that grant. Single fixturetest line, no validator/authority/helper changes, old582 file unchanged, all security/later assertions retained. Could instead derive through canonical naming API but that requires an import plus error handling; literal matches the existing fixture store exactly. Await QA review/explicit source-mutation grant before editing. Full production exclusions and twoCA limit unchanged.


## Frozen92eacab2 source-only canonical controller name correction

QA-approved one-line fixturetest correction committed as92eacab2: only HostGrant.Node ts-gru-c -> gru-1-ctl-3 at internal/app/controller_enrollment_integration_test.go226. Exact correction diff /tmp/ts-app-92eacab2-enrollment-name.diff against d34fcb90. All descriptor/spec/registration/response/issued identity/Agent fields already derive from grant.Node. No production validator, authority, helper or assertion changes. Entire prior582 startup/helper file remains byte-identical; original57352 failure preserved without retry.

ModernGo1.27 cached list fully read; gofmt, whitespace and preservation checks PASS. Worktree clean and source frozen. No compile/runtime executed for this correction; no runner/lease active. Prior d34 compile and runtime fail remain historical receipts; no corrected-source runtime inference. Same resource footprint and full production blockers as d34 handoff. Await separate compile-only grant, then separate same-binary runtime grant if compile passes.


## Exact92eacab2 fixturetest compile-only PASS

QA-approved wholeAPP fixturetest compile PASS session96600 terminal exit0; nonblocking GATE released. Clean frozen source92eacab24e601386cf909a1bf7e1929d3913c7d5 unchanged, prior582 entire startup/helper file unchanged. Log /tmp/ts-app-coherent-92eacab2-fixture.log empty0B. Binary /tmp/ts-app-coherent-92eacab2-fixture.test SHA256e1428e931502d29ba9b4d042ba700b832e959cc7c2e98e770580da9d542d8be8. No tests or other runner executed; original57352 failure preserved. Runtime unapproved/unexecuted for corrected source.

Exact argv (cwd /tmp/ts-refactor-app-integration): timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go test -mod=readonly -tags=fixturetest -c '-gcflags=github.com/TerraScale/ts-orchestrator/internal/...=-e' -o /tmp/ts-app-coherent-92eacab2-fixture.test ./internal/app > /tmp/ts-app-coherent-92eacab2-fixture.log 2>&1.

Next is a distinct runtime grant ONLY ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$ with this exact binary. Prior582 PASS retained without repeat; full production exclusions and twoCA limit unchanged.


## Exact92eacab2 lower enrollment composition runtime PASS

QA-authorized SAME-BINARY ONLY ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$ PASS session12983 terminal exit0/no skips; child2.27s/outer2.38s. Nonblocking GATE released. Raw log /tmp/ts-app-coherent-92eacab2-enrollment.log (line78 public producers/ordered+SDK recipient positive;80 issuedcredential Agent+disable+closed providers;102/105 PASS). Binary /tmp/ts-app-coherent-92eacab2-fixture.test SHA256e1428e931502d29ba9b4d042ba700b832e959cc7c2e98e770580da9d542d8be8 verified unchanged before/after; clean frozen source92eacab24e601386cf909a1bf7e1929d3913c7d5 verified before/after. No rebuild/retry/other selector or prior582 repeat. Failure57352 retained. No runner/lease active.

Exact argv (cwd /tmp/ts-refactor-app-integration/internal/app): timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /tmp/ts-app-coherent-92eacab2-fixture.test -test.v '-test.run=^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$' -test.timeout=120s > /tmp/ts-app-coherent-92eacab2-enrollment.log 2>&1.

Qualified LOWER scope: genuine signed controller-c seed/Gate authority and signed foundation+SDK Vault support actual paused manager. Public signed Request/Claim/ordered Register/Issuer.Issue/Response Sign+Verify/Finish CAS complete the exact instance grant; current ordered registration and actual receipt association read independently; current adopted roots/signed spec/slot ledger and SDK OCI facts pass private recipient verification. Signed changed-expiry response refused by completed matcher. One actual Agent using those issued scoped JWT/clientcertificate/request privatekeys establishes session and verifies independently read current registration. Disable CAS makes same current-source composition refuse; session cancellation joins once while manager remains live/paused and deferred material/registry providers stay closed. No source.bind.

Still NOT qualified: full RunManagedRuntime/production management wrapper, HTTP enrollment handler, fixed serviceUID source child/currentControllerHostReader/installed IMDS+credentials, production ReadControllerHostBinding/observer path, HomeIAM, positive material/registry binding, native/containerd/cgroups, installed CLI/image/systemd/live OCI acceptance. Fixture server/client CAs remain separate, explicitly lower scope. Full registry reauthorization/all-static worker/pool/DATA holds unchanged. Earlier582 startup PASS and prior focused/CAP25 passes retained separately without repeat.
