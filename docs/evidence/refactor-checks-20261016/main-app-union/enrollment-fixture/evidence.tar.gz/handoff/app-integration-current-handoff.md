# APP integration current checkpoint

Worktree /tmp/ts-refactor-app-integration, branch refactor/qa-app.
Current frozen clean HEAD ddc22a6e1030804353de618cfa080aec24af6175; original0846/f16/614f/3d evidence below is retained and superseded where explicitly stated. Exactddc whole APP compile PASS and membership-only same-binary runtime PASS0.18s/no skips; e604 source SEC clear plus actual positive leader/zeroDIRECT assertion closes the membership freshness bug. No APP runner or GATE lease active. Six earlier focused leaves retained without repeat. Connected manager startup remains unqualified; test-only first milestone may resume after QA acknowledgment.

## Actual check

APP whole test-package compile PASS (no tests executed):
GOMAXPROCS=2 GOFLAGS=-p=2 nice19, internal-only -e, QA GATE lease, outer180.
Binary /tmp/ts-app-coherent-0846e186.test SHA256 db495d3f7aaac1a8abdfc96f2a2e123c00423f2dcba198522a099e7291b24ea6.
Empty /tmp/ts-app-coherent-0846e186.log. Session96745 exit0, gate released.
Prior failed candidates/logs retained: 4e8a8b53 (release import),49dbe063 (duplicate actor),121641cf (missing worker recipe source),e92eb42b (unused registry import),e00c64e6 (11 actual APP production/test errors). All fixed in current candidate.
Focused exact0846 runtime binary evidence:
- /tmp/ts-app-coherent-0846e186-focused.log: PASS ordered membership/revocation, ordered registration/revocation, exact live preparation (10 cases), pool lineage Pending, pinned TLS/redirect. No skips.
- Host recovery first failed before startup because cwd was repo root.
- QA-authorized same-binary rerun from internal/app /tmp/ts-app-coherent-0846e186-host-focused.log FAIL5.93s. Three actual controllers/NATS peers started and elected metadata/stream leader; child TestControllerThreeProcessBootstrapAndRestart fails controller_cluster_test.go93: open KV snapshot storage: OCI region "" is not in region catalog. Host recovery did not execute. Gate released; no source edits.
No full startup, CLI, image/systemd or ARM claim.

## New source since old d95e

- Actual pool enrollment observePoolNode always canonical OCI ErrPoolCreationLineagePending. Canonical pool prefix gate runs before static listed/granted branches; actual signing child rejects ALL static workers (legacy names have no retained independent provenance). NODE d775+03+783+3bbb imported: root all-static denial, revoked flags, exact managed bindings prerequisite, private Prepare-only pending phase. This is fail-closed containment; no positive pool proof.
- Current ordered grant source restores disabled/terminal/reset flags, exact completed matcher or live exact pending owner+lease. Snapshot.Pending populated. External refresh completed-only and uses leader-backed ReadCurrentGrant, actual JS retained in enrollment handler. Private phase propagated through currentWorkerVaultGrant/authorizeWorkerVaultRead (OCI64db+NODEe68). Initial pre-Finish deadlock fixed without allowing pending Admit/audit.
- OCI original receipts bbda875e+4b90b939+c254f9d6; region13ed3497 and full worker originals b8f1ed1c,75bfe933,88307614,04619fe9,02b16042,5c8a4875. Pool point ee37 still missing; no positive child proof exists.
- REL fbb465ed+eb5aac40+83815017 allocation winner, canonical3369fb5c currentContainerAllocations+5e447d60 fixture; mandatory allocation forwarded material a415, registry fec417/4064, WASM078/5ce/493/3dd, DATAe7cf+fixture6280, COREd37 initializer. Actual worker InitializeStateful closure uses local.factory canonical helper.
- Credential expiry 1eccee20+79f4e320+31351ad3 +actual same-Agent adapter14208294.
- CORE function retained bundle243e230c+3bf20a77+a010f88e; dedicated function registry28c2916b. Registry libraries already stronger in APP; attempted old originals skipped, not overwritten.
- Durable completion delta from CORE3b314ffe preserves newer APP function enumeration; exact memberstatus completion+hooks now present.
- Actual controller capacity d2da9dc1+54890616 starts reservations from concrete foundation resolver, bound GRU startup public key, allocator mandatory arg; retains real journal and root management client; canRetire checks retained runtime effects by exact registrationID/instance. Function demand still uncomposed until startup helper.
- Plural OCI registry2a31bda8+4064 consumer; e00 cleanup unused strings shared OCI.
- OCI/MESH source actor/link closure preserving stronger existing sources; duplicate DTO corrected121641cf. Current image source exact74c3bc48 releasechannel file. MESH8b904 seed shadow fix included; later MESH5be47742/9a3756e9 not yet imported.
- Actual app compile fixes: registry confirmedRoots rename, missing OBS swarmruntime import, CAP475b44e0 actual ControlAPI scaler status fixture.

## Next bounded checks requested

Exact0846 binary tests: TestWorkerSourceReadsCurrentRegistrationAndRevocationOverNATS, TestWorkerPreparationRequiresExactLiveClaim, TestWorkerPoolAdmissionRemainsPendingWithoutCreationLineage, TestRuntimeWorkerPrivateTransportPinsCAAndRefusesRedirect, TestScaleStatusIsTheLeadersOwn. QA owns lease. Host session regression separate package and needs new authorized build/run; old first failure corrected388ec5b8, not rerun here yet.

## Ready next source epoch (do not claim integrated)

1. Actual independent managed verifier in signing child: OCI readonly observer2c4abad7 PASS9.859s, SEC reviewed. APIs OpenJournalReader(ctx,js,replicas), NewFleetObserver(config,intent,factory,reader,imageVerifier), preserve all real journal/profile/attachment checks; no fencer/mutations. APP needs read-only existing placement member reader, then newManagedRegistrationVerifier using current signed services/image allowlist. Never reopen pool/static Pending using journal consistency alone.
2. WASM new function_startup helper05e42ddf ->recipient8c493857 ->mandatory sealed startup3184f213 (reviewed). Signature startAutomaticFunctions(ctx,cfg,runtime,control,client,roots,factory,artifacts,accounts,hosts,membership)(functionController,stop,error). Actual caller/providers/demand still APP. accounts=gate.store, roots=services.roots, actualfactory, hosts=hostController.ListHosts, membership=ReadWorkerMembership accepted root bridge. OBS callback8a2daa26 adds observation functions field only. WASM fixture a5998dab also needed. CORE rollback pull e567d2a6 pending qualification; does not authorize stale material.
3. NODE root manager ownhost contract being implemented. RootREADY MUST precede Agent: manager unit Before+RequiredBy controller, whose embedded NATS Agent needs. Prebind deferred closed providers before StartAcceptedNode using forthcoming ReadAcceptedManagerAdmission; start node+management+rootREADY, then async ONE Agent/session after controller exists. Never separate native service or drain manager on session failure. ReadControllerHostBinding(ctx,reader,accepted,request,response) opaque, preserves signed slot distinct actual Agent host ULID; VerifyRegistration refreshes actual root/current completed grant/selfSDK. APP owns dedicated fixed runtime-controller-host-admission-source (same existing query/snapshot, no querymode switch), actual controller base enrollment (no fake Swarm projection), and retain real signed base request/response after hostsetup. NODE API committed03a45bcc (not yet imported).
4. NET full canonical chain /tmp/ts-net-refactor-handoff.md not imported. RunNetBirdFoundation external CLI dispatch source absent. Actual internal/app compilation does not check external main. Readonly readers ca63 +actual dedicated CLI9904 plus full deps required. No cloud changes.
5. Actual OCIR issuer always-on startup registry_issuer.go not implemented; plural authority API available. Protected Foundation/HomeIAM writer cloud permission remains ROOT+SEC external unresolved gap.

Producer owner authorized isolated OWN-leaf transplant from exact0846 (not active APP worktree), own QA lease. Ledger /tmp/ts-foundation-producer-own-leaves.md; NAT worker source dependencies remain owner leaves, never old APP snapshots.
No push/cloud changes; parent QA owns publication.

## Latest ready source updates

NODE03a45bcc ready actual API includes agent argument in ReadControllerHostBinding; independent completed binding only, pending initial controller preparation APP-owned. CORE rollback source e567d2a6 ->486da504 PASS12.917s actual registry pull only; old material remains denied. CAP00f22130 ->c9c62083 SEC reviewed, tests pending; preserve narrow capacity_selection.admit minimum authenticated expiry. MESH5be47742/9a3756e9 runtime source unimported, fixture qualification pending.

## Source epoch after0846 (2026-10-16 19:15)

Current frozen clean f16fdbb396d7df3cbbc53a299ab4e04da2a69bf5; QA-authorized whole internal/app compile running session61303. Candidate binary /tmp/ts-app-coherent-f16fdbb3.test, log /tmp/ts-app-coherent-f16fdbb3.log. No edits/imports while running.

Previous exactd12f4325 compile failed SINGLE helper MaxSecretBytes int64->int mismatch; /tmp/ts-app-coherent-d12f4325.log, GATE released. Fixed0da052d6.

Integrated source:
- OCI2c4->3591 readonly observer. APP6aa3b30e actual managed signing-child construction + readonly placement member pin reader. SEC findings corrected APP7a8aaacc: resolve actual image verifier factory; legacy explicit leader GetLastMsg (not modern GetLastMsgForSubject which uses followerDIRECT on KV AllowDirect); current exact placement+canonical versioned seat reread after slow OCI; final full source snapshot/grant flags after all OCI waits. SEC source-reviewed clear, no runtime claim.
- Critical prior374 ordered grant closure reopened: modern Stream API defaults DIRECT on KV. SEC343a3bd8->831d76ba replaces ReadCurrentGrant + membership source with concrete legacy GetLastMsg preserving Domain/APIPrefix. No generic helper. Existing app source tests extended1e06c504->f16fdbb3 to spy actual leader API and reject grant DIRECT reads only around authorization (fixture mutation reads intentionally excluded). Placement test checks exact3 leader reads/zeroDIRECT, persisted advanced attempt/tombstone/no bucket mutation.
- WASM05e->284438c0;8c->1621;318->3fa; originala599->9c7;4e040->81d; OBS8a2->546;8e3->a458. Actual APP function caller4f44746e uses real manager/factory/roots/artifacts/gate.store/hostController.ListHosts/root ReadWorkerMembership; providers atomically closed until installed, scaler functionDemandSource, OBS real callback. WASM source-reviewed correctness;0da adds RWMutex handler draining before signer wipe, reviewed clear.
- CORE rollback e567->4f0;486->244; current-task-material e9fd->6ff; WASM1f274->d96,bba->3bd,d2c->d12. CORE actual material fixture3996c37a PASS45.165s separate owner, NOT IMPORTED yet.
- NODE03a45bcc->09236a5d production + actual Agent test. Kept existing APP deletion of obsolete bootstrapstart/runtimefixture/runtime_integration_test.go (prior revert34eea21c); omitted only9-line fixture delta, owner/CORE notified. Manager ONE-session composition not yet done.

Next actual manager closure:
- NODE now implementing bootstrapstart.ReadControllerHostRecipient opaque proof using exact current root-signed HostGrant.Controller, protected signed plan/result/candidate/receipt, fresh full OCI comparator; handles requested peers (not issuer own instance). API final pending.
- NODE also fixing genuine automatic-derived nonseed ReadRuntimeAuthority: currently selected.PlanWire empty from readDerivedCompletedPeer but caller unconditionally decodes offline envelope. Must not fabricate envelope.
- CORE executor owns containermaterial.VerifyTask manager proof adaptation; worker ManagedOCI remains exact, true manager nilManagedOCI + opaque peer proof. APP must supply cloned task binding HostID=signed slot while actual Agent/transport uses registration ULID; proof final rechecks current registration/source. Original signed spec bytes must be exact current before/after slow calls.
- APP owns base controller preparation (exact live pending owner/lease before Finish, independent opaque proof, no fake Swarm), dedicated runtime-controller-host-admission-source completed-only, save genuine base response transport, root prebind closed material/registry BEFORE StartAcceptedNode, start node+management+rootREADY BEFORE async ownhost Agent (controller owns NATS), exactly ONE active Agent.RunSession and no native host service. Keep node running/tasks retained on ownhost loss; pause new placement through exact current NodeSpec Pause/Active, never drain.
- Additional connected gap: startContainerMaterial has ZERO production callers and host config ContainerMaterialProvider nil. APP must compose actual manager/factory/hostController/specs/delivery/evidence and container registry provider; new function registry provider currently only functions. Root managedRuntimeRegistryResolver currently directly reads fixed child, must route actual Agent.CurrentRegistryAdmission + completed opaque controller binding. Renewal currently skips nilManagedOCI and compares registration ULID with manager slot; fix genuine slot mapping.
- Pool00f22130->c9c62083->7236db3a OWN-only ledger /tmp/ts-capacity-wire-owned-7236db3a.md and patch, NOT IMPORTED. Prior owner test failed old dependency before scenarios, no pass.

## Final f16 check receipt and current source (2026-10-16)

Whole internal/app test-package compile PASS exit0 at exact clean f16fdbb396d7df3cbbc53a299ab4e04da2a69bf5.
Binary /tmp/ts-app-coherent-f16fdbb3.test SHA256 4070fd7850e5a28f661d696bcfacad719687a5e0cd7cf35099b835d841e4b2e6; empty /tmp/ts-app-coherent-f16fdbb3.log. GATE released. No CLI/full-binary/systemd/native/runtime startup claim.

Seven focused cases executed on same exact binary, log /tmp/ts-app-coherent-f16fdbb3-focused.log, aggregate exit1 ~0.4s, no skips, GATE released.
Retained PASS: TestFunctionMaterialRetirementRequiresAuthoritativeUnusedTask (0.05s); TestManagedRegistrationVerifierUsesExactCurrentPins; TestManagedRegistrationRejectsAuthorityChangesDuringOCIObservation (intent+seat); TestFunctionControllerIngestsSignedChannelIntoDurableIntent rollback+equivocation subcases. QA says do not rerun successful cases without material source/dependency changes.
FAIL: full-material-lifetime ingest qualification subcase and TestFunctionDemandRequiresWorkerQualifiedThroughFunctionExpiry: fixture lacks exact bounded retained OCI index bytes. WASM owns isolated fixture fix, not yet imported. Never add production fallback.
FAIL: TestWorkerSourceReadsCurrentRegistrationAndRevocationOverNATS and TestWorkerMembershipSourceReadsOrderedAdmissionAndRevocation spies counted0 leader reads because they watched bare $JS.API while actual runtime has JS domain. APP7c45f559 updates spy prefix using js.Options().Domain/APIPrefix, including independent placement reader test. Current7c source not compiled/executed.
Next runtime only after corrected WASM fixtures + new clean compile; retry only failed source spies and lifetime/demand cases. Placement reader is separate package, still unexecuted. Prior0846 PASS does not prove leader freshness (modern GetLastMsgForSubject used followerDIRECT).

Next source: review/transplant capacity ee37 prerequisite and bounded owned00f22130→c9c62083→7236db3a, then test-only2f978eb7. Preserve newer budget reservation, APP/worker/region sources; no positive pool child authority claim.

## Current source epoch after f16 (2026-10-16, APP614f9182)

No APP checks running. Exact614f APP test-package compile PASS receipt below; no current runtime claim. No cloud changes or push. QA owns focused runtime lease and eventual publication.

Integrated capacity OWN leaves only: ee37ce60→7d67697d point receipts;00f22130→333db824 individual wire attempts/outcomes and retained original replay; c9c62083→51ff2444 final deadline;7236db3a→2e96011e SDK UserAgent fixture;2f978eb7→ce7b14a4 four protocol fixtures. Newer APP/budget/region sources retained. Pool child authority stays Pending.

Integrated controller/manager source:
- NODE b860→a1c8cd2d genuine derived RuntimeAuthority continuation;6409→7c84d2cc opaque ControllerHostRecipient; private concrete SDK fixture seam3147→64a21fd8. Executor61766→7bd17f4e and8498→b93025f4 exact manager task/cert validation.
- APP4f9c1d3e dispatch and genuine base enrollment transport;85422642 dedicated completed-only controller enrollment source+initial preparation;81e2d709 production container material startup and slot↔ULID transport mapping;8ce4325a leader-backed signed spec reads and retained enrollment expiry.
- APPa43c5c24 prebound closed providers, real root manager startup/READY before one async real Agent.RunSession, fresh Agent retries after cancel/join, Pause preserving manager/tasks, same live Agent registry admission and completed ownhost authority. Session context cancels provider work and source readers drain before key wipe. No positive connected ownhost/manager runtime evidence.

Integrated fixture corrections/regressions:
- WASM777296c2→38e1e094 fixes only retained worker OCI index bytes in shared lifetime/demand helper; original assertions and passing rollback/equivocation remain unchanged.
- NODE10456369→97efbf03 adds actual signed controller recipient SDK/CAS integration fixtures. NODE79ddf16e→6399030f independent image helper correction, c61eee83→6e2879ad actual SDK object timestamp and ffa8e56f→614f9182 coherent fixture clocks imported. Owner exactffa8 positive PASS7.346s/no skips, all3slots; remaining7negatives PASS49.402s/no skips. Logs /tmp/ts-controller-recipient-ffa8e56f-{positive,negatives}.log. Sole owner GATE37218 terminal/released. This is verifier SDK/source evidence only, not APP connected startup. Do not duplicate NODE runs.
- APPd879125a two managedRuntimeHost registry session cancellation regressions (before callback and while callback blocked); these are lifetime guards only, not real Agent positive startup.
- APPc49944b6 real authenticated NATS leader-profile regression: exact signed current profile succeeds, same bytes at unadopted newer revision and tombstone reject, exactly3 domain-aware leader reads/zeroDIRECT.

Final admission source closure in progress:
- Executor d48d9c2d→eea83940 exposes VerifyCurrentTask without OCI repeat. APPd7507a3b invokes after all slow source reads, final local adopted revision/root/epoch/finite lifetimes afterward.
- Executor5b67e4f2→c2ae5279 makes RegistryAdmission.VerifyCurrent mandatory before Vault and invokes after Vault before resolver publication. APPc922ed10 installs all3 manager/container-worker/function-worker callbacks with fresh outer context, live Agent.CurrentRegistryAdmission exact whole-document comparison, captured original2m deadline and all document/release/root/signed-worker lifetimes. These callbacks REPEAT SERVER REAUTHORIZATION, including allocation/release/OCI reads; they are not cheap no-OCI checks. No second local full resolver lookup or Vault issuer discovery. APPca914607 removes weaker trailing generic task helper after final live source.
- Executor47cd6811→8ed892a1 adds explicit VerifyCurrentMaterialTask strict CURRENT service followed by exact final task/node/cert tail. APP86cae24b+60d2482a retain opaque proof and authority/deadlines; call strict helper after recipient and after final snapshot wait. Final local epoch+CanMutate/root/adopted revision/lifetimes and secret result expiry required.
- SEC source-cleared container60d strict current material and ca914 removal of weaker trailing generic. APPcd723094 removes redundant post-material ReadControllerHostBinding SDK wait from root wrapper; retains initial mapping, server strict final proof/task guard, final ctx/session/material expiry and error file clearing. SEC exact delta clear.
- Function af783b7d→d776d0fd opaque FunctionRegistryTaskAdmission; a25ffcc6→2b6d4b4c actual manager service-mutation fixture (only23 owned lines retained, no old3996 fixture context imported);298fe983→759bb0e6 final read order service→task→node then cert/function/worker/context checks. APP91d50614 calls AdmitFunctionRegistryTask then existing authority/root waits, receipt.VerifyCurrent, final local CanMutate/epoch/root before encode. No subsequent provider wait. SEC final caller review pending.
- Executor76eab7a3→511c9a15 signed actual Vault CURRENT integration regression: nil guard prevents Vault; current allows; stale/canceled after Vault deny. APPbc27787b supplies guard in existing foreign-node negative so missing guard does not mask its intended node check. These library test sources are uncompiled/unrun.

Next requested checks after clean compile: retry only failed source spies and WASM lifetime/demand cases; run new TestManagedRuntimeRegistry* and TestControllerHostSpecRequiresExactLeaderRevision. NODE recipient checks stay owner-run; placement readonly reader test remains separate/unexecuted. Successful f16 cases retain prior scoped evidence; no needless reruns.

Other acceptance gaps remain: actual connected manager ownhost+enrollment+Agent startup fixture; obsolete reachable workload reconciler/switch removal after replacement qualification; actual OCIR issuer startup; full NET CLI composition; protected Foundation/HomeIAM cloud writer permissions; native ARM/image/systemd/live regional acceptance; genuine pool child creation lineage. Do not mark complete from source integration or package compile.

## Exact614f whole APP compile receipt

PASS exit0 session13436, QA GATE released, checkout frozen and clean614f9182469106778157a111bc084e9d4c366ae1.
Command: timeout180 env GOMAXPROCS=2 GOFLAGS=-p=2 nice -n19 go test -c -mod=readonly -gcflags='github.com/TerraScale/ts-orchestrator/internal/...=-e' -o /tmp/ts-app-coherent-614f9182.test ./internal/app.
Binary /tmp/ts-app-coherent-614f9182.test SHA256 eeaa82f6109ee476ec13783c09628351858dba2e753016bbe46b07b4aab4b1a8. Log /tmp/ts-app-coherent-614f9182.log empty0B.
No tests executed, tags or runtime extras; no CLI/full binary/systemd/native/connected manager startup qualification. Focused same-binary lease requested after SEC final function caller91d review.

## Exact614f focused runtime and observer correction3d

SEC exact614f source ACK: final caller91d+node-last759 clear; reviewed local gaps closed. Callback remote source reauthorization repeats allocation/release/OCI work, preserving the recorded cheap-check limitation.

QA GATE focused existing614f binary executed with nonblocking /tmp/ts-orch-refactor-gate-check.lock, outer180/test120/GOMAX2/nice19, cwd internal/app. Exit1 ~0.77s, no session/no skips; /tmp/ts-app-coherent-614f9182-focused.log. GATE released. Exact selector retained only failed lifetime ingest subcase, did not repeat passing rollback/equivocation.
- PASS corrected ingest worker full material lifetime subcase and TestFunctionDemandRequiresWorkerQualifiedThroughFunctionExpiry.
- PASS both new TestManagedRuntimeRegistryRejectsEndedSession and TestManagedRuntimeRegistryCancelsInFlightSession.
- FAIL two grant source spies and TestControllerHostSpecRequiresExactLeaderRevision observer counts: controller JWT correctly refuses subscribing API request subjects, so no observer messages. Profile current/new-unadopted-revision/tombstone behavior checks reached before count failure. No leader freshness PASS claim.

APP3d9a933e test-only4file correction replaces observer connection with independent fixture-account signed user:5m expiry, Pub.Deny>, exact requested-bucket leader/DIRECT subjects under bare+GRU-domain API, independent mTLS socket using broker's trusted TLS material. Controller JWT and production ACL unchanged. Tests still require positive leader reads/exact3 profile reads/zero bucket DIRECT; helper now checks asynchronous observer permission errors.

Exact3d compile PASS exit0 session67976/GATE released, clean frozen3d9a933e0f59f3e69888d2cb17ed60d8ddea0457. Same compile flags as614f plus nonblocking GATE flock. Binary /tmp/ts-app-coherent-3d9a933e.test SHA256 eaa2249228134046d818fc2c515da7182c1917062d3d72167b8a487577b9bfee; /tmp/ts-app-coherent-3d9a933e.log0B. No runtime yet. Next selector only ^(TestWorkerSourceReadsCurrentRegistrationAndRevocationOverNATS|TestWorkerMembershipSourceReadsOrderedAdmissionAndRevocation|TestControllerHostSpecRequiresExactLeaderRevision)$; retain four614f leaf passes without rerun.

Sibling test qualification: CORE exact298 function manager receipt+mutation/current material/retained floor scenario PASS44.659s/no skips. CORE exact614f three containermaterial guard tests PASS0.055/no skips; both outside APP connected runtime. New registry postVault fixture initially blocked before execution by3 old mandatory SequenceLocation test compile errors. Original439814ba5fc87fe84432938a474fbf2de38809db is narrow9insert4delete authentic signed allocation fixture correction; APP3d target blob exactly equals donor parent, result equals earlier qualified49a. Not imported while APP frozen. CORE isolated e8c70091=614f+439 callback-only check queued, no result.

## Exact3d focused results and membership correctione604

QA GATE3case existing3d binary focused exit1 ~0.17s/no skips, /tmp/ts-app-coherent-3d9a933e-focused.log, nonblocking GATE/outer180/test120/GOMAX2/nice19/cwdinternal/app. GATE released. PASS TestControllerHostSpecRequiresExactLeaderRevision (actual exactly3leader/zeroDIRECT) and TestWorkerSourceReadsCurrentRegistrationAndRevocationOverNATS. Retain without repeat. FAIL only TestWorkerMembershipSourceReadsOrderedAdmissionAndRevocation: now-authorized observer detects1 real grant-bucket DIRECT read during initial membership publication.

Cause: WorkerMembershipSource.Read→GrantStore.RecordSwarmMembership→store.Read→kv.Get used follower DIRECT for pre-CAS exact expected grant/revision check. APPe604e489 retains original concrete js in GrantStore constructor, requires it in RecordSwarmMembership and substitutes existing ReadCurrentGrant for only that pre-CAS read. Full exact grant/revision/response checks, CAS and source post-CAS leader guards remain unchanged. Generic store.Read and observer assertions unchanged. SEC agreed proposal, exact delta review pending.

Original439814ba imported→ddc22a6e after3d runtime terminal (owned test fixture only). CORE isolated exacte8c70091 postVault callback4leaf regression PASS0.226s/no skips, /tmp/ts-core-registry-e8c70091-focused.log; no duplicate APP request. No source/runtime connected ownhost claim.

Current frozen clean ddc22a6e1030804353de618cfa080aec24af6175 uncompiled; QA compile requested then ONLY ^TestWorkerMembershipSourceReadsOrderedAdmissionAndRevocation$ runtime retry. Previously passing3d2/614four leaves must not repeat. Future positive connected manager fixture code paused until this source freshness bug is closed.


## Exactddc22a6e compile receipt

SEC exacte604 source clear confirmed. QA compile-only GATE lease exercised on clean frozen ddc22a6e1030804353de618cfa080aec24af6175; session34792 exit0, lock released. Same outer180/GOMAX2/p2/nice19/modreadonly/internal-only-e command. Binary /tmp/ts-app-coherent-ddc22a6e.test SHA256 11f677088cf5e712f32f55bac1074cc6a04f4733418455b64d1fa6aa9b6e6e10; /tmp/ts-app-coherent-ddc22a6e.log empty0B. No tests executed/source edits. Separate runtime grant requested ONLY ^TestWorkerMembershipSourceReadsOrderedAdmissionAndRevocation$ from internal/app; six earlier614f/3d leaf passes retained without repeat. No active APP command/lease while awaiting QA.


## Exactddc22a6e membership freshness runtime receipt

QA membership-only SAME-BINARY runtime lease exercised from internal/app, nonblocking GATE/outer180/test120/GOMAX2/nice19; exit0 ~0.18s/no skips. Binary unchanged SHA256 11f677088cf5e712f32f55bac1074cc6a04f4733418455b64d1fa6aa9b6e6e10, /tmp/ts-app-coherent-ddc22a6e-membership.log. GATE released, clean frozen source unchanged. ONLY TestWorkerMembershipSourceReadsOrderedAdmissionAndRevocation executed; six prior614f/3d leaves retained without repeat.

Actual signed admission CAS/readback, fresh retained reader (>64KiB grant), foreign-node refusal, ordered retirement, republish refusal, disabled flag and deletion passed. Each source read's independent signed observer asserted positive leader grant API reads and zeroDIRECT; no exact total leader count was logged or claimed. This closes e604's pre-CAS follower-read freshness bug. Parent QA/SEC informed. No connected manager startup/CLI/native/live acceptance claim. Next authorized bounded work is test-only genuine signed startup/rootREADY before ONE real Agent session; fixture edits remained paused through this closure.


## Frozen fixturetest composition candidate dbc43f0d (uncompiled)

Current CLEAN frozen HEAD dbc43f0d3fcd3e9a7264fc963bd1dfcdb0b17334. No active runner, GATE lock or lease. QA fixturetest whole internal/app COMPILE-ONLY grant requested. No build/runtime executed for this source epoch.

- 9819ff40 exact test executable dispatch for runtime-controller-host-admission-source uses genuine Run, stdout protocol, and keeps fixed-clock hook restricted to bootstrap-admit-restart.
- 4dfc59d0 adds fixturetest-only bootstrapstart.NewControllerManagerStartupFixture: genuine signed controller-c (seed10.44.0.10) external reservation/completion, ledger CAS, Gate.AdmitInitial, canonical marker/current authority. Signed controller-a/b plan rows only; no fabricated peer completion or accepted identity. NODE-style non-native image/material/live-credential checkers retain their explicit scope.
- TestManagedRuntimeReadyBeforeSingleOwnHostSession composes actual root-pinned SignedFootprint/ObjectFoundationStore and SDK Vault create/readback with existing NODE StartAcceptedNodeFixture, pauses manager, observes actual systemd READY datagram, then starts authenticated NATS/controller and ONE actual Agent.RunSession; signed own registration is independently read and verified. Session cancellation leaves the manager live/paused. Deferred material/registry providers stay closed; no source.bind.
- Source-only corrections: exact foundation journal key head-bucket/orchestrator/regions/v1/GRU.json legitimately permits production journal's omitted checksum/KMS headers while signed ledger/source writes require exact checksum/KMS and all writes require CAS. Host controller cleanup tracks consumed join result. Namespace uses exec and unshare --kill-child=SIGKILL.
- Explicit exclusions: HomeIAM, full RunManagedRuntime wrapper/management server, production session wrapper and its independent production binding observer, positive material delivery, native/containerd execution, CLI/systemd/image/live OCI acceptance. Production RuntimeInstanceObserver lacks an approved SDK injection; no new production observer/authority seam was introduced.
- Parent-approved CAP exact originals e841dce2→3c3e7c33 (pool SDK body fix, SEC clear),1cd6b189→38ee837f (retry phases/restart refusal),19558037→dbc43f0d (changed recipe resource retention). Target blobs match donor originals. CAP25 distinct leaf receipts in /tmp/ts-qa-capacity-owned-qualified.json retained without duplicate runs; no whole-current-union or positive child/cloud claim.

Formatting and staged/diff whitespace checks PASS. No source changes while frozen. Next: QA-authorized fixturetest compile only, then separate runtime authorization if compile succeeds.


## Exactdbc43f0d fixturetest compile receipt

QA-authorized whole internal/app fixturetest compile PASS. Session50406 terminal exit0, nonblocking GATE released, source remains clean frozen dbc43f0d3fcd3e9a7264fc963bd1dfcdb0b17334. No tests executed. /tmp/ts-app-coherent-dbc43f0d-fixture.log empty0B. Exact argv: timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go test -mod=readonly -tags=fixturetest -c '-gcflags=github.com/TerraScale/ts-orchestrator/internal/...=-e' -o /tmp/ts-app-coherent-dbc43f0d-fixture.test ./internal/app.

Complete source diff since9819 for QA safety review: /tmp/ts-app-dbc43f0d-since9819.diff. Runtime remains unqualified and requires a distinct grant; no runtime/native/cloud operations authorized or executed.


## Exactdbc startup first runtime FAIL; marker mode corrected582a3992

Authorized SAME-BINARY ONLY TestManagedRuntimeReadyBeforeSingleOwnHostSession terminal FAIL exit1 ~0.39s, no skips. Log /tmp/ts-app-coherent-dbc43f0d-startup.log. No async session ID (initial tool call finished). Binary SHA unchanged1f2c3d4f6db14e3f39620f766fd8a7216c0f2dcf448962669d8b67c278efe3c5, source clean/frozen through terminal. GATE released; no retry. Exact argv: timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env GOMAXPROCS=2 nice -n 19 /tmp/ts-app-coherent-dbc43f0d-fixture.test -test.v '-test.run=^TestManagedRuntimeReadyBeforeSingleOwnHostSession$' -test.timeout=120s (cwd internal/app).

Failure before manager/NATS/Agent: Gate.requireInitialJournalAbsent surfaced ErrIdentityRekeyJournal + ErrInvalidMarker. Source audit: store existed and journal genuinely absent; MarkerStore.openDirectory requires exact0755 directory, fixture had0700. Match NODE founder_runtime_test.go750/admission_flow_test.go420/testMarkerStore fixtures. Test-only582a39920cf2e486306579c9a66ceefb17cb013d adds os.Chmod(markerDirectory,0755),3lines; no production change. Diff /tmp/ts-app-marker-mode-correction.diff. Floor remains0700, store state directory0700/files0600, baked public dirs0755/files0444. Root UID/GID, nofollow/absence and journal protections unchanged. Only test ancestor relaxation already approved is retained. Remaining path/mode source audit found no further exact-mode mismatch; no runtime inference.

Current CLEAN frozen582a3992 awaits fresh compile-only grant; no build/runtime for corrected source. No manager/rootREADY/Agent milestone credited.


## Exact582a3992 fixturetest compile PASS

Whole internal/app fixturetest compile-only session21243 terminal exit0; GATE released. Log /tmp/ts-app-coherent-582a3992-fixture.log empty0B. Binary /tmp/ts-app-coherent-582a3992-fixture.test. Exact same pinnedGo1.27.1/unsetGOROOT/GOMAX2/p2/nice19/modreadonly/internal-only-e/nonblockingGATE/outer180 argv as dbc, changing artifact names to582. Source remains clean frozen582a39920cf2e486306579c9a66ceefb17cb013d; no tests executed. Separate one-selector same-binary runtime grant pending.


## Exact582a3992 startup composition PASS (bounded milestone)

QA-authorized SAME-BINARY ONLY ^TestManagedRuntimeReadyBeforeSingleOwnHostSession$ PASS exit0/no skips; child1.55s/outer1.65s. Session55421 terminal; GATE released. Log /tmp/ts-app-coherent-582a3992-startup.log. Binary SHA256e86878dca3fa60cd9958d635788b03f6d5e007b22b9ed9b219a49b3b9e239ed8 unchanged; source remains CLEAN frozen582a39920cf2e486306579c9a66ceefb17cb013d. No rebuild or retry under this lease. Previous dbcfail is retained.

Exact argv: timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env GOMAXPROCS=2 nice -n 19 /tmp/ts-app-coherent-582a3992-fixture.test -test.v '-test.run=^TestManagedRuntimeReadyBeforeSingleOwnHostSession$' -test.timeout=120s > /tmp/ts-app-coherent-582a3992-startup.log 2>&1 (cwd internal/app). Child reexecutes sudo-n unshare --net --fork --kill-child=SIGKILL with its own loopback10.44.0.10; no shared daemon or host network/cloud writes.

Actual passing scope: signed controller-c seed public external reservation/completion→SDK ledger CAS→Gate.AdmitInitial→canonical current authority→signed SDK foundation journal→real manager/Raft and create-once Vault SDK/readback. Manager paused before manually emitted/observed systemd READY datagram. Authenticated embedded NATS/controller start afterward; exactly ONE actual Agent.RunSession establishes current signed session, independently read registration matches actual Agent, then cancellation joins it while manager remains live/paused. Deferred material/registry stay closed throughout.

Explicitly NOT covered: full RunManagedRuntime/production management wrapper, production ownhost session wrapper and independent SDK binding observer, HomeIAM, positive material/registry binding, native execution, installed CLI/image/systemd/live OCI acceptance. This is a downstream composition milestone, not full production startup. All previous ddc/614/3d/CAP25 leaves retained without repeat.


## Frozen d34fcb90 lower enrollment source; uncompiled

Clean HEAD d34fcb90abf55949e0d6870e82d065fc220f4c95; complete source/resource/blocker handoff /tmp/ts-app-d34fcb90-enrollment-handoff.md; full diff /tmp/ts-app-d34fcb90-enrollment.diff. New one-selector fixture-only lower enrollment test; public Claim/Register/Issue/Sign/Finish CAS -> completed current registration -> private SDK recipient -> actual issued JWT/client-certificate Agent -> disabled-grant refusal. Prior582 startup/helper file byte-identical. Both fixturetest files only,561 insertions. gofmt/diff checks only; no build/runtime authorized or executed; no APP lease active. Separate fixture server/client CA roots explicitly scoped; production installation/full RunManagedRuntime blockers all retained. Await QA source review and compile-only grant, then separate selected runtime grant.


## Exactd34fcb90 compile-only PASS

QA GATE compile-only grant exercised on clean frozen d34fcb90abf55949e0d6870e82d065fc220f4c95 after exact-source QA/Security review clear. Session40390 terminal exit0; nonblocking GATE released. No tests or other runner executed. Log /tmp/ts-app-coherent-d34fcb90-fixture.log is0bytes. Binary /tmp/ts-app-coherent-d34fcb90-fixture.test SHA256541da78dda6d0011e5c6c77d65a23ac5e65663ab5193242d35b64c573c61f310. Source remains clean/frozen and prior582 startup/helper bytes unchanged; earlier582 PASS retained without repetition.

Exact argv (cwd /tmp/ts-refactor-app-integration): timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go test -mod=readonly -tags=fixturetest -c '-gcflags=github.com/TerraScale/ts-orchestrator/internal/...=-e' -o /tmp/ts-app-coherent-d34fcb90-fixture.test ./internal/app > /tmp/ts-app-coherent-d34fcb90-fixture.log 2>&1.

Runtime remains unapproved and unexecuted; only new selector ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$ would run under a distinct same-binary grant. Full RunManagedRuntime blockers and two-fixture-CA limit remain.


## Exactd34fcb90 one-selector runtime FAIL; no retry or source edit

QA's distinct SAME-BINARY runtime grant executed ONLY ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$. Session57352 terminal exit1; no skips; child1.57s/outer1.68s. Raw log /tmp/ts-app-coherent-d34fcb90-enrollment.log (line79 failure,101/103 FAIL). GATE released. Binary SHA256541da78dda6d0011e5c6c77d65a23ac5e65663ab5193242d35b64c573c61f310 verified before and after, unchanged. Source clean/frozen d34fcb90abf55949e0d6870e82d065fc220f4c95 before and after. No rebuild, retry, source mutation, prior582 test repeat or other runner.

Exact argv (cwd /tmp/ts-refactor-app-integration/internal/app): timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /tmp/ts-app-coherent-d34fcb90-fixture.test -test.v '-test.run=^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$' -test.timeout=120s > /tmp/ts-app-coherent-d34fcb90-enrollment.log 2>&1.

Failure at controller_enrollment_integration_test.go260: descriptor.CanonicalBytes rejects ts-gru-c: managed host boot descriptor is invalid: static host must name one database, controller, node or pool server of its cell and nothing else. Genuine manager and NATS started, then cleanly shut down. Failure precedes enrollment Claim/Register/Issue/Sign/Finish/recipient/Agent; no lower enrollment milestone credited. Prior582 startup PASS remains retained.

Read-only diagnosis: hostboot.Descriptor.validateFields also calls naming.Validate; ts-gru-c has a letter suffix and is not a genuine regional controller node. Production hostenroll.ReadControllerHostMetadata uses naming.RegionCell(region).ControllerSlot(bootstrap.Slot). For GRU/controller-c this returns gru-1-ctl-3, confirmed naming/naming_test.go19 and the bootstrap fixture's existing accepted store ServerName at controller_manager_startup_fixture.go355/362. The private recipient donor used arbitrary grant names without creating a host descriptor, which this composition now does.

Proposed minimum source-only correction FOR REVIEW, NOT APPLIED: change the new test's HostGrant.Node at line226 from "ts-gru-c" to "gru-1-ctl-3". Descriptor, signed spec, ordered registration, response/issued identities and Agent all already derive from that grant. Single fixturetest line, no validator/authority/helper changes, old582 file unchanged, all security/later assertions retained. Could instead derive through canonical naming API but that requires an import plus error handling; literal matches the existing fixture store exactly. Await QA review/explicit source-mutation grant before editing. Full production exclusions and twoCA limit unchanged.


## Frozen92eacab2 source-only canonical controller name correction

QA-approved one-line fixturetest correction committed as92eacab2: only HostGrant.Node ts-gru-c -> gru-1-ctl-3 at internal/app/controller_enrollment_integration_test.go226. Exact correction diff /tmp/ts-app-92eacab2-enrollment-name.diff against d34fcb90. All descriptor/spec/registration/response/issued identity/Agent fields already derive from grant.Node. No production validator, authority, helper or assertion changes. Entire prior582 startup/helper file remains byte-identical; original57352 failure preserved without retry.

ModernGo1.27 cached list fully read; gofmt, whitespace and preservation checks PASS. Worktree clean and source frozen. No compile/runtime executed for this correction; no runner/lease active. Prior d34 compile and runtime fail remain historical receipts; no corrected-source runtime inference. Same resource footprint and full production blockers as d34 handoff. Await separate compile-only grant, then separate same-binary runtime grant if compile passes.


## Exact92eacab2 fixturetest compile-only PASS

QA-approved wholeAPP fixturetest compile PASS session96600 terminal exit0; nonblocking GATE released. Clean frozen source92eacab24e601386cf909a1bf7e1929d3913c7d5 unchanged, prior582 entire startup/helper file unchanged. Log /tmp/ts-app-coherent-92eacab2-fixture.log empty0B. Binary /tmp/ts-app-coherent-92eacab2-fixture.test SHA256e1428e931502d29ba9b4d042ba700b832e959cc7c2e98e770580da9d542d8be8. No tests or other runner executed; original57352 failure preserved. Runtime unapproved/unexecuted for corrected source.

Exact argv (cwd /tmp/ts-refactor-app-integration): timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go test -mod=readonly -tags=fixturetest -c '-gcflags=github.com/TerraScale/ts-orchestrator/internal/...=-e' -o /tmp/ts-app-coherent-92eacab2-fixture.test ./internal/app > /tmp/ts-app-coherent-92eacab2-fixture.log 2>&1.

Next is a distinct runtime grant ONLY ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$ with this exact binary. Prior582 PASS retained without repeat; full production exclusions and twoCA limit unchanged.


## Exact92eacab2 lower enrollment composition runtime PASS

QA-authorized SAME-BINARY ONLY ^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$ PASS session12983 terminal exit0/no skips; child2.27s/outer2.38s. Nonblocking GATE released. Raw log /tmp/ts-app-coherent-92eacab2-enrollment.log (line78 public producers/ordered+SDK recipient positive;80 issuedcredential Agent+disable+closed providers;102/105 PASS). Binary /tmp/ts-app-coherent-92eacab2-fixture.test SHA256e1428e931502d29ba9b4d042ba700b832e959cc7c2e98e770580da9d542d8be8 verified unchanged before/after; clean frozen source92eacab24e601386cf909a1bf7e1929d3913c7d5 verified before/after. No rebuild/retry/other selector or prior582 repeat. Failure57352 retained. No runner/lease active.

Exact argv (cwd /tmp/ts-refactor-app-integration/internal/app): timeout 180s flock -n /tmp/ts-orch-refactor-gate-check.lock env -u GOROOT GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /tmp/ts-app-coherent-92eacab2-fixture.test -test.v '-test.run=^TestControllerEnrollmentIssuedCredentialsAndCurrentRecipient$' -test.timeout=120s > /tmp/ts-app-coherent-92eacab2-enrollment.log 2>&1.

Qualified LOWER scope: genuine signed controller-c seed/Gate authority and signed foundation+SDK Vault support actual paused manager. Public signed Request/Claim/ordered Register/Issuer.Issue/Response Sign+Verify/Finish CAS complete the exact instance grant; current ordered registration and actual receipt association read independently; current adopted roots/signed spec/slot ledger and SDK OCI facts pass private recipient verification. Signed changed-expiry response refused by completed matcher. One actual Agent using those issued scoped JWT/clientcertificate/request privatekeys establishes session and verifies independently read current registration. Disable CAS makes same current-source composition refuse; session cancellation joins once while manager remains live/paused and deferred material/registry providers stay closed. No source.bind.

Still NOT qualified: full RunManagedRuntime/production management wrapper, HTTP enrollment handler, fixed serviceUID source child/currentControllerHostReader/installed IMDS+credentials, production ReadControllerHostBinding/observer path, HomeIAM, positive material/registry binding, native/containerd/cgroups, installed CLI/image/systemd/live OCI acceptance. Fixture server/client CAs remain separate, explicitly lower scope. Full registry reauthorization/all-static worker/pool/DATA holds unchanged. Earlier582 startup PASS and prior focused/CAP25 passes retained separately without repeat.
