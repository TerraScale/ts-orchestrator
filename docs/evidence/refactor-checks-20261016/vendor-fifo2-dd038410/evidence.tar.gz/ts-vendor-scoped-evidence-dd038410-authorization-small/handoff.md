Review FIFO position2 on exact dd038410: two never-run root-only cases.

^TestAccount(ConfiguredImportsExportsOverTCP|StaleActivationExpiryOverTCP)$

Both candidate bodies, all called helper declarations and fixture bind exact67ec/dd; original bodies match847b. Production trace/activation paths survive canonical5tags. Resources:2serialservers/8dials/max4clients/max2listeners;17pubs/20deliveries;154/137payload bytes;5HTTP/4trace/1SYS.

Historical90s timeout remains frozen; proposed dispatch120s/outer180s is review-only pending separate parent grant. Preserve literal-user/privateOptions/nats.add trace/chunk completion/finiteabsence/callback/race gaps. No runner was launched.
