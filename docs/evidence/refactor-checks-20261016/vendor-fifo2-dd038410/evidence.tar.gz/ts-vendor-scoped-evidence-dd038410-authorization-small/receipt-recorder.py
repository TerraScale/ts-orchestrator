#!/usr/bin/env python3
"""Record broker evidence only. This file never launches Go or a test runner."""
import argparse
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess


PLAN = Path(__file__).with_name("dispatch.json")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_once(path, value):
    with Path(path).open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def snapshot(plan):
    def git(*args):
        return subprocess.check_output(
            ["git", "-C", plan["qa_path"], *args], text=True
        ).strip()

    return {
        "HEAD": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
        "status": git("status", "--porcelain"),
        "frozen_sha256": {path: digest(path) for path in plan["frozen_sha256"]},
    }


def binding_errors(plan, binding):
    errors = []
    for key, expected in (("HEAD", plan["revision"]), ("tree", plan["tree"]), ("status", "")):
        if binding[key] != expected:
            errors.append(f"{key} differs from frozen dispatch")
    for path, expected in plan["frozen_sha256"].items():
        if binding["frozen_sha256"].get(path) != expected:
            errors.append(f"Frozen file changed: {path}")
    return errors


def summarize(events, expected_roots):
    runs = [event.get("Test") for event in events if event.get("Action") == "run"]
    terminals = [event for event in events if event.get("Action") in ("pass", "fail", "skip")]
    tests = [event for event in terminals if event.get("Test")]
    packages = [event for event in terminals if not event.get("Test")]
    expected = set(expected_roots)
    terminal_names = [event["Test"] for event in tests]
    unexpected = sorted(set(runs + terminal_names) - expected)
    scope_ok = (len(runs) == len(expected_roots) and set(runs) == expected
                and len(tests) == len(expected_roots) and set(terminal_names) == expected
                and not unexpected)
    passed = (scope_ok and all(event["Action"] == "pass" for event in tests)
              and len(packages) == 1 and packages[0]["Action"] == "pass")
    return {"tests": tests, "packages": packages, "runs": runs, "unexpected": unexpected,
            "scope_ok": scope_ok, "passed": passed}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("before", "record"))
    parser.add_argument("--session", type=int)
    parser.add_argument("--exit-code", type=int)
    args = parser.parse_args()
    plan = json.loads(PLAN.read_text())
    assert plan["dispatcher"] == "/root/qa_integrator/storage_compare"
    assert plan["selector"] == '^TestAccount(ConfiguredImportsExportsOverTCP|StaleActivationExpiryOverTCP)$'
    assert plan["expected_roots"] == ["TestAccountConfiguredImportsExportsOverTCP", "TestAccountStaleActivationExpiryOverTCP"]
    if args.phase == "before":
        if Path(plan["log"]).exists() or Path(plan["receipt"]).exists():
            raise SystemExit("Existing run evidence found; do not repeat this dispatch")
        binding = snapshot(plan)
        errors = binding_errors(plan, binding)
        if errors:
            raise SystemExit("\n".join(errors))
        write_once(plan["before_record"], {"dispatch_sha256": digest(PLAN), "binding": binding})
        return

    if args.session is None or args.exit_code is None:
        parser.error("record requires broker --session and terminal --exit-code")
    before = json.loads(Path(plan["before_record"]).read_text())
    errors = binding_errors(plan, before["binding"])
    if before["dispatch_sha256"] != digest(PLAN):
        errors.append("Dispatch changed after precheck")
    after = snapshot(plan)
    errors.extend(binding_errors(plan, after))
    if before["binding"] != after:
        errors.append("Before/after bindings differ")
    lock_released = False
    try:
        with Path(plan["lock"]).open("r+") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            lock_released = True
            fcntl.flock(lock, fcntl.LOCK_UN)
    except (BlockingIOError, FileNotFoundError):
        errors.append("Lane lock is held or absent; terminal release is not verified")
    events = []
    try:
        for line in Path(plan["log"]).read_text().splitlines():
            if line.strip():
                events.append(json.loads(line))
    except (OSError, json.JSONDecodeError) as error:
        errors.append(f"Cannot parse complete JSONL evidence: {error}")
    result = summarize(events, plan["expected_roots"])
    qualified = args.exit_code == 0 and result["passed"] and not errors and lock_released
    receipt = {
        "revision": plan["revision"], "tree": plan["tree"], "session": args.session,
        "exit": args.exit_code, "selector": plan["selector"], "argv": plan["argv"],
        "cwd": plan["cwd"], "dispatch": str(PLAN), "dispatch_sha256": digest(PLAN),
        "log": plan["log"], "log_sha256": digest(plan["log"]) if Path(plan["log"]).is_file() else None,
        "before_binding": before["binding"], "after_binding": after,
        "result": result, "postcheck_errors": errors, "released": lock_released,
        "scoped_standard_pass": qualified,
        "qualification": "Only these two never-run FIFO roots. Preserve all previous passes/failures; no retry, race/equivalence/removal/central closure claim.",
    }
    write_once(plan["receipt"], receipt)
    if not qualified:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
