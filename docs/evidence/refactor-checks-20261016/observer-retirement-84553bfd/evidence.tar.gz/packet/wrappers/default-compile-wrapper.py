import datetime,hashlib,json,os,pathlib,subprocess,time,uuid
root=pathlib.Path('/tmp/ts-qa-observer-retirement')
expected={'commit':'84553bfd694c6c42987274cd1ae6e236bf03fab6','tree':'983cb348061082733da5aaf894aa090d3c3f2ff3','parents':'69546992515385c8fec88803db4b43decf29fae4','status':''}
files=['internal/bootstrapstart/oci_observer_test.go','internal/bootstrapstart/founder_replacement_test.go','tests/firecracker/production/fixturegen/compute_inventory_sdk_test.go','tests/firecracker/production/fixturegen/compute_inventory_observer_fixture_test.go']
def sha(path):
    digest=hashlib.sha256()
    with open(path,'rb') as source:
        for block in iter(lambda:source.read(1048576),b''):digest.update(block)
    return digest.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def binding():return {'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'parents':git('show','-s','--format=%P','HEAD'),'status':git('status','--porcelain=v1'),'source_sha256':{name:sha(root/name) for name in files}}
def json_x(path,data):
    with open(path,'x') as output:json.dump(data,output,indent=2);output.write('\n')
pre=binding()
for key,value in expected.items():
    if pre[key]!=value:raise SystemExit('Source binding rejected: '+key)
assert git('diff','--name-only',expected['parents'],'HEAD').splitlines()==['internal/bootstrapstart/oci_observer_test.go']
go='/home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go'
prior=pathlib.Path('/tmp/ts-qa-observer-tagged-runtime-ba75b29a-20261017T001016Z-b086adee/pre-binding.json')
approved_sha=json.loads(prior.read_text())['go_binary_sha256'];assert sha(go)==approved_sha
now=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=pathlib.Path('/tmp')/('ts-qa-observer-retirement-default-compile-84553bfd-'+now+'-'+uuid.uuid4().hex[:8]);out.mkdir(mode=0o700)
binary=out/'bootstrapstart-default.test'
argv=['flock','--nonblock','/tmp/ts-orch-refactor-gate-check.lock','timeout','--signal=TERM','--kill-after=5s','180s','env','-u','GOROOT','PATH=/home/mariogk/.local/share/mise/installs/go/1.27.1/bin:'+os.environ['PATH'],'GOMAXPROCS=2','GOFLAGS=-p=2','nice','-n','19',go,'test','-c','-p','1','-mod=readonly','-o',str(binary),'./internal/bootstrapstart']
json_x(out/'pre-binding.json',{'grant':'default bootstrapstart compile only; binary invocation forbidden','source':pre,'executable':go,'executable_sha256':approved_sha,'approved_executable_hash_source':str(prior),'argv':argv,'cwd':str(root),'GOROOT_unset':True,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('EVIDENCE_DIRECTORY='+str(out),flush=True);print('DEFAULT_BOOTSTRAPSTART_COMPILE_STARTED',flush=True)
start=time.monotonic()
with open(out/'compile.log','xb') as log:result=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=False)
elapsed=time.monotonic()-start;post=binding();json_x(out/'post-binding.json',post)
receipt={'qualification':'retirement default bootstrapstart compile only','pre_binding':pre,'post_binding':post,'source_unchanged':pre==post,'executable':go,'executable_sha256':approved_sha,'argv':argv,'cwd':str(root),'exit_code':result.returncode,'elapsed_seconds':elapsed,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_exists':binary.is_file(),'binary_path':str(binary),'binary_sha256':sha(binary) if binary.is_file() else None,'binary_bytes':binary.stat().st_size if binary.is_file() else None,'binary_invoked':False,'tests_executed':False,'fixturetest_compiled':False,'F2_runtime_repeated':False,'source_changes':False,'integration':False,'push':False,'cloud_calls':False,'artifact_sha256':{path.name:sha(path) for path in out.iterdir() if path.is_file()}}
json_x(out/'receipt.json',receipt)
with open(out/'SHA256SUMS','x') as manifest:
    for path in sorted(out.iterdir()):
        if path.is_file() and path.name!='SHA256SUMS':manifest.write(sha(path)+'  '+path.name+'\n')
for row in (out/'SHA256SUMS').read_text().splitlines():
    expected_hash,name=row.split('  ',1);assert sha(out/name)==expected_hash
for path in out.iterdir():path.chmod(0o444)
out.chmod(0o555)
print(json.dumps({'evidence_directory':str(out),'exit_code':result.returncode,'elapsed_seconds':elapsed,'source_unchanged':receipt['source_unchanged'],'binary_sha256':receipt['binary_sha256'],'binary_bytes':receipt['binary_bytes'],'receipt_sha256':sha(out/'receipt.json'),'log_sha256':sha(out/'compile.log'),'sha256sums_sha256':sha(out/'SHA256SUMS'),'read_only':True},indent=2),flush=True)
if result.returncode!=0:print((out/'compile.log').read_text(errors='replace')[-14000:],flush=True)
if result.returncode!=0 or pre!=post:raise SystemExit(1)
