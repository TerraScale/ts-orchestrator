# Source-only retirement of migrated observer tests

Candidate: 84553bfd694c6c42987274cd1ae6e236bf03fab6
Sole parent: 69546992515385c8fec88803db4b43decf29fae4 (published evidence-docs HEAD)
Tree: 983cb348061082733da5aaf894aa090d3c3f2ff3
Worktree: /tmp/ts-qa-observer-retirement; branch refactor/qa-observer-retirement; clean.
Qualified unchanged source base: ba75b29add6bbeea4d36d5e326cce84b7f6190b7.

Only `internal/bootstrapstart/oci_observer_test.go` changes:114 deletions, zero additions. Retires exactly the three TestOCIObserver declarations and now-unused observerFixture, removes only errors/testing imports, retains the file and all fakeComputeObservation/fakeNetworkObservation types and methods. Their six declaration byte hashes are in preservation-proof.json. The former blank separator before the deleted helper is removed by gofmt. Every other tracked entry, including production, qualified F2 owning scenarios and founder_replacement_test.go, is identical to the published docs parent. TestObserveLifecycleReportsTerminatedWithoutVNIC and its fake dependencies remain.

## Exact qualified mapping

TestOCIObserverRejectsNetworkOwnershipAndRegionMismatch maps to six independently passed SDK/socket cases: wrong VNIC compartment, wrong subnet compartment, wrong subnet identity, wrong VCN region, missing VCN, subnet unavailable. Each requires4 successful listed service reads.

TestOCIObserverRequiresExactAttachedPrimaryVNIC maps to the exact-primary/CreateKey positive(4reads) and foreign-attachment negative(2reads). Positive retains exact identity/ETag/compartment/image/AD/FD/shape/subnet/primary/IP/lifecycle/NSG fields and BootstrapCreateKey reviewed-seed-create.

TestOCIObserverRejectsMissingPrimaryAndCandidateMismatch maps to missing-primary(4reads) and returned-candidate mismatch(1read). The latter mutates returned identity on the original authorized route, preserving the old requested/returned candidate mismatch invariant.

All9 independent negatives require errors.Is(err, bootstrapstart.ErrInstanceObservation), listed200 responses, zero audit overflow, exact canonical request sequence and verified socket response bytes. source-mapping.json links every removed declaration to exact qualified case terminal events, request hashes and original/baseline/served/socket body provenance. qualified-per-case-proofs.json is copied unchanged from the accepted F2 packet; archive SHA25699b79c4f24e4b40b84bc8e63284c21a74b5a38aae5ee49d8336a3592df98c4b5. No successful F2 runtime was repeated.

## Parent adoption and validation

This worktree was created exactly at ba75. Its unpublished retirement commit was rebased onto the explicitly authorized docs-only69546992 parent. adoption-proof.json verifies docs-only changes and byte-identical retirement patch after adoption. Final source identity is the candidate above; the old8ed50b8b preliminary identity is superseded.

Full patch SHA256: 1a1aa82b4218c1b44217a9cff2cc88f0608258781c85c12ea235b637c3d1b830
Source mapping SHA256: da16bbe9264d93a59817ae05b7ce4d6dac13caf3265aa08896e3f9c266727e61
Preservation proof SHA256: db7f704c4771f97f922f8163abd6451761f492b364cbb9051e3918f63b31cdf4

Only Modern Go guidance, source inspection/byte comparisons, gofmt and Git whitespace checks ran. No build/test/lint/Go runner/server/F2 repeat/integration/push. Candidate is source-only awaiting separate exact-source compile review. Default-build compilation and normal observer construction supply no replacement runtime evidence; normal constructor/pinned production transport, DNS/TLS/live OCI/full Gate/native/NSG/F3/global qualification remain excluded.
