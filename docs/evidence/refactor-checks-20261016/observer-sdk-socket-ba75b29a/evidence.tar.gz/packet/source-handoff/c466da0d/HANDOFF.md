# F2 observer socket scenario: source-only candidate

Commit: c466da0d2af6c08ecdbd2917773594fd447697e0
Tree: 7648da22cc89762acb6d22f4ac43dbf840d79ced
Actual sole parent / required base: c748d540026fe3f2de4dcffbcd32f58bf7108286
Branch: fix/qa-observer-socket-rejections
Worktree: /tmp/ts-qa-observer-socket-rejections (clean)
Reviewed source plan SHA256: 6d6a62f45d11ace3bb5ae495456cf3065131ccd7ec42c0d617ea8c7803a07041
Exact change.patch SHA256: 4ac46d81dbf1510db70b5e78eeed1b8da65407fcdba389bd299c253810f42261

## Exact scope and preservation

Only the three reviewed test files changed, +201/-12: compute_inventory_sdk_test.go, compute_inventory_observer_fixture_test.go, compute_inventory_observer_default_test.go in tests/firecracker/production/fixturegen. Full diff is change.patch; source snapshots and per-file SHA256 are in candidate.json.

The existing enclosing signed-three-slot packet entry, all original observer declarations and fake helpers, lifecycle dependent, all production code/observer constructors/security/authority, NSG/F3 files and module files are byte-identical to base. preservation-proof.json records hashes and exact source comparisons. The SDK owner function changes only simulator/socket setup and trailing helper configuration argument; every existing SDK assertion is preserved byte-for-byte. The tagged positive observer function changes only its signature and an additive fixed-slot call; every old assertion remains byte-for-byte. Existing fixture certificate helper is byte-identical. Default helper exact source comparison proves only its matching production.Config parameter/import were added; its return-zero body is byte-identical. Both tag variants and the common caller have the same trailing configuration type/argument in source. The default helper still supplies zero observer assertions and cannot qualify this migration; no compilation is claimed by this source comparison.

## Connected behavior and negative proof

Existing SDK request signing/federation and production.Simulator now cross an actual httptest localhost socket. The private standard HTTP client has Proxy:nil, redirect rejection and a10s timeout. Dispatcher clones preserve canonical Host, raw URI/query and signature; only exact expected method/host/raw-URI tuples from configured reads plus fixed IMDS/federation routes are admitted before URL scheme/host are rewritten to its listener and RequestURI cleared. No global transport, environment or production seam changes; no external dials. The setup follows the established simulator_test.go socket pattern.

Every successful service response is read with a len(expected)+1 bound, checked status200 and byte-equal to its exact configured provider response, hashed in logs, then returned unchanged to the SDK decoder. Simulator request audits separately require all routes listed/200, exact canonical Compute route-hash sequence, and zero audit overflow. RouteSHA256 itself hashes the request tuple; separate body hashes prove response provenance.

The existing fixturetest constructor is reused. controller-a alone gets ten sequential fresh simulator/provider/SDK subcases: one exact positive observation including fixed BootstrapCreateKey, six network ownership/region/subnet failures, foreign attachment, missing primary and returned-candidate mismatch. Each case starts with deep-copied response bodies. A copied provider baseline adds only the observational CreateKey tag; signed packet files and authority expectations remain untouched. Logs bind original packet bytes, baseline copy and served mutation hashes, and actual socket-returned service bytes. No IMDS private key or federation token is logged.

Positive comparison preserves instance/ETag/control compartment/image/AD/FD/shape/subnet/primary VNIC/IP/lifecycle/NSGs and adds exact CreateKey readback. The key supplies no signed scope. All nine negatives require errors.Is(err, bootstrapstart.ErrInstanceObservation) plus the exact successful response sequence. The six network negatives require4service reads, foreign attachment2, missing primary4, returned-candidate mismatch1. A transport/signer/allowlist/JSON failure cannot pass merely by returning an error; it fails the required sentinel and/or successful byte/sequence checks. Candidate mismatch changes the returned ID on the existing exact packet-candidate route, preserving the old mismatch invariant without widening route authority.

## QA selector and resources, pending separate grant

Tag: fixturetest
Package: ./tests/firecracker/production/fixturegen
Selector: ^TestCompletedPacketEmitsSignedThreeSlotCaptureAndVerifiedFloors$

candidate.json records the proposed exact wrapper argv; it has NOT RUN. Suggested bounded grant: nonblocking gate flock, outer180s, test120s, pinned Go1.27.1, unset GOROOT, prepend pinned Go bin to PATH, GOMAXPROCS2, GOFLAGS=-p=2, nice19, explicit-p1/-parallel1/-mod=readonly/-count1/-json and -tags fixturetest. Pinning PATH is necessary for the existing nested child, whose actual source argv is:

["go", "run", "../../jwtsetup", "--dir", "<t.TempDir()>/secrets", "--cell", "gru", "--brokers", "controller-a,controller-b,seed-a", "--host-node", "host-a"]

Child cwd: tests/firecracker/production/fixturegen. It inherits low CPU priority, PATH and GOFLAGS; outer test flags are not automatically child flags. The grant must explicitly include this already-existing Go run/JWT fixture-generation child. The child has not executed under the source-only grant.

Source-derived resource estimate, not measured: one compiler lane, two scheduler processors, no parallel subtests,59canonical service GETs (24existing +4CreateKey positive +31negative), plus local IMDS/federation,13listener starts with at most2active, synthetic crypto and one temporary real signed packet. Packet validation can also construct non-listening simulators and crypto. No KVM, VM, containerd, real OCI account or TerraBase binary is needed. Reserve up to8GiB for cold compilation; estimated warm execution15-60s, not a runtime receipt.

## Proposed default-build compile-only gate, NOT RUN

Both tag variants changed. A separate QA grant can compile the default test variant without running tests or fixtures:

`GOMAXPROCS=2 GOFLAGS=-p=2 nice -n 19 /home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go test -c -p 1 -mod=readonly -o <QA artifact directory>/fixturegen-default.test ./tests/firecracker/production/fixturegen`

Use unset GOROOT, pinned PATH, nonblocking gate flock and outer180s as recorded in candidate.json's proposed_default_compile_only_argv_NOT_RUN. No fixturetest tag and no test execution; the produced binary must not be invoked under that compile-only grant. This command does not launch the nested Go child or any server. The tagged exact-selector runtime is a different, separately granted invocation.

## Boundaries and validation status

Normal NewOCIInstanceObserver construction and its pinned production transport are not exercised. This is local HTTP/socket, signed-SDK/protocol, persistent signed-packet and production observer validation evidence when executed. Canonical DNS/TLS, live OCI truth, full Gate admission, packaged VM restart and F3 live witnesses remain unqualified.

Only gofmt, source inspection, exact preservation comparisons and Git whitespace checks ran. No tests/builds/lint/Go runner/server/child/live call or push occurred. Commit is source-only pending exact-candidate QA review and a separate runner grant.
