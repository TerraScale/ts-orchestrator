# Source-only stale NATS fixture correction

Child: ba75b29add6bbeea4d36d5e326cce84b7f6190b7
Actual sole parent: c466da0d2af6c08ecdbd2917773594fd447697e0
Tree: 150a1394a3e405c0b2fe5299015b83cf002d7c7a
Worktree: /tmp/ts-qa-observer-socket-rejections (clean)

Only `tests/firecracker/production/fixturegen/production_guest.go` changed, one line. The correction removes exactly `cfg.NATS.Lab || ` from the validation expression. `correction.patch` SHA256: a23d0fa53b10054084f944aabf55e479e8978c540b2a16d2bc48c43467d1e0e4. Full cumulative diff from original c748d540 base is `cumulative.patch` SHA256: 6a6a4c7b4cae664afe0f7110a0689d79c3a60dc7f23aea47677c1498d0527f50.

## Preserved validation and authority

The parent source cannot compile because `natscell.Config` no longer has `Lab`. Strict decoding still executes before the fixture checks: `protocol.DecodeStrict` calls `decode(..., true)` and JSON v2 `RejectUnknownMembers(true)` recursively rejects an unsupported `nats.lab` member. `app.Config.NATS` is the concrete `natscell.Config`; it has no Lab member, inline unknown-member collector or custom JSON unmarshal method. Decoder, schema, production TLS/JWT checks and every remaining fixture identity/material check remain byte-identical.

`preservation-proof.json` proves the child file equals the parent file with only that exact byte deletion, every other tracked entry (3673) is identical, and all three accepted c466 observer test files retain their exact SHA256. No production seam, configuration switch, signed-packet change or authentication relaxation was added.

Modern Go1.27 CLI guidance was read before the edit; no new construct was introduced. Exact source comparison and staged Git whitespace checks passed. The source correction is committed separately and has not been compiled, tested, integrated or pushed.

## Immutable preceding default compile failure

Evidence: /tmp/ts-qa-observer-default-compile-c466da0d-20261017T000417Z-081513cf
Receipt SHA256: 961f923a7b4b846ce20a5559798daafe1ab286620efc7e74affd4f6fa4e205c8
Log SHA256: 1cb4b0650072ac431a51721f55f9368de7c4941d925fc63c47a25f70cffa249a
Exit1 after 120.469806s at production_guest.go:127:12, `cfg.NATS.Lab undefined`.
Source pre/post binding retained exact c466 commit/tree/parent/clean status. No binary was produced; zero tests, nested Go children or servers executed. Prior failure history remains unchanged.

## Next gate, not executed

`candidate.json` carries the same bounded compile-only and tagged proposals for separate exact-child grants. Default compilation and tagged selector runtime are distinct grants; runtime must explicitly include the existing `go run ../../jwtsetup` child. No runner retry is authorized here. FIFO4 runtime remains with the other QA lane.
