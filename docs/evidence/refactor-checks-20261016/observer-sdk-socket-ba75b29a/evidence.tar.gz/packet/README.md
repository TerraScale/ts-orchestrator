# F2 signed-SDK socket observer evidence

Qualified source: ba75b29add6bbeea4d36d5e326cce84b7f6190b7
Tree: 150a1394a3e405c0b2fe5299015b83cf002d7c7a
Sole parent: c466da0d2af6c08ecdbd2917773594fd447697e0; original base: c748d540026fe3f2de4dcffbcd32f58bf7108286

## Results

Default compile-only PASS: exit0 in8.633949s. The73,335,471-byte binary was never executed and is omitted; its SHA256225a5556aaf49ff8bf029f59b9d88f8b970616f537dac3f50765d53ddce8f22d remains in the original receipt and omitted-binary.json.

Tagged exact selector PASS after separate QA adjudication: fixturetest / ./tests/firecracker/production/fixturegen / ^TestCompletedPacketEmitsSignedThreeSlotCaptureAndVerifiedFloors$. One root and ten subcases passed, with no skips/extras/failures. Wall62.029416s, package7.699s.59 exact socket-returned service body hashes cover24 existing three-slot reads plus35 subcase reads;18 provenance logs link original packet, copied baseline and served mutations. derived/per-case-proofs.json and original-three-slot-proof.json bind canonical routes and actual body hashes.

The original wrapper metadata remains false because it demanded byte-identical parent/child PATH. Separate immutable QA adjudication resolves that flag: Go test prepends its own pinned bin. Actual nested PATH is exactly pinned_bin + ':' + authorized parent PATH; exact child executable/hash/argv/cwd/nice19/GOMAXPROCS2/GOFLAGS-p2/unsetGOROOT verified. Full pinned Go source, snippets and hashes document base.AppendPATH behavior. The original receipt, case-results issues and raw logs are unchanged; no rerun occurred.

Historical c466 default compile failure is retained: stale cfg.NATS.Lab at production_guest.go127, exit1, no binary/tests. Separate child removes only that impossible expression; strict unknown-member decoding and every remaining auth/validation check remain unchanged. Both source-review receipts, exact patches, source snapshots and preservation proofs are included. All original test declarations/helpers and the lifecycle dependent remain.

## Scope

This qualifies the existing fixturetest constructor NewOCIInstanceObserverWithClients using actual localhost HTTP sockets, real signed OCI SDK/simulator behavior and the signed-packet/production observer assertions. The observational CreateKey supplies no signed admission scope. Default-build compilation alone performs zero observer assertions and cannot qualify this migration. Normal NewOCIInstanceObserver construction and its pinned production transport remain unexercised. Canonical DNS/TLS, live OCI, full Gate admission, packaged VM restart/native/containerd/host services, NSG migration, F3 live witness and global migration remain outside this packet.

## Verification

Top-level SHA256SUMS verifies every packet file except itself; MEMBERS.json records payload origins/hashes. Original subdirectory manifests are retained verbatim, including the deliberately omitted default binary reference. External PACKAGE.json maps every archive member/hash and records deterministic tar/gzip hashes, safe-member checks, raw JSONL gzip byte roundtrip and archive gzip byte roundtrip. Archive metadata uses sorted members, mtime0, uid/gid0, blank owner names and fixed modes.
