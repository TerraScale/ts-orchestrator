#!/usr/bin/env python3
"""Hash immutable scoped source and exact selected Go declarations. No Go runners."""
import ast
import collections
import csv
import hashlib
import json
import pathlib
import subprocess
import unicodedata

ROOT = '/tmp/ts-refactor-main-union-3d9a933e'
HEAD = 'bfca60368f60d2da67f9016d1d489317ae8749c8'
TREE = '7b0b97136b7225c4897917bf600f76d5c069560f'
OUT = pathlib.Path(__file__).parent
BASE = pathlib.Path('/tmp/ts-firstparty-test-inventory-bfca6036-20261016')
# Load pure lexical definitions only; never execute the generator's top-level actions.
parsed = ast.parse((BASE / 'generate.py').read_text())
pure = ast.Module(body=[n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name in ('letter', 'tokens', 'paired')], type_ignores=[])
exec(compile(pure, '<retained lexical definitions>', 'exec'))
SELECT = {
 'tests/firecracker/production/fixturegen/compute_inventory_sdk_test.go': ['packetSimulatorDispatcher.Do', 'assertPacketComputeSDK'],
 'tests/firecracker/production/fixturegen/complete_packet_integration_test.go': ['TestCompletedPacketEmitsSignedThreeSlotCaptureAndVerifiedFloors'],
 'tests/firecracker/production/fixturegen/compute_inventory_observer_default_test.go': ['assertPacketComputeObserver'],
 'tests/firecracker/production/fixturegen/compute_inventory_observer_fixture_test.go': ['assertPacketComputeObserver'],
 'tests/firecracker/production/fixturegen/compute_inventory.go': ['BuildComputeInventory'],
 'internal/bootstrapstart/oci_observer_fixture.go': ['NewOCIInstanceObserverWithClients'],
 'internal/bootstrapstart/oci_observer.go': ['NewOCIInstanceObserver', 'OCIInstanceObserver.ObserveInstance', 'observerRegion', 'vnicSubnetMatches'],
 'internal/bootstrapstart/oci_observer_test.go': ['TestOCIObserverRejectsNetworkOwnershipAndRegionMismatch', 'TestOCIObserverRequiresExactAttachedPrimaryVNIC', 'TestOCIObserverRejectsMissingPrimaryAndCandidateMismatch', 'observerFixture'],
 'internal/bootstrapstart/admission.go': ['Gate.observe', 'Gate.AdmitRestart'],
 'internal/bootstrapstart/derived_startup.go': ['NewDerivedOCIAdmissionClients'],
 'internal/bootstrapstart/controller_config_install.go': [],
 'internal/bootstrap/ledger_oci.go': ['NewInstancePrincipalSDKHTTPClient', 'newInstancePrincipalHTTPClient'],
 'internal/bootstrap/ledger_oci_test.go': ['TestInstancePrincipalHTTPClientClonesNoProxyTransportAndRejectsRedirects'],
 'tests/firecracker/production/simulator.go': ['Simulator.ServeHTTP', 'Simulator.serve'],
 'tests/firecracker/production/simulator_test.go': ['TestSimulatorAuthenticatesFederationAndExactServiceRead', 'TestSimulatorRejectsTamperedFederationAndStaleServiceSignature', 'TestSimulatorAcceptsSDKSignatureAcrossNetHTTPServer'],
 'internal/terrabase/oci_live_test.go': ['TestLiveOCITerraBaseHostsReadOnly', 'peerPortOpen', 'TestPeerPortOpen', 'liveEnv'],
 'internal/terrabase/contract.go': ['ParsePeers'],
 'internal/attempt/cloud_live_test.go': ['TestLiveReadOnlyCellInstancesFollowTheNamingScheme'],
 'internal/attempt/cloud.go': ['newSDKCloud', 'sdkCloud.GetInstance', 'sdkCloud.ListInstances', 'sdkCloud.ListObjects'],
 'internal/attempt/attempt.go': ['Attempt.Cell', 'Attempt.PhaseStatus', 'Attempt.Phase', 'Run', 'Attempt.waitRunning', 'Attempt.adoptMember', 'Attempt.listObjects'],
 'internal/attempt/cell_test.go': ['launchCloud.ListInstances', 'launchCloud.GetInstance'],
 'internal/attempt/services.go': ['terraBaseMembers', 'deriveTerraBase'],
 'internal/attempt/services_test.go': ['TestServicesPhaseDerivesANewCellsFirstGenerations'],
 'internal/ociclient/factory.go': ['OperatorConfig', 'PinHost', 'Factory.Compute'],
 'internal/ociclient/factory_test.go': ['TestFactoryObjectStorageRecordsHTTPAttempts'],
 'internal/naming/naming.go': ['Cell.ControllerSlot', 'Cell.Node', 'Cell.Name', 'Validate', 'IsNode'],
 'internal/naming/naming_test.go': [],
 'internal/ociregion/seed.go': ['Engine.seedLaunch', 'controllerName', 'SeedLaunchDocument'],
 'internal/cli/cli.go': ['Run', 'runOCIRegion'],
 'cmd/terrascale-orchestrator/main.go': ['main'],
 'internal/testutil/tier/tier.go': ['Integration', 'Qualification', 'Unavailable'],
}
EXTRA = ['REFACTOR.md', 'deploy/oci-region/sfo-1-plan.json', 'deploy/oci-region/plan.json',
         'Makefile', 'scripts/ci/racetest/race-test.sh', 'scripts/ci/qualify-image.sh',
         '.github/workflows/ci.yml', '.github/workflows/image.yml']

def git(*args):
    return subprocess.check_output(['git', '-C', ROOT, *args])

def digest(data):
    return hashlib.sha256(data).hexdigest()

def functions(src):
    ts = tokens(src)
    result = {}
    i, depth = 0, 0
    while i < len(ts):
        if depth == 0 and ts[i][0] == 'func':
            start = i
            i += 1
            receiver = ''
            if ts[i][0] == '(':
                stop = paired(ts, i, '(', ')')
                receiver_names = [t[0] for t in ts[i + 1:stop] if t[4] == 'identifier']
                if not receiver_names or stop + 2 >= len(ts) or ts[stop + 1][4] != 'identifier' or ts[stop + 2][0] != '(':
                    i = start + 1
                    continue
                receiver = receiver_names[-1] + '.'
                i = stop + 1
            if ts[i][4] != 'identifier':
                i = start + 1
                continue
            name = receiver + ts[i][0]
            j = i + 1
            if ts[j][0] == '[': j = paired(ts, j, '[', ']') + 1
            assert ts[j][0] == '(', (name, ts[j])
            params_end = paired(ts, j, '(', ')')
            body = params_end + 1
            while body < len(ts):
                value = ts[body][0]
                if value in ('(', '['):
                    body = paired(ts, body, value, ')' if value == '(' else ']') + 1
                    continue
                if value == '{' and ts[body - 1][0] in ('struct', 'interface'):
                    body = paired(ts, body, '{', '}') + 1
                    continue
                if value in ('{', ';', 'var', 'const', 'type'): break
                if value == 'func' and ts[body + 1][0] != '(': break
                body += 1
            end = paired(ts, body, '{', '}') if body < len(ts) and ts[body][0] == '{' else params_end
            assert name not in result, name
            result[name] = dict(symbol=name, line=ts[start][3], end_line=ts[end][3],
                                declaration_sha256=digest(src[ts[start][1]:ts[end][2]].encode()),
                                hash_definition='UTF-8 bytes from func token through matching body closing brace; excludes leading comments')
            i = end + 1
            continue
        if ts[i][4] != 'literal':
            if ts[i][0] == '{': depth += 1
            if ts[i][0] == '}': depth -= 1
        i += 1
    return result

assert set(functions('package p; type Handler func() error; var f = func() {}; func (v Value) Run() {}; func TestReal() {}')) == {'Value.Run', 'TestReal'}
old = {(r['path'], r['name']):r for r in csv.DictReader((BASE / 'declarations.tsv').open(), delimiter='\t')}
file_rows, declarations = [], []
for path in sorted(set(SELECT) | set(EXTRA)):
    oid = git('rev-parse', HEAD + ':' + path).decode().strip()
    data = git('cat-file', 'blob', oid)
    file_rows.append(dict(path=path, git_blob_oid=oid, file_sha256=digest(data), bytes=len(data),
                          scope='selected-functions/call-sites-only; not whole-file review'))
    if path not in SELECT: continue
    found = functions(data.decode())
    for symbol in SELECT[path]:
        assert symbol in found, (path, symbol)
        decl = dict(path=path, file_sha256=digest(data), **found[symbol],
                    source_review='bounded-inspected', execution='unknown', integration_closure='not-established')
        if (path, symbol) in old:
            assert old[path, symbol]['declaration_sha256'] == decl['declaration_sha256'], (path, symbol)
        declarations.append(decl)
for name, rows in [('files.tsv', file_rows), ('declarations.tsv', declarations)]:
    with (OUT / name).open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter='\t', lineterminator='\n')
        writer.writeheader(); writer.writerows(rows)
metadata = dict(head=HEAD, tree=TREE, source_files=len(file_rows), selected_declarations=len(declarations),
                source_method='Immutable Git blobs; lexical declaration spans; hashes matched accepted inventory where present.',
                classification_policy='Classify only the inspected declaration behavior; never filenames or whole directories.',
                source_review='bounded-inspected', execution='unknown', integration_only_closure='not-established',
                deletion='none; replacement evidence required before removal', runner_commands_executed=[],
                source_edits=[], cloud_calls=[])
(OUT / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))
for decl in declarations:
    if decl['symbol'] in ('Attempt.PhaseStatus', 'TestLiveReadOnlyCellInstancesFollowTheNamingScheme', 'TestLiveOCITerraBaseHostsReadOnly', 'assertPacketComputeSDK', 'TestPeerPortOpen'):
        print(decl['path'], decl['symbol'], decl['line'], decl['end_line'], decl['declaration_sha256'])
