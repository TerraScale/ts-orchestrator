#!/usr/bin/env python3
import csv
import hashlib
import json
import pathlib

P = pathlib.Path(__file__).parent
m = json.loads((P / 'metadata.json').read_text())
d = {(r['path'], r['symbol']):r for r in csv.DictReader((P / 'declarations.tsv').open(), delimiter='\t')}
files = {r['path']:r for r in csv.DictReader((P / 'files.tsv').open(), delimiter='\t')}
def ref(path, symbol):
    return {k:d[path,symbol][k] for k in ['path', 'symbol', 'line', 'end_line', 'file_sha256', 'declaration_sha256']}

findings = [
 dict(id='F1', priority='P2', kind='concrete-reachable-production-observation-defect',
      title='Bootstrap status omits current SFO controller names',
      evidence=[ref('internal/attempt/attempt.go','Attempt.PhaseStatus'), ref('internal/cli/cli.go','runOCIRegion'),
                ref('internal/ociregion/seed.go','Engine.seedLaunch'), ref('internal/ociregion/seed.go','controllerName'),
                ref('internal/naming/naming.go','Cell.ControllerSlot')],
      trigger='An SFO attempt with a non-TERMINATED ts-sfo-1 instance returned by OCI ListInstances.',
      actual='PhaseStatus constructs sfo-1 and filters strings.HasPrefix(displayName, "sfo-1-"); it emits no status row for ts-sfo-1.',
      expected='The retained infrastructure status boundary reports the node names the production SFO seed/profile path emits.',
      production_witness='Checked-in SFO plan -> Engine.seedLaunch -> controllerName -> Cell.ControllerSlot -> ts-sfo-1 -> SeedLaunchDocument.displayName. This is a source-derived witness, not a live OCI observation or executed reproduction.',
      reachability='main -> cli.Run case oci-region -> runOCIRegion case attempt -> attempt.Run -> Attempt.Phase("status") -> Attempt.PhaseStatus.',
      disposition='Retained infrastructure observation correction; no evidence authorizes deleting this live CLI or retaining the entire mixed-purpose attempt package.',
      smallest_correction='Accept existing naming.IsNode(displayName, cellRegion) as well as the supported legacy cell prefix, keeping the existing TERMINATED exclusion. Preserve the intentional GRU ControllerSlot legacy mapping; do not rewrite generic task/scheduler phases.',
      required_scenario='Drive PhaseStatus (or its retained CLI owner) with production sdkCloud backed by real OCI SDK clients talking HTTP to a local OCI protocol simulator. Return paginated current and legacy node rows; assert status output and page requests, current-data-name/foreign-region/TERMINATED exclusions, and propagated later-page errors. Do not replace Cloud with a canned ListInstances fake or mirror the string predicate in an isolated test.',
      execution='unknown; not run', closure='open'),
 dict(id='F2', priority='review-gate', kind='source-proven-isolated-cases-require-migration',
      title='Required negative cases still include isolated helper/fake-API checks',
      evidence=[ref('internal/terrabase/oci_live_test.go','TestPeerPortOpen'),
                ref('internal/bootstrapstart/oci_observer_test.go','TestOCIObserverRejectsNetworkOwnershipAndRegionMismatch'),
                ref('internal/bootstrapstart/oci_observer_test.go','TestOCIObserverRequiresExactAttachedPrimaryVNIC'),
                ref('internal/bootstrapstart/oci_observer_test.go','TestOCIObserverRejectsMissingPrimaryAndCandidateMismatch')],
      actual='TestPeerPortOpen calls a test-only predicate on locally constructed rule maps. The three observer cases construct an observer over in-memory fake Compute/Network APIs. No service, network, persistent store or runtime boundary is crossed by those cases.',
      disposition='Bounded behavior-based unit-case finding under REFACTOR:1054-1095. It is not a classification of their files or helpers used by real boundary scenarios.',
      smallest_correction='Move NSG failure cases into the owning SDK/API-backed observation scenario and observer rejection cases into the existing signed-packet/SDK/simulator flow with the production observer variant; retain safeguards and remove old cases/helpers only after replacement evidence exists. Do not delete shared packet SDK/simulator infrastructure.',
      execution='unknown; not run', closure='open; no deletion performed'),
 dict(id='F3', priority='closure-gap', kind='vacuous-or-partial-live-witness-and-runner-gap',
      title='Passing live selectors need not witness hosts or instance readback',
      evidence=[ref('internal/terrabase/oci_live_test.go','TestLiveOCITerraBaseHostsReadOnly'),
                ref('internal/attempt/cloud_live_test.go','TestLiveReadOnlyCellInstancesFollowTheNamingScheme')],
      actual='The TerraBase entry explicitly returns successfully after regional checks when no matching hosts exist; with one host, no ordered peer pair is checked. The attempt entry asserts GetInstance/naming only inside returned-row loops and requires no row or matching-prefix witness. Both entries are absent from the seven image qualification selectors and skip on missing fixtures in ordinary runs.',
      disposition='These are source-proven limits, not a claim that their documented regional/read-only purpose is itself a production bug. No passing suite receipt can be inferred.',
      smallest_correction='Define the retained live acceptance witness, assert its required nonempty identities/counts, and route that dedicated selector through an owner-supplied qualification fixture with no selected skips. Keep offline protocol evidence distinct; do not add another switch or broaden this task into cloud execution.',
      execution='unknown; not run', closure='open'),
]

boundaries = [
 dict(id='C1', candidate='tests/firecracker/production/fixturegen/compute_inventory_sdk_test.go',
      entry=ref('tests/firecracker/production/fixturegen/complete_packet_integration_test.go','TestCompletedPacketEmitsSignedThreeSlotCaptureAndVerifiedFloors'),
      helper=ref('tests/firecracker/production/fixturegen/compute_inventory_sdk_test.go','assertPacketComputeSDK'),
      source_contract='Signed three-slot packet/file material -> real instance-principal OCI SDK federation and signed service reads -> project Simulator API -> decoded instance/VNIC/subnet fields. Under fixturetest, the same SDK clients also enter production OCIInstanceObserver.ObserveInstance.',
      assertion_scope=['The caller writes/reads a signed packet with synthetic executable bytes and three completed histories, checks floors/lock/files/routes, invokes the SDK helper per slot, and verifies the embedded image receipt.',
                       'The helper requires instance ID/ETag/identity presence and lifecycle; exactly one attached VNIC; primary VNIC identity/IP/lifecycle; separate network compartment and expected subnet/VCN; all audited requests listed/200 and a bounded exact Compute request count.',
                       'The fixturetest helper compares the production observer result against expected instance, ETag, control compartment, image/AD/FD/shape, subnet/primary VNIC/IP/lifecycle and NSGs. Default helper returns zero and performs no observer assertions.'],
      negative_evidence=['Adjacent simulator tests inspect wrong session key, changed signed query, write method, tampered federation and stale signature rejection. These are source assertions, not execution receipts.',
                         'Observer rejection tests inspect wrong VNIC/subnet ownership, wrong/missing VCN, unavailable subnet, foreign attachment, missing primary and candidate mismatch; these use in-memory fake APIs and require migration under integration-only policy.',
                         'A separate transport test actually uses localhost HTTP redirect/target servers and inspects no-proxy cloning, timeout and redirect rejection. Its source existence prevents a claim that transport coverage is absent repository-wide.'],
      gaps=['This scenario dispatches directly into Simulator.ServeHTTP through httptest.NewRecorder: no socket, DNS, TLS, real OCI account or normal OCIInstanceObserver constructor/transport is exercised.',
            'The positive packet has one attachment page; duplicate primaries, repeated/nonempty continuation tokens, over-64 attachments, API transport/error response and deadline cases are not asserted in this selected entry/helper path.',
            'Packet observations are generated from the same signed recipe used for expectations. This verifies protocol/model and binding consistency; it is not independent evidence of live cloud truth or a complete admission decision. Gate.observe/AdmitRestart enforce further signed identity/lifecycle comparisons.'],
      runner='Default root T0/T1 reach the entry subject to compilation/discovery. T1 ci-verify adds fixturetest-check to reach the production observer tag variant; PR excludes that target. Neither variant has an explicit seven-suite T2 image selector.',
      source_behavior='Offline real-component protocol/store scenario with a helper; no whole-file classification.', source_review='bounded-inspected', execution='unknown', integration_closure='not-established'),
 dict(id='C2', candidate='internal/terrabase/oci_live_test.go',
      entry=ref('internal/terrabase/oci_live_test.go','TestLiveOCITerraBaseHostsReadOnly'),
      source_contract='OperatorConfig-backed OCI SDK read APIs -> regional A1 shape/quota/image evidence -> selected running-host attachment/VNIC/NSG evidence -> ParsePeers and ingress-rule predicate.',
      assertion_scope=['Requires compartment fixture and API success; checks a matching A1 shape/Ampere description, minimum profile options, summed quota availability and at least one Ubuntu image.',
                       'For matching hosts with primary attached VNICs, checks A1 shape, parseable peer addresses, fault-domain separation when member count <=3, unique parsed peer names/addresses and an allowed ingress rule per ordered distinct-name pair.'],
      negative_evidence=['The separate TestPeerPortOpen rejects a mismatching destination port, wrong sender group and unrelated CIDR; it supplies in-memory maps to a test-only helper.',
                         'API errors and observed mismatches fail through assertions; no controlled live-API negative fixture is selected here.'],
      gaps=['Zero members return success explicitly; one member tests no pair. Default prefix targets the documented legacy GRU database hosts and does not establish coverage of every colocated/current node.',
            'peerPortOpen checks source CIDR/NSG and destination-port allowance, not an actual connection, egress, route table, security lists or application listener; it ignores TCP source-port constraints. Static ingress allowance is the strongest supported claim.',
            'Shape/image/instance/VNIC/NSG lists make individual bounded requests without exhausting continuation pages in this test. Optional numeric Shape option pointers are dereferenced without individual nil guards; malformed/partial model responses can panic.',
            'ParsePeers proves serialization/uniqueness, not signed runtime identity, ready state, actual peer handshake or replicated data behavior.'],
      runner='Direct tier.Qualification requires TS_OCI_LIVE_COMPARTMENT_ID: ordinary missing fixtures skip even in full runs; qualification missing fixture fails. Not selected by the seven-suite image runner. TestPeerPortOpen is independently discoverable without the fixture.',
      source_behavior='Live read-only SDK entry when fixtures exist, plus a distinct isolated helper case; no whole-file classification.', source_review='bounded-inspected', execution='unknown', integration_closure='not-established'),
 dict(id='C3', candidate='internal/attempt/cloud_live_test.go',
      entry=ref('internal/attempt/cloud_live_test.go','TestLiveReadOnlyCellInstancesFollowTheNamingScheme'),
      source_contract='Operator SDK cloud -> paginated OCI ListInstances -> GetInstance readback -> legacy-GRU-prefix naming validation. Connected production owners include bootstrap PhaseStatus, waitRunning and adoptMember.',
      assertion_scope=['newSDKCloud creates the shared OperatorConfig-backed production SDK adapter in GRU. ListInstances follows page tokens up to maxPages=256; the test GetInstance checks ID/display-name agreement for every returned row.',
                       'Only non-TERMINATED rows beginning gru-1- enter naming.Validate. API errors or mismatched readback fail; the entry never mutates cloud resources.'],
      negative_evidence=['Naming package examples include current ts-gru/ts-sfo nodes, foreign/invalid name cases, and intentional legacy GRU controller names; the live selector covers only its GRU legacy prefix.',
                         'Connected adoption tests use launchCloud to reject retained-launch mismatches. They do not exercise the production SDK HTTP/pagination boundary or fix the PhaseStatus output gap.'],
      gaps=['Empty lists require no GetInstance or naming witness. New-format GRU names and other regions do not enter this test naming guard, including invalid current-format strings with that different prefix.',
            'A naturally occurring fixture does not force multiple pages, later-page errors, repetition/page-bound exhaustion, normalization mismatches or cancellation. Those outcomes are unknown from this entry.',
            'The test never calls PhaseStatus or asserts CLI output. Production SFO status omission therefore survives this read-only adapter/naming check. It also does not establish launch/adoption safety or create-key/material identity.'],
      runner='Direct tier.Qualification requires TS_OCI_LIVE_COMPARTMENTS; ordinary missing fixtures skip. Not selected by the seven-suite image runner. Root ordinary execution and all fixture results remain unknown.',
      source_behavior='Live read-only SDK/naming entry when supplied; no execution or complete integration claim.', source_review='bounded-inspected', execution='unknown', integration_closure='not-established'),
]
review = dict(metadata=m, findings=findings, boundaries=boundaries,
              recommendation='Correct only the retained reachable OCI status observation boundary after owner review; migrate isolated negative cases into owning SDK/API scenarios before any deletion. Do not expand or permanently retain superseded attempt service/scheduler phases.',
              ownership_evidence='REFACTOR:206-237 permits read-only observations and retains OCI capacity/resources, regional/bootstrap and CLI. :243-251 requires caller/responsibility disposition; :1054-1104 requires integration-only migration and real boundary scenarios before deletion. No attempt-specific package disposition was found in REFACTOR.',
              witness_status='Source-derived deterministic counterexample, not an executed Go/CLI or live-cloud reproduction.',
              unknowns=['No runner discovery, build, race result, cloud fixture or live read was executed.',
                        'No repository-wide test classification, deletion inventory or integration-only completion claim.',
                        'No complete audit of every method in the 39 hashed files; declaration/call-site scope only.',
                        'Future retention/deletion of the full mixed-purpose attempt package remains owner-led and unproved by this review.'])
(P / 'review.json').write_text(json.dumps(review, indent=2) + '\n')

lines = ['# Bounded OCI contract review','',f"Frozen HEAD: `{m['head']}`  ",f"Frozen tree: `{m['tree']}`",'',
         '**One concrete defect:** reachable bootstrap status omits current SFO node names. The three reviewed contracts have source evidence for narrower boundaries; execution and integration-only closure remain unknown.','',
         f"Scope: three primary contracts, their selected entry/caller/helper/owner sites and runner policy. Hash coverage: {m['source_files']} source files / {m['selected_declarations']} selected declarations. Hashing a file does not mean every declaration was audited.",'',
         '## Findings and smallest corrections','']
for finding in findings:
    lines += [f"### {finding['id']} — {finding['priority']}: {finding['title']}",'']
    if finding['id'] == 'F1':
        lines += [finding['trigger'], '', finding['actual'], '', '**Reachability:** ' + finding['reachability'], '', '**Production witness:** ' + finding['production_witness'], '',
                  'GRU remains intentionally different: `Cell.ControllerSlot` retains `gru-1-ctl-N`, whereas SFO uses `ts-sfo-N`. `Cell.Node`/`IsNode` support current node names and naming tests cover both formats. A naming migration inferred from comments alone is not the basis of this finding.','',
                  '**Disposition:** ' + finding['disposition'], '', '**Smallest correction:** ' + finding['smallest_correction'], '',
                  '**Meaningful regression scenario:** ' + finding['required_scenario'], '',
                  'Use the existing production SDK adapter, not a fake `Cloud`: `ociclient.New(...).Compute()` plus SDK ObjectStorage clients can target a localhost simulator through the existing `PinHost` test pattern. Back the attempt plan/state with real temporary files and supply signed/local test credentials. Serve the actual ListObjects calls before the control/workload Compute lists. Verify page query, requested compartments, decoded display names and emitted rows. Keep production configuration free of new knobs.','',
                  'The minimum predicate addition uses existing `naming.IsNode(name, region)` with the supported legacy prefix. `IsNode` rejects `ts-sfo-1-data`, foreign regions and invalid indices. The existing TERMINATED test remains outside that disjunction. OCI ListInstances never returns block-volume resources; the scenario should still include a current data-name row to detect a broad `ts-*` shortcut. Preserve intended legacy instance support; do not infer that legacy data-volume names become valid instance identities.','']
    else:
        lines += [finding['actual'], '', '**Disposition:** ' + finding['disposition'], '', '**Smallest next correction:** ' + finding['smallest_correction'], '']
    lines += ['Evidence declarations:', '']
    for evidence in finding['evidence'][:5]:
        lines += [f"- `{evidence['path']}:{evidence['line']}` — `{evidence['symbol']}`"]
    lines += ['']
lines += ['## Contract boundaries, in requested review order','']
for boundary in boundaries:
    lines += [f"### {boundary['id']} — `{boundary['candidate']}`",'',boundary['source_contract'], '', '**What the source asserts:**', '']
    lines += ['- ' + text for text in boundary['assertion_scope']]
    lines += ['', '**Existing negative evidence:**', '']
    lines += ['- ' + text for text in boundary['negative_evidence']]
    lines += ['', '**Remaining gaps:**', '']
    lines += ['- ' + text for text in boundary['gaps']]
    lines += ['', '**Runner exposure:** ' + boundary['runner'], '', '**Disposition:** ' + boundary['source_behavior'], '',
              '**Status:** bounded source inspection complete; execution unknown; integration closure not established.','']
lines += ['## Ownership and deletion decision','',review['ownership_evidence'],'',review['recommendation'],'',
          'PhaseStatus is a read-only infrastructure/bootstrap inventory: its selected body calls object/instance list APIs and prints observations. It contains no task assignment, Machines planner or native task-execution call. This narrow fact does not clear other phases in the same package. Removing this command requires a replacement CLI/API caller migration and retained observation scenario; that evidence is absent here.','',
          'The packet SDK helper, controlled protocol simulator and production-observer fixture serve a real connected scenario. They are not shown to be unit-only infrastructure. Conversely, the inspected TestPeerPortOpen and fake-API observer cases are isolated by their actual bodies and need migration under the explicit integration-only policy. Never delete the complete mixed-purpose files on these local classifications.','',
          '## Hashes and reproducibility','',
          '`files.tsv` records full file SHA-256 and Git blob OID for all source references. `declarations.tsv` records exact selected declaration SHA-256 with source/end lines. Declaration hashes cover UTF-8 bytes from the `func` token through the matching body closing brace, excluding leading comments. The method is lexical, not compiler discovery; accepted inventory declaration hashes were checked wherever available.','',
          '| Primary declaration | File SHA-256 | Declaration SHA-256 |','| --- | --- | --- |']
for boundary in boundaries:
    evidence = boundary.get('helper', boundary['entry'])
    lines += [f"| `{evidence['path']}:{evidence['line']}` / `{evidence['symbol']}` | `{evidence['file_sha256']}` | `{evidence['declaration_sha256']}` |"]
evidence = ref('internal/attempt/attempt.go','Attempt.PhaseStatus')
lines += [f"| `{evidence['path']}:{evidence['line']}` / `{evidence['symbol']}` | `{evidence['file_sha256']}` | `{evidence['declaration_sha256']}` |",'',
          '`collect.py` reads immutable Git blobs and hashes selected lexical declarations. `verify.py` independently reconstructs declaration bytes from physical line spans and rechecks all scoped Git file bindings; its receipt is `verification.json`. `render.py` renders these notes and structured `review.json`. All write only alongside themselves in `/tmp`. `SHA256SUMS` seals all artifacts except itself. The accepted inventory/proposal artifacts were preserved.','',
          '**Not performed:** source edits, Go runners, builds, lint/race, cloud calls, exhaustive source review, deletions or integration-only closure. No runtime success is implied by a source assertion.','',
          'Next: have the OCI/bootstrap owner apply F1 only at the retained status boundary and qualify its real-SDK HTTP/pagination scenario before considering deletion of superseded dependents.','']
(P / 'REVIEW.md').write_text('\n'.join(lines))
names = ['collect.py','render.py','verify.py','files.tsv','declarations.tsv','metadata.json','review.json','verification.json','REVIEW.md']
(P / 'SHA256SUMS').write_text(''.join(hashlib.sha256((P/name).read_bytes()).hexdigest() + '  ' + name + '\n' for name in names))
for name in ['REVIEW.md','SHA256SUMS']:
    print(name, hashlib.sha256((P/name).read_bytes()).hexdigest())
