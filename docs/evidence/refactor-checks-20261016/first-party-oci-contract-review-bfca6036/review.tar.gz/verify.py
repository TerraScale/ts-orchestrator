#!/usr/bin/env python3
"""Independent file/line-span hash checks only; no project runners or runtime claims."""
import csv
import hashlib
import json
import pathlib
import subprocess

P = pathlib.Path(__file__).parent
ROOT = '/tmp/ts-refactor-main-union-3d9a933e'
m = json.loads((P / 'metadata.json').read_text())
def git(*args):
    return subprocess.check_output(['git','-C',ROOT,*args])
def digest(data):
    return hashlib.sha256(data).hexdigest()
assert git('rev-parse', m['head'] + '^{tree}').decode().strip() == m['tree']
sources = {}
rows = list(csv.DictReader((P / 'files.tsv').open(), delimiter='\t'))
for row in rows:
    oid = git('rev-parse', m['head'] + ':' + row['path']).decode().strip()
    data = git('cat-file','blob',oid)
    assert oid == row['git_blob_oid'] and digest(data) == row['file_sha256']
    assert len(data) == int(row['bytes'])
    sources[row['path']] = data
declarations = list(csv.DictReader((P / 'declarations.tsv').open(), delimiter='\t'))
for row in declarations:
    data = sources[row['path']]
    lines = data.splitlines(keepends=True)
    block = b''.join(lines[int(row['line'])-1:int(row['end_line'])])
    block = block[block.index(b'func '):block.rfind(b'}')+1]
    assert digest(data) == row['file_sha256']
    assert digest(block) == row['declaration_sha256'], (row['path'],row['symbol'])
assert len(rows) == m['source_files'] == 39
assert len(declarations) == m['selected_declarations'] == 66
assert not m['runner_commands_executed'] and not m['source_edits'] and not m['cloud_calls']
result = dict(status='PASS', source_files=39, exact_line_span_declaration_hashes=66,
              head=m['head'], tree=m['tree'],
              checks=['Frozen commit/tree binding','All scoped Git blob OIDs / file SHA256 / sizes','Independent physical-line reconstruction of all 66 declaration SHA256 hashes'],
              runtime_validation='none; no project runner invoked')
(P / 'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
