#!/usr/bin/env python3
"""Render the source-only evidence report and seal artifact hashes. No Go commands."""
import collections
import csv
import fnmatch
import hashlib
import json
import pathlib

P = pathlib.Path(__file__).parent
m = json.loads((P / 'metadata.json').read_text())
files = list(csv.DictReader((P / 'files.tsv').open(), delimiter='\t'))
decls = list(csv.DictReader((P / 'declarations.tsv').open(), delimiter='\t'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

suites = [
    ('terrabase-walkthrough', 'internal/app', 'TestTerraBaseWalkthroughAgainstRealMembers'),
    ('terrabase-successor', 'internal/managedmaterial', 'TestProduceSuccessorRustInterop'),
    ('native-validator', 'internal/managedmaterial', 'TestPrepareInitialUsesAdmittedPackagedNativeValidator'),
    ('rendered-sfo-enrollment', 'internal/app', 'TestManagedPlacementEnrollmentFromRenderedSFOBundle'),
    ('terrabase-binary', 'internal/terrabase', 'TestTerraBaseBinaryPeerMesh'),
    ('terrabase-release', 'internal/app', 'TestTerraBaseReleaseDeployUpgradeRollback'),
    ('ts-auth-terrabase', 'internal/tsauth', 'TestBootstrapAgainstTerraBaseRelease'),
]
suite_rows = []
for suite, package, name in suites:
    found = [d for d in decls if str(pathlib.PurePosixPath(d['path']).parent) == package and d['name'] == name]
    assert len(found) == 1, (suite, found)
    d = found[0]
    suite_rows.append(dict(suite=suite, package='./' + package, selector='^' + name + '$',
                           path=d['path'], line=d['line'], file_sha256=d['file_sha256'],
                           declaration_sha256=d['declaration_sha256'],
                           selection_status='explicit-selector-present-in-source', runtime_closure='unknown'))
with (P / 'qualification-selectors.tsv').open('w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(suite_rows[0]), delimiter='\t', lineterminator='\n')
    w.writeheader(); w.writerows(suite_rows)
patterns = ['TestFounderRuntime*', 'TestFounderReplacement*', 'TestReplacement*',
            'TestFencedReplacementStopsBeforeEveryMutation', 'TestFounderFloorArtifactsMatchInitializedPeerFloor']
norace_rows = []
for pattern in patterns:
    for d in decls:
        if str(pathlib.PurePosixPath(d['path']).parent) == 'internal/bootstrapstart' and d['kind'] == 'test' and fnmatch.fnmatchcase(d['name'], pattern):
            norace_rows.append(dict(pattern=pattern, path=d['path'], name=d['name'], line=d['line'],
                                    file_sha256=d['file_sha256'], declaration_sha256=d['declaration_sha256'],
                                    match_status='static-name-match-build-selection-unknown', execution_closure='unknown'))
with (P / 'norace-static-matches.tsv').open('w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(norace_rows[0]), delimiter='\t', lineterminator='\n')
    w.writeheader(); w.writerows(norace_rows)
assert len(norace_rows) == 37
assert len({(r['path'],r['name']) for r in norace_rows}) == 37
assert len(files) == 1036 and len(decls) == 5986
assert all(d['review_closure'] == d['execution_closure'] == 'unknown' for d in decls)
assert all(d['classification'] == 'unclassified' for d in decls)
assert digest(pathlib.Path(m['draft']['path'])) == m['draft']['sha256']
table = '\n'.join('| ' + ' | '.join([r['suite'], r['package'], '`' + r['selector'] + '`']) + ' |' for r in suite_rows)
report = f'''# First-party Go test source inventory

Frozen HEAD: `{m['head']}`  
Frozen tree: `{m['tree']}`  
Generated UTC: {m['generated_utc']}

## Verified artifact scope

The inventory contains **1,036 tracked first-party `_test.go` blobs**, read from immutable Git objects at the exact HEAD above. Every `third_party`, `vendor`, and `.git` path component is excluded. Both root-module and nested-module files are included. Working-tree status was empty before and after generation. Nothing in the source worktree was changed.

| Declaration kind | Lexical count |
| --- | ---: |
| Test candidates | 4,319 |
| TestMain candidates | 4 |
| Benchmark / Fuzz / Example candidates | 0 / 0 / 0 |
| Named non-method helper functions | 1,663 |
| Total recorded declarations | 5,986 |

996 files contain a Test or TestMain candidate; 40 have neither. Helpers, constants, methods, fixtures and build variants can still make those 40 files necessary. This report makes no deletion recommendation. All 4,323 entry candidates have lexically compatible signatures; none were typechecked. No lexical extraction errors were recorded.

## Explicit unknown closure

| Question | Status |
| --- | --- |
| Unit / integration contract classification | **Unclassified** for all 1,036 files and 5,986 declaration records |
| Manual source / assertion review | **Unknown** for every record; no exhaustive manual review |
| Test execution, race results, reliability | **Unknown** for every record; no runners executed |
| Exact package/build selection under any runner | **Unknown**, not evaluated |
| Integration quality or end-to-end completeness | **Unknown**; no inference from names, directories, or direct tier calls |

The artifact is a source declaration inventory, not a claim that 4,319 tests were discovered, executed or passed. No classification from the old draft was promoted. No original artifact was deleted or modified.

## Old draft provenance

`{m['draft']['path']}` has SHA-256 `{m['draft']['sha256']}` and 1,012 data rows. Its recorded 8,418 test and 323 benchmark declarations remain **unverified draft counts**. It has no producing command, commit/tree binding, per-file hashes, or classification/closure evidence. The existing inventory owner reported no verified producing command or source snapshot; that owner's authoritative inventory concerned vendored NATS only.

`docs/evidence/refactor-recovery-20261016.md:69` mentions the TSV. A mention and filesystem mtime do not establish the producing source snapshot. The evidence document's own snapshot commits cannot be assigned to the TSV without evidence.

The draft includes 131 `third_party` rows, outside this audit's scope; it has 881 first-party rows. First-party path comparison: **862 shared, 19 draft-only, 174 frozen-only**. `draft-comparison.tsv` excludes third-party paths and preserves old counts beside refreshed counts, including a separate Test-plus-TestMain alternate. Shared paths or matching counts do not prove identical old bytes or scanner semantics. Draft-only does not establish a deletion or a defect.

## Runner policy observed in frozen source

1. **T0 PR:** `.github/workflows/ci.yml` sets `TS_TEST_TIER=pr`; `Makefile` routes to `scripts/ci/racetest/race-test.sh`, whose PR mode adds `-short`. `tier.Integration` skips only when `testing.Short()`. T0 is therefore not a verified unit-only selection.
2. **T1 pushes:** `TS_TEST_TIER=full` omits `-short`; `ci-verify` also runs `fixturetest-check` (`go vet -tags fixturetest ./...` and fixturegen `go test -tags fixturetest`). Plain `make test` uses `go test ./...`; `test-fast` uses `go test -short ./...`.
3. **Race scheduler:** root-module package discovery uses `go list ./...`. It shards `internal/app`, `internal/bootstrapstart`, `internal/natscell`, and `tests/deploy`; other discovered packages run together. Sharded listing uses `go test -race -vet=off -list '.*'`, then ASCII `^(Test|Example|Fuzz)[A-Za-z0-9_]*$`. Its packed-count check covers only those selected listed names. Scheduling classes and duration estimates do not establish test contracts.
4. **T2 image:** the seven explicit selectors below share 600 seconds. `TS_TEST_TIER=qualification` makes missing fixtures fatal through the tier helper. The shell runner rejects any selected SKIP or absence of a top-level PASS. `image.yml` supplies all seven before image build when its gate proceeds. Presence of these rules is source evidence, not a successful qualification receipt.
5. **Nested module:** `e2e/go.mod` owns 3 test files / 9 Test candidates. Root `./...` does not automatically cover it. `.github/workflows/e2e.yml` separately runs `go test -race ./...`, vet and build from `e2e`, then the E2E driver. Workflow triggers and actual executions were not audited beyond source inspection.

`tier.Qualification` skips for missing fixtures in ordinary runs, fails for missing fixtures in qualification, and can run outside qualification when fixtures exist. It requires at least one fixture name. `tier.Unavailable` similarly skips ordinarily and fails in qualification. Ordinary CI can pass with skips. Indirect helper calls and tests missing a tier gate cannot be ruled out by this inventory.

| Qualification suite | Package | Selector |
| --- | --- | --- |
{table}

The seven selectors each resolve to one lexically observed declaration in this snapshot; file and declaration hashes are in `qualification-selectors.tsv`. This confirms source presence only. `CONTRIBUTING.md:116` says “eight” suites, while the actual script and workflow enumerate seven; this report follows executable source.

## Explicit coverage exceptions and limits

1. **Race exceptions:** `race-durations.txt` assigns `internal/bootstrapstart` patterns `TestFounderRuntime*`, `TestFounderReplacement*`, `TestReplacement*`, `TestFencedReplacementStopsBeforeEveryMutation`, and `TestFounderFloorArtifactsMatchInitializedPeerFloor` to `norace`. Static matches are 30, 3, 2, 1 and 1 declarations (37 distinct), preserved in `norace-static-matches.tsv`. Runtime selection remains unknown.
2. **Qualification exceptions:** the runner comments exempt `TestBackupGoRust*ProcessBridge` D10 children because a Rust parent supplies packets/results. Firecracker qualification uses `ts-orch qualification firecracker ...` on KVM outside this script. These comments explain intent, not proof those paths ran elsewhere. Seven selectors do not exhaust all qualification-gated source declarations.
3. **Scope exceptions:** the separate vendored NATS module and its `nats-identity-check` regression are excluded. 50 first-party test files carry leading build constraints; the three nested-module files have separate discovery. GOOS/GOARCH filename rules, build tags, toolchain, cgo, testdata and dot/underscore directory rules were not evaluated into runner inclusion. A textual declaration can be excluded from a given build.
4. **Execution limits:** no benchmark run (`-bench`) or fuzz campaign (`-fuzz`) is present in these tier runners; fuzz seed cases can run under ordinary Go tests. TestMain executes per package binary rather than as an individually listed test. Subtests, generated tests, registrations and runtime case counts are not enumerated.
5. **Scanner limits:** a Python lexical tokenizer skips comments, interpreted/raw strings and runes, scans package-level named non-method functions, and applies Go-style entry-name casing plus syntactic testing-parameter checks. It is not a Go parser/typechecker and does not validate all grammar, aliases, shadowing, example output rules or compiler discovery. Direct tier observations (17 Integration, 14 Qualification, 3 Unavailable call expressions across 30 Test and 4 helper declarations) are syntactic only; alias shadowing, indirect helpers, reachability and fixture contracts remain unknown.

## Artifact use

`files.tsv` binds every file to Git blob OID and SHA-256, build preamble observations, counts and unknown statuses. `declarations.tsv` adds source lines, declaration hashes, candidate signature status and direct tier observations. Both use the exact HEAD/tree recorded in `metadata.json`; filenames alone carry no classification.

`generate.py` reproduces the source scan, comparison and metadata. `finish.py` renders this report and runner selector artifacts. They write only beside themselves under `/tmp`; no Go, build, test, lint or race command is invoked. Synthetic scanner assertions passed; those checks are not repository test evidence. Automated scanning covered every scoped blob; manual inspection stayed bounded to runner sources and selected snippets, not more than 1,000 files.

`SHA256SUMS` seals every artifact here except itself. The original draft SHA is rechecked. Required next evidence for classification or closure is a bounded contract review plus applicable runner receipts bound to this exact source; neither exists in this inventory.
'''
(P / 'REPORT.md').write_text(report)
names = ['generate.py', 'finish.py', 'files.tsv', 'declarations.tsv', 'metadata.json',
         'draft-comparison.tsv', 'qualification-selectors.tsv', 'norace-static-matches.tsv', 'REPORT.md']
(P / 'SHA256SUMS').write_text(''.join(digest(P / name) + '  ' + name + '\n' for name in names))
print(report[:1100])
print('REPORT.md SHA256', digest(P / 'REPORT.md'))
print('SHA256SUMS SHA256', digest(P / 'SHA256SUMS'))
