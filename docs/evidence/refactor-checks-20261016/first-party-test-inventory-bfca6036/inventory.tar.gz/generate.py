#!/usr/bin/env python3
"""Source-only lexical inventory. Reads immutable Git objects; writes only /tmp artifacts."""
import collections
import csv
import datetime
import hashlib
import io
import json
import pathlib
import re
import subprocess
import unicodedata

ROOT = pathlib.Path('/tmp/ts-refactor-main-union-3d9a933e')
OUT = pathlib.Path(__file__).parent
HEAD = 'bfca60368f60d2da67f9016d1d489317ae8749c8'
TREE = '7b0b97136b7225c4897917bf600f76d5c069560f'
OLD = pathlib.Path('/tmp/ts-refactor-qa-test-inventory.tsv')
REFS = ['internal/testutil/tier/tier.go', 'internal/testutil/tier/tier_test.go',
        'Makefile', 'scripts/ci/racetest/race-test.sh', 'scripts/ci/racetest/race-durations.txt',
        'scripts/ci/qualify-image.sh', '.github/workflows/ci.yml', '.github/workflows/image.yml',
        '.github/workflows/e2e.yml', 'CONTRIBUTING.md', 'docs/testing.md',
        'docs/evidence/refactor-recovery-20261016.md']

def git(*args, data=None):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], input=data)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def letter(c):
    return c == '_' or unicodedata.category(c).startswith('L')

def tokens(src):
    # Offsets are Unicode character offsets, not byte offsets; hashes use re-encoded UTF-8.
    result = []
    i, line = 0, 1
    while i < len(src):
        c, start, ln = src[i], i, line
        if c.isspace():
            line += c == '\n'
            i += 1
            continue
        if src.startswith('//', i):
            j = src.find('\n', i + 2)
            i = len(src) if j < 0 else j
            continue
        if src.startswith('/*', i):
            j = src.find('*/', i + 2)
            if j < 0:
                raise ValueError('unterminated block comment')
            i = j + 2
            line += src[start:i].count('\n')
            continue
        if c in '\"\'`':
            quote = c
            i += 1
            while i < len(src):
                if src[i] == quote:
                    i += 1
                    break
                if quote != '`' and src[i] == '\\':
                    i += 2
                else:
                    i += 1
            else:
                raise ValueError('unterminated string/rune literal')
            line += src[start:i].count('\n')
            kind = 'literal'
        elif letter(c):
            i += 1
            while i < len(src) and (letter(src[i]) or unicodedata.category(src[i]) == 'Nd'):
                i += 1
            kind = 'identifier'
        else:
            i += 1
            kind = 'punctuation'
        result.append((src[start:i], start, i, ln, kind))
    return result

def paired(ts, start, left, right):
    depth = 0
    for j in range(start, len(ts)):
        if ts[j][4] == 'literal':
            continue
        if ts[j][0] == left:
            depth += 1
        elif ts[j][0] == right:
            depth -= 1
            if depth == 0:
                return j
    raise ValueError('unbalanced ' + left)

def imports(ts, path):
    aliases = []
    depth = 0
    for i, token in enumerate(ts):
        value = token[0]
        if value == '{': depth += 1
        if value == '}': depth -= 1
        if depth or value != 'import': continue
        j = i + 1
        end = paired(ts, j, '(', ')') if ts[j][0] == '(' else min(len(ts), j + 2)
        for k in range(j, end + 1):
            if k >= len(ts): break
            if ts[k][0] in ('"' + path + '"', '`' + path + '`'):
                previous = ts[k - 1]
                aliases.append(previous[0] if (previous[4] == 'identifier' and previous[0] != 'import') or previous[0] == '.' else path.rsplit('/', 1)[-1])
    return aliases

def entry_kind(name):
    if name == 'TestMain': return 'testmain'
    for prefix, kind in [('Test', 'test'), ('Benchmark', 'benchmark'), ('Fuzz', 'fuzz'), ('Example', 'example')]:
        if name.startswith(prefix) and (name == prefix or unicodedata.category(name[len(prefix)]) != 'Ll'):
            return kind
    return 'helper'

def extract(src):
    ts = tokens(src)
    testing_aliases = imports(ts, 'testing')
    tier_aliases = imports(ts, MODULE + '/internal/testutil/tier')
    result = []
    depth, i = 0, 0
    while i < len(ts):
        token = ts[i]
        if depth == 0 and token[0] == 'func' and i + 2 < len(ts) and ts[i + 1][4] == 'identifier':
            name = ts[i + 1][0]
            j = i + 2
            generic = ts[j][0] == '['
            if generic: j = paired(ts, j, '[', ']') + 1
            if ts[j][0] != '(':
                raise ValueError('function without parameter list at line ' + str(token[3]))
            params_end = paired(ts, j, '(', ')')
            body_start = params_end + 1
            while body_start < len(ts):
                value = ts[body_start][0]
                if value in ('(', '['):
                    body_start = paired(ts, body_start, value, ')' if value == '(' else ']') + 1
                    continue
                if value == '{' and ts[body_start - 1][0] in ('struct', 'interface'):
                    body_start = paired(ts, body_start, '{', '}') + 1
                    continue
                if value in ('{', ';', 'var', 'const', 'type'):
                    break
                if value == 'func' and ts[body_start + 1][0] != '(':
                    break
                body_start += 1
            has_body = body_start < len(ts) and ts[body_start][0] == '{'
            end = paired(ts, body_start, '{', '}') if has_body else params_end
            kind = entry_kind(name)
            param_tokens = [t[0] for t in ts[j + 1:params_end]]
            if param_tokens[-1:] == [',']: param_tokens.pop()
            expected_type = {'test': 'T', 'benchmark': 'B', 'fuzz': 'F', 'testmain': 'M'}.get(kind)
            type_options = [['*', alias, '.', expected_type] if alias != '.' else ['*', expected_type]
                            for alias in testing_aliases if alias != '_'] if expected_type else []
            valid_param = any(param_tokens == option or (len(param_tokens) == len(option) + 1 and letter(param_tokens[0][0]) and param_tokens[1:] == option) for option in type_options)
            if kind == 'example': valid_param = not param_tokens
            signature = 'not-an-entry-candidate' if kind == 'helper' else ('lexically-compatible-not-typechecked' if valid_param and not generic and body_start == params_end + 1 and has_body else 'unknown-or-incompatible-not-typechecked')
            gates = []
            body = ts[body_start + 1:end] if has_body else []
            for k, tok in enumerate(body):
                for alias in tier_aliases:
                    if alias == '.':
                        if tok[0] in ('Integration', 'Qualification', 'Unavailable') and k + 1 < len(body) and body[k + 1][0] == '(':
                            gates.append(tok[0] + '@' + str(tok[3]) + ':dot-import-ambiguous')
                    elif alias != '_' and tok[0] == alias and k + 3 < len(body) and body[k + 1][0] == '.' and body[k + 2][0] in ('Integration', 'Qualification', 'Unavailable') and body[k + 3][0] == '(':
                        gates.append(body[k + 2][0] + '@' + str(tok[3]))
            result.append(dict(name=name, kind=kind, line=token[3], end_line=ts[end][3],
                               declaration_sha256=sha(src[token[1]:ts[end][2]].encode()),
                               signature_status=signature, direct_tier_calls=';'.join(gates),
                               classification='unclassified', review_closure='unknown', execution_closure='unknown'))
            i = end + 1
            continue
        if token[4] != 'literal':
            if token[0] == '{': depth += 1
            if token[0] == '}': depth -= 1
            if depth < 0: raise ValueError('unbalanced closing brace')
        i += 1
    if depth: raise ValueError('unbalanced top-level braces')
    return result

def write_tsv(name, rows, columns):
    with (OUT / name).open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=columns, delimiter='\t', lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('rev-parse', HEAD + '^{tree}').decode().strip() == TREE
initial_status = git('status', '--porcelain').decode()
assert not initial_status, initial_status
entries = {}
for item in git('ls-tree', '-rz', HEAD).split(b'\0'):
    if not item: continue
    meta, name = item.split(b'\t', 1)
    mode, typ, oid = meta.decode().split()
    path = name.decode()
    if not {'third_party', 'vendor', '.git'}.intersection(path.split('/')):
        entries[path] = (mode, typ, oid)
paths = sorted(path for path in entries if path.endswith('_test.go'))
modules = sorted(path for path in entries if pathlib.PurePosixPath(path).name == 'go.mod')
requested = sorted(set(paths + modules + REFS))
objects = git('cat-file', '--batch', data=''.join(entries[p][2] + '\n' for p in requested).encode())
stream = io.BytesIO(objects)
blobs = {}
for path in requested:
    header = stream.readline().decode().split()
    assert header[0] == entries[path][2] and header[1] == 'blob'
    blobs[path] = stream.read(int(header[2]))
    assert stream.read(1) == b'\n'
assert not stream.read()
MODULE = re.search(rb'^module\s+(\S+)', blobs['go.mod'], re.M).group(1).decode()
# Generator self-checks only: no Go tools, package discovery or repository test runners.
sample = '''package p
import "testing"
var embedded = `func TestFake(t *testing.T) {}`
// func TestComment(t *testing.T) {}
func TestReal(t *testing.T) { t.Run("x", func(t *testing.T) {}) }
func BenchmarkReal(b *testing.B) {}
func Example_real() { /* } */ println("{") }
func (r Receiver) TestMethod(t *testing.T) {}
func helper() {}
'''
assert [(x['name'], x['kind']) for x in extract(sample)] == [('TestReal', 'test'), ('BenchmarkReal', 'benchmark'), ('Example_real', 'example'), ('helper', 'helper')]
assert extract(sample)[0]['signature_status'] == 'lexically-compatible-not-typechecked'
assert extract('package p; func helper() struct{ x int } { return struct{ x int }{} }; func TestNext(t *testing.T) {}')[1]['name'] == 'TestNext'
assert entry_kind('Testlowercase') == 'helper'
assert entry_kind('TestÉ') == 'test'
files, decls, errors = [], [], []
for path in paths:
    data = blobs[path]
    src = data.decode('utf-8')
    try:
        found = extract(src)
        scan_status = 'complete-lexical-scan'
    except (ValueError, IndexError) as exc:
        errors.append(dict(path=path, error=str(exc)))
        found, scan_status = [], 'unknown-extraction-error'
    counts = collections.Counter(d['kind'] for d in found)
    parents = [m for m in modules if m == 'go.mod' or path.startswith(m[:-len('go.mod')])]
    module = max(parents, key=len) if parents else 'unknown'
    dirs = path.split('/')[:-1]
    package_token = next((t for t in tokens(src) if t[0] == 'package'), None)
    preamble = src[:package_token[1]] if package_token else ''
    constraints = [line.strip() for line in preamble.splitlines() if line.startswith('//go:build ') or line.startswith('// +build ')]
    risk = []
    if 'testdata' in dirs: risk.append('testdata-directory')
    if any(p.startswith(('.', '_')) for p in dirs): risk.append('dot-or-underscore-directory')
    if module != 'go.mod': risk.append('nested-module')
    if constraints: risk.append('explicit-build-constraint')
    pkg = re.search(r'^package\s+(\w+)', src, re.M)
    row = dict(path=path, git_blob_oid=entries[path][2], file_sha256=sha(data), bytes=len(data),
               package_clause=pkg.group(1) if pkg else 'unknown', nearest_go_mod=module,
               build_constraints=' | '.join(constraints), discovery_observations=';'.join(risk),
               scan_status=scan_status, **{k + '_declarations': counts[k] for k in ['test', 'benchmark', 'fuzz', 'example', 'testmain', 'helper']},
               classification='unclassified', review_closure='unknown', execution_closure='unknown',
               runner_discovery='unknown-not-evaluated')
    files.append(row)
    for d in found:
        decls.append(dict(path=path, file_sha256=row['file_sha256'], **d))
write_tsv('files.tsv', files, list(files[0]))
write_tsv('declarations.tsv', decls, list(decls[0]))
old_data = OLD.read_bytes()
old_rows = list(csv.DictReader(io.StringIO(old_data.decode()), delimiter='\t'))
old_by_path = {row['path']: row for row in old_rows}
old_firstparty = {p:r for p,r in old_by_path.items() if not {'third_party', 'vendor', '.git'}.intersection(p.split('/'))}
new_by_path = {row['path']: row for row in files}
comparison = []
for path in sorted(set(old_firstparty) | set(new_by_path)):
    old, new = old_firstparty.get(path), new_by_path.get(path)
    # Old extraction semantics are unverified; include TestMain in comparison only as an explicit alternate.
    comparison.append(dict(path=path, presence='both' if old and new else ('draft-only' if old else 'frozen-only'),
                           draft_test_declarations=old['test_declarations'] if old else '',
                           frozen_test_declarations=new['test_declarations'] if new else '',
                           frozen_test_plus_testmain=(new['test_declarations'] + new['testmain_declarations']) if new else '',
                           draft_benchmark_declarations=old['benchmark_declarations'] if old else '',
                           frozen_benchmark_declarations=new['benchmark_declarations'] if new else '',
                           provenance_status='unknown-draft-bytes-unbound'))
write_tsv('draft-comparison.tsv', comparison, list(comparison[0]))
counts = collections.Counter(d['kind'] for d in decls)
for kind in ['test', 'benchmark', 'fuzz', 'example', 'testmain', 'helper']:
    counts.setdefault(kind, 0)
metadata = dict(head=HEAD, tree=TREE, worktree=str(ROOT), generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                scope='All tracked *_test.go blobs excluding any third_party/vendor/.git path component; no build selection applied.',
                method='Python lexical tokenizer and top-level named function scan; NOT Go AST, typechecking, go list, go test discovery, or runtime evidence.',
                file_count=len(files), declaration_counts=dict(counts), extraction_errors=errors,
                classification_counts=dict(collections.Counter(f['classification'] for f in files)),
                signature_status_counts=dict(collections.Counter(d['signature_status'] for d in decls if d['kind'] != 'helper')),
                direct_gate_call_declarations=dict(collections.Counter(d['kind'] for d in decls if d['direct_tier_calls'])),
                nested_modules=modules, module_path=MODULE,
                source_reference_hashes={p:dict(git_blob_oid=entries[p][2], sha256=sha(blobs[p])) for p in REFS + modules},
                draft=dict(path=str(OLD), sha256=sha(old_data), rows=len(old_rows),
                           firstparty_rows=len(old_firstparty), excluded_rows=len(old_rows)-len(old_firstparty),
                           classification_counts=dict(collections.Counter(r['classification'] for r in old_rows)),
                           unverified_test_total=sum(int(r['test_declarations']) for r in old_rows),
                           unverified_benchmark_total=sum(int(r['benchmark_declarations']) for r in old_rows),
                           provenance='unknown; no verified producing command, commit/tree or file hashes. Tracked evidence reference is only a mention.',
                           prior_owner_report='Existing test_inventory owner reports no verified producing command or source snapshot; authoritative inventory was vendor-only.'),
                comparison_presence=dict(collections.Counter(r['presence'] for r in comparison)),
                closure=dict(classification='unclassified', review='unknown', execution='unknown',
                             runner_discovery='unknown-not-evaluated', integration_quality='unknown-no-contract-review'),
                generator_sha256=sha(pathlib.Path(__file__).read_bytes()), generator_self_checks='passed',
                initial_worktree_status=initial_status)
assert len(files) == len(paths) == len({r['path'] for r in files})
assert sum(r['test_declarations'] for r in files) == counts['test']
assert sum(r['benchmark_declarations'] for r in files) == counts['benchmark']
assert OLD.read_bytes() == old_data
assert git('status', '--porcelain').decode() == initial_status
metadata['final_worktree_status'] = git('status', '--porcelain').decode()
(OUT / 'metadata.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
print(json.dumps({k:metadata[k] for k in ['head', 'tree', 'file_count', 'declaration_counts', 'extraction_errors', 'signature_status_counts', 'comparison_presence']}, indent=2))
