Review `union-dd038410-correction.patch` and the frozen source manifest before selecting this successor.

1. Candidate: `dd03841025c65c0a6c3350b3e8ad7c4d27eea77d`, tree `bac4b5eae4c69633777f8f89291cc032ea69b68c`; clean detached QA `/tmp/ts-vendor-union-qa-dd038410`. Manifest SHA `5eb590536c7455b40e78c68eed885efbea05f1e146557b0814c00f5fd94379a7`. Selected67ec and its manifest alias remain unchanged.
2. Exactly two failed additive bodies changed: ServiceLatency uses one public Connz RTT snapshot and guards its derived delay; Diagnostics matches the existing `[PING]` suffix. All original assertions remain. Independent lexical proof: 1,923 of 1,925 bodies unchanged; 19 other selected files and every byte outside the two bodies exact.
3. Proposed failed-only slots remain ungranted: ServiceLatency alone (one case), followed by Diagnostics (five cases). Preserve all 27 sampling passes, four rejected-auth passes and every other passing body. Resources and limitations are bound in `union-dd038410-qa-plan.json`; a later RTT increase fails its explicit budget guard.
4. Separate never-run FIFO: `union-67ec90a3-bounded-fifo.json`, 11 serial batches / 13 roots / 107 TCP-eligible cases. All admission-only cases and failed roots are excluded.

No compile, runtime, race or equivalence qualification for this successor. No original removal, central closure, runtime request, runner or push.
