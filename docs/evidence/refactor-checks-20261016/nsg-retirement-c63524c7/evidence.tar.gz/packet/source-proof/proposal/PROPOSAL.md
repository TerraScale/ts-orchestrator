# Declaration-only retirement proposal

Status: HOLD. No source change, runner, integration or removal authorization.

All five original semantic invariants are covered by the five accepted SDK cases. No unique negative blocks proposing removal of only `TestPeerPortOpen`.

Source: `e502eed69cd2c020448b94c6970d9bacd8942cd8`, tree `31d1fd6d1811db28dfa86b1207ab492b02aab2c8`, parent `7512c426670cef4558c94ee62350fd1f29b850e9`.
`internal/terrabase/oci_live_test.go` SHA256 `da7665e5f1e8ab5a73f7e5735dd29423712bef6ad8e739193ef017240d298c22` (25286 bytes).

| Original invariant | SDK leaf | Raw summary / PASS JSON lines |
|---|---|---|
| original map cidr => true; source 10.251.0.0/24, sender 10.251.0.22, TCP destination 9443..9443, requested 9443 | `cidr` | 6 / 15 |
| original map nsg => true; source members, senderGroups [members], TCP destination 9000..9500, requested 9443 | `nsg` | 18 / 27 |
| original map miss => false; matching CIDR but TCP destination 9465..9465 excludes requested 9443 | `destination_miss` | 30 / 39 |
| original explicit wrong sender group => false; rule source members versus unrelated sender group token | `sender_nsg_miss` | 42 / 51 |
| original explicit unrelated network => false; source 10.251.0.0/24 versus sender 10.9.0.1 | `sender_cidr_miss` | 54 / 63 |

Original CIDR denial passed nil sender groups. The SDK case passes groupB. This preserves the CIDR rejection invariant because the CIDR branch never reads sender groups; it does not prove literal nil-input execution. NSG labels also change consistently to OCI-like identities; equality/mismatch behavior is the retained invariant.

Minimal candidate: remove lines 299–321 plus following blank line 322 only (24 lines / 1,224 bytes). Keep every import. Proposed resulting source SHA256: `4ec96b458d4119605d24e1e04d1ef15da8e2ca9ec9fd22e21b54fe1a47e3f068`. This source was calculated in memory only.

Keep helpers: `peerPortOpen` has four direct call sites before removal, one afterwards in `observePeerIngress`; that observer has live and SDK callers. Keep all observation types and `liveEnv` (two callers). Local `tcp` has three calls within the removed declaration and no external user.

Evidence: exact e502 default compile and SDK root/five leaves accepted; raw 68-record stream independently cross-checked, including 35 GET exchanges and ten ordered assessments. Six decoded-object comparisons are established by pinned source assertions plus leaf PASS, not full structs printed in raw output. Full mappings, raw line pointers and all source/evidence hashes are in `proposal.json`.

Retained limits:
- Only the static ingress allowance predicate is covered; no actual peer TCP, egress, routes, security-list, listener or replication acceptance.
- Signature header structure/presence is checked; no cryptographic signature verification. No live OCI or real-host acceptance.
- One-page/static-ingress limits remain: no pagination/source-port/Direction/IsValid/IsStateless policy fixes.
- No F3 witness, global or central closure; no short/tagged/race/full-package execution.
- Accepted compile/runtime receipts qualify e502 source before retirement. Candidate deletion exists only as an in-memory calculation in this proposal; it has not been applied, compiled or run.

No source files changed. HOLD.
