from pathlib import Path
import os,sys,subprocess,hashlib,json,time,datetime,fcntl,traceback
D=Path(__file__).resolve().parent
R=json.loads((D/'compile-request.json').read_text())
W=Path(R['cwd']);OUT=Path(R['output_directory'])
def sha(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def fi(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'size':len(b),'sha256':sha(b)}
def write(name,value):
 with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output([R['git_path'],'-c','core.fsmonitor=false',*args],cwd=W,env=R['environment'])
def snapshot():
 head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();parent=git('show','-s','--format=%P','HEAD').decode().strip();status=git('status','--porcelain=v1').decode()
 assert (head,tree,parent,status)==(R['commit'],R['tree'],R['parent'],'')
 source=fi(W/R['source_path']);assert source['sha256']==R['source_sha256']
 checked=[]
 for item in R['bound_repository_files']:
  f=fi(W/item['path']);assert f['sha256']==item['sha256'];blob=git('rev-parse',head+':'+item['path']).decode().strip();assert blob==item['git_blob'];checked.append({'path':item['path'],'size':f['size'],'sha256':f['sha256'],'git_blob':blob})
 assert len(checked)==12
 executables=[]
 for expected in R['executables']:
  f=fi(expected['path']);assert f==expected;executables.append(f)
 return {'commit':head,'tree':tree,'parent':parent,'status_porcelain':status,'source':source,'bound_repository_files':checked,'executables':executables}
OUT.mkdir()
receipt={'state':'NOT_STARTED','request':fi(D/'compile-request.json'),'wrapper':fi(__file__),'argv':R['compile_argv'],'cwd':str(W),'environment':dict(os.environ),'interpreter':str(Path(sys.executable).resolve()),'python_flags':{'isolated':sys.flags.isolated,'dont_write_bytecode':sys.dont_write_bytecode},'limits':R['limits'],'lock':{'path':R['lock_path'],'exclusive_nonblocking':True,'acquired':False},'binary_executed':False,'other_go_commands':False,'runtime_or_server':False,'started_utc':now()}
lock=None;start=time.monotonic()
try:
 assert fi(__file__)['sha256']==R['wrapper_sha256']
 assert str(Path(sys.executable).resolve())==R['python_path'] and sys.version_info[:2]==(3,15)
 assert sys.flags.isolated==1 and sys.dont_write_bytecode
 assert dict(os.environ)==R['environment'] and len(os.environ)==6 and 'GOROOT' not in os.environ
 assert os.getpriority(os.PRIO_PROCESS,0)==19
 lock=Path(R['lock_path']).open('a+b');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);receipt['lock']['acquired']=True
 receipt['pre']=snapshot();write('pre-state.json',receipt['pre'])
 assert not Path(R['binary_output']).exists()
 receipt['compile_started_utc']=now();compile_start=time.monotonic()
 with (OUT/'compile.log').open('xb') as log:
  result=subprocess.run(R['compile_argv'],cwd=W,env=R['environment'],stdout=log,stderr=subprocess.STDOUT,check=False)
 receipt['compile_wall_seconds']=round(time.monotonic()-compile_start,6);receipt['compile_finished_utc']=now();receipt['exit_code']=result.returncode
 receipt['log']=fi(OUT/'compile.log');receipt['post']=snapshot();write('post-state.json',receipt['post']);assert receipt['pre']==receipt['post']
 receipt['prepost_identical']=True
 binary=Path(R['binary_output'])
 if binary.is_file():receipt['binary']=fi(binary)
 receipt['state']='COMPILE_PASS_BINARY_NEVER_EXECUTED' if result.returncode==0 and binary.is_file() else 'COMPILE_FAILURE_NO_RETRY'
except BlockingIOError:
 receipt['state']='NOT_RUN_LOCK_BUSY';receipt['exit_code']=None
except BaseException as exc:
 receipt['state']='WRAPPER_OR_IDENTITY_FAILURE_NO_RETRY';receipt['error_type']=type(exc).__name__;receipt['error']=str(exc);receipt['traceback']=traceback.format_exc()
finally:
 if lock is not None:lock.close()
 receipt['finished_utc']=now();receipt['wall_seconds']=round(time.monotonic()-start,6)
 write('broker-receipt.json',receipt)
 write('artifact-manifest.json',{'state':receipt['state'],'artifacts':[fi(q) for q in sorted(OUT.iterdir()) if q.is_file()],'excludes_self':True})
 print(json.dumps({'state':receipt['state'],'receipt':fi(OUT/'broker-receipt.json'),'output_directory':str(OUT)},indent=2),flush=True)
 if receipt['state']!='COMPILE_PASS_BINARY_NEVER_EXECUTED':sys.exit(1)
