# F1 corrected grant: pass

Exact commit: 61aa29d6b4226953308819a62bc5eb341c53b69d.
Selector: ^TestPhaseStatusThroughSignedOCISDK$
Tool session: 43484. Exit: 0. Wall: 5.514 seconds. Package runtime: 0.273 seconds.

All four leaves passed: SFO current/retained names, GRU retained controller names, control later-page error, workload later-page error. Individual events and terminal outcomes are saved under leaves/ and leaves.json.

One granted invocation used pinned Go1.27.1, unset GOROOT, GOMAXPROCS=2, GOFLAGS=-p=2, nice -n19, explicit -p1/-parallel1/-mod=readonly/-count=1/-json/-timeout=120s, outer180s and the nonblocking gate flock. argv.json records the exact wrapper and test command. session.json records process IDs and timing; tool-session.json records the tool session.

before.json and after.json are identical: exact commit/tree, clean status, source hashes, go.mod/go.sum hashes and working diff hash all match. No retry, source edit, other selector, external OCI call or push occurred. Scope is only the selected integration scenario; no full-suite, race, live-cloud or broader regression pass is claimed.
