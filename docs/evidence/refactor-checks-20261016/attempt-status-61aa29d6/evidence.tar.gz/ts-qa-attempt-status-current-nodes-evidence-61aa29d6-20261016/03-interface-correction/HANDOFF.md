# F1 source-only interface correction

Commit: 61aa29d6b4226953308819a62bc5eb341c53b69d
Tree: d96ac15185a481ee057543347fc1cfc7c98b59f5
Actual sole parent: 18b3ac46a269480ee74273259031c8dd47fb02ca
Original F1 base: cbfa626ac257e2c404e3581da1735f8494fabc64
Worktree: /tmp/ts-qa-attempt-status-current-nodes (clean)

Only correction: errors.AsType target is an inline interface embedding error and common.ServiceError. All getters, error assertions and every other test byte are preserved. Production source is byte-identical to prior candidate 18b3ac46. Exact byte replacement and parent checks passed. correction.patch is the precise parent-to-correction diff; candidate.patch is the complete base-to-corrected-candidate diff. proof.json contains full hashes and source checks.

Validation: gofmt and git whitespace checks only. No test, build, lint, runtime, retry or push under this grant. The prior candidate's single granted run failed compilation; this correction has not been compiled or executed.

Next QA selector after separate grant: ^TestPhaseStatusThroughSignedOCISDK$
