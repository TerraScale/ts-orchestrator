# F1: retained read-only attempt status

Base: cbfa626ac257e2c404e3581da1735f8494fabc64
Commit: 18b3ac46a269480ee74273259031c8dd47fb02ca
Tree: 0679b012856e3b57b5421063eb0a8b02e85ce11b
Branch: fix/qa-attempt-status-current-nodes
Worktree: /tmp/ts-qa-attempt-status-current-nodes
Push: not performed, as instructed.

## Exact scope

Only internal/attempt/attempt.go and internal/attempt/status_integration_test.go changed.
Production diff: cache the existing catalog cell string, accept naming.IsNode(displayName, region) OR the unchanged legacy cell-prefix predicate, with TERMINATED exclusion outside both predicates. No new production seam/configuration, deletes, or scheduler changes. GRU controller naming is unchanged.

## Connected scenario

Selector: ^TestPhaseStatusThroughSignedOCISDK$
Entry: actual Attempt.Phase("status") -> PhaseStatus -> production sdkCloud -> actual OCI Go SDK Compute/ObjectStorage HTTP clients from ociclient.Factory, pinned with existing PinHost.
State: actual temporary config and plan files passed through Attempt.New; no canned Cloud adapter.
Credentials: synthetic local configuration provider and one freshly generated 2048-bit RSA private key. Every request signature is cryptographically verified against its public key. No operator credentials or external OCI endpoints are used.
Cases: SFO current/legacy output, GRU current/retained controller output, control second-page error, workload second-page error.
Assertions: exact emitted instance rows exclude foreign current/legacy names, current -data names, current/legacy TERMINATED rows and malformed current names; arbitrary retained legacy-prefix names still display. Both compartment page chains and all four bootstrap ObjectStorage list prefixes are checked in order. Wrapped OCI later-page status/code/request ID are preserved; a failed control list prevents a workload request.

## QA execution, only after runner grant

cd /tmp/ts-qa-attempt-status-current-nodes
GOMAXPROCS=2 nice -n 19 go test -p 1 -parallel 1 ./internal/attempt -run '^TestPhaseStatusThroughSignedOCISDK$' -count=1 -timeout=5m

Runtime/resource estimate, not measured: one compiler lane (-p 1), two Go scheduler processors, no parallel subtests; 30 signed GET requests across four sequential localhost httptest servers, one RSA key generation, eight small config/plan files (<32 KiB logical content). Warm runtime expected under 5 seconds; cold package compilation may take minutes and several GiB (reserve up to 8 GiB pending QA measurements). No external service, VM, OCI mutation, Docker, or persistent daemon required.

## Validation receipt

NOT RUN: tests, builds, lint, benchmarks and all Go runners. Compiler lanes were held, and no subsequent runner grant was given. Commit is source-only pending QA execution; no runtime pass is claimed.
Completed: gofmt on both changed Go files; git diff --check and git diff --cached --check; source inspection against cached real OCI SDK signing, endpoint, model and service-error code; git hooks checked absent before commit. No checks triggered compilation.

## Artifact integrity

change.patch is the exact binary-capable diff from base to commit for both changed files.
Patch SHA256: 413864810688e15a7135030d60b52149b7b8a53aa20db0b02e6956e559303507
Changed source SHA256:
418ccb6125235e45835b791e02ad6e8ca0ae706f34b108f5463919e3cc81aa5c  internal/attempt/attempt.go
1acadf1452b0dc3eb498bce6a92221985bb41913555fce4425de652c15b279b8  internal/attempt/status_integration_test.go
