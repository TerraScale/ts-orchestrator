Review FIFO3 exactdd authorization matrix:22positive leaves only(20stream/2service),1root.

^TestAccountImportAuthorizationMatrixOverTCP$/^(5|8|9|10|13|17|18|19|20|21|22|23|24|25|26|27|32|33|38|39|40|41)$

All47 rows mechanically match original in order;27startup-only deny/invalid cases excluded,zeroTCPcredit. Both target/original and18helpers bound; original exact847b.22serialservers/44dials/max2clients/max2listeners;24pubs/24deliveries/160payloadbytes;22HTTP,nochild/SYS/routes. Historical90s proposal unchanged/ungranted. Private truth-table/error/wildcard and original service-invalid-fixture gaps remain.
