Source-only IAM claims slice. HOLD for independent QA.

Commit e2e1c4f4df20733b28ebf10b407e82a1dd1202d6
Tree 010c735d27aad5636271f5d08c7272beb1267ab7
Sole parent 6d4feea434d74e0f344fc7f9ab9bba9ed1e15080

Only simulator.go and simulator_test.go changed. Fixed opc-instance/ptype/tenant claims; existing actual SDK and net/http socket roots assert identity, current expiry/jti, simulator RSA signer and submitted-session-key provenance. Every original assertion retained. All other functions and negative roots byte-identical.

Formatting only: nice19 pinnedGo1.27.1 gofmt. Cached Modern Go guidance read with explicit1.27 and no compiler/install. No build/compile/test/list/vet/runtime/cloud/push/integration or new agent.

Proposed exact affected selector: ^(TestSimulatorAcceptsSDKSignatureAcrossNetHTTPServer|TestSimulatorAcceptsRealInstancePrincipalSDKRequests)$
See source-manifest.json for resource envelope and all limits. Existing negatives retained, not executed. This does not qualify production IAM/default constructor/Oracle trust/ownhost. Full enrollment bundle producer remains open.
