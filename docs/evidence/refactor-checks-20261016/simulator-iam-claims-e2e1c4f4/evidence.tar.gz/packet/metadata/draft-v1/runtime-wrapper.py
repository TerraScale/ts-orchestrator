from pathlib import Path
import datetime,fcntl,hashlib,json,os,stat,subprocess,sys,time,traceback
D=Path(__file__).resolve().parent
R=json.loads((D/'request.json').read_text())
W=Path(R['worktree'])
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def info(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'resolved_path':str(p.resolve()),'sha256':sha(b),'size':len(b)}
def write(name,value):
 with (D/name).open('x') as f: json.dump(value,f,indent=2); f.write('\n')
def git(*args): return subprocess.check_output([R['git'],*args],cwd=W,env=R['environment'])
def bound_files():
 actual=[info(e['path']) for e in R['executables']]
 assert actual==R['executables'],'executable path/hash drift'
 artifacts=[info(e['path']) for e in R['predecessor_artifacts']]
 assert artifacts==R['predecessor_artifacts'],'predecessor artifact drift'
 return {'executables':actual,'predecessor_artifacts':artifacts,'wrapper':info(__file__),'request':info(D/'request.json')}
def snapshot():
 head=git('rev-parse','HEAD').decode().strip(); tree=git('rev-parse','HEAD^{tree}').decode().strip(); parent=git('show','-s','--format=%P','HEAD').decode().strip(); status=git('status','--porcelain=v1').decode()
 assert (head,tree,parent,status)==(R['commit'],R['tree'],R['parent'],''),'source identity/status drift'
 aggregate=hashlib.sha256();count=0
 for row in git('ls-files','--stage','-z').split(b'\0'):
  if not row: continue
  meta,name=row.split(b'\t',1);mode,oid,stage=meta.split();assert stage==b'0'
  p=W/os.fsdecode(name);data=os.readlink(p).encode() if mode==b'120000' else p.read_bytes()
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()==oid,'tracked source byte drift'
  if mode!=b'120000': assert bool(p.stat().st_mode&0o111)==bool(int(mode,8)&0o111),'tracked mode drift'
  aggregate.update(name+b'\0'+hashlib.sha256(data).digest());count+=1
 assert (count,aggregate.hexdigest())==(R['tracked_entries'],R['tracked_binding_sha256']),'source aggregate drift'
 return {'head':head,'tree':tree,'sole_parent':parent,'status_porcelain':status,'tracked_entries':count,'tracked_binding_sha256':aggregate.hexdigest(),'bindings':bound_files()}
def audit_raw():
 rows=[json.loads(line) for line in (D/'raw.jsonl').read_text().splitlines()]
 roots=R['roots'];expected=R['package_import'];runs=[];passes=[];package_passes=0
 for e in rows:
  assert e.get('Package',expected)==expected,'unexpected package'
  assert e.get('Action') not in ('fail','skip'),'failure or skip event'
  test=e.get('Test')
  if test:
   assert test in roots,'extra root or subtest'
   if e.get('Action')=='run':runs.append(test)
   if e.get('Action')=='pass':passes.append(test)
  elif e.get('Action')=='pass':package_passes+=1
 assert runs==roots and passes==roots and package_passes==1,'not exactly two serial root passes'
 return {'records':len(rows),'runs':runs,'passes':passes,'package_passes':package_passes,'no_extra_roots_subtests_skips_failures':True,'claim_limit':'Pinned assertions plus root PASS; no printed-token/full decoded struct/Oracle trust/private IAM/default constructor credit.'}
receipt={'kind':'EXACT_TWO_SIMULATOR_IAM_ROOTS_ONCE','created_utc':now(),'request':info(D/'request.json'),'wrapper':info(__file__),'worktree':str(W),'commit':R['commit'],'tree':R['tree'],'parent':R['parent'],'argv':R['argv'],'go_argv':R['go_argv'],'environment':R['environment'],'lock':{'path':R['lock'],'nonblocking_exclusive':True,'acquired':False},'runtime_attempted':False,'child_started':False,'runtime_terminal':False,'exit_code':None,'state':'NOT_STARTED'}
lock=None;started=time.monotonic()
try:
 assert sys.flags.isolated==1 and sys.dont_write_bytecode,'requires pinned Python -I -B'
 assert Path(sys.executable).resolve()==Path(R['python']).resolve(),'Python identity drift'
 assert dict(os.environ)==R['environment'],'requires env-i exact six keys'
 assert 'GOROOT' not in os.environ
 assert info(__file__)==R['wrapper'],'wrapper hash drift'
 for name in ['pre-state.json','post-state.json','invocation.json','raw.jsonl','stderr.log','receipt.json','runtime-manifest.json']:
  assert not (D/name).exists(),'exclusive run output already exists'
 lock=Path(R['lock']).open('a+b');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);receipt['lock']['acquired']=True
 receipt['pre']=snapshot();write('pre-state.json',receipt['pre'])
 write('invocation.json',{'argv':R['argv'],'go_argv':R['go_argv'],'cwd':str(W),'environment':R['environment'],'launch_argv':R['launch_argv'],'executables':R['executables'],'wrapper':R['wrapper'],'limits':R['resource_envelope']})
 receipt['runtime_attempted']=True;receipt['runtime_started_utc']=now();runtime_start=time.monotonic()
 with (D/'raw.jsonl').open('xb') as stdout,(D/'stderr.log').open('xb') as stderr:
  child=subprocess.Popen(R['argv'],cwd=W,env=R['environment'],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
  receipt['child_started']=True;receipt['exit_code']=child.wait();receipt['runtime_terminal']=True
 receipt['runtime_finished_utc']=now();receipt['runtime_wall_seconds']=round(time.monotonic()-runtime_start,6)
 receipt['raw_json']=info(D/'raw.jsonl');receipt['stderr']=info(D/'stderr.log')
 receipt['post']=snapshot();write('post-state.json',receipt['post']);assert receipt['pre']==receipt['post'],'pre/post identity drift'
 receipt['prepost_identical']=True
 if receipt['exit_code']==0:
  receipt['raw_audit']=audit_raw();receipt['state']='TWO_ROOT_TERMINAL_PASS_PENDING_INDEPENDENT_QA'
 else:receipt['state']='RUNTIME_TERMINAL_FAILURE'
except BlockingIOError:
 receipt['state']='NOT_RUN_LOCK_BUSY'
except BaseException as exc:
 receipt['state']='WRAPPER_SOURCE_OR_AUDIT_FAILURE';receipt['error_type']=type(exc).__name__;receipt['error']=str(exc);receipt['traceback']=traceback.format_exc()
finally:
 if lock is not None:lock.close()
 receipt['completed_utc']=now();receipt['wrapper_wall_seconds']=round(time.monotonic()-started,6)
 write('receipt.json',receipt)
 write('runtime-manifest.json',{'state':receipt['state'],'artifacts':[info(p) for p in sorted(D.iterdir()) if p.is_file()]})
 print(json.dumps({'state':receipt['state'],'exit_code':receipt['exit_code'],'runtime_terminal':receipt['runtime_terminal'],'receipt':info(D/'receipt.json'),'runtime_manifest':info(D/'runtime-manifest.json')},indent=2),flush=True)
 if receipt['state']!='TWO_ROOT_TERMINAL_PASS_PENDING_INDEPENDENT_QA':sys.exit(1)
