HOLD. Metadata-only request; wrapper and Go not executed.

Exactly two accepted existing positive roots on frozen e2e1c4f4df20733b28ebf10b407e82a1dd1202d6. No separate compile-only; one Go test invocation, default tags, serial roots. Outer180s TERM/KILL5, nice19, pinnedGo1.27.1, test timeout120s. Launch uses pinnedPython3.15 -I -B via env-i exact six keys, no GOROOT, GOTOOLCHAIN=local and pinnedGo first PATH. Nonblocking exclusive gate lock.

request.json contains exact argv/source/executable/predecessor hashes. runtime-wrapper.py writes exclusive pre/post state, raw JSON stdout, separate stderr, actual terminal result and audit; no retry. It rejects source drift or extra roots/subtests/skips. Source may require a separately reviewed mechanical docs-only adoption later; this wrapper does not adopt or accept another parent.

No private IAM/default constructor/Oracle trust/ownhost claim. Wait for explicit QA queue grant.
