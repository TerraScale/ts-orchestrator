HOLD. Metadata-only exact two-root runtime request; no wrapper or Go executed.

Frozen e2e1c4f4 on exact6d4feea4 parent. One default-tag Go1.27.1 test invocation, no separate compile-only. Exact argv and immutable source/predecessor/executable hashes are in request.json. Launch: env-i exact6keys, direct pinnedPython3.15 -I -B; pinnedGo first PATH, GOROOT absent, GOMAXPROCS2 GOFLAGS-p2 GOTOOLCHAINlocal. Outer timeout180s TERM then KILL5s, nice19, -p1 -parallel1 -count1 -modreadonly, test timeout120s.

Two existing roots only: TestSimulatorAcceptsSDKSignatureAcrossNetHTTPServer and TestSimulatorAcceptsRealInstancePrincipalSDKRequests. One ephemeral loopback listener in socket root; zero in SDK custom-dispatcher root. Nonblocking exclusive /tmp/ts-orch-refactor-gate-check.lock, no retries. Wrapper writes exclusive pre/post/full tracked source bindings, rawJSON stdout, separate stderr, child actualterminal/exit, and rejects extra roots/subtests/skips/failures or changed source/executables/predecessors. Runtime PASS remains pending independent QA.

Queue HOLD: controller-c45320 sole Goactive and two further controller-c lanes pending. A future docs-only adoption requires separately reviewed new metadata; this wrapper fails on any parent change.

Metadata provenance: an escaping concern during static inspection was false. AST confirms first wrapper already correct, unchangedSHA across drafts. V2 correction wording was inaccurate; both earlier metadata-only drafts are preserved and unexecuted. No runtime receipts/logs exist.

No private IAM/default production constructor/Oracle trust/ownhost claim. HOLD for explicit QA queue grant.
