#!/usr/bin/env python3
"""Record broker evidence only. This file never launches Go or a test runner."""
import argparse
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess


POLICY = {'4': {'selector': '^TestAccountDefaultPermissionsAdmissionRaceOverTCP$', 'expected_tests': ['TestAccountDefaultPermissionsAdmissionRaceOverTCP'], 'outer_seconds': 240, 'test_seconds': 180}, '5': {'selector': '^TestAccountJetStreamRemovalLifecycleOverTCP$', 'expected_tests': ['TestAccountJetStreamRemovalLifecycleOverTCP', 'TestAccountJetStreamRemovalLifecycleOverTCP/0', 'TestAccountJetStreamRemovalLifecycleOverTCP/1', 'TestAccountJetStreamRemovalLifecycleOverTCP/2', 'TestAccountJetStreamRemovalLifecycleOverTCP/3', 'TestAccountJetStreamRemovalLifecycleOverTCP/4', 'TestAccountJetStreamRemovalLifecycleOverTCP/5', 'TestAccountJetStreamRemovalLifecycleOverTCP/6', 'TestAccountJetStreamRemovalLifecycleOverTCP/7', 'TestAccountJetStreamRemovalLifecycleOverTCP/8', 'TestAccountJetStreamRemovalLifecycleOverTCP/9', 'TestAccountJetStreamRemovalLifecycleOverTCP/10', 'TestAccountJetStreamRemovalLifecycleOverTCP/11', 'TestAccountJetStreamRemovalLifecycleOverTCP/12', 'TestAccountJetStreamRemovalLifecycleOverTCP/13', 'TestAccountJetStreamRemovalLifecycleOverTCP/14', 'TestAccountJetStreamRemovalLifecycleOverTCP/15', 'TestAccountJetStreamRemovalLifecycleOverTCP/16', 'TestAccountJetStreamRemovalLifecycleOverTCP/17', 'TestAccountJetStreamRemovalLifecycleOverTCP/18', 'TestAccountJetStreamRemovalLifecycleOverTCP/19', 'TestAccountJetStreamRemovalLifecycleOverTCP/20', 'TestAccountJetStreamRemovalLifecycleOverTCP/21', 'TestAccountJetStreamRemovalLifecycleOverTCP/22', 'TestAccountJetStreamRemovalLifecycleOverTCP/23', 'TestAccountJetStreamRemovalLifecycleOverTCP/24', 'TestAccountJetStreamRemovalLifecycleOverTCP/25', 'TestAccountJetStreamRemovalLifecycleOverTCP/26', 'TestAccountJetStreamRemovalLifecycleOverTCP/27', 'TestAccountJetStreamRemovalLifecycleOverTCP/28', 'TestAccountJetStreamRemovalLifecycleOverTCP/29', 'TestAccountJetStreamRemovalLifecycleOverTCP/30', 'TestAccountJetStreamRemovalLifecycleOverTCP/31', 'TestAccountJetStreamRemovalLifecycleOverTCP/32', 'TestAccountJetStreamRemovalLifecycleOverTCP/33', 'TestAccountJetStreamRemovalLifecycleOverTCP/34', 'TestAccountJetStreamRemovalLifecycleOverTCP/35', 'TestAccountJetStreamRemovalLifecycleOverTCP/36', 'TestAccountJetStreamRemovalLifecycleOverTCP/37', 'TestAccountJetStreamRemovalLifecycleOverTCP/38', 'TestAccountJetStreamRemovalLifecycleOverTCP/39', 'TestAccountJetStreamRemovalLifecycleOverTCP/40', 'TestAccountJetStreamRemovalLifecycleOverTCP/41', 'TestAccountJetStreamRemovalLifecycleOverTCP/42', 'TestAccountJetStreamRemovalLifecycleOverTCP/43', 'TestAccountJetStreamRemovalLifecycleOverTCP/44', 'TestAccountJetStreamRemovalLifecycleOverTCP/45', 'TestAccountJetStreamRemovalLifecycleOverTCP/46', 'TestAccountJetStreamRemovalLifecycleOverTCP/47', 'TestAccountJetStreamRemovalLifecycleOverTCP/48', 'TestAccountJetStreamRemovalLifecycleOverTCP/49'], 'outer_seconds': 240, 'test_seconds': 180}, '6': {'selector': '^TestAccountServiceRemovalConcurrentRefreshOverTCP$', 'expected_tests': ['TestAccountServiceRemovalConcurrentRefreshOverTCP'], 'outer_seconds': 240, 'test_seconds': 180}, '7': {'selector': '^TestAccountServiceImportConcurrencyOverTCP$', 'expected_tests': ['TestAccountServiceImportConcurrencyOverTCP'], 'outer_seconds': 240, 'test_seconds': 180}, '8': {'selector': '^TestClientTCP(TLSNoticeAndAcceptance|TLSHandshakeTimeout)Ingress$', 'expected_tests': ['TestClientTCPTLSNoticeAndAcceptanceIngress', 'TestClientTCPTLSHandshakeTimeoutIngress', 'TestClientTCPTLSNoticeAndAcceptanceIngress/TLS_only', 'TestClientTCPTLSNoticeAndAcceptanceIngress/TLS_available', 'TestClientTCPTLSNoticeAndAcceptanceIngress/TLS_first_only', 'TestClientTCPTLSNoticeAndAcceptanceIngress/TLS_fallback', 'TestClientTCPTLSHandshakeTimeoutIngress/Client', 'TestClientTCPTLSHandshakeTimeoutIngress/Leafnode', 'TestClientTCPTLSHandshakeTimeoutIngress/Router', 'TestClientTCPTLSHandshakeTimeoutIngress/Gateway'], 'outer_seconds': 180, 'test_seconds': 120}, '9': {'selector': '^TestClientTCPTLSFirstAliasesIngress$', 'expected_tests': ['TestClientTCPTLSFirstAliasesIngress', 'TestClientTCPTLSFirstAliasesIngress/true', 'TestClientTCPTLSFirstAliasesIngress/false', 'TestClientTCPTLSFirstAliasesIngress/"true"', 'TestClientTCPTLSFirstAliasesIngress/"false"', 'TestClientTCPTLSFirstAliasesIngress/on', 'TestClientTCPTLSFirstAliasesIngress/off', 'TestClientTCPTLSFirstAliasesIngress/auto', 'TestClientTCPTLSFirstAliasesIngress/auto_fallback', 'TestClientTCPTLSFirstAliasesIngress/300ms'], 'outer_seconds': 180, 'test_seconds': 120}, '10': {'selector': '^TestClientTCPSignedLimitsIngress$', 'expected_tests': ['TestClientTCPSignedLimitsIngress', 'TestClientTCPSignedLimitsIngress/client=1/account=1/server=1', 'TestClientTCPSignedLimitsIngress/client=-1/account=-1/server=0', 'TestClientTCPSignedLimitsIngress/client=1/account=-1/server=0', 'TestClientTCPSignedLimitsIngress/client=-1/account=1/server=0', 'TestClientTCPSignedLimitsIngress/client=-1/account=-1/server=1', 'TestClientTCPSignedLimitsIngress/client=1/account=2/server=3', 'TestClientTCPSignedLimitsIngress/client=1/account=3/server=2', 'TestClientTCPSignedLimitsIngress/client=2/account=1/server=3', 'TestClientTCPSignedLimitsIngress/client=2/account=3/server=1', 'TestClientTCPSignedLimitsIngress/client=3/account=1/server=2', 'TestClientTCPSignedLimitsIngress/client=3/account=2/server=1'], 'outer_seconds': 180, 'test_seconds': 120}, '11': {'selector': '^TestClientTCPStoredHeaderTransformIngress$', 'expected_tests': ['TestClientTCPStoredHeaderTransformIngress'], 'outer_seconds': 180, 'test_seconds': 120}}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_once(path, value):
    with Path(path).open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def snapshot(plan):
    def git(*args):
        return subprocess.check_output(
            ["git", "-C", plan["qa_path"], *args], text=True
        ).strip()

    return {
        "HEAD": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
        "status": git("status", "--porcelain"),
        "frozen_sha256": {path: digest(path) for path in plan["frozen_sha256"]},
    }


def binding_errors(plan, binding):
    errors = []
    for key, expected in (("HEAD", plan["revision"]), ("tree", plan["tree"]), ("status", "")):
        if binding[key] != expected:
            errors.append(f"{key} differs from frozen dispatch")
    for path, expected in plan["frozen_sha256"].items():
        if binding["frozen_sha256"].get(path) != expected:
            errors.append(f"Frozen file changed: {path}")
    return errors


def summarize(events, expected_roots):
    runs = [event.get("Test") for event in events if event.get("Action") == "run"]
    terminals = [event for event in events if event.get("Action") in ("pass", "fail", "skip")]
    tests = [event for event in terminals if event.get("Test")]
    packages = [event for event in terminals if not event.get("Test")]
    expected = set(expected_roots)
    terminal_names = [event["Test"] for event in tests]
    unexpected = sorted(set(runs + terminal_names) - expected)
    scope_ok = (len(runs) == len(expected_roots) and set(runs) == expected
                and len(tests) == len(expected_roots) and set(terminal_names) == expected
                and not unexpected)
    passed = (scope_ok and all(event["Action"] == "pass" for event in tests)
              and len(packages) == 1 and packages[0]["Action"] == "pass")
    return {"tests": tests, "packages": packages, "runs": runs, "unexpected": unexpected,
            "scope_ok": scope_ok, "passed": passed}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("before", "record"))
    parser.add_argument("--plan", required=True)
    parser.add_argument("--session", type=int)
    parser.add_argument("--exit-code", type=int)
    args = parser.parse_args()
    plan_path = Path(args.plan)
    plan = json.loads(plan_path.read_text())
    policy = POLICY[str(plan["FIFO_position"])]
    assert plan["selector"] == policy["selector"]
    assert plan["expected_tests"] == policy["expected_tests"]
    assert plan["outer_seconds"] == policy["outer_seconds"]
    assert plan["test_timeout_seconds"] == policy["test_seconds"]
    assert plan["revision"] == "dd03841025c65c0a6c3350b3e8ad7c4d27eea77d"
    assert plan["dispatcher"] == "/root/qa_integrator/storage_compare"
    if args.phase == "before":
        if Path(plan["log"]).exists() or Path(plan["receipt"]).exists():
            raise SystemExit("Existing run evidence found; do not repeat this dispatch")
        binding = snapshot(plan)
        errors = binding_errors(plan, binding)
        if errors:
            raise SystemExit("\n".join(errors))
        write_once(plan["before_record"], {"dispatch_sha256": digest(plan_path), "binding": binding})
        return

    if args.session is None or args.exit_code is None:
        parser.error("record requires broker --session and terminal --exit-code")
    before = json.loads(Path(plan["before_record"]).read_text())
    errors = binding_errors(plan, before["binding"])
    if before["dispatch_sha256"] != digest(plan_path):
        errors.append("Dispatch changed after precheck")
    after = snapshot(plan)
    errors.extend(binding_errors(plan, after))
    if before["binding"] != after:
        errors.append("Before/after bindings differ")
    lock_released = False
    try:
        with Path(plan["lock"]).open("r+") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            lock_released = True
            fcntl.flock(lock, fcntl.LOCK_UN)
    except (BlockingIOError, FileNotFoundError):
        errors.append("Lane lock is held or absent; terminal release is not verified")
    events = []
    try:
        for line in Path(plan["log"]).read_text().splitlines():
            if line.strip():
                events.append(json.loads(line))
    except (OSError, json.JSONDecodeError) as error:
        errors.append(f"Cannot parse complete JSONL evidence: {error}")
    result = summarize(events, plan["expected_tests"])
    qualified = args.exit_code == 0 and result["passed"] and not errors and lock_released
    receipt = {
        "revision": plan["revision"], "tree": plan["tree"], "session": args.session,
        "exit": args.exit_code, "selector": plan["selector"], "argv": plan["argv"],
        "cwd": plan["cwd"], "dispatch": str(plan_path), "dispatch_sha256": digest(plan_path),
        "log": plan["log"], "log_sha256": digest(plan["log"]) if Path(plan["log"]).is_file() else None,
        "before_binding": before["binding"], "after_binding": after,
        "result": result, "postcheck_errors": errors, "released": lock_released,
        "FIFO_position": plan["FIFO_position"],
        "individual_leaf_outcomes": [event for event in result["tests"] if event["Test"] in plan["expected_leaves"]],
        "parent_container_outcomes": [event for event in result["tests"] if event["Test"] not in plan["expected_leaves"]],
        "stop_required": not qualified,
        "advance": "No automatic advance; parent disposition required after any failure/binding/scope issue",
        "scoped_standard_pass": qualified,
        "qualification": "Only this single separately granted FIFO position and its exact never-run event/leaf set. Preserve all originals/private gaps/priorpassesandfailures; no retry/race/equivalence/removal/centralclosure/fullsuite/live/productionclaim.",
    }
    write_once(plan["receipt"], receipt)
    if not qualified:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
