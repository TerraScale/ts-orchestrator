Review remaining FIFO positions in original order on exactdd038410.

Position3 separateaudit:1root/22positiveTCPleaves. Consolidatedpositions4-11:9roots/82cases; exactselectors/leaves/resources/privategaps perposition. All9bodies/helpers exact67ec;23deduplicatedoriginals exact847b. Shared fullsource/module/cachebindings reused after exactrehash; newTLS/JS/wire/logger paths and readonlycertfixtures bound.

No runner/grant/sourceedit/retry/push/closure. Package/outerlimits remain parent decisions. All originalprivate/race/wildcard/memory/callback contracts retained.
