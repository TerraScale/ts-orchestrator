#!/run/current-system/sw/bin/python3
"""One compile-only lease: invoke only after QA grants the sealed request."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

PACKET = Path("/tmp/ts-controller-c-identity-compile-request-6d4feea4-v3")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def inventory(path):
    return {str(f.relative_to(path)): {"sha256": digest(f.read_bytes()), "bytes": f.stat().st_size}
            for f in sorted(path.rglob("*")) if f.is_file()}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    request_bytes = (PACKET / "request.json").read_bytes()
    request = json.loads(request_bytes)
    manifest = json.loads((PACKET / "manifest.json").read_bytes())
    assert digest(request_bytes) == manifest["request_sha256"], "request binding changed"
    assert digest(Path(__file__).read_bytes()) == manifest["wrapper_sha256"], "wrapper binding changed"
    assert dict(os.environ) == request["environment"], "nonminimal inherited environment"
    cwd = request["cwd"]
    git = "/run/current-system/sw/bin/git"
    def source():
        def command(*args):
            return subprocess.check_output([git, "-C", cwd, *args], env=request["environment"]).decode().strip()
        result = {"commit": command("rev-parse", "HEAD"), "tree": command("rev-parse", "HEAD^{tree}"),
                  "parent": command("rev-parse", "HEAD^"), "status_porcelain": command("status", "--porcelain")}
        assert result == request["source_git_binding"], "source git binding changed"
        for row in request["claimed_source_files"]:
            assert digest((Path(cwd) / row["path"]).read_bytes()) == row["sha256"], row["path"]
        return result
    def snapshot():
        predecessors = {p: inventory(Path(p)) for p in request["predecessor_packets"]}
        assert predecessors == request["predecessor_packets"], "sealed predecessor changed"
        binaries = {p: digest(Path(p).read_bytes()) for p in request["executables"]}
        assert binaries == {p: row["sha256"] for p, row in request["executables"].items()}, "executable changed"
        return {"source": source(), "predecessor_packets": predecessors, "executable_sha256": binaries,
                "request_sha256": digest((PACKET / "request.json").read_bytes()),
                "wrapper_sha256": digest(Path(__file__).read_bytes())}
    before = snapshot()
    run = Path(request["exclusive_output_directory"])
    run.mkdir(mode=0o700, exist_ok=False)
    receipt = {"kind": "default-fixturegen-compile-only", "started_utc": now(), "argv": request["compile_argv"],
               "cwd": cwd, "environment": request["environment"], "before": before,
               "binary_invoked": False, "runtime_tests_executed": 0, "nested_go_runs": 0}
    (run / "before.json").write_text(json.dumps(receipt, indent=2) + "\n")
    started = time.monotonic()
    try:
        with (run / "compile.log").open("xb") as log:
            result = subprocess.run(request["compile_argv"], cwd=cwd, env=request["environment"],
                                    stdout=log, stderr=subprocess.STDOUT, check=False)
        receipt["returncode"] = result.returncode
    except BaseException as error:
        receipt["wrapper_error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = now()
        receipt["elapsed_seconds"] = time.monotonic() - started
        try:
            receipt["after"] = snapshot()
            receipt["predecessors_source_executables_unchanged"] = receipt["after"] == before
        except BaseException as error:
            receipt["after_verification_error"] = type(error).__name__ + ": " + str(error)
        binary = run / "fixturegen.test"
        if binary.is_file():
            receipt["binary"] = {"path": str(binary), "sha256": digest(binary.read_bytes()),
                                  "bytes": binary.stat().st_size, "mode": oct(binary.stat().st_mode & 0o777)}
        log = run / "compile.log"
        if log.is_file():
            receipt["log_sha256"] = digest(log.read_bytes())
        (run / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    if not receipt.get("predecessors_source_executables_unchanged"):
        return 70
    return receipt["returncode"]

if __name__ == "__main__":
    raise SystemExit(main())
