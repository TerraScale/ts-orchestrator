#!/home/mariogk/.local/share/mise/installs/python/3.15.0/bin/python3.15
"""One selected default-runtime lease: invoke only after separate QA grant."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

PACKET = Path("/tmp/ts-controller-c-identity-driver-runtime-request-6d4feea4-v1")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def inventory(path):
    return {str(f.relative_to(path)): {"sha256": digest(f.read_bytes()), "bytes": f.stat().st_size}
            for f in sorted(path.rglob("*")) if f.is_file()}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    request_bytes = (PACKET / "request.json").read_bytes()
    request = json.loads(request_bytes)
    manifest = json.loads((PACKET / "manifest.json").read_bytes())
    assert digest(request_bytes) == manifest["request_sha256"], "request binding changed"
    assert digest(Path(__file__).read_bytes()) == manifest["wrapper_sha256"], "wrapper binding changed"
    assert dict(os.environ) == request["environment"], "nonminimal inherited environment"
    cwd = request["cwd"]
    git = "/run/current-system/sw/bin/git"
    def source():
        def command(*args):
            return subprocess.check_output([git, "-C", cwd, *args], env=request["environment"]).decode().strip()
        result = {"commit": command("rev-parse", "HEAD"), "tree": command("rev-parse", "HEAD^{tree}"),
                  "parent": command("rev-parse", "HEAD^"), "status_porcelain": command("status", "--porcelain")}
        assert result == request["source_git_binding"], "source git binding changed"
        for row in request["claimed_source_files"]:
            assert digest((Path(cwd) / row["path"]).read_bytes()) == row["sha256"], row["path"]
        return result
    def snapshot():
        predecessors = {p: inventory(Path(p)) for p in request["predecessor_packets"]}
        assert predecessors == request["predecessor_packets"], "sealed predecessor changed"
        binaries = {p: digest(Path(p).read_bytes()) for p in request["executables"]}
        assert binaries == {p: row["sha256"] for p, row in request["executables"].items()}, "executable changed"
        return {"source": source(), "predecessor_packets": predecessors, "executable_sha256": binaries,
                "request_sha256": digest((PACKET / "request.json").read_bytes()),
                "wrapper_sha256": digest(Path(__file__).read_bytes())}
    before = snapshot()
    run = Path(request["exclusive_output_directory"])
    run.mkdir(mode=0o700, exist_ok=False)
    receipt = {"kind": "qualification-driver-selected-runtime", "started_utc": now(), "argv": request["test_argv"],
               "cwd": cwd, "environment": request["environment"], "before": before,
               "prior_compile_binary_invoked": False, "expected_named_test_records": 20, "expected_nested_go_runs": 0, "nested_count_basis": "static known selected callers; no process-count observation claimed"}
    (run / "before.json").write_text(json.dumps(receipt, indent=2) + "\n")
    started = time.monotonic()
    try:
        with (run / "events.jsonl").open("xb") as log, (run / "stderr.log").open("xb") as errlog:
            result = subprocess.run(request["test_argv"], cwd=cwd, env=request["environment"],
                                    stdout=log, stderr=errlog, check=False)
        receipt["returncode"] = result.returncode
    except BaseException as error:
        receipt["wrapper_error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = now()
        receipt["elapsed_seconds"] = time.monotonic() - started
        try:
            receipt["after"] = snapshot()
            receipt["predecessors_source_executables_unchanged"] = receipt["after"] == before
        except BaseException as error:
            receipt["after_verification_error"] = type(error).__name__ + ": " + str(error)
        events_file = run / "events.jsonl"
        events, invalid = [], []
        if events_file.is_file():
            for line_number, line in enumerate(events_file.read_text().splitlines(), 1):
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    invalid.append(line_number)
            receipt["events_sha256"] = digest(events_file.read_bytes())
        passed = [e["Test"] for e in events if e.get("Action") == "pass" and e.get("Test")]
        ran = [e["Test"] for e in events if e.get("Action") == "run" and e.get("Test")]
        failed = [e.get("Test", "PACKAGE") for e in events if e.get("Action") == "fail"]
        skipped = [e.get("Test", "PACKAGE") for e in events if e.get("Action") == "skip"]
        expected = set(request["expected_named_tests"])
        receipt["json_terminal_events"] = [e for e in events if e.get("Action") in ("pass", "fail", "skip")]
        receipt["named_tests_run"] = ran
        receipt["named_tests_passed"] = passed
        receipt["missing_expected_tests"] = sorted(expected - set(passed))
        receipt["unexpected_tests"] = sorted((set(passed) | set(ran)) - expected)
        receipt["failed"] = failed
        receipt["skipped"] = skipped
        receipt["invalid_json_lines"] = invalid
        receipt["exact_expected_counts"] = len(ran) == len(passed) == len(expected)
        receipt["runtime_status"] = "PASS" if (receipt.get("returncode") == 0 and not invalid and not failed and not skipped
            and set(passed) == set(ran) == expected and receipt["exact_expected_counts"]) else "FAIL"
        errlog = run / "stderr.log"
        if errlog.is_file():
            receipt["stderr_sha256"] = digest(errlog.read_bytes())
        (run / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    if not receipt.get("predecessors_source_executables_unchanged"):
        return 70
    return receipt["returncode"] if receipt["returncode"] != 0 else (0 if receipt["runtime_status"] == "PASS" else 71)

if __name__ == "__main__":
    raise SystemExit(main())
