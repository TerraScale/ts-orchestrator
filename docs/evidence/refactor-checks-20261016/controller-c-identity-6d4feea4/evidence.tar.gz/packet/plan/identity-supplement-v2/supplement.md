# Controller-c external-seed producer identity supplement

**No-task/no-pull is UNPROVEN.** Always-on reconciliation remains intact. A future no-workload observation window requires real signed service spec/current allocation/DATA-hold evidence. This identity slice neither establishes that window nor authorizes a native run.

Status: source-only plan; no Go/source edits, builds, tests, servers, VM/native runs, cloud operations, Git mutations, pushes or new agents. Existing broad plan and prior evidence are unchanged. No broad HomeIAM/Vault implementation is proposed.

## Smallest concrete correction

Change the completed offline production packet scenario from seed-a to controller-c as its sole external seed. Preserve managed controller-a/controller-b and preserve IPs a=.11, b=.12, c=.10. The full sorted slot set becomes [controller-a, controller-b, controller-c]. Production naming then yields gru-1-ctl-3 for the external seed, agreeing with lower92e; production naming/authorizers are not changed.

This is one atomic fixture correction across nine non-test source files, seven test files and two documentation files. Splitting the identity rename across these owners creates a producer/consumer mismatch. Do not add topology knobs, compatibility branches, a second fixture framework, new auth/transport seams, or production flags. Do not change a HostGrant alone.

A new packet is freshly generated and signed. Replacing text in existing signed JSON invalidates signatures/digests and is forbidden. Historical seed-a packet logs/receipts remain historical. No already emitted packet or prior checksum is rewritten.

## Owning scenario and connected call chain

Rename existing TestCompletedPacketEmitsSignedThreeSlotCaptureAndVerifiedFloors in complete_packet_integration_test.go to:

    TestCompletedControllerCSeedPacketEmitsSignedCaptureAndVerifiedFloors

Default tags: no fixturetest tag. Repeat this same selector with fixturetest to retain the already integrated F2 observer lane. The new name records the changed scenario identity; earlier TestCompletedPacket... receipts remain pinned to their original commits and are not relabeled.

Existing chain stays intact: productionGuestTestInputs -> jwtsetup a/b/c credentials -> syntheticSignedHistoryRecipeWithMaterials -> real public trust/bootstrap signing -> SignedHistoryRecipe.Prepare -> EmitCompletedRestartPacket -> public Ledger ReserveSlot/RecordExternalSeed(c)/RecordManagedPeerCandidate(a/b)/RecordManagedPeer(a/b) -> verified ReadSlot and NewHistoricalLedger reread -> BuildFounderSelectionSource (host-only selector) -> BuildVerifiedGuestMaterial -> BuildVerifiedSeedFloorArtifacts(c)/BuildVerifiedPeerFloorArtifacts(a/b) -> BuildComputeInventory + captured exact Object Storage inventory -> signed manifest/files -> VerifyPacketEmbeddedImage + ValidateProductionGuests -> existing SDK/socket assertions for all three slots. No app runtime wrapper is replaced or claimed executed.

## Values that must migrate together

1. Signed authority/history: anchor ControllerSlots and ledger delegation slots; c launch profile; every manifest Slot/SeedSlot/ControllerSlots/profile list; root-signed FounderPlan SeedSlot=c, seed-manifest digest and private IP, a/b route endpoint rows; FounderPlan trust scope Slot=c; current FounderSelection manifest pins; observed instance/create/request/ETag maps; c has external-seed intent and seed receipt with no managed retry token, a/b retain managed intent/candidate/progress/peer receipts and retries. Public ledger object keys/body hashes, signed heads/results and selector/floor pins are regenerated from these signed inputs.
2. Installed marker/material: all accepted-install SeedSlot values become c; c Slot and InstanceOCID/primary VNIC/IP bind the c completed result; c marker uses SeedReceiptRecord, peers use PeerReceiptRecord. Host-only selector source contains the c manifest, while restart simulator still excludes selector requests. c floor and lock are built through the existing verified seed-floor API with unchanged UID/GID/0600 files/0700 directories. Slot-derived secret OCIDs, credentials/config digests and marker MaterialSHA256 are recalculated; source/executable/image receipt verification is preserved. Current packet emits AcceptedInstall, not a new full live AcceptedIdentity/material-generation contract; do not claim otherwise.
3. Broker/JWT/TLS: change only the producer's existing jwtsetup --brokers argument to controller-a,controller-b,controller-c. It already derives c.creds, signed user claims and exact broker fence grants. Regenerate all account/user keys and JWTs together; shared credentials change digests when reissued. c TLS file names become nats-controller-c.pem/key, subject CN follows the slot, private-IP SAN stays .10. c config NATS.Instance, CandidateID, CredentialsFile, TLS references and every BrokerIDs/route peer list match. Call naming.RegionCell(GRU).ControllerSlot(c) and naming.NATSServer(gru,c) as independent consumers; both must yield gru-1-ctl-3. Do NOT set logical broker IDs to the server name: slot identity c and derived server name have different contracts. Existing unused jwtsetup --host-node host-a generates a generic host credential outside GuestMaterialInputs; keep it until actual enrollment is a separate slice. It is not ownhost credentials or an ownhost pass.
4. Wire/packet/driver: signed manifest Controllers/GuestRoot/OwnerRole keys, per-slot simulator IMDS directory and DescriptorSlot, instance and VNIC IDs, Compute URI bodies and route ControllerSlot/InstanceOCID, captured ledger object names and digest response paths must agree. Existing simulator derives federation sub from its per-slot InstanceID, so c gets c's instance subject without changing token generation. Its missing opc-instance/ptype/tenant claims remain an explicit later blocker. Driver ProductionSlots/ProductionAddresses change to c=.10; audit keys, private routing/firewall iteration, tap/image/socket names and SSH targets follow that fixed map. No new routes, ports, methods, HomeIAM or Vault handlers are added in this slice.
5. Strict negatives: swapped external/managed roles, missing peers, wrong/duplicated slots, wrong instance, path traversal, private-key spill, immutable-copy corruption, source omissions and signature/digest tamper still reject. Update diagnostic text only where it names the new required seed. Keep or add a narrow seed-a rejection witness at the fixed packet boundary so an old topology does not accidentally pass as the new one. Do not lower counts or omit F2 nine independent rejection cases to make migration pass.

## Exact file claims

The claims below are a proposed atomic change set requiring owner coordination, not edits performed here. No new Go file is needed; extend the existing owning scenario.

### Non-test sources

| File | Required change |
|---|---|
| tests/firecracker/production/fixturegen/signed_history_recipe.go | Fix the exact three-slot anchor and founder-plan seed check; sign controller-c through the external-seed branch while a/b stay managed. |
| tests/firecracker/production/fixturegen/complete_packet.go | Require completed controller-c external-seed history with exactly managed a/b before capture or publication. |
| tests/firecracker/production/fixturegen/founder_selection_source.go | Stage the controller-c signed manifest in the separate host-only current selector source. |
| tests/firecracker/production/fixturegen/capture_inventory.go | Require the coherent a/b/c anchored topology before deriving exact captured Object Storage routes. |
| tests/firecracker/production/fixturegen/guest_material.go | Select seed state/seed receipt/floor branch for c; write SeedSlot=c in every marker; regenerate slot-derived credential refs, directories and material hashes. |
| tests/firecracker/production/fixturegen/guest_directories.go | Require c in signed guest directory plan with unchanged service ownership/modes. |
| tests/firecracker/production/fixturegen/packet.go | Require sorted a/b/c packet identity and c durable-floor paths; preserve strict file, source and identity validation. |
| tests/firecracker/production/fixturegen/production_guest.go | Require a/b/c BrokerIDs and derive exact peer routes from those observations; retain ba75 stale-Lab removal. |
| internal/qualification/firecracker/production.go | Change fixed ProductionSlots/ProductionAddresses key seed-a->controller-c with c still .10; all VM/audit/firewall/SSH consumers follow those maps without new driver features. |

### Tests

| File | Required change |
|---|---|
| tests/firecracker/production/fixturegen/signed_history_recipe_test.go | Regenerate root/delegation/anchor/launch profiles/all manifests/plan scope+seed manifest pin/current selection/observed IDs and retry distinction; seed assertion targets c. |
| tests/firecracker/production/fixturegen/complete_packet_integration_test.go | Rename the owning connected scenario, migrate malformed-material map keys, and add independent c external-seed/marker/name/JWT/route witnesses to the existing scenario. |
| tests/firecracker/production/fixturegen/complete_packet_test.go | Migrate fixed packet fixtures/error assertion and preserve swapped/missing role negatives; add one legacy seed-a rejection only if current role cases do not cover it. |
| tests/firecracker/production/fixturegen/production_guest_test.go | Invoke existing jwtsetup with a/b/c; retain .10 for c; regenerate c creds, TLS filenames/CN/private-IP SAN, candidate ID and config BrokerIDs/routes. |
| tests/firecracker/production/fixturegen/packet_test.go | Migrate all fixed packet identities, guest paths, route ownership, instance suffixes and packet-copy/tamper/private-key negatives coherently. |
| tests/firecracker/production/fixturegen/capture_inventory_test.go | Migrate fixed anchored slot list/controller roots and the captured seed object/missing keys; retain exact SDK URI and private-domain assertions. |
| internal/qualification/firecracker/production_test.go | Migrate expected audit count maps and seed-slot mutation keys to c; preserve rejection counts, firewall, reboot, cleanup and namespace assertions. |

### Documentation

| File | Required change |
|---|---|
| tests/firecracker/production/README.md | State a/b/c topology and c external seed for future packets; preserve the recorded historical failed VM result. |
| tests/firecracker/production/fixturegen/RECIPE.md | Describe c external seed and new owning selector, retain a/b managed roles and historical evidence limitations. |

## References deliberately left alone

The complete reference-inventory.md and references.json preserve every repository literal seed-a match and its disposition. Generic bootstrap/manifest/ledger/CLI tests retain their arbitrary external-seed names; seed mode is not globally renamed. internal/ociregion/seed.go's seed-a- create identity prefix belongs to preview identity generation, not this packet's logical slot. Two references inside the production fixture directory are independent generic tests: routes_test.go preserves arbitrary exact object-key bytes, and fixturegen/cmd/main_test.go verifies signing-key containment under an arbitrary guest path. They need no cosmetic edit. Historical evidence logs are immutable.

Data-driven consumers with no seed-a literal require no edits: histories.go, routes.go, compute_inventory.go, verified_production_guest.go, stage_guest.go, source_inventory.go, fixturegen/cmd/serve.go, simulator.go, jwtsetup/main.go and both compute_inventory_observer_*_test.go lanes. Their migrated outputs are tested through the owning scenario. compute_inventory_sdk_test.go's dispatcher/SDK helpers remain unchanged: the c config/instance/route values flow from the packet; its per-slot instance cert helper currently binds fixture tenancy and uses separate generated keys, not an Oracle-issued instance certificate. Do not invent stronger identity provenance for it. F2 rejection subcases remain on controller-a and all three positive observer cases remain data-driven.

## Independent provenance witnesses in the changed owning scenario

Use the existing connected scenario to assert facts through consumers separate from the producer strings; no second full integration harness is needed.

1. Public ledger witness: reopen c via verified ReadSlot/historical reader and require external-seed mode, c Result/Manifest/SeedReceiptRecord/head digests; reopen a/b with managed mode and Candidate/Progress/PeerReceiptRecord. Verify the signed founder plan/selection/manifest pins with the actual public verifier and externally retained test root. Require old seed-a packet topology to reject before emission.
2. Extracted guest witness: decode each signed packet's accepted-install JSON, compare c's fields/digests to the verified c ledger state and compare peer receipts to the peers; verify every marker SeedSlot=c. Read c service directory/floor/lock and c credential bytes through VerifiedPacket APIs; require unchanged modes/owners and no host-only selector/signing key in GuestFiles. Keep existing ValidateProductionGuests and VerifyPacketEmbeddedImage checks.
3. Naming/JWT witness: call existing production naming consumers for c -> gru-1-ctl-3; validate extracted c.creds with ValidateBrokerControllerCredentialBytes(bytes,gru,controller-c), and require the same credential to fail the seed-a broker scope (instance fence-grant mismatch). Do not manually generate permissive NATS credentials or relabel user IDs. Existing parser/verifier checks c config path/TLS/account scope and exact BrokerIDs.
4. Wire witness: existing real SDK/federation/localhost HTTP dispatcher checks byte/hash equality between packet provider responses and socket responses, decoded c instance/primary VNIC/subnet values and exact listed request sequence. Tagged F2 observer retains all its observed requests, hashes and nine negative field validations. Record c SimulatorConfig DescriptorSlot/InstanceID/private IP and ensure no old seed route/controller key remains in the NEW emitted packet. Generic tests/historical files may still contain seed-a.
5. Provenance receipt: pin new source commit+tree, changed file blob IDs, renamed selector, default/tagged binary SHA256, exact argv/cwd/parent-child execution, exit status/duration/skip count, fresh packet signature/inventory/source hashes and per-slot evidence. Compare original ba75 SDK observer helper blobs and documented changed recipe blobs, rather than borrowing ba75 runtime counts as a new pass. Store hashes/public identifiers only; no private key/JWT/credential bodies.

## Minimum validation after implementation and a QA lease

These are proposed commands, NOT executed by this source inspection. Run once on a frozen connected source commit; all local children inherit nice19, including existing go run ../../jwtsetup. No nice changes belong in CI/scripts.

    nice -n 19 mise exec -- go test ./tests/firecracker/production/fixturegen ./internal/qualification/firecracker -count=1
    nice -n 19 mise exec -- go test -tags fixturetest ./tests/firecracker/production/fixturegen -run '^TestCompletedControllerCSeedPacketEmitsSignedCaptureAndVerifiedFloors$' -count=1 -v

The first command covers the changed default producer/packet/driver test packages, including copied fixtures/negative contracts. fixturegen/cmd tests and production simulator tests are unchanged; no extra package run is needed unless implementation expands into them. The second command validates the new same-scenario identity with the current tagged F2 observer/socket lane. The default package run already covers the renamed owning selector, so no duplicate default single-selector rerun is required. If QA mandates compile/run separation, replace a command with one nice19 go test -c plus that binary's same selector; do not add redundant runs.

Read-only diff review must confirm only these claimed files changed, all connected literal references migrated, no new seed-a value in the emitted packet, helpers outside the claim unchanged, validators/negative cases intact and no new switches/auth/transport seams. gofmt only changed Go files. Before any Go edits, use the already active Modern Go Guidelines skill's version 1.27 CLI output as required. No implementation is authorized by this supplement.

## Historical evidence and exclusions

Lower startup582a39920cf2e486306579c9a66ceefb17cb013d and lower enrollment92eacab24e601386cf909a1bf7e1929d3913c7d5 remain separate composition/agent passes. F2 exact ba75b29add6bbeea4d36d5e326cce84b7f6190b7 retains its original seed-a owning selector and original 59 service-response witness; publication state is managed by QA. None is converted to a controller-c packet result. The broad plan /tmp/ts-app-production-ownhost-plan-c748d540/plan.md remains byte-identical and its no-workload caveat is strengthened at the top of this supplement.

The only future success claim for this slice is a coherent signed offline external-seed controller-c producer packet consumed by existing SDK/default+tagged observer tests and fixed driver identity readers. It does not qualify RunManagedRuntime, sdnotify READY order, production management cgroup/HTTPS ownhost enrollment, independent production binding constructor, full live material/AcceptedIdentity generation, HomeIAM/Vault, registry/pulls/allocations, native/restart execution, live OCI or deployment. Full production IAM token and metadata contracts remain incomplete. No-task/no-pull remains unproven under always-on reconciliation.

Next action for QA: assign the eighteen-file atomic identity correction to the packet/driver owner; keep native execution unscheduled.
