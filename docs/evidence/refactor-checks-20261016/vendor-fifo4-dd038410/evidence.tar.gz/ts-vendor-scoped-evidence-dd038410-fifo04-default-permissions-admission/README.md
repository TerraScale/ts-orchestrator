# FIFO4 default-permissions admission evidence

Frozen source dd03841025c65c0a6c3350b3e8ad7c4d27eea77d; tree
bac4b5eae4c69633777f8f89291cc032ea69b68c. Short-A session 17084,
exit 0: TestAccountDefaultPermissionsAdmissionRaceOverTCP PASS 2.36s;
package PASS 2.374s. Exactly one root-only case; zero skips or extras.
This packet packages the existing single invocation; no runner was launched.

Exact dispatch/argv/cwd, queue, recorder, self-check, audits, source binding,
historical resource plan, before/broker/canonical receipts and one individual
outcome/output are included. Raw JSONL decompresses byte-for-byte from gzip
mtime 0. All 155 frozen hashes match before/after and at packaging; source
HEAD/tree are clean. Original operation guards remain 2s. Parent authorized
outer 240s/test 180s; resource envelope/counts are source-derived, unmeasured.

Preparation dispatch, queue, audit, handoff and source-contract status strings
are historical source-only statuses, preserved byte-exact. Terminal receipts
record the later separately granted FIFO4 PASS. Metadata references to unrun
positions convey no runtime credit; no unrun Go source bodies are included.
FIFO5-11 remain source-only: seven batches, eight roots, 81 cases, no grant.
STOPPED after FIFO4, including after PASS; both lanes idle at completion.

Public auth/update paths reach locked fields, but exact original concurrent
interleaving and race-detector coverage remain open. Tokens were signed before
workers; full-resolver callbacks may serialize updates. Original/private,
equivalence/removal/central-closure/full-suite/live/production qualification
remains open. No source/feature edit, Git operation, retry or cloud action ran.

The five previous packets and three existing archives remain byte-identical;
historical-packets.json binds every file and existing archive. Copy provenance
is in source-artifact-map.json. evidence-manifest.json hashes payload files;
SHA256SUMS additionally binds the manifest. The matching tar.gz uses sorted
regular PAX members, uid/gid/mtime 0, mode 0644, empty owner/group and gzip
mtime 0. Two archive builds must match. A separate archive-verification.json
report records independent reopening, every member byte/hash/metadata and the
complete member map including manifest and SHA256SUMS.

fifo04-inventory-reconciliation-input.json is a distinct proposed inventory
input only. No canonical/broker receipt was overwritten. Any reconciliation
must use another unique basename and retain historical outcomes/private gaps.
