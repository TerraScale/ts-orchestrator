# FIFO6 source-only diagnosis

**Keep FIFO6 FAILED. No fixture correction is established.** Source supports a
production stale/duplicate service-import subscription candidate. The exact
runtime interleaving is not recorded. No Go/source changes or runners.

## Failure and public contract

The `svc.0 != svc.1` assertion at [accounts_test.go:1508](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/accounts_test.go:1508)
occurs in sequential final loop i=1. Loop i=0 already passed exact subject,
payload and reply checks. The single exporter wildcard subscription is at
[accounts_test.go:1453](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/accounts_test.go:1453). The helpers perform
one PublishRequest and one NextMsg [gateway_test.go:261](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/gateway_test.go:261),
[gateway_test.go:302](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/gateway_test.go:302). There is no unordered
result set to accommodate, and draining would hide an unexpected delivery.

Workers completed successful-return barriers for2000 refresh requests and50
delete/restore cycles before final deletion, denied reconnect and restoration
[accounts_test.go:1488](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/accounts_test.go:1488). The source workload
is2102 SYS calls including51 delete writers. This does not reproduce original
2000 private-write trials or establish simultaneous internal callback execution.

## Source-supported lifetime defect candidate

1. Refresh copies old imports/SIDs into a local map and empties the current
   map [accounts.go:3540](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/accounts.go:3540). It releases cmu while
   resolving/rebuilding imports [accounts.go:3697](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/accounts.go:3697).
2. Delete enumerates only current imports, detaches a.ic and closes the client
   [accounts.go:2295](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/accounts.go:2295). Old map entries held only
   in refresh's local map can be invisible to deletion.
3. Refresh cleans old SIDs using **current a.ic**, not their recorded owner
   [accounts.go:3823](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/accounts.go:3823). If deletion detached C0
   and rebuild created C1, old C0 SIDs are looked up on C1. Unsubscribe looks
   only in that client's map [client.go:3522](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/client.go:3522).
4. ACCOUNT close skips the generic subscription sweep
   [client.go:6236](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/client.go:6236). A still-open stale subscription
   can invoke its callback despite owning-client closure
   [client.go:3801](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/client.go:3801),
   [client.go:3927](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/client.go:3927). Orphan plus current service
   callbacks can forward one svc.0 more than once.

A second candidate window: si.sid is published under a.mu before actual
subscription installation outside that mutex
[accounts.go:2275](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/accounts.go:2275). Delete can unsubscribe before
insertion. processSubEx permits closed internal clients while c.subs remains
nonnil [client.go:3085](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/client.go:3085). Neither interleaving is
runtime-proved by the existing log.

Two SYS sockets do not impose global callback serialization: subscriptions
install direct handlers [events.go:2850](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/events.go:2850), invoked
inline after subscriber mutex release [client.go:3933](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/client.go:3933).
Store save unlocks before changed callback [dirstore.go:498](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/dirstore.go:498),
whereas delete invokes deleted under its store lock
[dirstore.go:458](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/dirstore.go:458). Other locking may serialize parts;
exact overlap remains unknown.

## Smallest separate diagnostic proposal

On mismatch only, before unchanged exact assertions, record loop index,
expected/actual subject, actual payload/reply and accepted i=0 request metadata.
Capture two failure-only public HTTP snapshots with existing2s guards:
`/subsz?subs=1&acc=<importer>&test=svc.0` and the equivalent svc.1 request.
Retain returned SID/message counts and pagination metadata. No drain, retry,
extra publish, changed expected payload or weakened subject/reply assertion.

The [monitor API](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/monitor.go:963) exposes these filters and details;
local collection includes ACCOUNT subscriptions
[sublist.go:1568](/tmp/ts-vendor-union-qa-dd038410/third_party/nats-server/server/sublist.go:1568). Multiple svc.0 imports after
final restore support duplicate state; payload identifies the observed phase.
A clean snapshot cannot exclude earlier cached/in-flight forwarding. Cost is
at most two extra HTTP requests only on failure, with2102 SYS calls unchanged.

## Bounds and correction ownership

Failure raw output omits actual payload/reply, SID/client generations and
callback order. Duplicate final svc.0, stale earlier traffic and svc.1 misrouting
cannot be conclusively separated. No fixture correction or production fix is
claimed as proved. A separately owned production review must preserve old-client
and SID ownership and coordinate in-flight insertion with deletion; capturing
an old client alone does not resolve every candidate lifetime window.

Original private locked-reader/SID stress, race detector, equivalence/removal/
closure remain open. FIFO7/retry ungranted. The matching JSON binds exact source
hashes and receipt hashes. All155 bindings match; additionally inspected
sublist.go is byte-identical to the selected commit blob.
