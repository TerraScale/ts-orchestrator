"""Authorized metadata-only parser self-check; no candidate entry points or subprocesses."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/tmp/ts-nats-vendor-migration-20261016/fifo06-diagnostic-parser-selfcheck-13185dcc-v1')
PACKET = Path('/tmp/ts-nats-vendor-migration-20261016/fifo06-diagnostic-dispatch-13185dcc-v3')
PYTHON = '/home/mariogk/.local/share/mise/installs/python/3.15.0/bin/python3.15'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_once(path, value):
    with Path(path).open('x') as output:
        json.dump(value, output, indent=2, allow_nan=False)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())


assert os.getpriority(os.PRIO_PROCESS, 0) == 19
assert str(Path('/proc/self/exe').resolve()) == PYTHON
assert sha(PYTHON) == '71c06b34ffee909d39e88c70c317e7e4f02dd43a491932d1ce165c0b291f433f'
assert sys.dont_write_bytecode and sys.flags.isolated
plan = json.loads((PACKET / 'dispatch.json').read_text())
assert dict(os.environ) == plan['environment']
assert sha(PACKET / 'dispatch.json') == 'dc6df398ba3b0a54c8e3a07985563da012fce2b2429d19435e36cfdbde731237'
source_manifest = json.loads((PACKET / 'resource-source-binding-manifest.json').read_text())
watched = {**plan['scripts'], **plan['executables'], **plan['preserved_sha256'],
           **source_manifest['old155'], **source_manifest['successor155'],
           **{str(p): sha(p) for p in PACKET.iterdir()}}
packet_members = sorted(p.name for p in PACKET.iterdir())
assert len(plan['preserved_sha256']) == 292
for path, expected in watched.items():
    assert sha(path) == expected, path
for path in plan['outputs'].values():
    assert not Path(path).exists() and not Path(path).is_symlink(), path
write_once(ROOT / 'before-bindings.json', {
    'sha256': watched, 'packet_members': packet_members,
    'reserved_outputs_absent': plan['outputs'], 'interpreter': PYTHON, 'niceness': 19,
})
blocked_attempts = []
forbidden_calls = []


def audit(event, args):
    if event in ('subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.fork',
                 'os.forkpty', 'os.exec', 'socket.__new__', 'socket.connect'):
        blocked_attempts.append(event)
        raise RuntimeError('Forbidden process/network action: ' + event)


sys.addaudithook(audit)
recorder_path = PACKET / 'receipt-recorder-v3.py'
spec = importlib.util.spec_from_file_location('fifo6_parser_selfcheck_only', recorder_path)
recorder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recorder)


def forbidden(*args, **kwargs):
    forbidden_calls.append('candidate_entry_point')
    raise RuntimeError('Candidate entry point is forbidden during parser self-check')


for name in ('main', 'load_plan', 'snapshot', 'record'):
    setattr(recorder, name, forbidden)
TEST, PACKAGE = recorder.TEST, recorder.PACKAGE


def event(action, test=None, **fields):
    value = {'Action': action, 'Package': PACKAGE}
    if test is not None:
        value['Test'] = test
    value.update(fields)
    return value


passed = [event('start'), event('run', TEST), event('output', TEST, Output='=== RUN   ' + TEST + '\n'),
          event('pass', TEST, Elapsed=0.01), event('output', Output='PASS\n'), event('pass', Elapsed=0.02)]
failed = copy.deepcopy(passed)
failed[2]['Output'] = 'accounts_test.go:1508: require string equal, but got: svc.0 != svc.1\n'
failed[3]['Action'] = failed[5]['Action'] = 'fail'
failed[4]['Output'] = 'FAIL\n'


def encode(events):
    return ''.join(json.dumps(item, allow_nan=False) + '\n' for item in events).encode()


cases = []


def add(name, data, scope_ok=False, is_pass=False):
    cases.append((name, encode(data) if isinstance(data, list) else data, scope_ok, is_pass))


def change(index, **fields):
    result = copy.deepcopy(passed)
    result[index].update(fields)
    return result


add('valid-pass', passed, True, True)
add('valid-fail', failed, True, False)
add('truncated', encode(passed)[:-1])
add('empty', b'')
add('malformed-json', b'{\n')
add('malformed-appended', encode(passed) + b'{\n')
add('nonobject-json', b'[]\n')
base = encode(passed)
add('duplicate-json-key', base.replace(b'"Action": "pass", "Package"', b'"Action": "pass", "Action": "fail", "Package"', 1))
for name, number in [('nan', b'NaN'), ('infinity', b'Infinity'), ('negative-infinity', b'-Infinity'), ('overflow', b'1e999')]:
    add('nonfinite-elapsed-' + name, base.replace(b'"Elapsed": 0.01', b'"Elapsed": ' + number, 1))
add('root-skip', change(3, Action='skip'))
add('package-skip', change(5, Action='skip'))
add('extra-test-output', change(2, Test='TestOther'))
add('extra-subtest-output', change(2, Test=TEST + '/extra'))
add('wrong-package-output', change(2, Package=PACKAGE + '/other'))
add('duplicate-root-run', passed[:2] + [copy.deepcopy(passed[1])] + passed[2:])
add('duplicate-root-terminal', passed[:4] + [copy.deepcopy(passed[3])] + passed[4:])
add('duplicate-package-terminal', passed + [copy.deepcopy(passed[5])])
add('missing-package-terminal', passed[:-1])
add('missing-package-start', passed[1:])
add('duplicate-package-start', [copy.deepcopy(passed[0])] + passed)
add('terminal-before-root-run', [passed[0], passed[3], passed[1], passed[2], passed[4], passed[5]])
add('root-output-before-run', [passed[0], passed[2], passed[1], passed[3], passed[4], passed[5]])
add('event-after-package-terminal', passed + [event('output', Output='extra\n')])
add('root-fail-package-pass', change(3, Action='fail'))
add('root-pass-package-fail', change(5, Action='fail'))
add('missing-root-run', passed[:1] + passed[2:])
add('missing-root-terminal', passed[:3] + passed[4:])
missing_package = copy.deepcopy(passed)
del missing_package[2]['Package']
add('missing-package-field', missing_package)
add('blank-json-line', base + b'\n')
add('invalid-output-type', change(2, Output=7))
add('negative-elapsed', change(3, Elapsed=-0.01))
add('boolean-elapsed', change(3, Elapsed=True))
add('package-start-out-of-order', [passed[4], passed[0], *passed[1:4], passed[5]])
add('unknown-action-pause', passed[:2] + [event('pause', TEST)] + passed[2:])
add('package-start-with-test', change(0, Test=TEST))
add('invalid-utf8', base + b'\xff\n')
add('root-output-after-root-terminal', passed[:4] + [copy.deepcopy(passed[2])] + passed[4:])
fixtures = ROOT / 'fixtures'
fixtures.mkdir()
results = []
for number, (name, data, expected_scope, expected_pass) in enumerate(cases, 1):
    path = fixtures / f'{number:02d}-{name}.jsonl'
    with path.open('xb') as output:
        output.write(data)
    fixture_sha = sha(path)
    try:
        result = recorder.summarize(path)
        assertions = {
            'scope': result['scope_ok'] is expected_scope,
            'pass': result['passed'] is expected_pass,
            'errors': (not result['errors']) if expected_scope else bool(result['errors']),
            'fixture_unchanged': sha(path) == fixture_sha,
        }
        outcome = {'name': name, 'fixture': str(path), 'sha256': fixture_sha,
                   'expected_scope_ok': expected_scope, 'expected_passed': expected_pass,
                   'assertions': assertions, 'passed': all(assertions.values()), 'result': result}
    except Exception as error:
        outcome = {'name': name, 'fixture': str(path), 'sha256': fixture_sha,
                   'passed': False, 'error': repr(error)}
    results.append(outcome)
after = {path: sha(path) for path in watched}
unchanged = after == watched and packet_members == sorted(p.name for p in PACKET.iterdir())
reserved_absent = all(not Path(path).exists() and not Path(path).is_symlink() for path in plan['outputs'].values())
write_once(ROOT / 'after-bindings.json', {
    'sha256': after, 'packet_members': sorted(p.name for p in PACKET.iterdir()),
    'reserved_outputs_absent': reserved_absent, 'matches_before': unchanged,
})
all_passed = all(item['passed'] for item in results) and unchanged and reserved_absent and not blocked_attempts and not forbidden_calls
receipt = {
    'status': 'PASS' if all_passed else 'FAIL', 'case_count': len(results),
    'passed_cases': sum(item['passed'] for item in results), 'cases': results,
    'recorder': str(recorder_path), 'recorder_sha256': sha(recorder_path),
    'dispatch_sha256': sha(PACKET / 'dispatch.json'), 'selfcheck_source_sha256': sha(__file__),
    'before_bindings_sha256': sha(ROOT / 'before-bindings.json'),
    'after_bindings_sha256': sha(ROOT / 'after-bindings.json'),
    'all_watched_hashes_and_members_unchanged': unchanged,
    'preserved_evidence_count': len(plan['preserved_sha256']),
    'reserved_runtime_outputs_absent': reserved_absent, 'blocked_attempts': blocked_attempts,
    'forbidden_entry_point_calls': forbidden_calls,
    'interpreter': PYTHON, 'interpreter_sha256': sha(PYTHON), 'niceness': 19,
    'candidate_module_name': recorder.__name__,
    'executed_scope': 'Only importlib import of recorder under a non-main name and summarize on fresh synthetic fixtures; no candidate main/load_plan/snapshot/record/wrapper, subprocess, Go, network, Git, lane or live test.',
    'original_fifo6_failure': 'RETAINED_FAIL_OPEN', 'disposition': 'HOLD; live runtime grant remains separate.',
}
write_once(ROOT / 'selfcheck-receipt.json', receipt)
print(json.dumps({'status': receipt['status'], 'cases': len(results), 'passed': receipt['passed_cases'],
                  'unchanged': unchanged, 'reserved_absent': reserved_absent,
                  'receipt_sha256': sha(ROOT / 'selfcheck-receipt.json'),
                  'failed_cases': [item['name'] for item in results if not item['passed']]}))
assert all_passed, 'Metadata-only parser self-check failed; preserve receipt and HOLD'
