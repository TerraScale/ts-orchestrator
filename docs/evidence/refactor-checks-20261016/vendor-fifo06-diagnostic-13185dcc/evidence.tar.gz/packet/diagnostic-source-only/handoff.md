# FIFO6 diagnostic successor: source only

Frozen commit `13185dcce9ef94f66359f0c5f740db93d5a5cb7e`, tree `223a8f501d826e6c02d81361ec28724f361b7d07`, parent exact`dd03841025c65c0a6c3350b3e8ad7c4d27eea77d`.
Branch`qa/fifo06-diagnostic-dd038410`, worktree`/tmp/ts-vendor-fifo06-diagnostic-dd038410` is clean.
Only`third_party/nats-server/server/accounts_test.go` changed; only authorizedFIFO6body;27insertions,0deletions.

On subject/payload mismatch, log index/expected+actualsubject/payload, published
reply/actualmappedreply andacceptedfinali0metadata; then at most2fixed2s public
HTTPsubsz calls(svc.0,svc.1;importer filter). Rawstatus/body/read/close errors
are logged. Exact original subject/data/reply assertions, allSYS/servicework
and every other body/import/helper/productionbyte stay identical. No drain,
retry, extra publish, addedloop or private server/subscription state read.
MonitorAddr is the existing public address accessor. Existingmonitorhelpers
are unsafe here because they failfatally or use unboundedhttp.Get.

Rawdiff/bodybytes/preservationproof, source-derived resource delta, original
failed evidence and eight prior packet/file/archive hashes are included. Original
dd155 bindings remain untouched. Successor155map relocates sourcefiles and has
exactlyone changed hash (accounts_test.go); historical artifacts stay historical.

Read full ModernGo list and t.Context explanation before edit. Only pinned
Go1.27.1`nice -n19 gofmt` ran; byte/scope assertions andgitdiffcheck passed.
No build/test/server/runner/retry/FIFO7/cloud/push/newagent orproductionedit.

Runnerproposal is ungranted and bound to this clean commit/tree/map. Existing
dd-only metadata recorder rejects this revision; a successor-aware recorder
requires separate review before execution. Originalfailure andprivate2000trial/
SID/race/interleaving/equivalence/removal/closure gaps remainopen. Freeze/HOLD.
