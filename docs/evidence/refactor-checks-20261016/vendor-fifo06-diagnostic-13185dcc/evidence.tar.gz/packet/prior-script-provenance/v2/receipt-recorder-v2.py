#!/usr/bin/env python3
"""Successor FIFO6 metadata recorder. Never launches Go or advances a queue."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/tmp/ts-nats-vendor-migration-20261016/fifo06-diagnostic-dispatch-13185dcc-v2')
WORKTREE = '/tmp/ts-vendor-fifo06-diagnostic-dd038410'
OLD_WORKTREE = '/tmp/ts-vendor-union-qa-dd038410'
REVISION = '13185dcce9ef94f66359f0c5f740db93d5a5cb7e'
TREE = '223a8f501d826e6c02d81361ec28724f361b7d07'
BASE = 'dd03841025c65c0a6c3350b3e8ad7c4d27eea77d'
BASE_TREE = 'bac4b5eae4c69633777f8f89291cc032ea69b68c'
MAP = '/tmp/ts-nats-vendor-migration-20261016/fifo06-diagnostic-dd038410/successor-bindings.json'
MAP_SHA = '667e258e762ce8958e3d5bb71967e8bfe6185a3416186f35314ad0461b1f66ac'
OLD_DISPATCH = '/tmp/ts-nats-vendor-migration-20261016/remaining-fifo-source-dd038410/dispatch/position-06/dispatch.json'
OLD_DISPATCH_SHA = '8a725f6ec9f715473dd10dc12d9d7334eb4e80e8b5842d499a3be84416059567'
TEST = 'TestAccountServiceRemovalConcurrentRefreshOverTCP'
PACKAGE = 'github.com/nats-io/nats-server/v2/server'
PYTHON = '/home/mariogk/.local/share/mise/installs/python/3.15.0/bin/python3.15'
GO = '/home/mariogk/.local/share/mise/installs/go/1.27.1/bin/go'
GIT = '/nix/store/b1wn5clix1mz4vpfih7x9cnj9qfh7c6h-git-2.54.0/bin/git'
CORE = '/nix/store/bhv6xyvqw6gjs3j488gi1z6wdv18bdpa-coreutils-9.11/bin/'
FLOCK = '/nix/store/0bmapmnznzaxgx76jhzbznhlwq738g03-util-linux-2.42.3-bin/bin/flock'
LOCK = '/tmp/ts-orch-refactor-short-check-a.lock'
ENVIRONMENT = {
    'HOME': '/home/mariogk', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
    'PATH': '/home/mariogk/.local/share/mise/installs/go/1.27.1/bin:/run/current-system/sw/bin:/usr/bin:/bin',
    'GOMAXPROCS': '2', 'GOFLAGS': '-p=2',
    # Third-party execution confinement: ignore user Go settings and toolchain downloads.
    'GOENV': 'off', 'GOTOOLCHAIN': 'local',
    # Third-party read-only Git inspection must not refresh the index.
    'GIT_OPTIONAL_LOCKS': '0',
}
ARGV = [CORE + 'timeout', '--signal=TERM', '--kill-after=5s', '240s',
        FLOCK, '-n', LOCK, CORE + 'env', '-u', 'GOROOT',
        'PATH=' + ENVIRONMENT['PATH'], 'GOMAXPROCS=2', 'GOFLAGS=-p=2',
        CORE + 'nice', '-n', '19', GO, 'test', '-p=1', '-parallel=1',
        '-mod=readonly',
        '-tags=skip_store_tests,skip_js_tests,skip_mqtt_tests,skip_msgtrace_tests,skip_no_race_tests',
        './server', '-run', '^' + TEST + '$', '-count=1', '-timeout=180s', '-json']
PREFIX = '/tmp/ts-vendor-diagnostic-13185dcc-fifo06-v2'
OUTPUTS = {name: PREFIX + suffix for name, suffix in {
    'before': '-before.json', 'launch': '-launch.json', 'raw': '.jsonl',
    'terminal': '-wrapper-terminal.json', 'receipt': '-receipt.json',
}.items()}
OUTPUTS['summary'] = '/tmp/ts-nats-vendor-migration-20261016/qualifications/diagnostic-13185dcc-fifo06-v2.json'
EXECUTABLES = {
    PYTHON: '71c06b34ffee909d39e88c70c317e7e4f02dd43a491932d1ce165c0b291f433f',
    GO: '30969f97169d7f43fe6a085873d75613adc21e30818a8c61d95bd27275df4624',
    GIT: 'f97ba8863b93a05b4193c5c436d95c62bb3879c96024753d764cf74d1594e027',
    FLOCK: '74d5a1efc2b47530bb7c6850d4f6b692b2c35a3e03a71d37cf50a7c9561d6914',
    **{CORE + name: '05218a9db33464c631d42a8a6cdbaec757d0df3c1678a87da11b0d2ec3a78d72'
       for name in ('timeout', 'env', 'nice')},
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError('Non-finite JSON value: ' + value)


def read_json(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique_object,
                      parse_constant=reject_constant)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_once(path, value):
    with Path(path).open('x', encoding='utf-8') as output:
        json.dump(value, output, indent=2, allow_nan=False)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())


def load_plan(path, expected_sha):
    require(Path(path) == ROOT / 'dispatch.json', 'Unexpected dispatch path')
    require(digest(path) == expected_sha, 'Dispatch SHA differs from reviewed binding')
    plan = read_json(path)
    expected = {'revision': REVISION, 'tree': TREE, 'base': BASE,
                'worktree': WORKTREE, 'cwd': WORKTREE + '/third_party/nats-server',
                'selector': '^' + TEST + '$', 'expected_tests': [TEST], 'package': PACKAGE,
                'lane': 'Short-A', 'lock': LOCK, 'outer_seconds': 240,
                'kill_after_seconds': 5, 'test_timeout_seconds': 180,
                'argv': ARGV, 'environment': ENVIRONMENT, 'outputs': OUTPUTS,
                'executables': EXECUTABLES, 'successor_map': MAP, 'successor_map_sha256': MAP_SHA,
                'original_dispatch': OLD_DISPATCH, 'original_dispatch_sha256': OLD_DISPATCH_SHA,
                'status': 'SOURCE_ONLY_REVIEW_REQUIRED_NO_RUNTIME_GRANT',
                'stop_after_terminal': True, 'automatic_advance': False,
                'original_failure_disposition': 'RETAINED_FAIL_OPEN'}
    for key, value in expected.items():
        require(plan.get(key) == value, 'Dispatch policy differs: ' + key)
    require(set(plan['scripts']) == {str(ROOT / 'receipt-recorder-v2.py'),
                                      str(ROOT / 'run-once-v2.py')}, 'Unexpected scripts')
    require(digest(MAP) == MAP_SHA, 'Successor map changed')
    require(digest(OLD_DISPATCH) == OLD_DISPATCH_SHA, 'Original dispatch changed')
    successor = read_json(MAP)
    original = read_json(OLD_DISPATCH)
    require(successor['revision'] == REVISION and successor['tree'] == TREE
            and successor['worktree'] == WORKTREE, 'Successor map identity differs')
    old_map, new_map = original['frozen_sha256'], successor['frozen_sha256']
    relocated = {path.replace(OLD_WORKTREE + '/', WORKTREE + '/', 1): sha
                 for path, sha in old_map.items()}
    require(len(old_map) == len(new_map) == 155 and set(relocated) == set(new_map),
            'Maps must contain the same 155 relocated keys')
    changed = [path for path in new_map if relocated[path] != new_map[path]]
    changed_file = WORKTREE + '/third_party/nats-server/server/accounts_test.go'
    require(changed == [changed_file] and new_map[changed_file] ==
            '0448ecc0279446309d3a56f85c0d2b3af546224c7a8aad46e6d55bd0bceb238a',
            'Successor must change exactly the diagnostic accounts_test.go hash')
    return plan, old_map, new_map


def snapshot(plan, dispatch_sha, old_map, new_map, expected_cmdline):
    errors = []
    def hashed(paths):
        actual = {}
        for path, expected in paths.items():
            try:
                actual[path] = digest(path)
            except OSError as error:
                actual[path] = {'error': str(error)}
            if actual[path] != expected:
                errors.append('Hash binding differs: ' + path)
        return actual

    def git_state(worktree, revision, tree):
        state = {}
        for key, args in [('HEAD', ['rev-parse', 'HEAD']),
                          ('tree', ['rev-parse', 'HEAD^{tree}']),
                          ('status', ['status', '--porcelain=v1', '--untracked-files=all'])]:
            try:
                state[key] = subprocess.check_output(
                    [GIT, '-c', 'core.fsmonitor=false', '-C', worktree, *args],
                    text=True, stderr=subprocess.PIPE, timeout=15).strip()
            except (OSError, subprocess.SubprocessError) as error:
                state[key] = {'error': str(error)}
        if state != {'HEAD': revision, 'tree': tree, 'status': ''}:
            errors.append('Source identity or clean status differs: ' + worktree)
        return state

    source = {
        'successor': git_state(WORKTREE, REVISION, TREE),
        'original': git_state(OLD_WORKTREE, BASE, BASE_TREE),
        'old155': hashed(old_map), 'successor155': hashed(new_map),
        'preserved': hashed(plan['preserved_sha256']),
        'scripts': hashed(plan['scripts']),
        'dispatch': hashed({str(ROOT / 'dispatch.json'): dispatch_sha}),
        'executables': hashed(EXECUTABLES),
    }
    context = {'cwd': os.getcwd(), 'environment': dict(os.environ),
               'cmdline': Path('/proc/self/cmdline').read_bytes().rstrip(b'\0').decode().split('\0'),
               'interpreter': str(Path('/proc/self/exe').resolve()),
               'niceness': os.getpriority(os.PRIO_PROCESS, 0),
               'intended_argv': list(ARGV), 'intended_cwd': plan['cwd']}
    # Never persist an unexpected environment: it could contain credentials.
    if context['environment'] != ENVIRONMENT:
        context['environment'] = {'error': 'Environment differs from the complete approved allowlist'}
        errors.append('Wrapper/recorder environment differs')
    for key, expected in [('cwd', plan['cwd']), ('cmdline', expected_cmdline),
                          ('interpreter', PYTHON), ('niceness', 19)]:
        if context[key] != expected:
            errors.append('Execution context differs: ' + key)
    return {'source': source, 'context': context, 'errors': errors}


def summarize(raw_path):
    events, errors = [], []
    try:
        raw = Path(raw_path).read_bytes()
        require(bool(raw) and raw.endswith(b'\n'), 'Raw JSONL is empty or truncated')
        for number, line in enumerate(raw.decode('utf-8').splitlines(), 1):
            try:
                event = json.loads(line, object_pairs_hook=unique_object, parse_constant=reject_constant)
                require(isinstance(event, dict), 'Event is not an object')
                events.append(event)
            except (ValueError, TypeError) as error:
                errors.append(f'Line {number}: {error}')
    except (OSError, UnicodeError, ValueError) as error:
        errors.append(str(error))
    starts = runs = root_terminals = package_terminals = 0
    root_action = package_action = None
    for number, event in enumerate(events, 1):
        action, test = event.get('Action'), event.get('Test')
        if event.get('Package') != PACKAGE:
            errors.append(f'Event {number}: unexpected package')
        if 'Test' in event and test != TEST:
            errors.append(f'Event {number}: extra or invalid test name')
        if action not in ('start', 'run', 'output', 'pass', 'fail'):
            errors.append(f'Event {number}: forbidden or unknown action {action!r}')
        if package_terminals:
            errors.append(f'Event {number}: event after package terminal')
        if action == 'start':
            starts += 1
            if test is not None or number != 1:
                errors.append(f'Event {number}: package start out of order')
        elif starts != 1:
            errors.append(f'Event {number}: missing or duplicate package start')
        if action == 'run':
            runs += 1
            if test != TEST or root_terminals or runs != 1:
                errors.append(f'Event {number}: invalid root run')
        if action == 'output':
            if not isinstance(event.get('Output'), str):
                errors.append(f'Event {number}: missing output text')
            if test is not None and (runs != 1 or root_terminals):
                errors.append(f'Event {number}: root output out of order')
        if action in ('pass', 'fail'):
            elapsed = event.get('Elapsed')
            if type(elapsed) not in (int, float) or elapsed < 0:
                errors.append(f'Event {number}: invalid elapsed time')
            if test == TEST:
                root_terminals += 1
                root_action = action
                if runs != 1 or root_terminals != 1:
                    errors.append(f'Event {number}: invalid root terminal')
            elif test is None:
                package_terminals += 1
                package_action = action
                if root_terminals != 1 or package_terminals != 1:
                    errors.append(f'Event {number}: invalid package terminal')
    if (starts, runs, root_terminals, package_terminals) != (1, 1, 1, 1):
        errors.append('Expected exactly one package start, root run, root terminal, package terminal')
    if root_action != package_action:
        errors.append('Root/package outcomes disagree')
    return {'scope_ok': not errors, 'passed': not errors and root_action == 'pass',
            'root_action': root_action, 'package_action': package_action,
            'events': events, 'errors': errors}


def record(plan, dispatch_sha, old_map, new_map, session, broker_exit):
    out = plan['outputs']
    before, launch, terminal = [read_json(out[key]) for key in ('before', 'launch', 'terminal')]
    errors = list(before['binding']['errors']) + list(terminal['after_binding']['errors'])
    expected_cmdline = [PYTHON, '-I', '-B', str(ROOT / 'receipt-recorder-v2.py'),
                        '--dispatch', str(ROOT / 'dispatch.json'), '--dispatch-sha256', dispatch_sha,
                        '--session', str(session), '--exit-code', str(broker_exit)]
    after = snapshot(plan, dispatch_sha, old_map, new_map, expected_cmdline)
    errors.extend(after['errors'])
    if before['binding'] != terminal['after_binding']:
        errors.append('Wrapper pre/post bindings differ')
    if before['binding']['source'] != after['source']:
        errors.append('Source changed between wrapper and recorder')
    for label, value in [('before', before), ('launch', launch), ('terminal', terminal)]:
        if value.get('dispatch_sha256') != dispatch_sha:
            errors.append(label + ': dispatch SHA differs')
    expected_launch = {'dispatch_sha256': dispatch_sha, 'argv': ARGV, 'cwd': plan['cwd'],
                       'environment': ENVIRONMENT, 'before_sha256': digest(out['before']),
                       'wrapper_cmdline': before['binding']['context']['cmdline']}
    if launch != expected_launch:
        errors.append('Actual launch metadata differs from approved arguments/environment/cwd')
    for key in ('before', 'launch', 'raw'):
        if terminal.get(key + '_sha256') != digest(out[key]):
            errors.append('Wrapper terminal digest differs: ' + key)
    if terminal.get('child_returncode') != broker_exit or terminal.get('wrapper_exit') != broker_exit:
        errors.append('Broker/child/wrapper exits disagree')
    if terminal.get('errors'):
        errors.extend(terminal['errors'])
    released = False
    try:
        with Path(LOCK).open('r') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            released = True
            fcntl.flock(lock, fcntl.LOCK_UN)
    except OSError as error:
        errors.append('Short-A release unverified: ' + str(error))
    raw_before = digest(out['raw'])
    result = summarize(out['raw'])
    if terminal.get('raw_result') != result or digest(out['raw']) != raw_before:
        errors.append('Raw JSON or parsed result changed after wrapper terminal')
    errors.extend(result['errors'])
    qualified = broker_exit == 0 and result['passed'] and released and not errors
    evidence = {key: {'path': out[key], 'sha256': digest(out[key])}
                for key in ('before', 'launch', 'raw', 'terminal')}
    receipt = {'revision': REVISION, 'tree': TREE, 'session': session, 'exit': broker_exit,
               'dispatch': str(ROOT / 'dispatch.json'), 'dispatch_sha256': dispatch_sha,
               'argv': ARGV, 'cwd': plan['cwd'], 'environment': ENVIRONMENT,
               'evidence': evidence, 'before_binding': before['binding'],
               'wrapper_after_binding': terminal['after_binding'], 'recorder_binding': after,
               'result': result, 'errors': errors, 'released': released,
               'scoped_diagnostic_pass': qualified, 'stop_required': True,
               'automatic_advance': False, 'original_failure_disposition': 'RETAINED_FAIL_OPEN',
               'qualification': plan['qualification']}
    write_once(out['receipt'], receipt)
    write_once(out['summary'], {
        'revision': REVISION, 'tree': TREE, 'receipt': out['receipt'],
        'receipt_sha256': digest(out['receipt']), 'session': session, 'exit': broker_exit,
        'scoped_diagnostic_pass': qualified, 'errors': errors, 'stop_required': True,
        'automatic_advance': False, 'original_failure_disposition': 'RETAINED_FAIL_OPEN',
        'qualification': plan['qualification'],
    })
    return 0 if qualified else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dispatch', required=True)
    parser.add_argument('--dispatch-sha256', required=True)
    parser.add_argument('--session', required=True, type=int)
    parser.add_argument('--exit-code', required=True, type=int)
    args = parser.parse_args()
    require(args.session > 0, 'Broker session must be positive')
    plan, old_map, new_map = load_plan(args.dispatch, args.dispatch_sha256)
    return record(plan, args.dispatch_sha256, old_map, new_map, args.session, args.exit_code)


if __name__ == '__main__':
    sys.exit(main())
