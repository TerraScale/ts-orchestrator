#!/usr/bin/env python3
"""One separately authorized diagnostic invocation; no retry or queue advancement."""
import argparse
import hashlib
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/tmp/ts-nats-vendor-migration-20261016/fifo06-diagnostic-dispatch-13185dcc-v2')
RECORDER_SHA = '12f0ebcc88726e53c549d8b4927ca9cc649a5289c5cd83aefc3a9b9a5d3cce8e'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dispatch', required=True)
    parser.add_argument('--dispatch-sha256', required=True)
    args = parser.parse_args()
    dispatch = Path(args.dispatch)
    if dispatch != ROOT / 'dispatch.json' or hashlib.sha256(dispatch.read_bytes()).hexdigest() != args.dispatch_sha256:
        raise ValueError('Dispatch differs from reviewed binding')
    recorder = ROOT / 'receipt-recorder-v2.py'
    if hashlib.sha256(recorder.read_bytes()).hexdigest() != RECORDER_SHA:
        raise ValueError('Recorder differs from reviewed source')
    spec = importlib.util.spec_from_file_location('fifo6_recorder', recorder)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    plan, old_map, new_map = module.load_plan(str(dispatch), args.dispatch_sha256)
    out = plan['outputs']
    module.require(not any(Path(path).exists() or Path(path).is_symlink() for path in out.values()),
                   'Existing diagnostic output: preserve it; never repeat this dispatch')
    expected_cmdline = [module.PYTHON, '-I', '-B', str(ROOT / 'run-once-v2.py'),
                        '--dispatch', str(dispatch), '--dispatch-sha256', args.dispatch_sha256]
    before = module.snapshot(plan, args.dispatch_sha256, old_map, new_map, expected_cmdline)
    module.require(not before['errors'], '\n'.join(before['errors']))
    # The exclusive before artifact is the irreversible single-use dispatch fence.
    module.write_once(out['before'], {'dispatch_sha256': args.dispatch_sha256, 'binding': before})
    launch = {'dispatch_sha256': args.dispatch_sha256, 'argv': list(module.ARGV),
              'cwd': plan['cwd'], 'environment': dict(module.ENVIRONMENT),
              'before_sha256': module.digest(out['before']),
              'wrapper_cmdline': before['context']['cmdline']}
    child_returncode, child_pid, wrapper_exit, errors = None, None, 125, []
    started = time.monotonic()
    try:
        with Path(out['raw']).open('xb') as raw:
            module.write_once(out['launch'], launch)
            # Exact approved argv/cwd/environment are the actual Popen arguments.
            child = subprocess.Popen(launch['argv'], cwd=launch['cwd'], env=launch['environment'],
                                     stdout=raw, stderr=subprocess.STDOUT, start_new_session=True)
            child_pid = child.pid
            child_returncode = child.wait()
            wrapper_exit = child_returncode if child_returncode >= 0 else 128 - child_returncode
            raw.flush()
            os.fsync(raw.fileno())
    except OSError as error:
        errors.append('Launch or raw capture failed: ' + str(error))
    after = module.snapshot(plan, args.dispatch_sha256, old_map, new_map, expected_cmdline)
    errors.extend(after['errors'])
    raw_result = module.summarize(out['raw'])
    errors.extend(raw_result['errors'])
    if before != after:
        errors.append('Pre/post wrapper binding differs')
    if errors:
        wrapper_exit = 125
    terminal = {'dispatch_sha256': args.dispatch_sha256, 'child_pid': child_pid,
                'child_returncode': child_returncode, 'wrapper_exit': wrapper_exit,
                'elapsed_seconds': time.monotonic() - started, 'after_binding': after,
                'errors': errors, 'raw_result': raw_result,
                **{key + '_sha256': module.digest(out[key]) if Path(out[key]).is_file() else None
                   for key in ('before', 'launch', 'raw')}}
    module.write_once(out['terminal'], terminal)
    return wrapper_exit


if __name__ == '__main__':
    sys.exit(main())
