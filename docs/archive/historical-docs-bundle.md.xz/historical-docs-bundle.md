# TerraScale.Orchestrator historical docs bundle
Generated 2026-07-17 during docs consolidation.
Live documentation lives under docs/guides/ and docs/adr/.



---

# FILE: docs/adr/0004-pulumi-provider-ownership.md

# ADR 0004: Pulumi and regional provider ownership

- Status: Proposed
- Date: 2026-07-13
- Decision owner: Cloud
- Readiness entry: `4 / pulumi-provider-ownership`

## Context

TerraScale needs Pulumi to establish durable cloud foundation without leaving Pulumi and the regional orchestrator as competing reconcilers. The platform is greenfield: the new ownership graph may not adopt an OCID, identity root, data resource, or control resource from the deleted OKE estate (`REQ-O023`). The checked-in residual inventory does not weaken that rule: OCI discovery failed before scoped queries ran, so OKE absence and residual resource counts remain unproven, not empty ([OCI audit, lines 16-32](../audits/oci/phase0-residual-inventory.md#L16-L32)).

The specification already separates durable foundation from concrete regional resources. Pulumi creates and versions networking, IAM, root protection, image and launch templates, caps, bootstrap generations, initial seeds, initial dual-NATS stores, and the signed `BootstrapBundle`. After a deliberate handoff, the regional controller owns concrete nodes, workload backends, eligible attachments, and orchestrator-created volumes ([specification, lines 627-640](../../ORCHESTRATOR.md#L627-L640)). This is the boundary expressed by `REQ-O010` and `INV-014` ([requirement trace, lines 122 and 156](../../ORCHESTRATOR.md#L122-L156)).

The historical estate is evidence only. Its Pulumi stack still contains OKE assumptions and concrete regional identifiers; `WRK-001` preserves the durable-foundation boundary while replacing OKE capacity, and `WRK-018` requires unknown resources to be quarantined rather than adopted or deleted ([WRK-001, lines 103-123](../retirement/workaround-ledger.yaml#L103-L123); [WRK-018, lines 481-505](../retirement/workaround-ledger.yaml#L481-L505)).

## Proposed decision

Use an explicit two-owner lifecycle:

1. **Pulumi foundation owner.** Pulumi exclusively creates and versions durable network/routing/security foundation, regional IAM capabilities, KMS/Vault roots, object storage, DNS/LB foundation, approved images and launch templates, quotas/caps, bootstrap/recovery generations, seed hosts, and the initial dual-NATS storage needed to establish regional authority.
2. **Handoff transaction.** A regional controller may assume ownership only through the proposed `SM-PULUMI-OWNERSHIP-HANDOFF`: establish both NATS quorums, enroll controller candidates, verify the regional journal/PKI/provider access/backups, persist a signed `HandoffReceipt`, make Pulumi retain or unmanage the exact transferred inventory, activate the regional fencing epoch, and only then enable self-management ([specification, lines 650-663](../../ORCHESTRATOR.md#L650-L663)).
3. **Regional actuator owner.** After the receipt is durable and both owners agree on the exact inventory, the cell exclusively owns concrete replacement and elastic compute, ephemeral boot volumes, post-handoff NATS/TerraBase/workload volumes, attachments, workload LB membership, node generation, drain/scale/termination, expansion, and orphan reconciliation.
4. **No count reconciliation by Pulumi after transfer.** Pulumi continues to version foundation, allowed templates, IAM, caps, and bootstrap/recovery generations, but does not reconcile transferred regional instance counts ([specification, line 648](../../ORCHESTRATOR.md#L648)). A changed template enters a region through a reviewed native GitOps plan and rolling generation operation, not through Pulumi replacing region-owned instances.
5. **Positive ownership is mandatory.** Resource tags are inventory and reconciliation evidence. They are never authority to adopt, terminate, detach, delete, format, or otherwise mutate. Mutation requires the compartment-scoped actuator capability plus the persisted, fenced operation described by ADR 0020 ([specification, lines 642-646](../../ORCHESTRATOR.md#L642-L646)).
6. **Disaster bootstrap is distinct.** A higher `bootstrapGeneration` and recovery authorization are required, after proving no viable regional quorum exists; it may not seed a competing cluster beside a partitioned one ([specification, line 685](../../ORCHESTRATOR.md#L685)).

This is a proposed direction, not an accepted contract. The exact Pulumi retain/unmanage mechanism, tag schema, IAM statements, receipt schema, transferred resource-type matrix, and crash checkpoints remain open.

## Safety invariants

- One resource has exactly one active lifecycle owner. Pulumi and a regional actuator never concurrently reconcile the same transferred resource.
- A transfer is between owners in the new greenfield system. Historical or merely discovered resources cannot enter it.
- A missing, invalid, stale, partial, or inventory-mismatched receipt holds self-management; it does not trigger best-effort adoption.
- A tag match cannot establish mutation authority. `ERR-PROVIDER-OWNERSHIP-MISMATCH` must be a typed hold for absent or mismatched positive ownership evidence.
- The exact resource inventory and bootstrap generation are bound into the signed receipt and regional journal. Retries resume the same handoff; they do not create a second ownership lineage.
- Handoff receipts and correlated evidence obey `SEC-NO-SECRET-OUTPUT`; they identify secret/key versions without containing secret values or private key material.
- Foundation changes cannot bypass the accepted regional desired-state and rolling-generation path.
- Regional autonomy preserves the applicable quorum, permanent-member, and storage invariants. This ADR does not select owner questions 1, 3, 5, or 8, nor does it define their unresolved SLOs.

## Alternatives considered

### Continuous Pulumi reconciliation of regional capacity

Rejected because Pulumi and the orchestrator would become two autoscalers with incompatible observations and failure recovery. A late `pulumi up` could recreate, resize, or delete a resource already controlled by a regional operation.

### Orchestrator owns all foundation from first boot

Rejected because it creates a circular bootstrap and recovery dependency and moves durable networking, root trust, IAM, and template-generation responsibilities across `INV-014` without an approved replacement authority.

### Import or adopt the historical OCI estate

Rejected. Full greenfield deployment is `REQ-O023`, and the residual inventory is currently incomplete. Unknown or old resources remain unrelated, quarantined, or separately approved cleanup targets.

### Tags determine ownership

Rejected. Tags are mutable and eventually observed metadata. They support discovery and mismatch detection but cannot prove authority or fence a leader.

### Handoff by operator convention only

Rejected. An undocumented order or manual runbook cannot prove agreement after a crash. The journaled signed receipt and an explicit Pulumi state transition are required.

## Consequences

- Foundation and regional reconciler code need disjoint, machine-checkable resource-type and action matrices.
- Handoff must be modeled as a crash-resumable state machine, not a deployment script.
- Pulumi state/history and the regional R3 journal must retain correlated, sanitized evidence of the same transfer without exposing secrets or private keys.
- Template evolution becomes a versioned input to regional GitOps and node-generation workflows.
- Greenfield collision checks and a separate approved cleanup process are mandatory before any mutation.
- Regional autonomy can proceed during GRU loss after handoff, subject to the still-open authority, survival-window, storage, RPO/RTO, and budget decisions.

## Unresolved inputs and evidence

The readiness map labels this draft-ready but requires exact OCI IAM/tag schemas, a primary-source Pulumi retain/unmanage spike, and fresh-resource crash-recovery evidence; it also depends on ADRs 1, 20, and 24 ([readiness index, lines 47-57](readiness-index.yaml#L47-L57)). Acceptance remains blocked on:

- the exact per-region compartment policy, dynamic-group/workload identity design, action and resource-type allowlists, and explicit deny/hold behavior;
- the exact required/free-form tag namespace and immutable-versus-observed field rules;
- proof of the selected Pulumi retain/unmanage operation across preview, apply, refresh, rollback, import rejection, and crashes;
- a complete resource-type handoff matrix, including which seed boot/NATS volumes transfer and which foundation resources never do;
- owner questions that determine regional authority/topology, vault custody, elastic volume retention, and physical NATS isolation;
- approved cost, storage performance, regional RPO/RTO, security, and survival-window targets;
- repaired read-only OCI evidence. Current account discovery is authentication-blocked and proves no resource absence ([OCI audit, lines 34-50](../audits/oci/phase0-residual-inventory.md#L34-L50)).

## Required verification before acceptance

- **Review:** exact ownership/action matrix, tag schema, IAM policy, receipt schema, Pulumi primary-source behavior, and independent security review.
- **L0:** model every handoff checkpoint, duplicate/reordered callbacks, stale bootstrap generation, mismatched inventory, partial Pulumi state transition, competing owner, and forbidden adoption. Prove `INV-004`, `INV-005`, `INV-006`, and `INV-014`.
- **L3S:** perform two from-zero handoffs from the same signed contracts, crash both sides at every checkpoint, resume the same lineage, and replace a node from the survival bundle while GRU/Git are disconnected.
- **L4:** use only fresh disposable OCI resources after the exact-tree pre-deployment gate; prove a later Pulumi run cannot mutate transferred resources and the regional actuator cannot mutate foundation or unowned resources.
- **L5:** retain a signed inventory/receipt trail across the production soak and verify no drift creates dual ownership.

No SUT VM or OCI mutation is authorized by this ADR. The repository's exact-tree pre-deployment evidence gate remains mandatory ([specification, lines 1114-1122](../../ORCHESTRATOR.md#L1114-L1122)).

## Traceability

| Kind | Stable/proposed ID | Disposition in this ADR |
|---|---|---|
| Requirement | `REQ-O010` | Defines bootstrap-to-regional ownership transfer. |
| Requirement | `REQ-O023` | Forbids adoption of the deleted estate. |
| Invariant | `INV-004` | One fenced writer per node/volume operation. |
| Invariant | `INV-005` | Handoff and provider commands are replay-safe and generation/deadline bound. |
| Invariant | `INV-006` | Stale leaders cannot mutate or complete operations. |
| Invariant | `INV-014` | Assigns durable foundation to Pulumi and concrete post-handoff resources to the cell. |
| Security rule | `SEC-NO-SECRET-OUTPUT` | Keeps credentials and private keys out of receipts, journals, tags, and evidence. |
| Proposed state machine | `SM-PULUMI-OWNERSHIP-HANDOFF` | Defines the crash-resumable transfer; not yet in the canonical registry. |
| Proposed security rule | `SEC-PROVIDER-MUTATION-AUTHORITY` | Tags never authorize; only scoped capability plus persisted operation may mutate. |
| Proposed error | `ERR-PROVIDER-OWNERSHIP-MISMATCH` | Holds mutation on absent/mismatched ownership proof. |
| Proposed gate | `REQ-GATE-PHASE4` | Requires exact-one-owner outcome across every provider/handoff crash checkpoint. |

The canonical registry currently contains the requirement/invariant IDs but lacks semantic anchors, while the state-machine/security/error/gate IDs above are registry-audit proposals rather than frozen IDs ([registry audit, lines 30-57](../audits/registry/registry-audit.json#L30-L57); [registry audit, lines 67-98](../audits/registry/registry-audit.json#L67-L98)).


---

# FILE: docs/adr/0013-native-gitops.md

# ADR 0013: Native GitOps schema and complete Flux removal

- Status: Proposed
- Date: 2026-07-13
- Owner lane: Delivery
- Readiness entry: `docs/adr/readiness-index.yaml:155-164`, ADR 13 (`native-gitops`)
- Depends on: ADR 1, ADR 6, ADR 14, ADR 18, ADR 24
- Traces: `REQ-O014`, `REQ-O017`, `REQ-O023`, `INV-002`, `INV-004`, `INV-005`, `INV-011`, `INV-013`, `INV-015`, `INV-017`, `WRK-002`, `WRK-003`, `WRK-004`, `WRK-005`

## Context

The owner decision is a clean break: GitOps is native to the orchestrator and Flux is removed rather than embedded, emulated, or retained as a runtime dependency (`ORCHESTRATOR.md:52-61`). The greenfield deployment adopts no Kubernetes or Flux resource, state, identity, secret, or API (`ORCHESTRATOR.md:54-60`, `ORCHESTRATOR.md:162-180`). Historical repositories remain read-only evidence of behavior and workarounds, not an input contract (`ORCHESTRATOR.md:182-220`).

ADR readiness classifies this record as draft-ready but identifies three missing bodies of proof: the fresh schema and compatibility fixtures, complete historical behavior reconciliation, and cleanup-PR sequencing tied to native replacement gates (`docs/adr/readiness-index.yaml:155-164`). This proposal states the boundary and the evidence required to accept it; it does not claim those proofs exist.

The retirement ledger records the behavior that must survive without preserving its implementation:

| Ledger item | Historical constraint | Behavior to preserve | Native replacement evidence |
|---|---|---|---|
| `WRK-002` | Flux reconciliation could acknowledge before dependencies were healthy because readiness waiting was disabled. | Ordered dependencies, asynchronous progress, health gates, restart-safe acknowledgement. | Typed dependency and health state machines; a journaled receipt acknowledged only at the configured durable checkpoint; dependency failure and restart at every checkpoint in L0/L3S (`docs/retirement/workaround-ledger.yaml:125-145`). |
| `WRK-003` | A webhook was followed by forced `kubectl` reconciliation and polling. | Prompt triggering, durable acceptance, safe replay, and a visible rejection/failure. | One signed, generation/deadline/idempotency/fence-bound reconcile command journaled before acknowledgement; webhook, NATS, controller, duplicate, and stale-writer failures in L0/L3S (`docs/retirement/workaround-ledger.yaml:147-171`). |
| `WRK-004` | Suspended regional image writers and rollout-guard coordination approximated exclusive publication. | Build once, exact-digest promotion, one release writer, and safe rollback. | A fenced writer, promotion lease, and compare-and-swap generation over the immutable digest; concurrent-writer, lease-expiry, partial-promotion, and adversarial rollback proof (`docs/retirement/workaround-ledger.yaml:173-193`). |
| `WRK-005` | Deployment progress was assembled through `kubectl`, context fan-out, polling, and shell recovery. | Cross-region progress, explicit failure, exact-digest convergence, timeout, and resumability. | Typed regional operations with durable checkpoints, idempotent resume, and a global same-digest barrier; crash, timeout, WAN-loss, partial-convergence, and retry proof (`docs/retirement/workaround-ledger.yaml:195-215`). |

The audited release contract independently requires immutable candidates, a fenced promotion lease, resumable external-operation boundaries, and promotion without rebuilding. Existing `flux-*` strategy strings are rollout evidence only and are not compatibility contracts (`docs/audits/phase0-product-contract-source-audit.md:52-67`).

## Proposed decision

### Fresh native contract only

Define a versioned TerraScale desired-state schema directly from the closed C# admitted-role catalog and reviewed product/runtime contracts. Publish JSON Schema, semantic validation, visible defaults, plans, fixtures, and generated documentation from that same versioned contract (`INV-015`).

The source adapter accepts only:

- Git revisions and OCI artifacts identified by immutable revision/digest after signature verification;
- fresh native manifests conforming to a supported TerraScale schema version; and
- credential references, never credential values.

It does not parse, import, translate, emulate, or silently ignore Kubernetes objects, Helm values/templates, Kustomizations, Flux resources, or historical `flux-*` strategy names. No compatibility reader, converter, dual-read period, shadow Flux controller, or fallback to `kubectl` is introduced. Unsupported formats fail with a typed, non-mutating validation error before a plan can be accepted (`ORCHESTRATOR.md:924-959`).

Historical sources are reviewed into a behavior matrix. Each behavior is either represented by a native typed contract plus tests, explicitly rejected as obsolete with rationale, or held as an open gap. Copying a historical resource shape or field name is not proof that its behavior was preserved.

### One owner for each state class

Git is authoritative only for declared parent intent: allowlisted roles, releases, policies, templates, bounds, budgets, retention classes, and desired minimum/maximum capacity.

The accepted global journal is authoritative for signed accepted revisions, global plans, releases, policy generations, signatures, and rollout result. Each regional journal is authoritative for its accepted `CellSpec`, operations, concrete instances, host allocations, attachments, replacement peers, generated/expanded volumes, and deployment progress (`ORCHESTRATOR.md:538-549`).

Ordinary controller-created children are linked to their parent policy/template generation but are not written back into Git, Git drift, or Git prune targets. This prevents Git and a regional controller from becoming concurrent owners of the same concrete resource. Removing a Git parent records a guarded regional retirement intent; the appropriate domain controller then proves ownership, safety, retention, dependency, and fencing preconditions before any child cleanup (`ORCHESTRATOR.md:941-959`).

ADR 18 supplies the separate customer project-placement boundary. A GitOps plan may carry deployment and capacity policy but cannot author or infer `Project.Regions` from workload or host state.

### Durable reconciliation and rollback

Use this mandatory sequence:

```text
source revision observed
-> signature and schema verified
-> dependency graph resolved and cycles rejected
-> immutable artifacts resolved exactly once
-> policy and budget evaluated
-> global plan durably recorded
-> signed per-cell CellSpecs compiled
-> each cell durably accepts its generation
-> regional deployment operations execute with typed health gates
-> global same-digest live verification completes
-> success or an explicit rollback generation is durably recorded
```

Webhook HTTP success means the signed command is durably queued, not that reconciliation or deployment succeeded. Commands and operations are generation-, deadline-, idempotency-, and fencing-bound (`INV-004`, `INV-005`). Exactly one fenced writer advances each source revision, release, deployment, and rollback (`INV-004`). A replacement leader resumes from the durable journal rather than reconstructing progress from Git, process state, or telemetry.

Rollback is a new explicit desired generation pointing to a previously qualified immutable digest. It follows the same acceptance and health gates. It never rebuilds or mutates an artifact (`INV-011`). When Git or GRU is unavailable, a region serves and repairs from its last accepted `CellSpec`; it does not accept an unseen global generation (`INV-002`).

### Drift, prune, and deletion

Drift comparison is scoped by the resource's authoritative owner and generation. A plan may repair a declared parent or a declarative, orchestrator-owned leaf. It may not classify journal-owned autoscaled children, generated volumes, product placement records, or foreign/unproven resources as Git drift.

Prune produces a typed retirement operation rather than a direct delete. The operation must prove exact ownership, generation/fence, retention policy, absence of protected data/quorum/placement dependencies, and domain-controller authorization. Unknown, ambiguous, stale, or filtered observations hold safely. Tags are evidence, never deletion authority.

## Cleanup sequencing

Cleanup is not part of this ADR branch and is never bundled ahead of replacement proof. The sequence is:

1. Inventory every historical behavior and artifact against `WRK-002` through `WRK-005`, with immutable source citations.
2. Implement the fresh native contracts and pure reconciliation decisions. Pass L0 schema, dependency, signature/digest, plan/diff, drift/prune, health, rollback, and one-writer tests, including adversarial ownership and crash cases.
3. Pass L3S from the exact integration tree: restart at every acknowledgement/deployment checkpoint, source/webhook/NATS/controller/WAN loss, duplicate and stale writers, partial regional convergence, same-digest verification, rollback, and proof that Git prune cannot delete journal/data children.
4. Record one reviewed replacement-evidence packet per `WRK-*`, mapping preserved behavior to native implementation, test IDs, exact source/binary digests, and captured results.
5. Open a first owning-repository PR that stops and removes the historical runtime writer or trigger path while leaving its authority unrevoked solely for a bounded, declared rollback window. During that window the old credential is sealed from ordinary runtime use, activation requires explicit operator approval plus the recorded fence/generation transition, and monitoring must detect any attempted use. The native replacement remains the primary writer throughout. This PR must state its rollback preconditions, expiry, fence transition, and proof that a restored historical writer cannot overlap the native writer. Before authority revocation, rollback may restore that writer only through this explicit fenced procedure; merely reverting or redeploying its artifact is forbidden.
6. After the native replacement passes its declared soak and the runtime-writer rollback window closes, record a reviewed cutoff stating that historical-writer restoration is retired. Then use separate repository and, where applicable, explicitly authorized provider cleanup changes to revoke the old credentials, RBAC/IAM/Vault authority, webhook tokens, endpoints, and DNS. Each change must prove the native identity remains valid and define rollback as a forward fix or issuance of new, narrowly scoped, fenced authority. After revocation, rollback must never blindly restore an old artifact, credential, secret version, permission, endpoint, or writer authority.
7. Only after runtime removal and authority revocation evidence is accepted may a separate owning-repository PR delete passive Flux/Kubernetes manifests, bootstrap resources, rollout glue, and documentation. Its rollback can restore passive review/history material only; it cannot recreate runtime authority or make the historical controller executable. Each PR targets that repository's `develop`, cross-links the replacement packet and preceding cleanup evidence, and records the exact cutoff reached.
8. After every cleanup stage, run read-only repository/provider inventories and native deployment regression. Close an item only when its ledger `cleanup_proof` is satisfied and the evidence distinguishes runtime writer absence, authority/credential revocation, and passive-manifest absence. Any positively identified cloud cleanup requires its own explicitly authorized provider operation; absence from Git is not proof of cloud deletion.
9. Finally enforce negative CI scans for Flux API resources, Flux controllers/receivers, Kubernetes/Helm/Kustomize readers, `kubectl` rollout/reconcile code, legacy webhook secrets/endpoints, packaged Kubernetes credentials, and attempts to restore authority after its recorded cutoff.

For `WRK-002`, stop its active reconciliation path only after native dependency/health acknowledgement passes; revoke its controller authority after the bounded rollback window; then delete passive Kustomizations/bootstrap sync. For `WRK-003`, remove the receiver/forced-reconcile runtime path only after durable signed command acceptance passes; then revoke webhook credentials and endpoints; then delete passive configuration. For `WRK-004`, stop image automation/rollout-guard writers only after fenced single-writer promotion passes; then revoke their publication authority; then remove suspend toggles and passive resources. For `WRK-005`, stop rollout/context/polling/shell execution only after typed resumable regional deployment and same-digest proof passes; then remove Kubernetes credentials; then delete passive recovery/configuration artifacts. Every arrow is a separate evidence boundary, and stages may be separate PRs or provider changes even when they concern the same ledger item. Failure at any gate leaves that item open; it does not authorize a temporary compatibility reader or an unfenced historical writer.

## Alternatives considered

### Embed or retain Flux

Rejected. It contradicts `REQ-O014`, retains the runtime and acknowledgement problems being retired, and creates two reconciliation authorities.

### Import or convert historical Kubernetes, Helm, Kustomize, or Flux inputs

Rejected. A converter would turn implementation residue into a permanent public schema, mask missing behavioral analysis, and create a second contract surface. The platform is greenfield and does not need an in-place migration reader.

### Dual-read or shadow reconciliation during transition

Rejected. Two readers can disagree on defaults, ownership, prune, and generation, while shadow controllers can still observe or mutate inconsistently. Replacement correctness is established in L0/L3S before separately reviewed cleanup.

### Put every concrete child in Git

Rejected. Autoscaled instances, allocations, attachments, peers, and volumes are regional recovery state. Writing them into Git creates control-loop latency and competing ownership, and makes ordinary controller activity appear as drift.

### Let CI/CD mutate deployments directly

Rejected. CD supplies exact artifacts and release intent to the native reconciler. Bypassing it would evade durable acceptance, regional gates, fencing, resumption, and audit.

## Consequences

Positive consequences:

- one typed desired-state contract and no Kubernetes/Flux compatibility burden;
- direct durable acknowledgement and deterministic restart instead of webhook/poll inference;
- explicit parent/child ownership prevents unsafe drift and prune;
- exact-digest promotion, fenced writers, and rollback preserve the valuable historical release semantics; and
- retirement is reviewable per repository and per workaround rather than inferred from a bulk deletion.

Costs and risks:

- Phase 6 must implement source, schema, planning, journaling, health, drift, pruning, promotion, and recovery behavior that Flux previously supplied;
- historical behavior review and replacement evidence must be complete before cleanup, so repository retirement is intentionally later than schema drafting; and
- ADR dependencies remain proposed, so acceptance waits for their compatible authority, workload, CI, placement, and greenfield-cleanup contracts.

## Acceptance evidence required

This ADR may become Accepted only when all of the following are reviewed against one exact integration tree:

- fresh C# resource contracts, generated JSON Schema/docs, unknown-field/version/default behavior, and golden native fixtures; no compatibility reader exists;
- a complete historical-behavior disposition for every Flux/Kubernetes delivery finding, including `AUD-SRC-006` and `WRK-002` through `WRK-005`;
- L0 positive and adversarial tests for dependency/cycle planning, signatures, immutable digest resolution, ownership-aware diff/drift/prune, durable acknowledgement, fencing, idempotency, staged promotion, rollback, and restart at every state-machine checkpoint (`ORCHESTRATOR.md:1114-1163`);
- L3S Git/OCI/webhook/NATS/controller/WAN failure and recovery at every reconciliation checkpoint, exact-digest SFO/FRA/GRU convergence, stale-writer rejection, and safe rollback (`ORCHESTRATOR.md:1561-1571`);
- evidence that a Git parent removal cannot directly delete a journal-owned child, data resource, project placement, or unproven cloud resource;
- per-item replacement packets and separately reviewed cleanup PRs satisfying each ledger cleanup proof; and
- repository/provider scans proving no Flux runtime/API/credential/endpoint, Kubernetes credential, or compatibility path remains in the new platform (`ORCHESTRATOR.md:1734-1755`).

Until then, status remains Proposed and no sibling cleanup is authorized.


---

# FILE: docs/adr/0018-placement-boundary.md

# ADR 0018: Project placement versus host scheduling boundary

- Status: Proposed
- Date: 2026-07-13
- Owner lane: Integration/contract steward
- Readiness entry: `docs/adr/readiness-index.yaml:215-224`, ADR 18 (`placement-boundary`)
- Depends on: ADR 10, ADR 13, ADR 15
- Traces: `INV-005`, `INV-007`, `INV-008`, `INV-009`, `INV-013`, `INV-017`, `WRK-022`

## Context

TerraScale has two distinct kinds of placement:

1. **Product placement** decides the customer data-residency and service geography of a project: which regional cells belong to `Project.Regions`, at which `PlacementGeneration`, with which drain, replication, routing, storage-epoch, and filtered-absence semantics.
2. **Host scheduling** decides which eligible machine in one already-selected regional cell runs a concrete allowlisted workload/member/allocation, subject to resources, topology, stateful vetoes, safety reserves, and health.

Conflating these decisions would let infrastructure load move customer data, or make the product reconciler compete with the host scheduler. Contract invariant `INV-013` therefore states that product project/database placement remains in the product placement domain and the host scheduler does not create a second source of truth for `Project.Regions` (`ORCHESTRATOR.md:139-160`).

The audited product snapshot at TerraScale.Internals commit `3643df207f9f1129c9f677148e6890d436339141` is concrete evidence of the existing product contract:

- `docs/databases/regions-and-replication.md:3-6`: a project selects regions and its databases, queues, and project-scoped authentication inherit them; child resources cannot widen or narrow residency;
- `docs/databases/regions-and-replication.md:54-83`: `Project.Regions` is desired state, `PlacementGeneration` is monotonic, transition/final generations are CAS-bound, selected cells create/update, removed cells drain before deletion, and filtered/untagged uncertainty fails closed;
- `docs/databases/regions-and-replication.md:87-114`: selected cells replicate bidirectionally and all directed paths are independently qualified;
- `docs/databases/regions-and-replication.md:125-159`: catalog changes cannot implicitly move stored placement, and routing remains within healthy selected origins; and
- `docs/databases/regions-and-replication.md:195-233`: removal drains accepted queue work before project data deletion, re-selection cancels drain, and project-auth storage epochs/region sets fence writers.

The target specification preserves this explicitly: the orchestrator provides regional TerraBase capacity and typed fenced machine operations but does not infer customer region selection from host load; monotonic generations, filtered-absence non-deletion, storage epochs, six directed replication paths, conflicts, and restore remain acceptance gates (`ORCHESTRATOR.md:1012-1039`, `ORCHESTRATOR.md:1659-1666`).

ADR readiness identifies the still-missing evidence: golden placement compatibility fixtures, an explicit storage-epoch/filtered-absence ownership map, and cross-repository approval before any source-of-truth move (`docs/adr/readiness-index.yaml:215-224`). This record preserves the current owner; it does not move that authority.

## Proposed decision

### Product placement has one authoritative owner

The TerraScale product placement domain remains the sole authority for:

- canonical project region membership in `Project.Regions`;
- monotonic logical `PlacementGeneration` and its transition/final CAS phases;
- selected, draining, blocked, removed, and re-selected regional placement state;
- customer data-residency validation, plan entitlement, catalog availability, and placement errors;
- creation/catch-up/drain/deletion eligibility for each regional project database;
- all directed external-replication intent, conflict policy, and filtered-absence handling;
- queue-region drain completion and project-auth authority/storage epoch tied to the placement generation; and
- routing eligibility among healthy selected cells.

The current product reconciler continues to advance that state. Neither GitOps, the global coordinator, a cell controller, the provider controller, the TerraBase machine controller, nor the generic scheduler may independently write, derive, repair, normalize, default, or prune project placement.

The orchestrator may consume a versioned, typed projection of product placement solely to enforce downstream constraints and report status. It must preserve the project generation and observation completeness in that projection. Missing, stale, filtered, conflicting, or future-version observations cause a hold; they never mean region removal. There is no dual write and no reconstructed fallback from tags, host inventory, Git manifests, registry endpoints, traffic, telemetry, or current database copies.

### Host scheduling has one authoritative owner

Within a cell that product placement has already selected, the regional scheduler is the sole authority for concrete host allocations. It consumes the locally accepted `CellSpec`, node observations, declared reservations, health, security zones, and domain-controller constraints. It chooses an eligible host using deterministic constrained least-waste scoring with explicit tie-breakers and a reason trace (`ORCHESTRATOR.md:591-619`).

The scheduler owns:

- admission and concrete allocation identity/generation;
- CPU, memory, IO, disk, PID, port, file-descriptor, bandwidth, and huge-page constraints;
- architecture, node class, failure domain, affinity/anti-affinity, topology spread, priority, disruption budgets, and GRU N+1 reserve;
- volume locality and already-proven single-writer attachment constraints;
- workload trust/network/secret-zone eligibility; and
- host cordon/drain/replacement placement of an otherwise-authorized workload.

Scheduler output is a persisted, fenced machine intent. It cannot change `Project.Regions`, `PlacementGeneration`, project replication topology, project storage epoch, or customer routing eligibility. Host pressure may produce `CapacityUnavailable`, a reason trace, and a capacity request. It cannot solve capacity pressure by adding/removing a project region or treating an unselected region as spillover.

### Domain controllers own their safety decisions

The generic scheduler does not decide whether a TerraBase or NATS member is safe to create, move, replace, attach, drain, or remove. The relevant domain controller owns stable member/volume identity, quorum/topology, leader handoff, replication/catch-up, backup, and decommission authorization. It may reserve or veto a host placement; the scheduler selects only among allowed candidates (`ORCHESTRATOR.md:593-605`).

For TerraBase specifically:

- the **product placement domain** owns which project databases/replication relationships should exist in the cell;
- the **TerraBase domain controller** owns machine-level member, shard-capacity, volume, topology, upgrade, backup, and repair operations; and
- the **regional scheduler** owns the concrete eligible host allocation after those constraints are supplied.

Adding a machine/member does not increase logical database capacity by assumption and never changes project geography (`INV-009`; `ORCHESTRATOR.md:1026-1037`).

### GitOps and catalogs carry policy, not a second placement truth

Native GitOps may declare regional service roles, capacity bounds, routing/catalog policy, and templates. It may distribute a product-placement schema or a reference to the product authority, but no Git manifest enumerates customer `Project.Regions` as authoritative desired state. Git prune cannot remove a project copy.

The dynamic region catalog defines which cells are available for new selection and supplies canonical metadata. It does not retroactively edit stored project placement. An unavailable or temporarily unknown stored region remains part of the existing placement until the product placement domain advances its generation.

`WRK-022` requires catalog-aware selection to distinguish absent preference from invalid/unavailable input while preserving only an explicitly approved default. The orchestrator must not reproduce the historical behavior that silently maps invalid regions to GRU (`docs/retirement/workaround-ledger.yaml:581-605`). Catalog/default cleanup belongs to separate owning-repository work after golden compatibility fixtures and approval; no SDK or documentation file is changed by this ADR.

## Boundary protocol

The integration contract must distinguish these immutable records:

| Record | Authoritative writer | Required identity/version | Permitted consumers |
|---|---|---|---|
| `ProjectPlacementIntent` | Product placement domain | project ID, exact `Project.Regions`, logical `PlacementGeneration`, document/CAS version, catalog/policy version | product reconciler, routing, compatibility projection |
| `ProjectRegionPlacementObservation` | Product placement reconciler for that project/cell generation | project, cell, placement generation, phase, observation completeness/freshness, replication/drain/storage epoch | operator projection, capacity/domain controllers; never a replacement desired-state writer |
| `CellSpec` workload/capacity policy | Native GitOps global authority | cell, desired generation, source revision/signature, immutable artifact/template/policy generations | regional controller/scheduler/domain controllers |
| `DomainPlacementConstraint` | TerraBase/NATS/workload domain controller | stable member/workload/volume identity, operation generation/fence, required/vetoed domains and safety reason | regional scheduler |
| `HostAllocation` | Regional scheduler under the current regional fence | cell, allocation and desired generations, node, resources, domain-controller constraint generation, reason trace | host agent and relevant domain controller |

No record is accepted as a lossy substitute for another. In particular, a `HostAllocation` cannot update `ProjectPlacementIntent`; a `ProjectRegionPlacementObservation` cannot create a host allocation; a `CellSpec` cannot default customer regions; and resource tags cannot authorize any of these mutations.

Normal sequencing is:

```text
product placement CAS accepts Project.Regions generation
-> selected cell product reconciler establishes/catches up product data and emits exact-generation state
-> GitOps/cell policy authorizes the required allowlisted regional role and capacity bounds
-> TerraBase/workload domain controller emits safety constraints or a hold
-> regional scheduler selects an eligible host and persists a fenced HostAllocation
-> host agent executes the allocation
-> domain and product reconcilers verify readiness before routing/placement advances
```

Region removal reverses product readiness first: the product placement domain advances the generation, stops new origin work as specified, completes exact-generation queue/replication/data drain, and authorizes project-copy deletion. Host drain or low load cannot initiate this sequence. Host allocation cleanup occurs only after the product/domain authority says the workload or member is no longer required and all normal ownership/retention/fencing gates pass.

## Failure behavior

- **Host exhaustion:** hold or request orchestrator-owned capacity in the same selected cell. Never spill the project into another region.
- **Host/node loss:** the domain controller and scheduler repair machine placement within the cell. `Project.Regions` is unchanged.
- **Missing/stale/filtered product observation:** hold destructive placement/data actions. Absence is not deletion authorization.
- **Catalog authority unavailable:** use the last accepted catalog for validation policy while preserving stored project regions; do not normalize to GRU.
- **GRU/Git/WAN unavailable:** each cell serves from its accepted `CellSpec` and accepted product placement state. No cell invents a new global/project placement generation.
- **Conflicting generation or storage epoch:** reject/hold the stale writer and surface a typed reason. Host success cannot override the product fence.
- **Insufficient TerraBase capacity:** report the explicit product-capacity signal and create safe same-cell machine capacity if authorized. Do not interpret member count as logical shard capacity or change customer geography.

## Alternatives considered

### Let the scheduler optimize customer region placement

Rejected. Resource/cost pressure is not customer residency intent. This would violate `INV-013`, make placement nondeterministic under load, and risk silent data movement.

### Copy `Project.Regions` into Git and reconcile from both systems

Rejected. It introduces two desired-state writers, incompatible generation/CAS semantics, disclosure and scale concerns, and unsafe Git prune behavior.

### Infer project placement from databases, replication tags, hosts, routing, or telemetry

Rejected. Those are incomplete observations. Filtered absence, outages, and draining states make inference unsafe; observation cannot replace the product intent and generation.

### Let the product reconciler choose machines directly

Rejected. It would duplicate scheduler resource, topology, reserve, security-zone, and host-health logic. The product domain supplies required regional capacity and safety constraints; the scheduler owns concrete host selection.

### Move product placement into the orchestrator now

Rejected for this proposal. There is no approved cross-repository contract, golden compatibility proof, or migration/authority transfer plan. Any future move requires a new deliberate ADR, owner approval, an explicit single-writer cutover, storage-epoch and filtered-absence proof, and independently reviewed owning-repository changes. This ADR provides no dual-read bridge.

## Consequences

Positive consequences:

- customer residency and replication remain stable under infrastructure load and failures;
- the scheduler stays explainable and regional without becoming a product database authority;
- TerraBase/NATS safety remains with controllers that understand topology and storage identity;
- every mutation has one authoritative writer and one generation/fence domain; and
- GitOps, host repair, and autoscaling cannot accidentally prune or widen customer placement.

Costs and risks:

- the product-to-orchestrator projection and capacity signal must be explicitly versioned and tested rather than inferred;
- operator views must correlate multiple authority records without presenting a projection as writable truth; and
- cross-domain workflows require durable correlation and typed holds when either authority is stale, which is more explicit work than sharing a mutable record.

## Acceptance evidence required

This ADR may become Accepted only after all of the following are reviewed against one exact integration tree and the pinned product snapshot or an explicitly approved successor:

- a reviewed ownership map for project intent, placement generation/phases, replication/drain, storage epoch, routing eligibility, domain constraints, cell policy, and host allocation, naming exactly one writer for every field and transition;
- golden compatibility fixtures for `Project.Regions`, monotonic `PlacementGeneration`, transition/final CAS, disabled/unknown stored regions, empty positive-generation drain, filtered absence, re-selection, queue drain, project-auth storage epoch, and routing within selected cells;
- L0 positive/adversarial proof that host load, cost, host loss, drain, Git change/prune, catalog fallback, telemetry, tags, stale observations, or a forged allocation cannot mutate or infer customer placement;
- L0 proof that a product region change cannot bypass generation/storage-epoch fences or directly choose a host, and that a scheduler cannot bypass domain-controller veto/quorum/volume constraints;
- L3S all six directed GRU/SFO/FRA replication paths, WAN loss/reorder/duplication, conflict convergence, empty-cell recovery, region addition/removal/re-selection, filtered-absence non-deletion, same-cell host loss/reallocation, and unchanged project placement under host pressure (`ORCHESTRATOR.md:1655-1666`);
- a typed, versioned product capacity signal proving that the host autoscaler never treats raw member count as logical project/database capacity;
- `WRK-022` compatibility and cleanup evidence showing absent preference, invalid alias, unavailable region, stale catalog, explicit GRU choice, and approved default are distinct and no invalid input silently becomes GRU; and
- explicit cross-repository owner approval and a separate ADR/PR sequence before any future movement of the product source of truth. There is no compatibility reader or dual-writer transition in this proposal.

Until that evidence exists, status remains Proposed and the current product placement owner remains unchanged.


---

# FILE: docs/adr/0020-provider-actuator-threat-model.md

# ADR 0020: Provider actuator crash-stop and irreversible-operation fencing

- Status: Proposed
- Date: 2026-07-13
- Decision owner: Cloud
- Readiness entry: `20 / provider-actuator-threat-model`

## Context

An OCI mutation can outlive the controller leadership and HTTP call that initiated it. The control plane may crash after its last authority check, lose the response, observe an SDK timeout while the request continues, or receive a delayed work-request completion after another leader takes over. OCI does not understand a NATS lease or controller fencing epoch, and IAM or dynamic-group propagation is not a leader-failover fence ([specification, lines 642-646](../../ORCHESTRATOR.md#L642-L646)).

The safety requirement is stronger than avoiding duplicate API calls: every external mutation must have one persisted, authorized terminal intent, and stale actors must be unable to create a conflicting accepted outcome (`INV-004`, `INV-005`, and `INV-006`; [specification, lines 146-148](../../ORCHESTRATOR.md#L146-L148)). The provider interface therefore requires a `ProviderOperationContext` for every mutation ([specification, lines 687-702](../../ORCHESTRATOR.md#L687-L702)).

This threat model is scoped to crash-stop failure of trusted, signed orchestrator code and ordinary provider/network faults. It does not claim safety against Byzantine execution by a root-compromised actuator host. Compromise prevention, detection, credential revocation, and recovery still require a separately reviewed IAM/host security design.

## Proposed decision

Use **persisted intent plus same-operation resume** as the control fence:

1. A pure controller decision persists an operation as `Prepared`, with exact target/creation key, expected observation and generation, proposed terminal state, permitted compensations, required approvals, deadline, preparing controller epoch, and operation identity. `Prepared` is durable intent, but **is not provider-call authorization**.
2. While `Prepared`, the current fenced writer evaluates fresh provider observation, positive ownership, generation, approvals, policy/quorum/budget gates, and the unexpired deadline. A failed or stale check transitions to `Held` and makes no provider call. The controller may safely abandon or re-plan a never-authorized preparation according to its owning state machine.
3. If every gate passes, the writer atomically persists `AuthorizedForProviderCall`. That record freezes the exact provider action and payload digest, target OCID or create key, desired terminal state, provider idempotency/retry key, allowed compensations, authorizing epoch, evidence/approval digests, deadline evaluated at authorization, and authorization commit sequence/digest.
4. The durable transition to `AuthorizedForProviderCall` is the **irreversible commit point**. Before it, expiry, leadership loss, stale observation, or approval withdrawal may hold the operation without a call. After it, a leadership or deadline change may pause an as-yet-unsent dispatch or force reconciliation/escalation, but cannot cancel the committed provider step, replace its terminal target, change its payload/request key, or authorize a conflicting operation.
5. Only an exact `AuthorizedForProviderCall` record can produce a `ProviderOperationContext`. The compartment-scoped regional actuator verifies that record and its digest immediately before dispatch. If the current executor cannot safely dispatch—for example, it lost leadership before crossing the API boundary—it records a hold/transfer of execution; a successor continues the same committed operation rather than preparing a replacement.
6. Before crossing the provider boundary, the actuator durably records the dispatch attempt against the authorization commit. It supplies the frozen operation-bound OCI retry/idempotency token and captures the work-request identifier or exact provider resource identity when OCI exposes them. The exact OCI SDK/service semantics remain unselected until primary sources and spikes establish them.
7. The adapter persists the returned identity/result. A timeout or transport loss is `outcome unknown`, never `operation failed` and never permission to issue a fresh logical operation.
8. Recovery reads provider truth and the recorded work request/idempotency key. A new leader resumes or re-observes the **same authorized operation and desired terminal state**. Any renewed execution lease or approval to resume dispatch is attached to that operation; it cannot change the authorization commit's action, target, payload, request key, or terminal target.
9. Late completion is accepted only when it completes that already-authorized operation safely. Otherwise it is quarantined as an inconsistent observation and cannot authorize compensating destruction by itself.
10. Tags aid discovery and mismatch detection only. Mutation authority requires the scoped OCI capability and the authoritative `AuthorizedForProviderCall` record; IAM propagation is never treated as a fencing signal.

Once the `AuthorizedForProviderCall` transition commits, the destructive provider step is irrevocable in the control model. “Irrevocable” means the exact action and desired terminal intent cannot be replaced with a conflicting intent merely because leadership changed, the deadline elapsed, or a call timed out. It does not mean the provider call must succeed, that execution may ignore an expired dispatch/leadership gate, that every action lacks a deliberate compensation, or that an operator can never approve a later independent operation after the committed operation reaches a known terminal state. A post-commit hold preserves the committed target and request identity; recovery reconciles or resumes that same operation.

## `ProviderOperationContext` contract

The proposed minimum fields are:

- authoritative operation ID and operation kind;
- `AuthorizedForProviderCall` commit sequence and record digest;
- cell and exact compartment;
- authorizing controller/fencing epoch and current executor identity/lease;
- exact target OCID, or a deterministic idempotent create key before an OCID exists;
- expected provider observation and resource/template/bootstrap generation;
- desired terminal state;
- exact action/payload digest, approval/evidence digests, and permitted compensations;
- absolute deadline evaluated at authorization and persisted dispatch-attempt sequence;
- provider idempotency/retry token and, once known, work-request ID;
- immutable correlation to the owning handoff receipt and accepted desired-state generation.

The adapter must reject a context whose authorization state, commit digest, payload digest, target, request key, or correlation does not match the authoritative journal. A `Prepared` or `Held` operation cannot be converted to an adapter context. This ADR does not freeze serialization, OCI header names, token lifetimes, SDK versions, per-operation compensation policy, or the exact action-specific required fields.

## Safety rules

- Every mutating adapter call consumes an exact committed `AuthorizedForProviderCall` record; an adapter cannot invent business intent or execute a merely `Prepared` operation.
- Exactly one logical operation may own a target transition. A leadership change changes the executor, not the authorized terminal outcome.
- All create retries use the same deterministic create identity. Losing an HTTP response cannot create a second VM ([scale-out rule, lines 706-725](../../ORCHESTRATOR.md#L706-L725)).
- The irreversible commit requires fresh observation, exact target identity, generation match, an unexpired deadline, all required approvals, and positive ownership under ADR 0004.
- Wall-clock anomalies before commit hold destructive actions. Local lease validity uses bounded monotonic duration plus authoritative server timestamps ([partition rule, line 589](../../ORCHESTRATOR.md#L589)). After commit, anomaly or expiry can hold dispatch but cannot erase or alter the committed authorization; resume/reconciliation stays on the same operation.
- An unknown response is reconciled through read/work-request APIs before retry or compensation.
- A stale leader's late call can only be absent or safely complete the existing operation; it cannot create a second accepted writer or conflicting terminal state.
- Discovery results and tags cannot authorize mutation, adoption, cleanup, or compensation.
- Credentials are regional and compartment scoped. GRU distributes policy and ceilings but does not receive ordinary SFO/FRA mutation authority after handoff ([specification, lines 665-671](../../ORCHESTRATOR.md#L665-L671)).
- The global emergency budget may stop new non-safety scale-out but cannot manufacture destructive authority or block safety expansion needed to avoid data loss ([specification, lines 746-754](../../ORCHESTRATOR.md#L746-L754)).

## Failure and resume matrix

| Failure point | Required recovery behavior |
|---|---|
| Before `Prepared` persistence | No provider call is permitted. Replanning may create a new operation. |
| `Prepared`, before authorization checks | Resume evaluation; transition to `Held` if authority, observation, generation, approval, ownership, or deadline is stale. No provider call is permitted. |
| Checks passed, before `AuthorizedForProviderCall` commits | The irreversible boundary has not been crossed. Leadership loss or expiry holds without a call; the successor must re-evaluate all gates. |
| `AuthorizedForProviderCall` committed, before dispatch record | The exact action/target/payload/request key/terminal state are irrevocably fixed. A leadership/deadline change may hold dispatch, but cannot authorize a replacement; a successor resumes the same committed operation. |
| Dispatch recorded, before request reaches OCI | Treat provider outcome as potentially unknown if boundary crossing cannot be disproved. Reconcile before reusing the same operation-bound request key. |
| OCI accepted request, response lost | Read by work-request/idempotency/resource identity; never infer failure from timeout. |
| Resource created, ID not persisted | Discover only within the exact compartment and create identity, verify the full operation/generation/ownership tuple, then bind or quarantine. Tags alone are insufficient. |
| Leadership changes while work request runs | New leader observes/resumes the same terminal target; it cannot cancel by issuing a conflicting destructive request. |
| Late old-leader completion | Accept only as safe completion of the same authorized operation; otherwise hold and alert for review. |
| Deadline expires after authorization commit | Deadline stops blind dispatch/retries and may enter a held/escalated state; it does not negate the committed target or an in-flight mutation. Continue read-only reconciliation, and resume only the same operation under its action-specific recovery policy. |
| Provider returns inconsistent target/generation | `ERR-PROVIDER-OWNERSHIP-MISMATCH`; quarantine and make no further mutation. |
| Credential revoked or access denied | Persist denial, make no broader-credential fallback, and require scoped recovery. |

## Rejected unsafe interpretations

### Fencing token in a tag prevents a stale OCI call

Rejected. OCI does not atomically validate the control-plane lease when applying general compute/storage/LB calls. A tag is observation metadata, not a provider-side compare-and-swap fence.

### IAM/dynamic-group propagation fences leadership

Rejected. Propagation is delayed and is not transactionally coupled to regional leadership. Revoking the old identity may reduce exposure, but cannot prove a late call is absent.

### Timeout means the operation failed

Rejected. The provider may have accepted the request. Starting a new logical operation after timeout can duplicate a create or conflict with an in-flight destruction.

### New leader compensates before learning provider truth

Rejected. Compensation is itself a mutation and may race the original request. Only the persisted operation's permitted compensation may run, after reconciliation and its own authorization checkpoint.

### Best-effort target discovery by name or tags

Rejected. Non-unique or mutable metadata cannot bind an irreversible operation to an exact owned resource.

### Epoch change cancels an authorized destructive step

Rejected. The provider cannot enforce that cancellation. Once durably authorized, leaders converge on the same terminal intent so a late call remains safe in the control model.

## Consequences

- Provider adapters return typed observations and never contain ownership, retry, compensation, or terminal-state business rules.
- Journals distinguish `Prepared`, `Held`, and the immutable `AuthorizedForProviderCall` commit from dispatch attempts and provider outcomes.
- Journals retain enough sanitized request/work-request identity to distinguish `not sent`, `unknown`, `in progress`, `succeeded`, `failed`, and `inconsistent` after crashes.
- Journals, errors, logs, traces, metrics, and evidence obey `SEC-NO-SECRET-OUTPUT`; credential material and private keys are never persisted as provider-operation diagnostics.
- Each provider operation needs explicit idempotency, ambiguity, reconciliation, and compensation semantics; a generic retry policy is unsafe.
- Operator tooling must display an unknown/held provider outcome without offering an unscoped “retry anyway.”
- Credential scope is a blast-radius control, not the logical fence. A root-compromised trusted actuator remains outside this ADR's crash-stop guarantee.
- ADR 0004 must establish positive ownership before this actuator can mutate transferred resources.

## Unresolved inputs and evidence

The readiness map requires exact OCI SDK idempotency/work-request semantics, a compartment-scoped IAM policy, leadership-loss/adapter-race evidence, and an independent security review; it depends on ADRs 1, 4, and 23 ([readiness index, lines 239-248](readiness-index.yaml#L239-L248)). Acceptance remains blocked on:

- per-OCI-service retry token support, token scope/retention, work-request lookup, cancellation, timeout, and eventual-consistency behavior from primary documentation and executable spikes;
- the exact per-operation ambiguity and compensation table for compute, boot/block volume, attachment, LB backend, and any later provider mutations;
- exact regional compartment IAM statements, workload identity issuance/rotation/revocation, and denial behavior;
- the controller leadership-loss state model, `Prepared`/`Held`/`AuthorizedForProviderCall` journal schema, and action-specific post-commit dispatch-expiry policy;
- approved regional RPO/RTO, storage SLO, maximum survival window, and cost limits where they control deadlines, safe holds, expansion, and replacement;
- owner decisions governing regional outage mutation policy, storage cleanup, runtime defaults, and provider portability where downstream operations differ;
- independent review of the crash-stop assumption and the residual risk of host or credential compromise.

The incomplete read-only OCI audit grants no mutation authority and establishes no resource ownership ([OCI audit, lines 22-40](../audits/oci/phase0-residual-inventory.md#L22-L40)).

## Required verification before acceptance

- **Review:** primary OCI semantics for every mutating API, exact `ProviderOperationContext`, per-operation ambiguity/compensation matrix, compartment policy, and independent security threat-model review.
- **L0:** exhaustively inject leader loss and deadline/approval/observation changes on both sides of the `AuthorizedForProviderCall` commit, then before and after every dispatch, call, response, work-request, reconciliation, compensation, and completion checkpoint. Explore duplicate, reordered, delayed, and contradictory observations. Prove pre-commit changes make no call, post-commit changes cannot alter the exact terminal target/request identity, one owned terminal outcome, no stale accepted mutation, and no tag-authorized action.
- **L3S:** fake-provider full-region scenarios for lost responses, arbitrarily delayed completions, actuator crash/restart, leadership churn, GRU/WAN loss, duplicate callbacks, stale observations, and operation-journal restore.
- **L4:** targeted disposable OCI A1/IAM/storage/LB tests after the exact-tree credential gate. Delay real work requests across leadership change and prove a new leader resumes the same operation without duplicate creation or conflicting destruction.
- **Security:** demonstrate that an identity cannot mutate another region/compartment or an unlisted resource/action, and that access denial never falls back to broader credentials.

Phase 4 cannot exit until crash/retry and leadership loss at every provider and handoff checkpoint produces exactly one owned terminal outcome and unowned resources remain untouched ([specification, lines 1538-1548](../../ORCHESTRATOR.md#L1538-L1548)). No test described here authorizes a VM or cloud call before the exact-tree pre-deployment gate.

## Traceability

| Kind | Stable/proposed ID | Disposition in this ADR |
|---|---|---|
| Requirement | `REQ-O010` | Provides the regional actuator created by the Pulumi handoff. |
| Requirement | `REQ-O011` | Applies the fence to automatic node and storage mutations. |
| Requirement | `REQ-O023` | Prevents old-estate discovery from becoming adoption or mutation authority. |
| Invariant | `INV-004` | Exactly one fenced writer advances a provider operation. |
| Invariant | `INV-005` | Commands are idempotent, generation/deadline bound, and replay-safe. |
| Invariant | `INV-006` | Stale leaders/agents cannot produce a conflicting accepted mutation. |
| Invariant | `INV-014` | Limits the actuator to concrete resources transferred under ADR 0004. |
| Security rule | `SEC-NO-SECRET-OUTPUT` | Excludes credentials/private keys from operation state and diagnostics. |
| Proposed state machine | `SM-NODE-SCALE-OUT` | Requires request persistence before create and same-operation recovery. |
| Proposed state machine | `SM-NODE-SCALE-IN` | Requires exact-instance, gated destruction with fresh observations. |
| Proposed security rule | `SEC-PROVIDER-MUTATION-AUTHORITY` | Scoped capability plus persisted intent is required; tags never authorize. |
| Proposed error | `ERR-PROVIDER-OWNERSHIP-MISMATCH` | Holds mutation on target/ownership mismatch. |
| Proposed error | `ERR-SCALE-IN-METRICS-STALE` | Holds destructive scale-in on stale evidence. |
| Proposed error | `ERR-CLOCK-SKEW-DESTRUCTIVE-HOLD` | Holds destructive action when wall-clock validity is anomalous. |
| Proposed gate | `REQ-GATE-PHASE4` | Requires leadership-loss and delayed-call proof at every checkpoint. |

The registry audit classifies existing requirement/invariant entries as ID-only and proposes the state-machine/security/error/gate IDs; this ADR does not freeze those proposals ([registry audit, lines 30-57](../audits/registry/registry-audit.json#L30-L57); [registry audit, lines 67-98](../audits/registry/registry-audit.json#L67-L98)).


---

# FILE: docs/adr/README.md

# ADR readiness index

This directory records Phase 0 decision readiness. Owner choices 1A–10A were accepted on 2026-07-16 with reliability first; measurable cost, storage, RPO, and RTO targets remain deployment-qualification inputs rather than blockers for pure contract work.

`readiness-index.yaml` is JSON-compatible YAML validated by the dependency-free C# tooling executable. It is the canonical Phase 0 map of the 24 items in `ORCHESTRATOR.md`'s initial ADR backlog.

## Status rules

- `draft-ready`: the proposed contract and checked-in evidence are sufficient to write a choice-preserving draft. It does not mean accepted.
- `owner-input-required`: a numbered owner choice or owner-approved SLO can materially change the decision. A draft may compare alternatives but cannot select one.
- `evidence-required`: the decision is not controlled by an open owner choice, but a measurement, inventory, threat-model result, product-contract reconciliation, or primary implementation source is still missing.
- `accepted`: requires an explicit owner/architecture approval record plus every exit-evidence item. Phase 0 has no accepted ADRs.

Only the exact canonical owner lane names from `ORCHESTRATOR.md`'s exclusive-workstream table are valid: `Integration/contract steward`, `Core`, `Messaging/security`, `Runtime`, `Cloud`, `Storage`, `TerraBase`, `Delivery`, `Operations`, `Cross-repository cleanup`, and `Verification`.

Run `dotnet run --project tools/TerraScale.Orchestrator.Tooling -- adr-readiness` and `dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test` after any update. The validator proves IDs 1 through 24 occur exactly once, fields are populated, lanes and statuses are canonical, `accepted` is absent while owner inputs remain open, every local evidence anchor resolves to nonblank in-bounds lines, and every `draft-ready` record has both a precise specification anchor and a checked-in audit/ledger anchor.


---

# FILE: docs/adr/readiness-index.yaml

{
  "schemaVersion": 1,
  "contract": "ORCHESTRATOR.md proposed architecture dated 2026-07-13",
  "generatedAt": "2026-07-13",
  "status": "readiness-map-not-decision-record",
  "openOwnerQuestions": [1,2,3,4,5,6,7,8,9,10],
  "openPlanningInputs": ["team-size", "first-production-date", "maximum-three-region-pre-user-cost", "storage-iops-throughput-p95-p99", "regional-rpo-rto"],
  "canonicalOwnerLanes": ["Integration/contract steward", "Core", "Messaging/security", "Runtime", "Cloud", "Storage", "TerraBase", "Delivery", "Operations", "Cross-repository cleanup", "Verification"],
  "entries": [
    {
      "id": 1,
      "slug": "global-regional-authority",
      "title": "Global versus regional authority and outage mutation policy",
      "status": "owner-input-required",
      "ownerLane": "Core",
      "controllingInputs": ["owner-question-1", "owner-question-2", "regional-rpo-rto"],
      "availableEvidence": ["ORCHESTRATOR.md:30-39", "ORCHESTRATOR.md:83-99", "ORCHESTRATOR.md:538-552"],
      "missingEvidence": ["Owner selections for topology and isolated-region mutation authority", "Approved regional RPO/RTO and partition acceptance traces"],
      "dependencies": [],
      "exitEvidence": ["Signed owner decision for questions 1 and 2", "L0 authority/partition model proving one fenced writer and permitted outage actions", "L3S WAN/GRU partition evidence meeting approved RPO/RTO"]
    },
    {
      "id": 2,
      "slug": "dual-regional-nats",
      "title": "Dual dedicated regional NATS topology, host co-location isolation, bootstrap, upgrade, and recovery",
      "status": "owner-input-required",
      "ownerLane": "Messaging/security",
      "controllingInputs": ["owner-question-1", "owner-question-8", "storage-slo"],
      "availableEvidence": ["ORCHESTRATOR.md:492-517", "ORCHESTRATOR.md:519-536"],
      "missingEvidence": ["Host co-location decision", "Pinned NATS server/client N/N-1 policy", "Two-plane cgroup and storage isolation benchmark", "Bootstrap/peer replacement conformance"],
      "dependencies": [1,3,8,11],
      "exitEvidence": ["Owner decisions 1 and 8", "Pinned NATS versions and compatibility window", "L0C permissions/gateway/peer/snapshot recovery report", "L3S one-server-loss and rolling-upgrade evidence for both planes", "Storage benchmark proving selected physical layout"]
    },
    {
      "id": 3,
      "slug": "jetstream-correctness",
      "title": "JetStream streams, KV CAS, snapshot/restore, fencing, and audit retention",
      "status": "owner-input-required",
      "ownerLane": "Messaging/security",
      "controllingInputs": ["regional-rpo-rto", "storage-slo", "audit-retention-policy"],
      "availableEvidence": ["ORCHESTRATOR.md:461-489", "ORCHESTRATOR.md:535-552", "ORCHESTRATOR.md:554-580"],
      "missingEvidence": ["Approved acknowledged-write RPO and audit retention", "Measured sync_interval latency/durability tradeoff", "Real NATS L0C snapshot/CAS/dedup/redelivery evidence"],
      "dependencies": [1,2],
      "exitEvidence": ["Approved RPO and retention values", "Per-stream retention/replica/ack/sync decision table", "L0 fencing and replay model", "L0C CAS/watch/dedup/snapshot/restore and peer-loss evidence"]
    },
    {
      "id": 4,
      "slug": "pulumi-provider-ownership",
      "title": "Pulumi/provider ownership and exact resource tags/IAM",
      "status": "draft-ready",
      "ownerLane": "Cloud",
      "controllingInputs": [],
      "availableEvidence": ["ORCHESTRATOR.md:627-648", "ORCHESTRATOR.md:650-671", "ORCHESTRATOR.md:139-158", "docs/retirement/workaround-ledger.yaml:103-123"],
      "missingEvidence": ["Exact OCI IAM policy and tag schema", "Pulumi retain/unmanage primary-source spike", "Fresh-resource handoff and crash-recovery model evidence"],
      "dependencies": [1,20,24],
      "exitEvidence": ["Reviewed exact ownership/tag/IAM schema", "L0 handoff model covering every crash checkpoint", "L3S fresh-resource handoff receipt and survival test", "L4 proof Pulumi and regional actuator cannot concurrently own a transferred resource"]
    },
    {
      "id": 5,
      "slug": "oci-instance-strategy",
      "title": "Direct OCI instances versus instance pools by node class",
      "status": "owner-input-required",
      "ownerLane": "Cloud",
      "controllingInputs": ["maximum-three-region-pre-user-cost", "storage-slo"],
      "availableEvidence": ["ORCHESTRATOR.md:687-709", "ORCHESTRATOR.md:711-754"],
      "missingEvidence": ["OCI termination-selection and work-request primary sources", "A1 capacity and provisioning measurements", "Per-node-class stateful/stateless failure analysis and TCO"],
      "dependencies": [4,19,20],
      "exitEvidence": ["Node-class decision matrix with OCI primary citations", "Fake-provider timeout/duplicate/capacity suite", "L4 direct-instance and any proposed pool behavior evidence", "Measured cost and create-to-ready p95"]
    },
    {
      "id": 6,
      "slug": "workload-runtime-contract",
      "title": "Unified workload schema and systemd/containerd driver contract",
      "status": "owner-input-required",
      "ownerLane": "Runtime",
      "controllingInputs": ["owner-question-4"],
      "availableEvidence": ["ORCHESTRATOR.md:400-445", "ORCHESTRATOR.md:843-871", "docs/audits/phase0-product-contract-source-audit.md:30-50"],
      "missingEvidence": ["Runtime-default owner choice", "Pinned containerd/runc versions", "systemd D-Bus and containerd API contract spikes", "Cross-driver lifecycle fixtures"],
      "dependencies": [7,11,22],
      "exitEvidence": ["Owner decision 4", "Closed role and typed WorkloadSpec schemas", "L0 admission/capability denial tests", "L1R identical lifecycle/identity/health/volume/rollback contract for both drivers", "L4 ARM64 artifact/runtime qualification"]
    },
    {
      "id": 7,
      "slug": "host-networking",
      "title": "Host network/port allocation versus namespaced network roadmap",
      "status": "owner-input-required",
      "ownerLane": "Runtime",
      "controllingInputs": ["memory-and-density-slo"],
      "availableEvidence": ["ORCHESTRATOR.md:850-857", "ORCHESTRATOR.md:873-879"],
      "missingEvidence": ["Port exhaustion and collision model", "Network namespace isolation/memory comparison", "Role-by-role protocol and exposure inventory", "DNS/LB integration evidence"],
      "dependencies": [6,15,16],
      "exitEvidence": ["Closed port/exposure catalog", "Deterministic allocator property/concurrency tests", "L1R host-network and namespace security tests", "Compact A1 density test with twice projected stateless replicas"]
    },
    {
      "id": 8,
      "slug": "compact-profile",
      "title": "Compact co-location performance and promotion to isolated node classes",
      "status": "owner-input-required",
      "ownerLane": "Core",
      "controllingInputs": ["owner-question-8", "maximum-three-region-pre-user-cost", "storage-slo", "memory-and-density-slo"],
      "availableEvidence": ["ORCHESTRATOR.md:503-517", "ORCHESTRATOR.md:248-256", "ORCHESTRATOR.md:1280-1289"],
      "missingEvidence": ["Host-isolation choice", "Approved cost/memory/storage targets", "Colocated A1 TerraBase/NATS/observability benchmark", "Promotion/demotion hysteresis model"],
      "dependencies": [2,5,9,19],
      "exitEvidence": ["Owner decision 8 and approved SLOs", "Reproducible compact and isolated benchmark results", "Deterministic promotion policy tests", "Seven-day L5 soak proving cost and performance without reduced HA margin"]
    },
    {
      "id": 9,
      "slug": "volume-lifecycle",
      "title": "Volume identity, filesystem layout, fencing, expansion, performance, retention, and deletion",
      "status": "owner-input-required",
      "ownerLane": "Storage",
      "controllingInputs": ["owner-question-5", "storage-slo", "regional-rpo-rto"],
      "availableEvidence": ["ORCHESTRATOR.md:758-840", "docs/audits/toolchain/local-toolchain-audit.md:12-29"],
      "missingEvidence": ["Elastic-volume cleanup choice", "Approved storage SLO/RPO", "Filesystem selection", "OCI Block Volume and guest-rescan primary evidence", "Real ext4/XFS crash-point tests"],
      "dependencies": [4,8,20],
      "exitEvidence": ["Owner decision 5 and approved storage/RPO targets", "Selected filesystem/layout/tool pins", "L0 irreversible-operation model and wrong-volume rejection", "L1R ext4/XFS online-growth crash matrix", "L4 OCI attach/expand/detach/performance evidence"]
    },
    {
      "id": 10,
      "slug": "terrabase-controller",
      "title": "TerraBase topology, upgrade, backup, replication, and autoscaling controller contract",
      "status": "owner-input-required",
      "ownerLane": "TerraBase",
      "controllingInputs": ["owner-question-4", "owner-question-5", "owner-question-10", "storage-slo", "regional-rpo-rto"],
      "availableEvidence": ["ORCHESTRATOR.md:1012-1039", "docs/audits/phase0-product-contract-source-audit.md:30-42"],
      "missingEvidence": ["Runtime, elastic cleanup, and rootless container scale-out choices", "Approved RPO/RTO and storage SLO", "Typed TerraBase admin contract", "Real backup/restore and 3-to-4-to-3 evidence"],
      "dependencies": [1,6,9,11,21],
      "exitEvidence": ["Owner decisions 4, 5, and 10 plus approved SLOs", "Typed topology/backup/replication contract and L0 state models", "L3S six-direction replication, upgrade/rollback, backup/restore and 3-to-4-to-3", "L4 retained-volume host replacement and storage performance"]
    },
    {
      "id": 11,
      "slug": "pki-workload-identity",
      "title": "Root/intermediate PKI, workload identity namespace, certificate TTL, revocation, and disconnected renewal",
      "status": "owner-input-required",
      "ownerLane": "Messaging/security",
      "controllingInputs": ["security-slo", "maximum-survival-window"],
      "availableEvidence": ["ORCHESTRATOR.md:41-51", "ORCHESTRATOR.md:881-902"],
      "missingEvidence": ["Approved certificate TTL/renewal/revocation objectives", "Root/intermediate custody threat model", "NATS active connection revocation proof", "Disconnected-issuer recovery evidence"],
      "dependencies": [1,12,21],
      "exitEvidence": ["Reviewed PKI namespace/profile/custody design", "Approved TTL/revocation/survival targets", "L0 authorization/anti-rollback/redaction models", "L0C active NATS credential revocation", "L3S issuer rotation and disconnected renewal", "L4 KMS root-protection evidence"]
    },
    {
      "id": 12,
      "slug": "vault-backend",
      "title": "Built-in vault backend and disaster recovery",
      "status": "owner-input-required",
      "ownerLane": "Messaging/security",
      "controllingInputs": ["owner-question-3", "regional-rpo-rto", "maximum-survival-window"],
      "availableEvidence": ["ORCHESTRATOR.md:904-922"],
      "missingEvidence": ["Vault authority owner choice", "Approved vault RPO/RTO and disconnected duration", "Ciphertext store/KMS threat model", "Backup/restore/anti-rollback drill"],
      "dependencies": [3,11,21],
      "exitEvidence": ["Owner decision 3", "Reviewed backend/custody/lease/DR threat model", "L0 policy/lease/outage/anti-rollback/no-secret-output suite", "L3S disconnected cache and recovery drill", "L4 OCI KMS/Vault rotation and restore evidence"]
    },
    {
      "id": 13,
      "slug": "native-gitops",
      "title": "Native GitOps schema, fresh typed desired state, historical-behavior review, and complete Flux removal",
      "status": "draft-ready",
      "ownerLane": "Delivery",
      "controllingInputs": [],
      "availableEvidence": ["ORCHESTRATOR.md:924-959", "docs/retirement/workaround-ledger.yaml:125-214", "docs/audits/phase0-product-contract-source-audit.md:52-67"],
      "missingEvidence": ["Fresh native schema and compatibility fixtures", "Complete historical behavior reconciliation", "Cleanup PR sequencing and native replacement gates"],
      "dependencies": [1,6,14,18,24],
      "exitEvidence": ["Reviewed typed schema and Git-parent/journal-child ownership rules", "L0 dependency/signature/diff/prune/rollback/one-writer tests", "L3S deterministic recovery at every reconcile checkpoint", "Per-WRK replacement evidence before separate Flux cleanup PRs"]
    },
    {
      "id": 14,
      "slug": "ci-supply-chain",
      "title": "CI trust zones, release graph, bootstrap/recovery path, and artifact signing",
      "status": "owner-input-required",
      "ownerLane": "Delivery",
      "controllingInputs": ["owner-question-7", "artifact-and-evidence-signing-selection"],
      "availableEvidence": ["ORCHESTRATOR.md:961-1010", "docs/audits/phase0-product-contract-source-audit.md:52-73", "docs/audits/toolchain/local-toolchain-audit.md:12-29"],
      "missingEvidence": ["Bootstrap/recovery owner choice", "Signing identity/tool selection and pin", "Reconciled feature/develop/main policy", "Authentication build target", "Runner isolation threat model"],
      "dependencies": [6,13,22,23],
      "exitEvidence": ["Owner decision 7", "Pinned signing/SBOM tools and protected identity design", "Reconciled complete build descriptor inventory", "L0 candidate/release/trust-zone/interruption suite", "Evidence-gated L3S SFO-to-FRA-to-GRU exact-digest promotion and forced rollback"]
    },
    {
      "id": 15,
      "slug": "service-routing",
      "title": "Service registry, DNS, ingress/LB, region headers, and routing ownership",
      "status": "evidence-required",
      "ownerLane": "Operations",
      "controllingInputs": ["dns-implementation-selection"],
      "availableEvidence": ["ORCHESTRATOR.md:873-879", "docs/audits/phase0-product-contract-source-audit.md:44-50"],
      "missingEvidence": ["DNS implementation and HA selection", "Exact public/product routing compatibility fixture", "LB/Cloudflare ownership and default-deny ingress model", "Twenty-region topology scaling evidence"],
      "dependencies": [7,16,18,24],
      "exitEvidence": ["Selected DNS/registry design with ARM64 and HA evidence", "Golden region-header/routing-loop/client-IP fixtures", "L0 ownership and stale-readiness models", "L3S registry/DNS/LB failure tests", "L4 OCI LB reconciliation and ingress withdrawal proof"]
    },
    {
      "id": 16,
      "slug": "vpn-connectivity",
      "title": "VPN implementation and scalable twenty-region connectivity",
      "status": "owner-input-required",
      "ownerLane": "Operations",
      "controllingInputs": ["owner-question-6", "vpn-implementation-selection"],
      "availableEvidence": ["ORCHESTRATOR.md:1096-1110", "ORCHESTRATOR.md:248-256"],
      "missingEvidence": ["Provider portability timing", "Selected WireGuard implementation and pinned version", "Route/ACL/relay/secret lifecycle threat model", "At-least-20-region qualified connectivity matrix"],
      "dependencies": [11,15,19],
      "exitEvidence": ["Owner decision 6", "Selected VPN with primary-source, ARM64, HA and memory evidence", "Twenty-region topology/route policy model", "L3S GRU-control-loss, revocation and partition tests", "L4 real OCI UDP/route/ACL evidence"]
    },
    {
      "id": 17,
      "slug": "operator-security",
      "title": "Operator OIDC/RBAC/break-glass/API and Grafana threat model",
      "status": "owner-input-required",
      "ownerLane": "Operations",
      "controllingInputs": ["owner-question-9", "operator-identity-provider-selection", "security-slo"],
      "availableEvidence": ["ORCHESTRATOR.md:1065-1094"],
      "missingEvidence": ["Telemetry loss/durability owner choice", "OIDC provider/client and role mapping", "Break-glass custody/expiry procedure", "Grafana data-source/plugin selection", "Exact projection/cardinality and browser threat model"],
      "dependencies": [11,15],
      "exitEvidence": ["Owner decision 9", "Reviewed operator API/RBAC/audit/break-glass and telemetry-loss threat model", "Provisioned read-only exact-state data source decision", "L0 authorization/cardinality/no-mutation tests", "L3S OIDC/session/failover, telemetry exhaustion, and Grafana read-only tests", "Operational break-glass drill"]
    },
    {
      "id": 18,
      "slug": "placement-boundary",
      "title": "Project placement versus host scheduling boundary",
      "status": "draft-ready",
      "ownerLane": "Integration/contract steward",
      "controllingInputs": [],
      "availableEvidence": ["ORCHESTRATOR.md:155-155", "ORCHESTRATOR.md:1031-1039", "docs/retirement/workaround-ledger.yaml:581-605"],
      "missingEvidence": ["Golden product placement compatibility fixtures", "Explicit storage-epoch and filtered-absence ownership map", "Cross-repository approval before any source-of-truth move"],
      "dependencies": [10,13,15],
      "exitEvidence": ["Reviewed boundary naming one authoritative owner for project placement and one for host allocation", "Product compatibility fixtures for Project.Regions and PlacementGeneration", "L0 proof host load cannot mutate customer placement", "L3S six-direction replication behavior without duplicate placement authority"]
    },
    {
      "id": 19,
      "slug": "cost-slo-portability",
      "title": "Three-region cost/SLO target and provider portability contract",
      "status": "owner-input-required",
      "ownerLane": "Core",
      "controllingInputs": ["owner-question-6", "maximum-three-region-pre-user-cost", "storage-slo", "regional-rpo-rto", "team-size", "first-production-date"],
      "availableEvidence": ["ORCHESTRATOR.md:248-256", "ORCHESTRATOR.md:756-756"],
      "missingEvidence": ["All planning values", "Post-OKE residual bill", "Normalized OCI/AWS/GCP/Azure TCO", "At-least-20-row OCI eligibility matrix", "Comparable ARM64 TerraBase/storage benchmarks"],
      "dependencies": [5,8,9,16,24],
      "exitEvidence": ["Owner decision 6 and approved planning/SLO values", "Current normalized provider decision report with raw evidence", "At least 20 qualified OCI region rows", "Seven-day measured three-region billing and storage-performance gate"]
    },
    {
      "id": 20,
      "slug": "provider-actuator-threat-model",
      "title": "Provider-actuator crash-stop threat model, irreversible-operation fencing/resume, and OCI credential boundary",
      "status": "draft-ready",
      "ownerLane": "Cloud",
      "controllingInputs": [],
      "availableEvidence": ["ORCHESTRATOR.md:627-648", "ORCHESTRATOR.md:687-709", "docs/retirement/workaround-ledger.yaml:481-505"],
      "missingEvidence": ["Exact OCI SDK idempotency/work-request semantics", "Compartment-scoped IAM policy", "Leadership-loss model and adapter race evidence", "Independent security review"],
      "dependencies": [1,4,23],
      "exitEvidence": ["Reviewed crash-stop/late-call threat model", "Exact ProviderOperationContext contract and compartment policy", "L0 exhaustive leadership-loss-before/after-call model", "L4 delayed work-request and new-leader same-operation resume evidence", "Proof tags never authorize mutation"]
    },
    {
      "id": 21,
      "slug": "regional-survival",
      "title": "Regional survival bundle, artifact/secret availability, disconnected node replacement, and maximum survival window",
      "status": "owner-input-required",
      "ownerLane": "Messaging/security",
      "controllingInputs": ["owner-question-2", "owner-question-3", "regional-rpo-rto", "maximum-survival-window", "regional-artifact-mirror-selection"],
      "availableEvidence": ["ORCHESTRATOR.md:673-685"],
      "missingEvidence": ["Outage mutation and vault choices", "Approved survival window/RTO", "Regional artifact mirror", "Per-secret/certificate expiry inventory", "Disconnected restore/replacement evidence"],
      "dependencies": [1,2,10,11,12,14,22],
      "exitEvidence": ["Owner decisions 2 and 3 plus approved window/RTO", "Content-addressed encrypted bundle schema and freshness rules", "L0 expiry/artifact/rollback completeness models", "L3S replacement with GRU/Git/Vault/registry disconnected", "L4 A1 node replacement inside approved RTO"]
    },
    {
      "id": 22,
      "slug": "host-image-self-upgrade",
      "title": "Golden-image bootstrap, N/N-1 compatibility, and A/B orchestrator self-upgrade/rollback",
      "status": "evidence-required",
      "ownerLane": "Runtime",
      "controllingInputs": ["arm64-host-image-selection", "nats-n-minus-one-policy"],
      "availableEvidence": ["ORCHESTRATOR.md:333-382", "docs/audits/phase0-build-baseline.md:1-26", "docs/audits/toolchain/local-toolchain-audit.md:12-29"],
      "missingEvidence": ["Pinned ARM64 LTS image/kernel/glibc", "Ordinary-Linux reproducible publish", "N/N-1 protocol/schema matrix", "Independent rollback timer/slot implementation evidence"],
      "dependencies": [6,11,14,21,23],
      "exitEvidence": ["Pinned signed host/base image and toolchain", "Both RID digests built reproducibly with approved loaders", "L0 compatibility/rollback state model", "L1R A/B rollback timer and systemd PID-1 tests", "L3S one-failure-domain rolling self-upgrade", "L4 real A1 execution"]
    },
    {
      "id": 23,
      "slug": "evidence-gate",
      "title": "Requirement/error registry, pure decision dependency rules, test toolchain, evidence attestation, and deployment-credential gate",
      "status": "evidence-required",
      "ownerLane": "Verification",
      "controllingInputs": ["artifact-and-evidence-signing-selection"],
      "availableEvidence": ["ORCHESTRATOR.md:1114-1179", "requirements/registry.yaml:1-48", "Directory.Packages.props:1-9", "global.json:1-9", "docs/audits/toolchain/local-toolchain-audit.md:12-29"],
      "missingEvidence": ["Complete canonical registry and generated trace", "Property/model/fuzz/mutation/analyzer pins", "Signing/SBOM selection and tools", "Forgejo/IAM credential enforcement design", "Pinned Podman and image-manifest evidence"],
      "dependencies": [14,22],
      "exitEvidence": ["Complete stable-ID registry and architecture graph", "Fully pinned hermetic test and signing toolchain", "Negative tests for missing trace and dependency reversal", "Cold full L0/L0C thresholds", "Signed exact-tree DSSE/in-toto evidence rejected after any input change", "Credential issuance impossible without valid evidence"]
    },
    {
      "id": 24,
      "slug": "greenfield-bringup",
      "title": "Greenfield OCI inventory, stale-resource quarantine/approved cleanup, partial-create recovery, initial trust/NATS/TerraBase seeding, independent regional partial success, Pulumi handoff, cleanup-PR sequencing, ingress activation/withdrawal, and first-production rollback boundaries",
      "status": "owner-input-required",
      "ownerLane": "Cloud",
      "controllingInputs": ["explicit-cleanup-approvals", "explicit-ingress-enable-approval", "maximum-three-region-pre-user-cost", "regional-rpo-rto"],
      "availableEvidence": ["ORCHESTRATOR.md:54-66", "ORCHESTRATOR.md:1579-1630", "docs/retirement/workaround-ledger.yaml:481-505"],
      "missingEvidence": ["Sanitized read-only OCI inventory", "Positive ownership and stale-remnant classifications", "Approved cleanup list", "Partial-create/independent-region recovery model", "Closed-ingress clean-room rehearsal"],
      "dependencies": [4,10,13,15,19,20,21,22,23],
      "exitEvidence": ["Read-only account inventory proving old estate remains outside new ownership graph", "Explicit per-remnant quarantine/cleanup approval", "L0 every-checkpoint partial-create/retry model", "Two equivalent from-zero L3S rehearsals", "Closed-ingress L4 assembly with independent regional handoffs", "Signed post-soak ingress enable and tested withdrawal", "Separate reviewed cleanup PR evidence"]
    }
  ]
}


---

# FILE: docs/audits/delivery/descriptor-inventory.json

{
  "coverageGaps": [
    {
      "conflict": "CI-CONFLICT-003",
      "id": "CI-GAP-001",
      "repository": "TerraScale.Internals",
      "status": "open",
      "summary": "Authentication lacks build and release-test targets."
    },
    {
      "conflict": null,
      "id": "CI-GAP-002",
      "repository": "TerraScale.DevHost",
      "status": "open",
      "summary": "No .terrascale descriptor or Forgejo workflow exists; DevHost is local-only and must not be inferred as a production role."
    },
    {
      "conflict": "CI-CONFLICT-002",
      "id": "CI-GAP-003",
      "repository": "TerraScale.Internals",
      "status": "open",
      "summary": "CI documentation references three absent per-service workflow paths."
    },
    {
      "conflict": "CI-CONFLICT-001",
      "id": "CI-GAP-004",
      "repository": "cross-repository",
      "status": "open",
      "summary": "Observed generic workflow, repository policy, and historical cleanup targets have no single accepted native pipeline contract yet."
    }
  ],
  "deploymentDescriptors": [
    {
      "buildTargets": [
        "studio",
        "linux-amd64",
        "linux-arm64"
      ],
      "candidatePackage": "ci-candidates-terrabase",
      "dependencies": [
        {
          "reason": "TerraBase runtime changes require API/Auth consumer compatibility",
          "source": "src/",
          "target": "internals-api-auth"
        },
        {
          "reason": "runtime changes require Operator compatibility",
          "source": "src/",
          "target": "operator"
        }
      ],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "flux-rolling",
      "releaseProfiles": [
        "release-e2e",
        "slow",
        "issues",
        "rachis",
        "embedded"
      ],
      "repository": "TerraBase",
      "source": "TerraBase@349cd1a11e5b252ffc193d3c3cdf059b954828fd:.terrascale/deploy.json:1-30"
    },
    {
      "buildTargets": [
        "linux-amd64",
        "linux-arm64",
        "helm"
      ],
      "candidatePackage": "ci-candidates-operator",
      "dependencies": [
        {
          "reason": "CRD changes require TerraBase rollout compatibility",
          "source": "api/",
          "target": "terrabase-manifests"
        }
      ],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "flux-rolling",
      "releaseProfiles": [
        "go-regression",
        "helm-generated"
      ],
      "repository": "Terrabase.Operator",
      "source": "Terrabase.Operator@b3b105be880e169d62e3cb4506846b8a11342d5c:.terrascale/deploy.json:1-24"
    },
    {
      "buildTargets": [
        "cli-nuget"
      ],
      "candidatePackage": "ci-candidates-deploy",
      "dependencies": [
        {
          "reason": "Deploy CLI contract changes require every workflow/profile compatibility fixture",
          "source": "src/",
          "target": "all-workflow-fixtures"
        }
      ],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "package",
      "releaseProfiles": [
        "cli-regression",
        "fixture-regression"
      ],
      "repository": "TerraScale.Deploy",
      "source": "TerraScale.Deploy@cacb596cd0f6f25a40e76160554fecc14f047965:.terrascale/deploy.json:1-15"
    },
    {
      "buildTargets": [
        "sdk-nuget",
        "ef-nuget"
      ],
      "candidatePackage": "ci-candidates-dotnet",
      "dependencies": [
        {
          "reason": "SDK changes require API and Dashboard consumer validation",
          "source": "src/",
          "target": "internals-api-dashboard"
        }
      ],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "package",
      "releaseProfiles": [
        "base-sdk-release-e2e",
        "ef-core-release-e2e"
      ],
      "repository": "TerraScale.DotNet",
      "source": "TerraScale.DotNet@9d98e4e3dc3e05eb955ba06f03b05bf462cfb21b:.terrascale/deploy.json:1-18"
    },
    {
      "buildTargets": [
        "npm"
      ],
      "candidatePackage": "ci-candidates-typescript",
      "dependencies": [
        {
          "reason": "SDK changes require Dashboard build and browser E2E",
          "source": "src/",
          "target": "internals-dashboard"
        }
      ],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "package",
      "releaseProfiles": [
        "regression",
        "release-e2e"
      ],
      "repository": "TerraScale.TypeScript",
      "source": "TerraScale.TypeScript@7d9b629ce5a5d41a3fa457911305b057749e3252:.terrascale/deploy.json:1-15"
    },
    {
      "buildTargets": [
        "rendered-gitops"
      ],
      "candidatePackage": "ci-candidates-infrastructure",
      "dependencies": [
        {
          "reason": "workload and route policy changes require render, rollout, and endpoint verification",
          "source": "gitops/apps/terrascale/",
          "target": "affected-public-service"
        }
      ],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "none",
      "releaseProfiles": [
        "offline-validators",
        "preview-gru",
        "preview-sfo",
        "preview-fra"
      ],
      "repository": "TerraScale.Infrastructure",
      "source": "TerraScale.Infrastructure@3bfdb4ee0124fbcce43e7db57cf00045f374fbcb:.terrascale/deploy.json:1-17"
    },
    {
      "buildTargets": [
        "api-amd64",
        "api-arm64",
        "dashboard"
      ],
      "candidatePackage": "ci-candidates-internals",
      "dependencies": [
        {
          "reason": "shared Core/Hosting changes affect every service",
          "source": "src/Core/",
          "target": "all-internals"
        },
        {
          "reason": "public API contract changes require both SDK live suites",
          "source": "src/API/",
          "target": "dotnet-typescript-e2e"
        },
        {
          "reason": "Dashboard consumes the TypeScript SDK",
          "source": "src/Dashboard/",
          "target": "typescript"
        }
      ],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "flux-blue-green",
      "releaseProfiles": [
        "api-regression",
        "apphost-regression",
        "dashboard-release-e2e"
      ],
      "repository": "TerraScale.Internals",
      "source": "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:.terrascale/deploy.json:1-24"
    },
    {
      "buildTargets": [
        "pages"
      ],
      "candidatePackage": "ci-candidates-documentation",
      "dependencies": [
        {
          "reason": "OpenAPI snapshots require TypeScript and DotNet drift validation",
          "source": "static/openapi",
          "target": "sdk-contracts"
        }
      ],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "pages",
      "releaseProfiles": [
        "release-e2e"
      ],
      "repository": "Terrascale.Documentation",
      "source": "Terrascale.Documentation@ccca078a99f4d0702d4e55ac02d6585277ea08e9:.terrascale/deploy.json:1-12"
    },
    {
      "buildTargets": [
        "pages"
      ],
      "candidatePackage": "ci-candidates-landing",
      "dependencies": [],
      "prProfiles": [
        "static",
        "build"
      ],
      "promotionStrategy": "pages",
      "releaseProfiles": [
        "release-e2e"
      ],
      "repository": "Terrascale.Landingpage",
      "source": "Terrascale.Landingpage@0a763469d3d086e672be673b080a97dbc31dff26:.terrascale/deploy.json:1-12"
    }
  ],
  "descriptorRules": {
    "excludedSegments": [
      "bin",
      "node_modules",
      "obj",
      "vendor"
    ],
    "included": "first-party workflow, delivery, runtime, container/bake, dependency lock/toolchain, language/project/solution/build-policy, Makefile, and Pulumi descriptors",
    "pathPattern": "(^|/)(\\.terrascale/[^/]+|\\.forgejo/workflows/[^/]+|\\.github/workflows/[^/]+|Dockerfile[^/]*|[^/]*\\.service|(?:docker-)?compose[^/]*\\.(?:ya?ml)|package\\.json|[^/]*\\.csproj|[^/]*\\.fsproj|[^/]*\\.slnx?|global\\.json|Directory\\.(?:Build|Packages)\\.(?:props|targets)|Pulumi(?:\\.[^/]*)?\\.ya?ml|packages\\.lock\\.json|package-lock\\.json|npm-shrinkwrap\\.json|pnpm-lock\\.ya?ml|yarn\\.lock|bun\\.lockb?|NuGet\\.Config|\\.config/dotnet-tools\\.json|Makefile|GNUmakefile|go\\.(?:mod|sum|work|work\\.sum)|Cargo\\.(?:toml|lock)|rust-toolchain(?:\\.toml)?|docker-bake[^/]*\\.(?:hcl|json|ya?ml)|pyproject\\.toml)$",
    "scriptBoundary": "local scripts referenced by pinned delivery descriptors or workflows are enumerated; unreferenced standalone scripts are outside this inventory"
  },
  "generatedAt": "2026-07-13",
  "policyConflicts": [
    {
      "accepted": false,
      "evidence": [
        "Terrabase.Operator@b3b105be880e169d62e3cb4506846b8a11342d5c:AGENTS.md:11-12",
        "TerraScale.Deploy@cacb596cd0f6f25a40e76160554fecc14f047965:AGENTS.md:75-76",
        "TerraScale.DotNet@9d98e4e3dc3e05eb955ba06f03b05bf462cfb21b:AGENTS.md:83-84",
        "TerraScale.TypeScript@7d9b629ce5a5d41a3fa457911305b057749e3252:AGENTS.md:25-26",
        "TerraScale.Infrastructure@3bfdb4ee0124fbcce43e7db57cf00045f374fbcb:AGENTS.md:5-5",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:AGENTS.md:19-20",
        "Terrascale.Documentation@ccca078a99f4d0702d4e55ac02d6585277ea08e9:AGENTS.md:49-50",
        "Terrascale.Landingpage@0a763469d3d086e672be673b080a97dbc31dff26:AGENTS.md:105-105",
        "Terrabase.Operator@b3b105be880e169d62e3cb4506846b8a11342d5c:.forgejo/workflows/ci.yml:43-103",
        "TerraScale.Deploy@cacb596cd0f6f25a40e76160554fecc14f047965:.forgejo/workflows/ci.yml:43-103",
        "TerraScale.DotNet@9d98e4e3dc3e05eb955ba06f03b05bf462cfb21b:.forgejo/workflows/ci.yml:43-103",
        "TerraScale.TypeScript@7d9b629ce5a5d41a3fa457911305b057749e3252:.forgejo/workflows/ci.yml:43-103",
        "TerraScale.Infrastructure@3bfdb4ee0124fbcce43e7db57cf00045f374fbcb:.forgejo/workflows/ci.yml:43-103",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:.forgejo/workflows/ci.yml:43-103",
        "Terrascale.Documentation@ccca078a99f4d0702d4e55ac02d6585277ea08e9:.forgejo/workflows/ci.yml:43-103",
        "Terrascale.Landingpage@0a763469d3d086e672be673b080a97dbc31dff26:.forgejo/workflows/ci.yml:43-103"
      ],
      "id": "CI-CONFLICT-001",
      "proposedReconciliation": "Choose one feature-validation authority and update policies/workflows together; preserve affected-change validation without duplicate execution.",
      "repositories": [
        "Terrabase.Operator",
        "TerraScale.Deploy",
        "TerraScale.DotNet",
        "TerraScale.TypeScript",
        "TerraScale.Infrastructure",
        "TerraScale.Internals",
        "Terrascale.Documentation",
        "Terrascale.Landingpage"
      ],
      "status": "observed-unresolved",
      "summary": "Eight repository policies say feature PRs intentionally run no Forgejo automation, while each pinned ci.yml runs policy, static, and build jobs for pull requests targeting develop."
    },
    {
      "accepted": false,
      "evidence": [
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:docs/ci-setup.md:5-15",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:.forgejo/workflows/ci.yml:1-171"
      ],
      "id": "CI-CONFLICT-002",
      "proposedReconciliation": "Make the consolidated descriptor/workflow graph authoritative and remove or regenerate stale per-service workflow documentation after compatibility review.",
      "repositories": [
        "TerraScale.Internals"
      ],
      "status": "observed-unresolved",
      "summary": "Internals CI documentation names API, Authentication, and Dashboard image workflows that are absent from the pinned tree, which contains only consolidated ci.yml."
    },
    {
      "accepted": false,
      "evidence": [
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:41-43",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:79-86",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:.terrascale/deploy.json:12-20"
      ],
      "id": "CI-CONFLICT-003",
      "proposedReconciliation": "Add explicit Authentication tests and linux-amd64/linux-arm64 immutable build targets in the future native descriptor revision.",
      "repositories": [
        "TerraScale.Internals"
      ],
      "status": "observed-unresolved",
      "summary": "Authentication is a production runtime in AppHost and policy, but Internals deploy.json has no Authentication build target or Authentication regression profile."
    },
    {
      "accepted": false,
      "evidence": [
        "TerraBase@349cd1a11e5b252ffc193d3c3cdf059b954828fd:.terrascale/deploy.json:1-30",
        "Terrabase.Operator@b3b105be880e169d62e3cb4506846b8a11342d5c:.terrascale/deploy.json:1-24",
        "TerraScale.Infrastructure@3bfdb4ee0124fbcce43e7db57cf00045f374fbcb:.terrascale/deploy.json:1-17",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:.terrascale/deploy.json:17-23"
      ],
      "id": "CI-CONFLICT-004",
      "proposedReconciliation": "Port semantic release dependencies and immutable promotion to the native pipeline, then retire Flux/Helm/Kubernetes targets only after replacement gates pass.",
      "repositories": [
        "TerraBase",
        "Terrabase.Operator",
        "TerraScale.Infrastructure",
        "TerraScale.Internals"
      ],
      "status": "observed-unresolved",
      "summary": "Several observed promotion/build targets still encode Flux, Helm, or rendered Kubernetes GitOps while the orchestrator contract requires native GitOps and separate cleanup gates."
    }
  ],
  "productionRoles": [
    {
      "buildTargets": [
        "linux-amd64",
        "linux-arm64"
      ],
      "coverage": "present",
      "evidence": [
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:38-74",
        "TerraBase@349cd1a11e5b252ffc193d3c3cdf059b954828fd:scripts/linux/pkg/deb/assets/terrabase/debian/terrabase.service:1-27"
      ],
      "role": "TerraBase",
      "runtimeOwner": "TerraBase"
    },
    {
      "buildTargets": [
        "api-amd64",
        "api-arm64"
      ],
      "coverage": "present",
      "evidence": [
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:44-46",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:87-97"
      ],
      "role": "API",
      "runtimeOwner": "TerraScale.Internals"
    },
    {
      "buildTargets": [],
      "coverage": "missing-build-target",
      "evidence": [
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:41-43",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:79-86"
      ],
      "role": "Authentication",
      "runtimeOwner": "TerraScale.Internals"
    },
    {
      "buildTargets": [
        "dashboard"
      ],
      "coverage": "present",
      "evidence": [
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:50-55",
        "TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:98-113"
      ],
      "role": "Dashboard",
      "runtimeOwner": "TerraScale.Internals"
    }
  ],
  "proposedPolicy": {
    "rules": [
      "affected feature validation",
      "develop-to-main release qualification",
      "build once",
      "immutable candidate",
      "exact candidate promotion",
      "native GitOps after replacement gate"
    ],
    "source": "ORCHESTRATOR.md:199,961-1010,1492,1573-1583",
    "status": "proposal-not-accepted"
  },
  "repositories": [
    {
      "commit": "349cd1a11e5b252ffc193d3c3cdf059b954828fd",
      "descriptorCount": 64,
      "descriptors": [
        {
          "gitBlob": "d262aaa08d4b3ceb095a4afd6d2d70d72e8b9f83",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "1fe9d96c0c27c886f7afcfba47e0f181d4b6377f",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "e93f8284250c2ea83d0cdc344905df642fe63958",
          "mode": "100644",
          "path": "Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "6348a593d88364ba63cee88b8fc0ce68e660120c",
          "mode": "100644",
          "path": "Directory.Packages.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "d16a57dfeceb3c682b56225cbc22fda3ce9b4f41",
          "mode": "100644",
          "path": "NuGet.Config",
          "type": "dotnet-dependency-lock"
        },
        {
          "gitBlob": "c0fcf05e0af984a09d05844ccf7ba6a89c8eb79d",
          "mode": "100644",
          "path": "TerraBase.slnx",
          "type": "dotnet-solution"
        },
        {
          "gitBlob": "6cfd4f1ce8b0ffcc346c24f354c1375713c45e77",
          "mode": "100644",
          "path": "bench/Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "c3fcd34f4374ae4f4eeeb899f30d50634696088d",
          "mode": "100644",
          "path": "bench/TerraBase.BulkInsert.Benchmark/TerraBase.BulkInsert.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "7a1992094bbddbae4adf4b9da6e10b3fdf367ddb",
          "mode": "100644",
          "path": "bench/TerraBase.Indexing.Benchmark/TerraBase.Indexing.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "7e68d76c5cfdd7e13810bd515dae4fceb48e137d",
          "mode": "100644",
          "path": "bench/TerraBase.Micro.Benchmark/TerraBase.Micro.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "f200595c53bca4ed414179963c5a79e082d01702",
          "mode": "100644",
          "path": "bench/TerraBase.Regression.Benchmark/TerraBase.Regression.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "e66d4943e9193bb6298d13bec54ea82390132ad7",
          "mode": "100644",
          "path": "bench/TerraBase.RequestHandler.Benchmark/TerraBase.RequestHandler.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "3bdfbe38d7b6d2ecec130e78c7486943c615e8bd",
          "mode": "100644",
          "path": "bench/TerraBase.ServerStoreTxMerger.Benchmark/TerraBase.ServerStoreTxMerger.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "f2cbc36fda1d54bf8357127c1d747a4ab6aa3904",
          "mode": "100644",
          "path": "bench/TerraBase.SubscriptionFailover.Benchmark/TerraBase.SubscriptionFailover.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "df399d234beeb13a25e44d66aa276a0ea762b9d6",
          "mode": "100644",
          "path": "bench/TerraBase.Subscriptions.Benchmark/TerraBase.Subscriptions.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "dbfaf54b992bf7d664cfe0fe749fff75f81f0f2e",
          "mode": "100644",
          "path": "bench/TerraBase.TimeSeries.Benchmark/TerraBase.TimeSeries.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "4b6629376ad36b436336ed1291cc5d37196c8112",
          "mode": "100644",
          "path": "bench/TerraBase.Vector.Benchmark/TerraBase.Vector.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "898626a733b680dd1ca9a4e896e11bbea800e5da",
          "mode": "100644",
          "path": "bench/TerraBase.Voron.Benchmark/TerraBase.Voron.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "5797d907d5842d25776b0408236016691bcb2c22",
          "mode": "100644",
          "path": "bench/TerraBase.VxSort.Benchmark/TerraBase.VxSort.Benchmark.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "c931afb7310b9fa6c2a5c87dfd81d5b20f09278e",
          "mode": "100644",
          "path": "docker/debug/terrabase-ubuntu-debug/Dockerfile",
          "type": "container-build"
        },
        {
          "gitBlob": "6c4bdc32ef1f24e587421c2c6aded30ce58b5284",
          "mode": "100644",
          "path": "docker/terrabase-nanoserver/Dockerfile.1809",
          "type": "container-build"
        },
        {
          "gitBlob": "f5812cde2b84bf6e9e2df7b6d17dc69c503350ba",
          "mode": "100644",
          "path": "docker/terrabase-nanoserver/Dockerfile.ltsc2022",
          "type": "container-build"
        },
        {
          "gitBlob": "021d0bbfbea9b3b3e0e19dd4aac8441ff37d5568",
          "mode": "100644",
          "path": "docker/terrabase-ubuntu/Dockerfile.arm32v7",
          "type": "container-build"
        },
        {
          "gitBlob": "9e0316b48449d133720a402bbf1cc6bca6c4dd70",
          "mode": "100644",
          "path": "docker/terrabase-ubuntu/Dockerfile.arm64v8",
          "type": "container-build"
        },
        {
          "gitBlob": "92b53832add07fd08a5d2fd5d858693ea6f5d3cc",
          "mode": "100644",
          "path": "docker/terrabase-ubuntu/Dockerfile.arm64v8.tarball",
          "type": "container-build"
        },
        {
          "gitBlob": "fae1bbd0a37ee36cc21703f30557ee06b2011beb",
          "mode": "100644",
          "path": "docker/terrabase-ubuntu/Dockerfile.x64",
          "type": "container-build"
        },
        {
          "gitBlob": "9080e6b97b31b13cfb7bd910ec77cb6312d10263",
          "mode": "100644",
          "path": "docker/terrabase-ubuntu/Dockerfile.x64.tarball",
          "type": "container-build"
        },
        {
          "gitBlob": "42fb9a45b6f254865546660f481d77eaa8548bcd",
          "mode": "100644",
          "path": "global.json",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "64793cd5eef32c4a4bcdb7246f7ad676ed629b9d",
          "mode": "100644",
          "path": "scripts/linux/pkg/deb/assets/terrabase/debian/terrabase.service",
          "type": "systemd-runtime"
        },
        {
          "gitBlob": "42489717b83d22ed97bd05abde9d43dce8c60b5f",
          "mode": "100644",
          "path": "scripts/linux/terrabase.service",
          "type": "systemd-runtime"
        },
        {
          "gitBlob": "b617a462a19a509cf928e360dfa97ccb6e3c5197",
          "mode": "100644",
          "path": "src/Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "e3c1e54a480939ab525b3bd644b1608b047be014",
          "mode": "100644",
          "path": "src/Directory.Build.targets",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "6dd3779c2bd5d72311b2fea2c12bb596e44ca2d1",
          "mode": "100644",
          "path": "src/TerraBase.Client/TerraBase.Client.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "d45d818d2e700cd2da608ec2f56e3d6bac723dfd",
          "mode": "100644",
          "path": "src/TerraBase.Corax/TerraBase.Corax.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "da3a66c8779106de4e28a109ced7f061796cc596",
          "mode": "100644",
          "path": "src/TerraBase.Embedded/TerraBase.Embedded.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "57e3b5cb36c9e449cc8247f5aaf30dbef6780f7b",
          "mode": "100644",
          "path": "src/TerraBase.Server/TerraBase.Server.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "e131759df07912c9a84a310082ac34fcc653869e",
          "mode": "100644",
          "path": "src/TerraBase.Sparrow.Server/TerraBase.Sparrow.Server.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "b2c74a6e7a361d433067c28782d50e72e7af1062",
          "mode": "100644",
          "path": "src/TerraBase.Sparrow/TerraBase.Sparrow.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "717468a96a751826513c28a53cdec99ba04ff673",
          "mode": "100644",
          "path": "src/TerraBase.Studio/TerraBase.Studio.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "25e343933b32aaf39c4b96697cd3c73f660132b9",
          "mode": "100644",
          "path": "src/TerraBase.Studio/aceBuild/package-lock.json",
          "type": "node-lock"
        },
        {
          "gitBlob": "1d856e3634c5a5f0dd45c3d5955f42c4ae94400c",
          "mode": "100644",
          "path": "src/TerraBase.Studio/aceBuild/package.json",
          "type": "node-build"
        },
        {
          "gitBlob": "823fcc29be3f3473111b5debaae209aa2c3d92d1",
          "mode": "100644",
          "path": "src/TerraBase.Studio/package-lock.json",
          "type": "node-lock"
        },
        {
          "gitBlob": "846e6c77b6acc1903d843369c50c594ffd9595a7",
          "mode": "100644",
          "path": "src/TerraBase.Studio/package.json",
          "type": "node-build"
        },
        {
          "gitBlob": "2baedd69cc6302aa50e0336b3443a5c8bf4b1498",
          "mode": "100644",
          "path": "src/TerraBase.TestDriver/TerraBase.TestDriver.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "921895ec88648ab744124dbce26a13c2d3ce298c",
          "mode": "100644",
          "path": "src/TerraBase.Voron/TerraBase.Voron.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "218e72fdf51acb00eb4de64ede62bf71597f8618",
          "mode": "100644",
          "path": "test/Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "8ba8f0db97ab2c4a88b53e6643a8983bd1220d17",
          "mode": "100644",
          "path": "test/TerraBase.BenchmarkTests/TerraBase.BenchmarkTests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "f5fccb3f914a7fa74858f854619b0de901911e60",
          "mode": "100644",
          "path": "test/TerraBase.EmbeddedTests/TerraBase.EmbeddedTests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "2727cd9939910cfa6f62477167c1e0c0e9d1e7ad",
          "mode": "100644",
          "path": "test/TerraBase.EndToEndTests/TerraBase.EndToEndTests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "e98fc21a0c1a27c89003d0a4d9b6b0b59704c76a",
          "mode": "100644",
          "path": "test/TerraBase.RachisTests/TerraBase.RachisTests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "b00444d421c4f31342cc82de4dbc953d6d652ef1",
          "mode": "100644",
          "path": "test/TerraBase.SlowTests.Issues/TerraBase.SlowTests.Issues.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "adfe823765d753670d7f73ab92a31bebb13aa408",
          "mode": "100644",
          "path": "test/TerraBase.SlowTests.Tools/TerraBase.SlowTests.Tools.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "8bb4fdc09678497f60f1ffe8deb5cb30329e4432",
          "mode": "100644",
          "path": "test/TerraBase.SlowTests/TerraBase.SlowTests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "5f72585da4060b51b45358dfef82a10795376a51",
          "mode": "100644",
          "path": "test/TerraBase.StressTests/TerraBase.StressTests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "845037446aafe0a5e63c4819a26cf139d4bc2701",
          "mode": "100644",
          "path": "test/TerraBase.Tests.Infrastructure/TerraBase.Tests.Infrastructure.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "380b62277fa67929ba477a41719d672be6b559cd",
          "mode": "100644",
          "path": "test/TerraBase.Tryouts.Fast/TerraBase.Tryouts.Fast.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "1e7489a9299fdbf9d0636801aed907e4864f8ff8",
          "mode": "100644",
          "path": "test/TerraBase.Tryouts/TerraBase.Tryouts.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "7c50027e314191ec1554edba7293b088dd25689e",
          "mode": "100644",
          "path": "tools/Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "4aef2dc7ea9242c633c80bb503b5069e9fe6c86c",
          "mode": "100644",
          "path": "tools/TerraBase.Debug/TerraBase.Debug.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "b7d1a859b365de64f301c758d6088d44867d2dc3",
          "mode": "100644",
          "path": "tools/TerraBase.Migrator/TerraBase.Migrator.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "60c7e71826c38712d7aad3bade4b45ac57bedd60",
          "mode": "100644",
          "path": "tools/TerraBase.TypingsGenerator/TerraBase.TypingsGenerator.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "a1af693374f9e2f0b5f8ca2b607d19d9c77c101d",
          "mode": "100644",
          "path": "tools/TerraBase.Voron.Dictionary.Generator/TerraBase.Voron.Dictionary.Generator.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "6f2db0ac065566b83f8e06fac3e897553b8483cb",
          "mode": "100644",
          "path": "tools/TerraBase.Voron.Recovery/TerraBase.Voron.Recovery.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "d7aa0db1acd2a9bc0a3607500de5971195e7c27c",
          "mode": "100644",
          "path": "tools/TerraBase.rvn/TerraBase.rvn.csproj",
          "type": "dotnet-project"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "TerraBase",
      "referencedLocalScripts": [
        {
          "classification": "referenced-build-script-or-executable",
          "gitBlob": "43ea3442aef8a824ceaef9e379a590632e1e6cdc",
          "mode": "100755",
          "path": "build/linux/build-server-payload.sh",
          "referencedBy": ".terrascale/deploy.json"
        },
        {
          "classification": "referenced-build-script-or-executable",
          "gitBlob": "ccb2e3a58d64798879fc868272a97881c8b5957a",
          "mode": "100755",
          "path": "build/linux/build-studio.sh",
          "referencedBy": ".terrascale/deploy.json"
        }
      ],
      "referencedScriptCount": 2,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "b3b105be880e169d62e3cb4506846b8a11342d5c",
      "descriptorCount": 7,
      "descriptors": [
        {
          "gitBlob": "d262aaa08d4b3ceb095a4afd6d2d70d72e8b9f83",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "fc9cb80b4b4b81e4756384a1b9219f9ec6926acd",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "24c4343b3a6236399446120bcc9b19168a12eb69",
          "mode": "100644",
          "path": "Dockerfile",
          "type": "container-build"
        },
        {
          "gitBlob": "f855b8c298ceba83abbe74fdb335c3df4482976d",
          "mode": "100644",
          "path": "Dockerfile.prebuilt",
          "type": "container-build"
        },
        {
          "gitBlob": "11a4b07da85174cf4cbff5402c4e9b9aad9ddc27",
          "mode": "100644",
          "path": "Makefile",
          "type": "make-build"
        },
        {
          "gitBlob": "86f589adbf6b2d6e47280d7662712563de011e34",
          "mode": "100644",
          "path": "go.mod",
          "type": "go-build"
        },
        {
          "gitBlob": "77cba4082389ec32401c386b9547066c3035e714",
          "mode": "100644",
          "path": "go.sum",
          "type": "go-lock"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "Terrabase.Operator",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "cacb596cd0f6f25a40e76160554fecc14f047965",
      "descriptorCount": 10,
      "descriptors": [
        {
          "gitBlob": "205c7e7694a7c036e2420c023de0832663c634ca",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "f6d5a019dc5fe0eec6f062ef0fcbc6bcb8657543",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "8a5bcee0e5638c0e0d4fbeab5a0b45b24c684a09",
          "mode": "100644",
          "path": "Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "5323aec507baddd650a1ed44692097156bf2e3c3",
          "mode": "100644",
          "path": "Directory.Packages.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "dd4ddb00c3cdf24ff6f9ce9cc832c27393735aa5",
          "mode": "100644",
          "path": "TerraScale.Deploy.slnx",
          "type": "dotnet-solution"
        },
        {
          "gitBlob": "b3d9d5e26d751e9f905017e828cfc73ac96fe48d",
          "mode": "100644",
          "path": "global.json",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "83a7030697badd7450b34f56f530555df708a8ca",
          "mode": "100644",
          "path": "src/TerraScale.Deploy.Cli/TerraScale.Deploy.Cli.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "dbb038020a6f6456fcaef23eff25da9e5157ca2a",
          "mode": "100644",
          "path": "tests/TerraScale.Deploy.Cli.Tests/TerraScale.Deploy.Cli.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "2539bc73528d75759ac1856a30257a473dc19bb1",
          "mode": "100644",
          "path": "tests/TerraScale.Deploy.Fixture.Service.Tests/TerraScale.Deploy.Fixture.Service.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "9bb1f757dbcf4fcaee260991c16bd9f86595f8f1",
          "mode": "100644",
          "path": "tests/TerraScale.Deploy.Fixture.Service/TerraScale.Deploy.Fixture.Service.csproj",
          "type": "dotnet-project"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "TerraScale.Deploy",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "dd2b8762beb85199578ee41bdfafc199e977a0b4",
      "descriptorCount": 4,
      "descriptors": [
        {
          "gitBlob": "4baed55f2130490e09889d767359ceef3be23196",
          "mode": "100644",
          "path": "Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "7dc0b5df3d963e9b5e32325c876d424e408b0d0f",
          "mode": "100644",
          "path": "Directory.Packages.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "97f06394eb40383c2cfe68b6850438a13388db58",
          "mode": "100644",
          "path": "TerraScale.DevHost.slnx",
          "type": "dotnet-solution"
        },
        {
          "gitBlob": "a8aa6db41d75ef8f7e490fd027a1f5fb2df41537",
          "mode": "100644",
          "path": "src/TerraScale.DevHost/TerraScale.DevHost.csproj",
          "type": "dotnet-project"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "TerraScale.DevHost",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "9d98e4e3dc3e05eb955ba06f03b05bf462cfb21b",
      "descriptorCount": 10,
      "descriptors": [
        {
          "gitBlob": "d262aaa08d4b3ceb095a4afd6d2d70d72e8b9f83",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "4ff7a17ce978d3605d19f5f8370177454fe6decc",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "c856c42f5fd02f3c625835ad26458cfff43f9a37",
          "mode": "100644",
          "path": "Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "f039726fbb3b68355dc58844bd23470b333a6308",
          "mode": "100644",
          "path": "TerraScale.DotNet.slnx",
          "type": "dotnet-solution"
        },
        {
          "gitBlob": "08dc726c59260074e425e10535c9a281a90d3938",
          "mode": "100644",
          "path": "global.json",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "3f5105b9d99244e9e600d1826780448b4ee033e8",
          "mode": "100644",
          "path": "samples/TerraScale.Samples.Quickstart/TerraScale.Samples.Quickstart.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "edca77b23d2955f866b2f5fca684df809ed605b7",
          "mode": "100644",
          "path": "src/TerraScale.DotNet/TerraScale.DotNet.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "e1ead8ebc41831453f30b68536729a9aea48e2de",
          "mode": "100644",
          "path": "src/TerraScale.EntityFrameworkCore/TerraScale.EntityFrameworkCore.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "fd6a31cc20a5308e453ef95b22e5652fd3c70e2b",
          "mode": "100644",
          "path": "tests/TerraScale.DotNet.Tests/TerraScale.DotNet.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "f3a149ce887f72158344d41956fc774d48873845",
          "mode": "100644",
          "path": "tests/TerraScale.EntityFrameworkCore.Tests/TerraScale.EntityFrameworkCore.Tests.csproj",
          "type": "dotnet-project"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "TerraScale.DotNet",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "7d9b629ce5a5d41a3fa457911305b057749e3252",
      "descriptorCount": 4,
      "descriptors": [
        {
          "gitBlob": "d262aaa08d4b3ceb095a4afd6d2d70d72e8b9f83",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "5ca3cbbca6ea4294f5858523a399deed1e22f2f3",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "26074e1d15752569a15bebaf07b57c982b90a94d",
          "mode": "100644",
          "path": "package-lock.json",
          "type": "node-lock"
        },
        {
          "gitBlob": "c0f7b5d42a7bcb338a32ae4b7f14cb7c7bb6cb7a",
          "mode": "100644",
          "path": "package.json",
          "type": "node-build"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "TerraScale.TypeScript",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "3bfdb4ee0124fbcce43e7db57cf00045f374fbcb",
      "descriptorCount": 14,
      "descriptors": [
        {
          "gitBlob": "d262aaa08d4b3ceb095a4afd6d2d70d72e8b9f83",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "5dc34591feeb42cd1e4361f0494f9ba6091af2f5",
          "mode": "100644",
          "path": ".forgejo/workflows/oci-container-retention.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "03d3209c6a1b183929a1b13555f1ed61d14b6798",
          "mode": "100644",
          "path": ".forgejo/workflows/service-deployment-notification.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "7fba51eb59e7451ccd8bd58128765d9b1e7d2a80",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "f269241687cf3da936dbb4cd22601775ff473dea",
          "mode": "100644",
          "path": "Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "5b064bcb4c6cf71ce41c9a599de9038a1fc294d4",
          "mode": "100644",
          "path": "Pulumi.production-fra.yaml",
          "type": "pulumi-stack"
        },
        {
          "gitBlob": "e80fa518df89405323122f404cd04efda3e35d87",
          "mode": "100644",
          "path": "Pulumi.production-gru.yaml",
          "type": "pulumi-stack"
        },
        {
          "gitBlob": "45096d9595614e71350262bc0f17e32982a31bbc",
          "mode": "100644",
          "path": "Pulumi.production-sfo.yaml",
          "type": "pulumi-stack"
        },
        {
          "gitBlob": "aba0f693456a6f0098aede325c54137daaf4e9ba",
          "mode": "100644",
          "path": "Pulumi.yaml",
          "type": "pulumi-stack"
        },
        {
          "gitBlob": "3d1b70f6a0e7c135bf9903d1f033c211876c9321",
          "mode": "100644",
          "path": "TerraScale.Infrastructure.slnx",
          "type": "dotnet-solution"
        },
        {
          "gitBlob": "7c8e277cf07fce40a61edef6283ffc6d1ce13c89",
          "mode": "100644",
          "path": "global.json",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "d55fa84b0bf12acc7daa938914776a6040b97282",
          "mode": "100644",
          "path": "src/TerraScale.Infrastructure.Cli/TerraScale.Infrastructure.Cli.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "dc529a382426e40cbe20884e6b17a96b01543df8",
          "mode": "100644",
          "path": "src/TerraScale.Infrastructure.Verifier/TerraScale.Infrastructure.Verifier.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "64e71a69a53e4cd8b9d3be2ad59b4db437324b63",
          "mode": "100644",
          "path": "src/TerraScale.Infrastructure/TerraScale.Infrastructure.csproj",
          "type": "dotnet-project"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "TerraScale.Infrastructure",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "3643df207f9f1129c9f677148e6890d436339141",
      "descriptorCount": 35,
      "descriptors": [
        {
          "gitBlob": "d262aaa08d4b3ceb095a4afd6d2d70d72e8b9f83",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "2a2a613c66a66a2fd3c88aeca0c9155532829499",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "e074ea73fbaa47774d3e1b4889f39529cac7242e",
          "mode": "100644",
          "path": "Directory.Build.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "a3a72a1fba94a0172bb823aa7553b927ac801106",
          "mode": "100644",
          "path": "Directory.Packages.props",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "94b85f6cd12c7651423758df9cc0a80c94ed0249",
          "mode": "100644",
          "path": "NuGet.config",
          "type": "dotnet-dependency-lock"
        },
        {
          "gitBlob": "f40291f1790dd2d978c89f260992314d77904ac5",
          "mode": "100644",
          "path": "TerraScale.Internals.slnx",
          "type": "dotnet-solution"
        },
        {
          "gitBlob": "08dc726c59260074e425e10535c9a281a90d3938",
          "mode": "100644",
          "path": "global.json",
          "type": "dotnet-build-policy"
        },
        {
          "gitBlob": "2aca56f6b8aaeb6a7811e62b341c11ef3c8cc500",
          "mode": "100644",
          "path": "src/API/TerraScale.API.Tests/TerraScale.API.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "48d9a0ee77d9469a954ae2d0802b0128fd943c11",
          "mode": "100644",
          "path": "src/API/TerraScale.API/TerraScale.API.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "666ce9ebed73fd4d0256a3a380b1229f6da7c8ba",
          "mode": "100644",
          "path": "src/Auth/TerraScale.Authentication.Abstractions/TerraScale.Authentication.Abstractions.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "5109fa6b545683752a2027d470e0a7820f8ee0b3",
          "mode": "100644",
          "path": "src/Auth/TerraScale.Authentication.Tests/TerraScale.Authentication.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "0707f8dc189204b2921c0106b277032896358366",
          "mode": "100644",
          "path": "src/Auth/TerraScale.Authentication/TerraScale.Authentication.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "da512b24e977e1d39ccb35ac605de26bf5015fb1",
          "mode": "100644",
          "path": "src/CLI/TerraScale.CLI.Tests/TerraScale.CLI.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "139913a0032da6c584b77d4a64178821baa3def6",
          "mode": "100644",
          "path": "src/CLI/TerraScale.CLI/TerraScale.CLI.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "666ce9ebed73fd4d0256a3a380b1229f6da7c8ba",
          "mode": "100644",
          "path": "src/Core/TerraScale.Abstractions/TerraScale.Abstractions.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "9e0bcf3a96beafec882b20eb5a7e872198a7d970",
          "mode": "100644",
          "path": "src/Core/TerraScale.Core.Tests/TerraScale.Core.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "9ddb8617855e9a666add0ba55312139ada344111",
          "mode": "100644",
          "path": "src/Core/TerraScale.Core/TerraScale.Core.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "7c2be70787067ab5da6a5e2e6804678b7c3b1a91",
          "mode": "100644",
          "path": "src/Core/TerraScale.DataProtection/TerraScale.DataProtection.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "9b76a57011ab7bc22018de972a6b25457e499e79",
          "mode": "100644",
          "path": "src/Core/TerraScale.Email/TerraScale.Email.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "7ed997ec226c4c33b3aedf2d2161247165716ab2",
          "mode": "100644",
          "path": "src/Core/TerraScale.Endpoints.Example/TerraScale.Endpoints.Example.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "c21d1ec6ce032b4f3df50e7ce7fdd177ba75f1fc",
          "mode": "100644",
          "path": "src/Core/TerraScale.Endpoints/TerraScale.Endpoints.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "703df262c6ff49e346baaff2a9be23c7d0c3cd34",
          "mode": "100644",
          "path": "src/Core/TerraScale.Queue.Benchmarks/TerraScale.Queue.Benchmarks.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "850a13b73783eb451f32ab5ab1ad7f256cf4c6e0",
          "mode": "100644",
          "path": "src/Core/TerraScale.Queue.Tests/TerraScale.Queue.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "6168076ba7d044c42c12bf7c0e8728f8da32546e",
          "mode": "100644",
          "path": "src/Core/TerraScale.Queue/TerraScale.Queue.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "b357ab8b84be734f28055da74e164683d3378023",
          "mode": "100644",
          "path": "src/Core/TerraScale.Testing/TerraScale.Testing.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "e76b6a819777c16d4c985c4783047833b2ff2b10",
          "mode": "100644",
          "path": "src/Dashboard/TerraScale.Dashboard.Next/package-lock.json",
          "type": "node-lock"
        },
        {
          "gitBlob": "0f8fffba5f5ac7bbc9c9ea50a262ce07d7857d84",
          "mode": "100644",
          "path": "src/Dashboard/TerraScale.Dashboard.Next/package.json",
          "type": "node-build"
        },
        {
          "gitBlob": "fd94dfb1bdd5e7c2da755038dd9a4320921e8766",
          "mode": "100644",
          "path": "src/Hosting/TerraScale.AppHost.Tests/TerraScale.AppHost.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "97b4313004616fb2a879ac266db1fe930a94c312",
          "mode": "100644",
          "path": "src/Hosting/TerraScale.AppHost/TerraScale.AppHost.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "ca98e40bf0429f7a71ed420a725fa0638035ac1a",
          "mode": "100644",
          "path": "src/Hosting/TerraScale.LocalEmulators/TerraScale.LocalEmulators.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "0be78eb133de418d661f26327b13e60beb96742c",
          "mode": "100644",
          "path": "src/Hosting/TerraScale.Nats.AppHost/TerraScale.Nats.AppHost.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "c240b1d21defa9172fd13ef155c5a6caca701b53",
          "mode": "100644",
          "path": "src/Hosting/TerraScale.ServiceDefaults.Tests/TerraScale.ServiceDefaults.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "b21652706df41b19bf2f1c571ed424930674676e",
          "mode": "100644",
          "path": "src/Hosting/TerraScale.ServiceDefaults/TerraScale.ServiceDefaults.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "21edba3d2a5d0ddf82a5b20886172f97a6818fd5",
          "mode": "100644",
          "path": "src/Payments/TerraScale.Payments.Tests/TerraScale.Payments.Tests.csproj",
          "type": "dotnet-project"
        },
        {
          "gitBlob": "352c8d7f9da0ac85439eccead12f1780d1eac9c2",
          "mode": "100644",
          "path": "src/Payments/TerraScale.Payments/TerraScale.Payments.csproj",
          "type": "dotnet-project"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": true,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 13
      },
      "name": "TerraScale.Internals",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "ccca078a99f4d0702d4e55ac02d6585277ea08e9",
      "descriptorCount": 4,
      "descriptors": [
        {
          "gitBlob": "d262aaa08d4b3ceb095a4afd6d2d70d72e8b9f83",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "0eef9784bf2430089e64e11bff8a061e7756bd13",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "5f7aec61a18e36e35b73ab3b70e0f089cb0e1902",
          "mode": "100644",
          "path": "package-lock.json",
          "type": "node-lock"
        },
        {
          "gitBlob": "b9bf573c93f96be69b60fa5f24618089ffe8b3ec",
          "mode": "100644",
          "path": "package.json",
          "type": "node-build"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "Terrascale.Documentation",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    },
    {
      "commit": "0a763469d3d086e672be673b080a97dbc31dff26",
      "descriptorCount": 4,
      "descriptors": [
        {
          "gitBlob": "d262aaa08d4b3ceb095a4afd6d2d70d72e8b9f83",
          "mode": "100644",
          "path": ".forgejo/workflows/ci.yml",
          "type": "workflow"
        },
        {
          "gitBlob": "79b19f9d489b5589bb3714798a67a5c667d07cc9",
          "mode": "100644",
          "path": ".terrascale/deploy.json",
          "type": "delivery-descriptor"
        },
        {
          "gitBlob": "ce4de34d307331647dbbe5ac46677e931e61dcfe",
          "mode": "100644",
          "path": "package-lock.json",
          "type": "node-lock"
        },
        {
          "gitBlob": "1e761118b31f4b0ce9d6d97f33a5aa8d1fd2c9bb",
          "mode": "100644",
          "path": "package.json",
          "type": "node-build"
        }
      ],
      "dirtyWorktreeObservation": {
        "excludedFromPinnedTreeInventory": true,
        "observedAt": "2026-07-13",
        "observedDirty": false,
        "preservation": "not-inventoried-not-modified-not-cleaned",
        "statusEntryCount": 0
      },
      "name": "Terrascale.Landingpage",
      "referencedLocalScripts": [],
      "referencedScriptCount": 0,
      "sourceMode": "immutable-git-tree"
    }
  ],
  "schemaVersion": 1,
  "scope": "pinned sibling commit trees; dirty worktree content excluded and preserved",
  "status": "observed-inventory-not-reconciled-policy"
}


---

# FILE: docs/audits/delivery/phase0-ci-descriptor-inventory.md

# Phase 0 runtime/build descriptor and CI policy inventory

- Audit date: 2026-07-13
- Status: observed pinned-tree evidence; policy reconciliation is proposed, not accepted
- Scope: ten sibling product repositories at exact commits
- Safety: read-only Git object/status inspection; no sibling edit, cleanup, workflow, build, deployment, credential, or external mutation

## Coverage boundary

`descriptor-inventory.json` contains 156 first-party descriptors from immutable Git trees. The classifier covers workflows, `.terrascale` delivery descriptors, Dockerfiles and bake graphs, systemd/Compose runtime definitions, .NET projects/solutions/build policy/tool manifests/NuGet locks, Node manifests and lockfiles, Go modules/workspaces/checksums, Rust manifests/locks/toolchains, Python project files, Makefiles, and Pulumi project/stack files. `node_modules`, `vendor`, `bin`, and `obj` trees are explicitly excluded because they are dependency/generated closure rather than first-party descriptor ownership.

The distribution is 77 .NET projects, 20 .NET build-policy files, 11 workflows, 10 Dockerfiles, 9 delivery descriptors, 6 .NET solutions, 6 Node locks, 6 Node manifests, 4 Pulumi files, 2 NuGet/dependency locks, 2 systemd units, 1 Makefile, 1 Go module, and 1 Go checksum.

Standalone scripts are not silently included under the word “descriptor.” Instead, every local script path referenced by a pinned delivery descriptor or workflow is separately resolved to a pinned Git blob. Two such references exist, both in TerraBase: `build/linux/build-server-payload.sh` and `build/linux/build-studio.sh`. Unreferenced standalone scripts are outside this inventory. The generator and validator share the explicit classifier and script-reference rule; deleting a supported file or referenced script from the checked inventory fails validation against the pinned tree.

The audit observed TerraScale.Internals as dirty with 13 status entries and all other canonical sibling checkouts clean. Dirty contents were not inventoried, modified, staged, cleaned, or used for citations. All evidence comes from `git show`/`git ls-tree` at the recorded commit, so owner worktree changes remain preserved and cannot silently change this report.

## Runtime and release coverage

The four admitted application runtime roles are evidenced directly:

- TerraBase: three local members are wired by the pinned Internals AppHost (`TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:38-74`), and TerraBase declares amd64/arm64 server targets.
- API: AppHost resolves and starts the API behind Authentication/TerraBase/NATS readiness (`TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:44-46`, `:87-97`); the deploy descriptor declares amd64 and arm64 targets.
- Authentication: AppHost resolves and starts the service (`TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:41-43`, `:79-86`), but the deploy descriptor has no Authentication test or build target.
- Dashboard: AppHost treats Dashboard as a runtime with API/Auth health ordering (`TerraScale.Internals@3643df207f9f1129c9f677148e6890d436339141:src/Hosting/TerraScale.AppHost/AppHost.cs:50-55`, `:98-113`), and the deploy descriptor contains its build target.

Nine repositories own `.terrascale/deploy.json`; local-only TerraScale.DevHost intentionally has neither one nor a Forgejo workflow. The machine inventory preserves every dependency edge, PR/release profile name, build target, candidate package, and promotion strategy. It does not infer a build artifact from the presence of a project file.

## Observed conflicts

1. `CI-CONFLICT-001`: eight repository policies state that feature PRs intentionally run no Forgejo automation, but each pinned consolidated `.forgejo/workflows/ci.yml` executes policy, static, and build jobs for PRs targeting `develop`. This is an observed contradiction, not evidence that either side has been accepted as authoritative.
2. `CI-CONFLICT-002`: Internals CI documentation names `api-image.yml`, `authentication-image.yml`, and `dashboard-image.yml`, but none exists in the pinned tree; the only primary workflow is consolidated `ci.yml`.
3. `CI-CONFLICT-003`: Authentication is a controlled production runtime, yet Internals has API amd64/arm64 and Dashboard targets only. It also lacks a dedicated Authentication release regression profile.
4. `CI-CONFLICT-004`: TerraBase and Internals promotion strategies still name Flux, Operator still builds Helm, and Infrastructure still builds rendered Kubernetes GitOps. These are historical observed contracts awaiting native replacement gates, not designs to copy into the orchestrator.

The machine document includes exact repo/commit/path/line evidence for each conflict and verifies every range against the pinned blob. It keeps all four conflicts unresolved and all four coverage gaps open.

## Proposed reconciliation—not accepted policy

The strongest direction is affected feature validation, a protected `develop -> main` release qualification, build-once immutable candidates, and exact-candidate promotion, followed by native GitOps only after replacement evidence exists. That direction comes from the Orchestrator proposal; it does not erase contradictory sibling policy or authorize edits.

Before implementation, the delivery owner must choose one feature-validation authority, add exhaustive Authentication tests and dual-architecture build targets, update stale Internals CI documentation, preserve release dependency/health semantics, and sequence Flux/Helm/Kubernetes removal behind the corresponding native regression gates. Owner question 7 still controls the independent orchestrator bootstrap/recovery exception.

## Verification

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- delivery-inventory-generate > /tmp/descriptor-inventory.json
cmp /tmp/descriptor-inventory.json docs/audits/delivery/descriptor-inventory.json
rm -f /tmp/descriptor-inventory.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- delivery-inventory-validate
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format docs/audits/delivery/descriptor-inventory.json
git diff --check
```

Ten adversarial fixtures prove rejection of a missing repository, changed commit pin, omitted descriptor, omitted dependency lock, omitted referenced build script, invented Authentication target, accepted conflict, falsely closed gap, promoted proposal, and dirty-worktree boundary violation.


---

# FILE: docs/audits/mutation/composition-root-exclusion-proof.md

# Composition-root mutation exclusion proof

The `TerraScale.Orchestrator` executable project currently contains only
`Program.cs`, which prints a Phase 0 disabled-state message. It contains no
state transition, validator, authority, fencing, deletion, retry,
compensation, adapter result classification, credential release, or
deployment behavior.

The checked-in mutation policy excludes exactly that file as trivial
composition-root wiring. The validator fails if another C# source file is
added to the project, if the exclusion expands, or if any correctness-critical
project is marked optional. This proof must be removed or narrowed before the
composition root gains behavior.

This is an exclusion-policy proof only. It is not mutation execution evidence.


---

# FILE: docs/audits/mutation/phase1-mutation-readiness.md

# Phase 1 mutation readiness audit

- Audit date: 2026-07-13
- Status: blocked; mutation tool selection unresolved
- Execution: no mutation tool installed, restored, downloaded, or run
- Result: no mutation score, mutant count, threshold, safety closure, L0, or
  deployment-evidence claim

## Finding

The checked-in Phase 0 supply-chain audit contains `dotnet-stryker` 4.16.0 as
`PIN-DOTNET-STRYKER`, but its state is `candidate-unselected`. The audit also
states that TUnit/.NET 10 compatibility, stable mutation accounting,
safety-mutant policy, locked NuGet content hash, and internal mirroring are
unproven. `Directory.Packages.props` does not select a mutation tool. Therefore
this work does not add or invoke a package and does not manufacture a score.

The owner/toolchain steward must select the mutation engine and exact version.
That decision must also approve a locked content hash/internal mirror and the
stable denominator/report-normalization contract. Candidate metadata is not a
selection.

## Fail-closed foundation

The machine-readable policy inventories all five current production projects.
Contracts, ControlPlane, Protocol, and Scheduler are always mutation-required.
The baseline executable has one content-addressed exclusion for its exact
trivial `Program.cs`, backed by a checked-in proof. Adding or changing source in
that composition root invalidates the proof.

Exclusions can never name state transitions, validators, authority, fencing,
deletion, retry, compensation, or adapter result classification. The allowed
set is limited to generated code, immutable DTO property accessors, and proven
trivial composition-root wiring. The validator rejects project inventory
drift, unknown/duplicate schema fields, unsafe/symlink paths, stale policy or
source hashes, a weakened 85% threshold, any safety survivor, and all premature
execution or acceptance claims.

The current report is explicitly `blocked-unselected-tool`: execution fields
are null and claims are false. It expires after 30 days so unresolved readiness
must be reviewed rather than silently treated as current.

## Verification and non-claims

On 2026-07-13 the validator passed, and eleven unit tests plus eighteen named
negative fixtures passed. These checks validate policy/report structure only.
They do not validate dotnet-stryker, run mutants, establish a mutation score,
satisfy the full correctness-critical solution, mint L0/L0C or CI evidence, or
grant deployment authority.


---

# FILE: docs/audits/nats/phase0-nats-readiness.md

# Phase 0 NATS candidate and L0C readiness audit

- Audit date: 2026-07-13
- Status: candidate evidence, not a version selection or N/N-1 policy
- Local evidence: bounded credential-free x86_64 loopback smoke only
- Qualification: full L0C, ARM64, L1–L5, and production qualification are not achieved

## Candidate evidence

The official NATS server release currently identified by this audit is 2.14.3. Its release publishes Linux amd64 and arm64 archives with GitHub-supplied SHA-256 digests. Version 2.12.7 is retained only as a prior-train compatibility candidate; the audit does not assert that 2.14/2.12 is TerraScale's approved N/N-1 window. The 2.12.7 release itself directs operators to its upgrade guide for compatibility notes, which is evidence that release notes and executable mixed-version tests—not SemVer inference—must control the decision. See the official [2.14.3 release](https://github.com/nats-io/nats-server/releases/tag/v2.14.3), [2.12.7 release](https://github.com/nats-io/nats-server/releases/tag/v2.12.7), and [server installation/architecture matrix](https://docs.nats.io/running-a-nats-service/introduction/installation).

The client candidates are `NATS.Net` 3.0.0 and 2.8.2. Version 3.0.0 is a newly published major and is not promoted merely because it is current; its subject-validation/NKeys and other compatibility changes require the same contract suite. Both NuGet packages were downloaded from the official NuGet flat-container endpoints solely to calculate the recorded SHA-256/byte size and inspect their managed target-framework directories, then deleted. The packages are managed IL/AnyCPU candidates, but neither was executed on ARM64. See the official [NATS.Net 3.0.0 release](https://github.com/nats-io/nats.net/releases/tag/v3.0.0) and [NuGet version index](https://api.nuget.org/v3-flatcontainer/nats.net/index.json).

The CLI candidate is 0.4.0 with official Linux amd64 and arm64 asset digests. It is a candidate administrative/test tool, not a production runtime dependency or an accepted pin. See the official [NATS CLI 0.4.0 release](https://github.com/nats-io/natscli/releases/tag/v0.4.0) and [CLI repository](https://github.com/nats-io/natscli).

`testlab/pins/nats-candidates.json` records exact URLs, SHA-256 digests, sizes, architectures, release timestamps, and selection state. Every `selected` field is false, `nMinusOnePolicy` is null, and the candidate pair is unexecuted. The repository still needs internal mirrors/signatures and independent archive verification before any candidate becomes an approved supply-chain pin.

## Capability and security evidence

The 27-row matrix covers every capability at `ORCHESTRATOR.md:465-488`, plus mandatory mTLS, snapshot/peer recovery, and mixed-version behavior. Every row has a precise specification anchor and an official NATS source. The primary references include:

- [JWT/operator security](https://docs.nats.io/running-a-nats-service/nats_admin/security/jwt) for decentralized operators, accounts, users, signing keys, and scoped credentials.
- [TLS configuration](https://docs.nats.io/running-a-nats-service/configuration/securing_nats/tls) for client, route, and gateway transport security.
- [Gateways](https://docs.nats.io/running-a-nats-service/configuration/gateways) for supercluster topology behavior.
- [JetStream clustering administration](https://docs.nats.io/running-a-nats-service/configuration/clustering/jetstream_clustering/administration) for peer and clustered stream administration.
- [KV](https://docs.nats.io/using-nats/developer/develop_jetstream/kv) for revisions, CAS-style update, history, and watch behavior, and [Object Store](https://docs.nats.io/using-nats/developer/develop_jetstream/object) for chunked objects and object metadata/digests.
- [Monitoring](https://docs.nats.io/running-a-nats-service/configuration/monitoring), whose security warning supports the specification's loopback/management-network boundary rather than treating HTTP monitoring as an authenticated application endpoint.

Primary documentation establishes that features exist and describes intended semantics; it does not prove TerraScale's generated permissions, topology, retention, durability, or recovery behavior. Those rows remain unexecuted until exact generated contracts exist.

## Executed local evidence

The smoke binary reported `nats-server: v2.14.3` and SHA-256 `588b858328bc507ddff3b6078cda7db762f28e6da8c3fa368099a204f0f37a37`. It is the official static Linux amd64 release binary used as bounded local test infrastructure. Presence and smoke success do not approve that host path as the production artifact.

`testlab/nats/run_local_l0c_smoke.cs` starts one process with JetStream and monitoring on dynamically allocated loopback ports, uses a unique temporary file store, and has a `finally` cleanup boundary that terminates or kills and waits for the process. It proves:

- Core pub/sub.
- Core request/reply.
- Single-server file-backed JetStream stream creation, publish acknowledgement, and direct message retrieval.
- A loopback monitoring health response.
- Process cleanup and temporary-store removal.

The checked report is deterministic and reproducible byte-for-byte. It binds the result to both the observed server binary and the exact repository-relative harness path plus SHA-256; the offline validator recomputes the harness digest so a changed procedure invalidates old booleans. No credentials, VM, systemd unit, container, cloud API, persistent service, or non-loopback listener was used. The result is 3 `passed-local-x64-smoke`, 1 `partial-loopback-health-only`, 22 `not-executed`, and 1 `blocked-owner-policy-unset` capability row.

## Fail-closed gaps

Full L0C remains false. Required gaps include generated JWT operators/accounts/users and least-privilege permissions; separate control/product trust planes; imports/exports; mTLS for client/route/gateway; regional gateway mesh; R3 JetStream; durable consumer acknowledgement/redelivery/backoff; retention/deduplication/expected-sequence behavior; KV CAS/watch; Object Store; `$SYS` and advisories; snapshots/restores; peer loss/removal/replacement; configuration reload/lame-duck rolling behavior; NATS.Net and CLI behavior; and mixed server/client N/N-1 permutations.

ARM64 asset availability is metadata evidence only. No ARM64 archive was downloaded or executed, and real A1 qualification remains L4. No N/N-1 policy may be selected until the owner decision and a matrix covering read/write compatibility, store format/downgrade boundary, JetStream leadership, snapshots, client API/protocol behavior, and rollback is approved and executed.

## Reproduction

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- nats-readiness
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- nats-smoke > /tmp/nats-smoke.json
cmp /tmp/nats-smoke.json testlab/nats/local-x64-l0c-report.json
rm -f /tmp/nats-smoke.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/nats-candidates.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/nats/local-x64-l0c-report.json
git diff --check
```

The validator is offline and deterministic. Eight adversarial fixtures prove rejection of missing ARM64 metadata, non-official provenance, accidental candidate selection, accidental owner-policy selection, a false full-L0C claim, failed process cleanup, semantic drift in the specification's capability matrix, and harness/report digest drift.


---

# FILE: docs/audits/oci/phase0-residual-inventory.json

{
  "categories": {
    "block-volume-attachments": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "block-volume-backups": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "block-volumes": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "boot-volume-attachments": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "boot-volume-backups": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "boot-volumes": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "certificate-authorities-metadata": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "certificates-metadata": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "compute-instances": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "dns-records": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "dns-zones": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "iam-dynamic-groups": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "iam-policies": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "kms-vaults-metadata": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "load-balancers": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "nats-streams-consumers": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "network-load-balancers": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "object-storage-buckets": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "oke-clusters": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "oke-node-pools": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "public-ips": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "vault-secrets-metadata": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    },
    "workload-runtime-inventory": {
      "minimum_observed_count": 0,
      "scopes_attempted": 0,
      "scopes_failed": 0,
      "scopes_permission_denied": 0,
      "scopes_succeeded": 0,
      "state": "not-queried"
    }
  },
  "command_templates": [
    "oci bv backup list --compartment-id <redacted> --all",
    "oci bv boot-volume list --compartment-id <redacted> --all",
    "oci bv boot-volume-backup list --compartment-id <redacted> --all",
    "oci bv volume list --compartment-id <redacted> --all",
    "oci ce cluster list --compartment-id <redacted> --all",
    "oci ce node-pool list --compartment-id <redacted> --all",
    "oci certs-mgmt certificate list --compartment-id <redacted> --all",
    "oci certs-mgmt certificate-authority list --compartment-id <redacted> --all",
    "oci compute boot-volume-attachment list --compartment-id <redacted> --all",
    "oci compute instance list --compartment-id <redacted> --all",
    "oci compute volume-attachment list --compartment-id <redacted> --all",
    "oci dns record zone get --zone-name-or-id <redacted> --all",
    "oci dns zone list --compartment-id <redacted> --all",
    "oci iam compartment list",
    "oci iam dynamic-group list --compartment-id <redacted> --all",
    "oci iam policy list --compartment-id <redacted> --all",
    "oci iam region-subscription list",
    "oci kms management vault list --compartment-id <redacted> --all",
    "oci lb load-balancer list --compartment-id <redacted> --all",
    "oci network public-ip list --compartment-id <redacted> --all",
    "oci nlb network-load-balancer list --compartment-id <redacted> --all",
    "oci object-storage bucket list --namespace-name <redacted> --compartment-id <redacted> --all",
    "oci object-storage namespace get",
    "oci usage-api usage-summary request-summarized-usages --tenant-id <redacted> --query-type COST --granularity DAILY --is-aggregate-by-time false --time-usage-started <utc> --time-usage-ended <utc> --all",
    "oci vault secret list --compartment-id <redacted> --all"
  ],
  "cost_window": {
    "currencies": [],
    "duration_days": 7.0,
    "end_utc": "2026-07-13T12:00:00Z",
    "measured_total": null,
    "seven_day_residual_bill_established": false,
    "start_utc": "2026-07-06T12:00:00Z",
    "state": "not-queried"
  },
  "inventory_as_of_utc": "2026-07-13T12:00:00Z",
  "oke_absence_proven": false,
  "profile": "redacted",
  "safety": {
    "mutation_commands_present": false,
    "raw_identifiers_persisted": false,
    "read_only_allowlist_enforced": true,
    "secret_contents_queried": false
  },
  "schema_version": 1,
  "scope": {
    "accessible_compartment_count": null,
    "discovery": "region-subscriptions",
    "discovery_state": "query-failed",
    "region_identifiers": [],
    "subscribed_region_count": null
  }
}


---

# FILE: docs/audits/oci/phase0-residual-inventory.md

# Phase 0 OCI residual inventory audit

Status: incomplete read-only evidence; account discovery was denied before any
resource-category query could safely run.

## Result

The bounded live command was:

```bash
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- oci-inventory --live \
  --end-utc 2026-07-13T12:00:00Z \
  --output docs/audits/oci/phase0-residual-inventory.json
```

The first live API category, `iam region-subscription list`, returned an
authentication-class failure. The tool suppressed the raw OCI
response and persisted only the coarse state. Because region discovery is the
scope boundary, every resource category is correctly `not-queried`, not
`observed-empty`.

Consequences:

- OKE cluster and node-pool absence is **not proven**.
- No residual resource count is established for compute, volume/backup,
  bucket, load-balancer, public-IP, IAM, Vault/secret metadata, certificate,
  or DNS categories.
- NATS stream/consumer and runtime workload inventories are explicitly
  `not-queried`; they are not OCI control-plane inventory APIs.
- The exact intended billing window is 2026-07-06 12:00 UTC through 2026-07-13
  12:00 UTC. Billing was not queried after discovery failed, so a seven-day
  residual bill is not established and no missing amount is presented as cost.

## Required follow-up authority

Provide a locally configured OCI profile whose signing identity can perform
read-only region-subscription and accessible-compartment discovery plus the
listed metadata/cost APIs. No broader mutation authority is needed. Re-run the
same command after access is repaired. Any resulting partial denial remains a
permission gap and prevents an account-wide absence claim.

The executable plan and complete category templates are embedded in the
sanitized JSON report and can also be reviewed without API calls using:

```bash
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- oci-inventory --plan
```

The tool has no create, update, delete, start, stop, secret-bundle retrieval,
key retrieval, policy mutation, DNS/network mutation, or Pulumi command path.


---

# FILE: docs/audits/phase0-build-baseline.md

# Phase 0 build baseline

Date: 2026-07-13

The repository baseline restores and builds with the pinned .NET SDK 10.0.301, and its two contract/architecture tests pass. Self-contained single-file publishing produces both `linux-x64` and `linux-arm64` ELF apphosts.

This is not release evidence. The current workspace is NixOS, and its x64 .NET apphost embeds a Nix-store ELF interpreter path:

```text
/nix/store/8kvxvr3pmsypxiypq4g8zy13glnfr7nx-glibc-2.42-67/lib/ld-linux-x86-64.so.2
```

The cross-published ARM64 apphost requests the conventional `/lib/ld-linux-aarch64.so.1`, but it has not run on ARM64. A production or recovery artifact must be built in the pinned ordinary-Linux hermetic toolchain, must request an approved loader compatible with the selected host image, and must pass real OCI A1 execution. A successful local `dotnet publish` cannot close `REQ-O005` or authorize a deployment.

Reproduce the baseline checks without starting a VM:

```bash
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx --no-restore
dotnet test TerraScale.Orchestrator.slnx --no-build
dotnet publish src/TerraScale.Orchestrator/TerraScale.Orchestrator.csproj -c Release -r linux-x64 --no-restore
dotnet publish src/TerraScale.Orchestrator/TerraScale.Orchestrator.csproj -c Release -r linux-arm64 --no-restore
readelf -l src/TerraScale.Orchestrator/bin/Release/net10.0/linux-x64/publish/terrascale-orchestrator
readelf -l src/TerraScale.Orchestrator/bin/Release/net10.0/linux-arm64/publish/terrascale-orchestrator
```



---

# FILE: docs/audits/phase0-product-contract-source-audit.md

# Phase 0 product contract source audit

Status: evidence inventory, not a contract freeze or cleanup authorization

Scope: `REQ-O005`, `REQ-O012`, `REQ-O016`, `REQ-O017`, and `REQ-O023`

This audit records the executable product contracts that a native orchestrator descriptor must preserve. Historical Kubernetes and Flux files are behavioral evidence only. They are not import formats or resources for adoption: the infrastructure catalog still describes Kubernetes deployments and OCI repositories for the three public services (`../TerraScale.Infrastructure/infra/regions/regions.yaml:24-29`, `../TerraScale.Infrastructure/infra/regions/regions.yaml:57-62`, `../TerraScale.Infrastructure/infra/regions/regions.yaml:91-96`), while the orchestrator work package explicitly prohibits editing sibling repositories (`docs/work-packages/phase0-source-contract-audit.md:7-11`).

## Audited source snapshot

Every `../<repository>/...` citation below resolves against the exact commit in this table, not a future branch tip. `git branch --show-current`, `git rev-parse HEAD`, and `git status --porcelain` recorded all ten sibling inputs on branch `develop` with clean worktrees at audit time.

| Repository | Audited commit | Branch | Worktree |
|---|---|---|---|
| `TerraBase` | `349cd1a11e5b252ffc193d3c3cdf059b954828fd` | `develop` | clean |
| `Terrabase.Operator` | `b3b105be880e169d62e3cb4506846b8a11342d5c` | `develop` | clean |
| `TerraScale.Internals` | `3643df207f9f1129c9f677148e6890d436339141` | `develop` | clean |
| `TerraScale.DotNet` | `9d98e4e3dc3e05eb955ba06f03b05bf462cfb21b` | `develop` | clean |
| `TerraScale.TypeScript` | `7d9b629ce5a5d41a3fa457911305b057749e3252` | `develop` | clean |
| `TerraScale.Infrastructure` | `3bfdb4ee0124fbcce43e7db57cf00045f374fbcb` | `develop` | clean |
| `TerraScale.Deploy` | `cacb596cd0f6f25a40e76160554fecc14f047965` | `develop` | clean |
| `TerraScale.DevHost` | `dd2b8762beb85199578ee41bdfafc199e977a0b4` | `develop` | clean |
| `Terrascale.Documentation` | `ccca078a99f4d0702d4e55ac02d6585277ea08e9` | `develop` | clean |
| `Terrascale.Landingpage` | `0a763469d3d086e672be673b080a97dbc31dff26` | `develop` | clean |

Orchestrator-local citations resolve against the tree containing this audit. Historical sibling evidence remains reproducible with `git -C ../<repository> show <audited-commit>:<path>` even after `develop` advances.

`../CI_REFACTOR_PLAN.md` is a workspace-root loose file rather than a sibling Git object. All citations to it resolve against the 778-line copy with SHA-256 `4296b3dfd85e23fe467f780efef067fca0532f902d8b3d998a24f6976d4f71b8` captured by this audit.

## Runtime and build inventory

| Role | Source-backed runtime contract | Build and release contract | Audit disposition |
|---|---|---|---|
| TerraBase | The checked-in native unit runs as user `terrabase`, restarts on failure, uses a five-minute stop timeout, binds durable data/log/key/certificate paths, and executes `/usr/lib/terrabase/server/TerraBase.Server` (`../TerraBase/scripts/linux/pkg/deb/assets/terrabase/debian/terrabase.service:5-27`). The local AppHost models three distinct members and uses `/databases` as its HTTP health signal (`../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:59-74`, `../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:144-154`). | The deploy descriptor has separate `linux-amd64` and `linux-arm64` targets (`../TerraBase/.terrascale/deploy.json:23-26`). The payload script accepts only `linux-x64`/`linux-arm64` and publishes self-contained artifacts (`../TerraBase/build/linux/build-server-payload.sh:10-15`, `../TerraBase/build/linux/build-server-payload.sh:92-106`). | Preserve the native lifecycle, paths, three-member test shape, and an application-level readiness probe. Do not reduce readiness to systemd active state. Runtime default remains owner question 4 rather than an audit decision (`ORCHESTRATOR.md:87-93`).
| TerraScale API | AppHost starts API as a .NET executable after TerraBase, Authentication, both emulators, and NATS, and probes `/health/ready` (`../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:87-97`). Historical production runs an OCI image on port 8080 with `/health/ready` and `/health/live` probes (`../TerraScale.Infrastructure/gitops/apps/terrascale/base/api.yaml:60-71`, `../TerraScale.Infrastructure/gitops/apps/terrascale/base/api.yaml:94-110`). | Internals declares x64 and ARM64 API publish targets (`../TerraScale.Internals/.terrascale/deploy.json:17-20`). The shared release workflow builds candidate targets only on a `develop -> main` PR and later promotes the stored candidate on a `main` push (`../TerraScale.Internals/.forgejo/workflows/ci.yml:121-137`, `../TerraScale.Internals/.forgejo/workflows/ci.yml:139-171`). | Initial descriptor may use the owner-recommended container default, but must preserve the dependency/readiness edges and both target architectures. Do not silently select the final runtime while question 4 is open.
| TerraScale Authentication | Authentication is a distinct required AppHost project and resource; it waits for TerraBase and the email emulator and is a prerequisite of API and Dashboard (`../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:41-46`, `../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:75-106`). Historical production also assigns it its own OCI image and readiness/liveness probes (`../TerraScale.Infrastructure/gitops/apps/terrascale/base/authentication.yaml:60-69`, `../TerraScale.Infrastructure/gitops/apps/terrascale/base/authentication.yaml:88-104`). | A dedicated test project exists and is granted internal visibility (`../TerraScale.Internals/src/Auth/TerraScale.Authentication/TerraScale.Authentication.csproj:23-25`), but the Internals release profiles list API, AppHost, and Dashboard tests only, and its build targets list API x64/ARM64 plus Dashboard only (`../TerraScale.Internals/.terrascale/deploy.json:12-20`). | **Blocking source-contract gap:** add an Authentication regression profile and x64/ARM64 candidate targets in the owning repository before the orchestrator can claim an exhaustive build graph. The orchestrator must not fabricate a target name or artifact contract.
| Dashboard Next | AppHost treats Dashboard Next as the active optional local surface, waits for Authentication and API, and probes `/health/ready` (`../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:50-55`, `../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:98-114`). It builds and starts through VitePlus/Vinext (`../TerraScale.Internals/src/Dashboard/TerraScale.Dashboard.Next/package.json:6-12`). Historical production runs a separate OCI image on port 8080 with readiness/liveness probes (`../TerraScale.Infrastructure/gitops/apps/terrascale/base/dashboard.yaml:64-73`, `../TerraScale.Infrastructure/gitops/apps/terrascale/base/dashboard.yaml:89-105`). | Internals declares a Dashboard browser E2E release profile and one Dashboard build target (`../TerraScale.Internals/.terrascale/deploy.json:12-20`). | Preserve it as the customer Dashboard workload. It is not the orchestrator operator console; the console contract assigns that role to Grafana and forbids another bespoke operator UI (`ORCHESTRATOR.md:1065-1075`).
| TerraBase Operator | The historical descriptor builds Go managers for amd64/arm64 plus a Helm artifact (`../Terrabase.Operator/.terrascale/deploy.json:17-23`), and the infrastructure source says production TerraBase is managed through its CR and must retain a three-node floor (`../TerraScale.Infrastructure/AGENTS.md:151-160`). | Its release profiles cover Go/envtest regression and generated Helm validation (`../Terrabase.Operator/.terrascale/deploy.json:13-20`). | Treat controller rules and tests as executable behavior to port, not as a runtime admitted to the greenfield platform. Helm, CRDs, and the Go controller are historical implementation surfaces (`ORCHESTRATOR.md:182-190`).
| NATS | The local graph enables JetStream and makes API wait for NATS health (`../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:57-58`, `../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:87-97`). | The Internals descriptor has no NATS build target; its targets cover only API and Dashboard (`../TerraScale.Internals/.terrascale/deploy.json:17-23`). | Consume NATS/JetStream as a dependency/managed workload, as required by the build-versus-reuse boundary (`ORCHESTRATOR.md:166-176`). Do not invent a TerraScale NATS build pipeline.
| DevHost | DevHost is explicitly a local-only supervisor and must not gain production images or infrastructure (`../TerraScale.DevHost/AGENTS.md:1-4`). | The workspace CI plan excludes it as a releasable product (`../CI_REFACTOR_PLAN.md:41-46`). | Exclude from the production admitted-role and release catalogs. Reuse only local dependency/session behavior where separately specified.
| Documentation and Landing | Both repositories build static Pages candidates (`../Terrascale.Documentation/.terrascale/deploy.json:8-11`, `../Terrascale.Landingpage/.terrascale/deploy.json:8-11`). Landing's repository contract says it is static and has no runtime server (`../Terrascale.Landingpage/AGENTS.md:7-13`). | Each has its own release E2E and Pages promotion strategy (`../Terrascale.Documentation/.terrascale/deploy.json:8-11`, `../Terrascale.Landingpage/.terrascale/deploy.json:8-11`). | Keep both outside the orchestrator application workload catalog. Their release artifacts remain independently hosted static sites.
| Public SDKs | The .NET SDK is restricted to public HTTP and must not add internal service clients (`../TerraScale.DotNet/AGENTS.md:18-27`). The TypeScript SDK likewise consumes only public REST APIs (`../TerraScale.TypeScript/AGENTS.md:3-14`). | Their descriptors build NuGet and npm candidates, respectively (`../TerraScale.DotNet/.terrascale/deploy.json:12-17`, `../TerraScale.TypeScript/.terrascale/deploy.json:8-14`). | Preserve public compatibility tests, but do not expose operator/host APIs through either customer SDK.

## Health and observability contract

1. API readiness is stronger than process liveness. It includes product-project bootstrap and queue-replication checks tagged `ready`; `/health/ready` evaluates tagged checks while `/health/live` executes none of them (`../TerraScale.Internals/src/API/TerraScale.API/Program.cs:101-110`, `../TerraScale.Internals/src/API/TerraScale.API/Program.cs:141-149`). A native descriptor therefore needs separate readiness and liveness semantics.
2. Authentication currently registers only the shared default health check plus an otherwise empty health-check builder. Its `/health/ready` selects `ready` tags, while `/health/live` selects no checks (`../TerraScale.Internals/src/Auth/TerraScale.Authentication/Program.cs:14-25`, `../TerraScale.Internals/src/Auth/TerraScale.Authentication/Program.cs:49-56`). This means the current Authentication readiness endpoint proves HTTP responsiveness, not TerraBase/email/provider dependency readiness.
3. Dashboard's readiness and liveness routes are unconditional JSON responses (`../TerraScale.Internals/src/Dashboard/TerraScale.Dashboard.Next/app/health/ready/route.ts:1-6`, `../TerraScale.Internals/src/Dashboard/TerraScale.Dashboard.Next/app/health/live/route.ts:1-6`). AppHost dependency ordering supplies a startup gate, but the deployed readiness route does not itself validate API or Authentication.
4. Shared .NET defaults add a self liveness check, JSON logging, and OpenTelemetry metrics/traces/logs; OTLP exporters are conditional on an endpoint (`../TerraScale.Internals/src/Hosting/TerraScale.ServiceDefaults/Extensions.cs:42-69`, `../TerraScale.Internals/src/Hosting/TerraScale.ServiceDefaults/Extensions.cs:154-226`). Native workload descriptors must preserve OTLP configuration and must not infer dependency health from telemetry alone.
5. Existing Grafana is a single GRU surface backed by central and forwarded regional telemetry (`../TerraScale.Infrastructure/docs/cluster-map.md:322-329`). Current global panels derive state from Kubernetes deployment metrics and synthetic probes, for example public-service replica availability and regional API health (`../TerraScale.Infrastructure/gitops/observability/resources/production-gru/global-dashboard.yaml:237-255`, `../TerraScale.Infrastructure/gitops/observability/resources/production-gru/global-dashboard.yaml:456-456`). No exact orchestrator status projection was found in the audited product source; the target contract requires an authenticated, read-only, sanitized projection with journal position, observation age, and stale/degraded markers, and says metrics/logs alone are insufficient (`ORCHESTRATOR.md:1065-1075`). `REQ-O016` therefore requires a new typed projection/data source rather than renaming these historical metric panels.

## Release contract

The intended release contract is build once and promote exact tested artifacts. A `develop -> main` PR runs affected tests and builds in parallel; a merge to `main` promotes existing artifacts without rebuilding (`../CI_REFACTOR_PLAN.md:13-20`). The candidate record must include the Git tree, dependency snapshot, completed test inventory, platform digests, final manifest digest, and artifact hashes (`../CI_REFACTOR_PLAN.md:161-179`). Promotion must reject a mismatch, use a renewable fenced lease, publish existing artifacts, trigger reconciliation, and record resumable external-operation boundaries (`../CI_REFACTOR_PLAN.md:185-202`).

The checked-in generic workflow implements the same broad split: feature PR static/build jobs (`../TerraScale.Internals/.forgejo/workflows/ci.yml:79-103`), `develop -> main` test/build matrices (`../TerraScale.Internals/.forgejo/workflows/ci.yml:105-137`), candidate storage (`../TerraScale.Internals/.forgejo/workflows/ci.yml:139-155`), and main-push promotion from the stored manifest/bundle (`../TerraScale.Internals/.forgejo/workflows/ci.yml:157-171`). These source contracts are the input to native CI/CD. The historical `flux-*` promotion strategy strings in product descriptors remain evidence of rollout intent, not permission to retain Flux (`../TerraBase/.terrascale/deploy.json:28-29`, `../TerraScale.Internals/.terrascale/deploy.json:22-23`).

## Contradictions and gaps requiring disposition

| ID | Evidence | Required disposition |
|---|---|---|
| `AUD-SRC-001` | Authentication is a production resource and dependency (`../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:41-46`, `../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:79-106`), but Internals has no Authentication release-test profile or build target (`../TerraScale.Internals/.terrascale/deploy.json:12-20`). | Owning Internals change must define Auth test plus x64/ARM64 artifact targets before Phase 1 freezes the release graph.
| `AUD-SRC-002` | Internals policy says feature PRs intentionally trigger no automation (`../TerraScale.Internals/AGENTS.md:18-22`), while its checked-in workflow runs `pr/static` and `pr/build` for PRs into `develop` (`../TerraScale.Internals/.forgejo/workflows/ci.yml:79-103`) and the workspace CI plan requires those checks (`../CI_REFACTOR_PLAN.md:103-120`). | Owner must select and synchronize the policy text. Recommended source-of-truth direction is the current workflow plus workspace CI plan; this audit does not rewrite sibling policy.
| `AUD-SRC-003` | TerraBase's project declares runtime identifiers through `linux-x64` but omits `linux-arm64` (`../TerraBase/src/TerraBase.Server/TerraBase.Server.csproj:5-14`), while its deploy target and payload script explicitly publish `linux-arm64` (`../TerraBase/.terrascale/deploy.json:23-26`, `../TerraBase/build/linux/build-server-payload.sh:10-15`). | Qualify the ARM64 publish on the exact clean source tree and align the project declaration if the build relies on implicit RID resolution. Do not mark A1 compatibility from descriptor text alone.
| `AUD-SRC-004` | Authentication readiness selects `ready`-tagged checks but registers no dependency check in its program (`../TerraScale.Internals/src/Auth/TerraScale.Authentication/Program.cs:14-25`, `../TerraScale.Internals/src/Auth/TerraScale.Authentication/Program.cs:49-56`). Dashboard readiness is unconditional (`../TerraScale.Internals/src/Dashboard/TerraScale.Dashboard.Next/app/health/ready/route.ts:1-6`). | Define typed readiness dependencies and failure semantics before generating production descriptors. Preserve liveness as a separate process-responsiveness signal.
| `AUD-SRC-005` | The existing global Grafana panel source queries Kubernetes deployment state (`../TerraScale.Infrastructure/gitops/observability/resources/production-gru/global-dashboard.yaml:237-255`); the Grafana catalog is assembled from historical observability resources (`../TerraScale.Infrastructure/gitops/observability/resources/production-gru/kustomization.yaml:1-13`). | Implement the mandatory authenticated, sanitized, exact read-only projection and its journal-position/age/staleness contract (`ORCHESTRATOR.md:1065-1075`). Metric inference alone does not satisfy `REQ-O016`.
| `AUD-SRC-006` | The current product descriptors still encode `flux-rolling` and `flux-blue-green` strategies (`../TerraBase/.terrascale/deploy.json:28-29`, `../TerraScale.Internals/.terrascale/deploy.json:22-23`), while the target release semantics require exact digest promotion (`../CI_REFACTOR_PLAN.md:185-202`). | Preserve staged verification, rollback intent, fencing, and exact-digest proof in native state machines. Do not preserve Flux resource names, webhooks, or strategy strings as runtime compatibility contracts.
| `AUD-SRC-007` | API has substantive readiness checks (`../TerraScale.Internals/src/API/TerraScale.API/Program.cs:101-110`), Authentication does not (`../TerraScale.Internals/src/Auth/TerraScale.Authentication/Program.cs:20-25`), Dashboard is unconditional (`../TerraScale.Internals/src/Dashboard/TerraScale.Dashboard.Next/app/health/ready/route.ts:1-6`), and TerraBase local readiness is `/databases` (`../TerraScale.Internals/src/Hosting/TerraScale.AppHost/AppHost.cs:144-154`). | The canonical workload contract must model per-role probes. A universal HTTP path or a universal “process is up” rule would erase current semantics.
| `AUD-SRC-008` | The target contract requires one signed operational binary, self-contained single-file `linux-arm64`/`linux-x64` artifacts, release-blocking ARM64, per-architecture digests, and real A1 qualification (`ORCHESTRATOR.md:333-368`), but this lane is prohibited from changing solution/build files (`docs/work-packages/phase0-source-contract-audit.md:5-9`). | The repository-baseline lane must supply and qualify both single-file targets. Product artifact evidence in this audit cannot substitute for the orchestrator's own ARM64 release gate.

## Phase 1 handoff

Before contract freeze, the owner should decide or assign: Authentication artifact/test ownership (`AUD-SRC-001`), feature-PR policy precedence (`AUD-SRC-002`), and runtime default question 4 (`ORCHESTRATOR.md:87-93`). Engineering owners should close the ARM64 declaration/qualification gap, define Auth/Dashboard readiness, specify the exact Grafana projection, and ensure the baseline lane owns the orchestrator's release targets. None of these gaps authorizes edits to historical sibling resources or adoption of any deleted OKE/Flux state (`ORCHESTRATOR.md:71-81`, `ORCHESTRATOR.md:182-199`).


---

# FILE: docs/audits/provider/phase0-provider-qualification-schema.md

# Phase 0 provider/TCO and OCI region qualification schema

- Audit date: 2026-07-13
- Status: blank contract and official source map only
- Cloud/API activity: none
- Prices, eligible regions, provider winner, provider selection, and production qualification: none

## Outcome

The lane creates three machine-readable inputs:

- [`provider-qualification-schema.json`](../../../testlab/pins/provider-qualification-schema.json) is a custom field-contract that enumerates the required provider, TCO, benchmark, and OCI-region fields. It is not presented as JSON Schema and does not claim JSON Schema semantics.
- [`provider-qualification-blank.json`](../../../testlab/pins/provider-qualification-blank.json) is a fail-closed four-provider dataset. All cost, benchmark, and normalized results are `null`; all four providers are unqualified; OCI has zero eligible rows; both winner and selection are `null`.
- [`provider-source-catalog.json`](../../../testlab/pins/provider-source-catalog.json) maps evidence topics to official primary documentation without treating a public catalog as account, capacity, performance, price, or regional qualification evidence.

This preserves the specification's distinction between a listed cloud region and a TerraScale-qualified region. The provider comparison must model the exact topology and all named cost components ([ORCHESTRATOR.md, lines 248-250](../../../ORCHESTRATOR.md#L248-L250)); the OCI matrix needs complete per-region evidence and at least 20 qualifying rows ([ORCHESTRATOR.md, line 252](../../../ORCHESTRATOR.md#L252)); price cannot win without the common storage/TerraBase benchmark and normalized BRL results ([ORCHESTRATOR.md, line 254](../../../ORCHESTRATOR.md#L254)).

## Required contract coverage

The schema lists every named cost input separately: compute; boot, data, NATS, and observability volumes; provisioned IOPS and throughput; snapshots/backups; inter-region and internet egress; public IPv4; NAT/gateways; load balancers; object requests/storage; KMS/secrets; logs/metrics; artifact storage; support; taxes; FX sensitivity; discounts/commitments; idle floor; burst cost; and engineer/operational cost.

A populated cost component must include amount, currency, unit, quantity, source reference, effective date, and explicit tax/discount treatment. The common benchmark contract requires immutable workload/script/raw-result digests; p50/p95/p99 read, write, and fsync latency; IOPS; throughput; noisy-neighbor results; online expansion; attach/detach/replacement time; regional capacity failure; recovery under compact load; and assumptions. Normalized results reserve BRL/day, BRL per sustained database transaction, BRL per sustained IOPS, and sensitivity bounds.

The OCI row schema includes public region/realm, subscription state, home/paired geography, availability/fault domains, A1 and approved ARM fallback/capacity evidence, images, full Block Volume size/VPU/IOPS/throughput/online-resize/benchmark evidence, required regional services, limits/quota request, inter-region path/latency/egress price, residency constraints, normalized BRL floor, qualification timestamp, evidence references, status, and reasons. The blank template exposes the complete shape while contributing zero eligible rows.

## Official primary-source catalog

The catalog is a map of where later evidence collection starts. It is not proof that a service is usable in a region, available to an account, within quota, currently in capacity, priced as assumed, or acceptable for TerraScale.

| Provider | Region/account discovery | ARM compute | Block storage | Pricing and billing evidence |
|---|---|---|---|---|
| OCI | [regions/realms/ADs](https://docs.oracle.com/en-us/iaas/Content/General/Concepts/regions.htm), [tenancy subscriptions](https://docs.oracle.com/en-us/iaas/Content/Identity/Tasks/managingregions.htm) | [official compute shapes](https://docs.oracle.com/en-us/iaas/Content/Compute/References/computeshapes.htm) | [VPU/IOPS/throughput](https://docs.oracle.com/en-us/iaas/Content/Block/Concepts/blockvolumeperformance.htm), [online resize](https://docs.oracle.com/en-us/iaas/Content/Block/Tasks/update-online-resize-block-boot-volume.htm) | [list-price/cost-estimator access](https://docs.oracle.com/en-us/iaas/Content/Billing/Tasks/signingup_topic-Estimating_Costs.htm), [Usage API/cost analysis](https://docs.oracle.com/en-us/iaas/Content/Billing/Concepts/costanalysisoverview.htm) |
| AWS | [regions/AZs and opt-in status](https://docs.aws.amazon.com/global-infrastructure/latest/regions/aws-regions.html) | [EC2 processor families](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-types.html) | [EBS Elastic Volumes](https://docs.aws.amazon.com/ebs/latest/userguide/ebs-modify-volume.html) | [Price List APIs](https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/price-changes.html), [Cost and Usage Reports](https://docs.aws.amazon.com/cur/latest/userguide/what-is-cur.html) |
| Google Cloud | [Compute regions/zones](https://cloud.google.com/compute/docs/regions-zones), [product locations](https://cloud.google.com/about/locations) | [general-purpose machine families](https://cloud.google.com/compute/docs/general-purpose-machines) | [Persistent Disk resize](https://cloud.google.com/compute/docs/disks/resize-persistent-disk) | [disk/image pricing](https://cloud.google.com/compute/disks-image-pricing), [Cloud Billing export](https://cloud.google.com/billing/docs/how-to/export-data-bigquery) |
| Azure | [official region list](https://learn.microsoft.com/en-us/azure/reliability/regions-list), [products by region](https://azure.microsoft.com/en-us/explore/global-infrastructure/products-by-region/) | [Arm-based Dpsv5 series](https://learn.microsoft.com/en-us/azure/virtual-machines/sizes/general-purpose/dpsv5-series) | [Linux managed-disk expansion](https://learn.microsoft.com/en-us/azure/virtual-machines/linux/expand-disks) | [Retail Prices API](https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices), [Cost Management exports](https://learn.microsoft.com/en-us/azure/cost-management-billing/costs/tutorial-export-acm-data) |

The official OCI compute-shape documentation itself warns that a new region can precede host capacity and directs users to account-visible shape discovery. That reinforces why this package records no A1 regional availability. Likewise, public price catalogs cannot establish negotiated discounts, tax, FX, measured usage, or the seven-day post-deletion residual bill.

## Fail-closed validator

The [`provider-qualification` C# command](../../../tools/TerraScale.Orchestrator.Tooling/TranslatedCommands.cs) performs no network or cloud operation. Structural validation checks the checked-in schema, blank evidence, source catalog, qualification state, and absence of any production claim.

The unit suite generates—but never writes—a clearly marked `synthetic-fixture-only` dataset with all four provider cost/benchmark/normalized result sets and 20 fully populated unique OCI rows. That positive fixture proves the structural contract can represent complete results and exercise winner/count rules. Its invented digests, amounts, regions, and outcomes are test data, are accepted only when the test explicitly disables the checked-in-blank policy, and cannot pass the CLI's normal committed-dataset validation.

The [adversarial fixtures](../../../tools/phase0/provider-qualification/fixtures/negative-cases.json) exercise stale/future/non-official sources, missing source coverage, partial OCI rows, erased schema fields, false eligibility counts/claims, winner/selection without results, false provider qualification, partial results, ambiguous currency, missing providers, a qualified row with unknown evidence, and a synthetic secret-named field.

Run:

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/provider-qualification-schema.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/provider-qualification-blank.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/provider-source-catalog.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- provider-qualification
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
```

Green validation proves only that the blank contract remains honest and structurally complete. It is not a provider comparison, region qualification, storage benchmark, cost approval, or permission to call cloud APIs.


---

# FILE: docs/audits/registry/README.md

# Phase 0 semantic registry coverage audit

The draft registry now binds every seeded entry to a normative source range and digest, a canonical owner, and explicit missing evidence targets. It is still not a frozen Phase 1 traceability contract: the proposed state-machine/error/security/gate families require steward review, and all acceptance evidence remains missing.

The audit found 43 registered IDs: all 23 owner requirements, all 18 numbered invariants, one error, and one security rule. All 43 now carry source-anchored semantic metadata and canonical lane names; zero are verified or contract-complete, and every evidence state remains `missing`. The separate discovery inventory still contains 43 unregistered proposals whose names, kinds, relationships, owners, and per-assertion gate decomposition require steward and owner review before registration.

The machine-readable audit proposes 43 missing IDs grouped as:

- 8 explicit arrow-defined state machines;
- 10 externally meaningful rejects/holds;
- 8 independently testable security rules;
- 17 gate families covering the hard pre-deployment gate, evidence floors, layer authority, performance/correctness, Phase 0–9 exits, and the three production acceptance sections.

The gate-family IDs are deliberately umbrella findings for steward review. Before contract freeze, each bullet or threshold that can fail independently should receive its own stable evidence target beneath the applicable family. Treating an entire production section as one test would repeat the semantic under-specification this audit identifies.

## Deterministic verification

Run from the repository root:

```bash
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- registry-audit \
  --negative-fixtures docs/audits/registry/fixtures/negative-cases.json
```

The checker is part of the dependency-free C# tooling executable. It validates the checked-in registry audit, seeded entry and finding counts, and fail-closed evidence state. The translated C# suite covers drift and false-completion cases.

## Steward actions

1. Preserve the schema-v2 normative statement/source digest and evidence-target checks as entries evolve.
2. Resolve the independent v2 review findings before registering any proposed SM/ERR/SEC/gate ID; in particular, do not add the contradictory `REQ-GATE-*`/`acceptance-gate` pairs unchanged.
3. Review co-review metadata for cross-lane entries, especially the former `control-plane`, `cloud-storage`, and `delivery-security` aliases.
4. Record decisions 1A–10A as accepted; keep deployment qualification incomplete until measured cost, storage, RPO, and RTO targets pass without weakening reliability floors.
5. Make the checker (or its steward-integrated successor) a Phase 0 CI input before generating code/test/evidence traceability.


---

# FILE: docs/audits/registry/fixtures/negative-cases.json

{
  "cases": [
    {
      "name": "duplicate-proposed-id",
      "mutation": {"op": "set", "path": "/findings/44/proposedId", "value": "SM-SELF-UPGRADE"},
      "expected": "proposed IDs are not unique"
    },
    {
      "name": "noncanonical-owner",
      "mutation": {"op": "set", "path": "/findings/41/owner", "value": "control-plane"},
      "expected": "uses noncanonical owner"
    },
    {
      "name": "invalid-layer",
      "mutation": {"op": "set", "path": "/findings/41/acceptanceLayers/0", "value": "unit"},
      "expected": "missing/invalid acceptance layers"
    },
    {
      "name": "bad-citation",
      "mutation": {"op": "set", "path": "/findings/41/citation/contains", "value": "text absent from the cited lines"},
      "expected": "citation text does not match"
    },
    {
      "name": "duplicate-finding",
      "mutation": {"op": "append-copy", "path": "/findings/0"},
      "expected": "duplicate finding IDs"
    },
    {
      "name": "registered-id-omission",
      "target": "registry",
      "mutation": {"op": "remove-entry", "id": "REQ-O001"},
      "expected": "registry is missing required seeded ID REQ-O001"
    },
    {
      "name": "block-entry-missing-owner",
      "target": "registry",
      "mutation": {"op": "remove-block-owner", "id": "REQ-O001"},
      "expected": "registry entry REQ-O001 at line 7 is missing owner"
    },
    {
      "name": "block-entry-cannot-be-skipped",
      "target": "registry",
      "mutation": {"op": "misindent-block-entry", "id": "REQ-O001"},
      "expected": "skipped/misindented '- id:' entry at line 7"
    },
    {
      "name": "semantic-source-digest-drift",
      "target": "registry",
      "mutation": {"op": "set-block-field", "id": "REQ-O001", "field": "normativeSha256", "value": "0000000000000000000000000000000000000000000000000000000000000000"},
      "expected": "semantic source digest mismatch"
    },
    {
      "name": "semantic-evidence-state-default",
      "target": "registry",
      "mutation": {"op": "set-block-field", "id": "REQ-O001", "field": "evidenceState", "value": "verified"},
      "expected": "semantic statement/evidence targets incomplete"
    },
    {
      "name": "root-schema-version-drift",
      "target": "registry",
      "mutation": {"op": "set-root-field", "field": "schemaVersion", "value": "999"},
      "expected": "registry root schemaVersion/source mismatch"
    },
    {
      "name": "audit-registry-owner-parity",
      "mutation": {"op": "set", "path": "/findings/0/owner", "value": "Cloud"},
      "expected": "semantic owner/layer parity mismatch"
    },
    {
      "name": "invalid-co-reviewer",
      "target": "registry",
      "mutation": {"op": "set-block-field", "id": "REQ-O001", "field": "coReviewers", "value": "[NOT-A-LANE]"},
      "expected": "invalid/duplicate co-reviewers"
    },
    {
      "name": "vacuous-normative-statement",
      "target": "registry",
      "mutation": {"op": "set-block-field", "id": "REQ-O001", "field": "normativeStatement", "value": "\"x\""},
      "expected": "semantic statement/evidence targets incomplete"
    },
    {
      "name": "vacuous-evidence-target",
      "target": "registry",
      "mutation": {"op": "set-block-list-item", "id": "REQ-O001", "field": "evidenceTargets", "index": 0, "value": "x"},
      "expected": "semantic evidence target does not identify layer L0"
    },
    {
      "name": "audit-registry-kind-parity",
      "mutation": {"op": "set", "path": "/findings/0/kind", "value": "security"},
      "expected": "semantic audit kind mismatch"
    },
    {
      "name": "missing-explicit-co-reviewers",
      "target": "registry",
      "mutation": {"op": "remove-block-field", "id": "REQ-O001", "field": "coReviewers"},
      "expected": "missing explicit coReviewers"
    },
    {
      "name": "unknown-root-field",
      "target": "registry",
      "mutation": {"op": "add-root-field", "field": "unknownContract", "value": "true"},
      "expected": "registry root contains unknown key unknownContract"
    },
    {
      "name": "duplicate-root-status",
      "target": "registry",
      "mutation": {"op": "duplicate-root-field", "field": "status", "value": "frozen"},
      "expected": "registry root contains duplicate key status"
    }
  ]
}


---

# FILE: docs/audits/registry/owner-mapping.json

{
  "schemaVersion": 1,
  "source": "ORCHESTRATOR.md:1424-1438",
  "aliases": {
    "integration": "Integration/contract steward",
    "core": "Core",
    "control-plane": "Core",
    "messaging-security": "Messaging/security",
    "runtime": "Runtime",
    "cloud": "Cloud",
    "cloud-storage": "Storage",
    "storage": "Storage",
    "terrabase": "TerraBase",
    "delivery": "Delivery",
    "delivery-security": "Messaging/security",
    "operations": "Operations",
    "verification": "Verification"
  }
}


---

# FILE: docs/audits/registry/registry-audit.json

{
  "schemaVersion": 1,
  "source": "ORCHESTRATOR.md",
  "registry": "requirements/registry.yaml",
  "summary": {
    "registryEntries": 43,
    "idOnly": 0,
    "semantic": 43,
    "missing": 43,
    "semanticallyComplete": 0,
    "registryOwnerAliases": 0,
    "unmappedRegistryOwners": 0,
    "decision": "not-ready-for-contract-freeze"
  },
  "canonicalOwners": ["Integration/contract steward", "Core", "Messaging/security", "Runtime", "Cloud", "Storage", "TerraBase", "Delivery", "Operations", "Cross-repository cleanup", "Verification"],
  "canonicalAcceptanceLayers": ["review", "L0", "L0C", "L1S", "L2S", "L3S", "L1R", "L4", "L5"],
  "classification": {
    "findings": "explicit specification obligations with exact source citations",
    "stewardRecommendations": "inferred registry-design changes; not new product requirements"
  },
  "findings": [
    {"id":"AUD-ID-001","status":"semantic","registryId":"REQ-O001","kind":"requirement","owner":"Integration/contract steward","acceptanceLayers":["L0","L3S","L4","L5"],"citation":{"start":113,"end":113,"contains":"production/final platform rather than a toy"}},
    {"id":"AUD-ID-002","status":"semantic","registryId":"REQ-O002","kind":"requirement","owner":"Core","acceptanceLayers":["L0","L4","L5"],"citation":{"start":114,"end":114,"contains":"Reduce the historical"}},
    {"id":"AUD-ID-003","status":"semantic","registryId":"REQ-O003","kind":"requirement","owner":"Core","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":115,"end":115,"contains":"Avoid Kubernetes memory overhead"}},
    {"id":"AUD-ID-004","status":"semantic","registryId":"REQ-O004","kind":"requirement","owner":"Integration/contract steward","acceptanceLayers":["review","L0","L3S"],"citation":{"start":116,"end":116,"contains":"Custom tailor-made orchestrator"}},
    {"id":"AUD-ID-005","status":"semantic","registryId":"REQ-O005","kind":"requirement","owner":"Runtime","acceptanceLayers":["L0","L1R","L4"],"citation":{"start":117,"end":117,"contains":"single binary under systemd"}},
    {"id":"AUD-ID-006","status":"semantic","registryId":"REQ-O006","kind":"requirement","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S"],"citation":{"start":118,"end":118,"contains":"full communication platform"}},
    {"id":"AUD-ID-007","status":"semantic","registryId":"REQ-O007","kind":"requirement","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S","L4"],"citation":{"start":119,"end":119,"contains":"Dedicated orchestrator NATS"}},
    {"id":"AUD-ID-008","status":"semantic","registryId":"REQ-O008","kind":"requirement","owner":"Operations","acceptanceLayers":["L0","L3S","L5"],"citation":{"start":120,"end":120,"contains":"At least GRU/SFO/FRA"}},
    {"id":"AUD-ID-009","status":"semantic","registryId":"REQ-O009","kind":"requirement","owner":"Verification","acceptanceLayers":["L0","L3S","L4","L5"],"citation":{"start":121,"end":121,"contains":"any one node fails"}},
    {"id":"AUD-ID-010","status":"semantic","registryId":"REQ-O010","kind":"requirement","owner":"Cloud","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":122,"end":122,"contains":"Pulumi bootstraps"}},
    {"id":"AUD-ID-011","status":"semantic","registryId":"REQ-O011","kind":"requirement","owner":"Storage","acceptanceLayers":["L0","L3S","L4","L5"],"citation":{"start":123,"end":123,"contains":"Automatic node and TerraBase storage scaling"}},
    {"id":"AUD-ID-012","status":"semantic","registryId":"REQ-O012","kind":"requirement","owner":"Runtime","acceptanceLayers":["L0","L1R","L3S","L4"],"citation":{"start":124,"end":124,"contains":"containers and native systemd"}},
    {"id":"AUD-ID-013","status":"semantic","registryId":"REQ-O013","kind":"requirement","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S","L4"],"citation":{"start":125,"end":125,"contains":"mTLS support"}},
    {"id":"AUD-ID-014","status":"semantic","registryId":"REQ-O014","kind":"requirement","owner":"Delivery","acceptanceLayers":["L0","L3S"],"citation":{"start":126,"end":126,"contains":"Built-in native GitOps"}},
    {"id":"AUD-ID-015","status":"semantic","registryId":"REQ-O015","kind":"requirement","owner":"Delivery","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":127,"end":127,"contains":"Built-in vault, CI and CD"}},
    {"id":"AUD-ID-016","status":"semantic","registryId":"REQ-O016","kind":"requirement","owner":"Operations","acceptanceLayers":["L0","L3S"],"citation":{"start":128,"end":128,"contains":"without rebuilding Grafana"}},
    {"id":"AUD-ID-017","status":"semantic","registryId":"REQ-O017","kind":"requirement","owner":"Verification","acceptanceLayers":["L0","L0C"],"citation":{"start":129,"end":129,"contains":"before the first deployment test"}},
    {"id":"AUD-ID-018","status":"semantic","registryId":"REQ-O018","kind":"requirement","owner":"Verification","acceptanceLayers":["L0","L1S","L2S","L3S"],"citation":{"start":130,"end":130,"contains":"reproducible test environment"}},
    {"id":"AUD-ID-019","status":"semantic","registryId":"REQ-O019","kind":"requirement","owner":"Cloud","acceptanceLayers":["L0","L4","L5"],"citation":{"start":131,"end":131,"contains":"at least 20 regions"}},
    {"id":"AUD-ID-020","status":"semantic","registryId":"REQ-O020","kind":"requirement","owner":"Storage","acceptanceLayers":["L0","L1R","L3S","L4","L5"],"citation":{"start":132,"end":132,"contains":"performance is a primary constraint"}},
    {"id":"AUD-ID-021","status":"semantic","registryId":"REQ-O021","kind":"requirement","owner":"Verification","acceptanceLayers":["L3S"],"citation":{"start":133,"end":133,"contains":"complete GRU/FRA/SFO tests"}},
    {"id":"AUD-ID-022","status":"semantic","registryId":"REQ-O022","kind":"requirement","owner":"Integration/contract steward","acceptanceLayers":["review","L0","L3S"],"citation":{"start":134,"end":134,"contains":"parallel with multiple sub-agents"}},
    {"id":"AUD-ID-023","status":"semantic","registryId":"REQ-O023","kind":"requirement","owner":"Cloud","acceptanceLayers":["L0","L3S","L4","L5"],"citation":{"start":135,"end":135,"contains":"full greenfield"}},
    {"id":"AUD-ID-024","status":"semantic","registryId":"INV-001","kind":"invariant","owner":"Integration/contract steward","acceptanceLayers":["L0","L3S","L5"],"citation":{"start":143,"end":143,"contains":"active cells"}},
    {"id":"AUD-ID-025","status":"semantic","registryId":"INV-002","kind":"invariant","owner":"Core","acceptanceLayers":["L0","L3S"],"citation":{"start":144,"end":144,"contains":"last accepted `CellSpec`"}},
    {"id":"AUD-ID-026","status":"semantic","registryId":"INV-003","kind":"invariant","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S"],"citation":{"start":145,"end":145,"contains":"WAN-spanning Raft quorum"}},
    {"id":"AUD-ID-027","status":"semantic","registryId":"INV-004","kind":"invariant","owner":"Core","acceptanceLayers":["L0","L3S"],"citation":{"start":146,"end":146,"contains":"Exactly one fenced writer"}},
    {"id":"AUD-ID-028","status":"semantic","registryId":"INV-005","kind":"invariant","owner":"Core","acceptanceLayers":["L0","L3S"],"citation":{"start":147,"end":147,"contains":"idempotent, generation-bound"}},
    {"id":"AUD-ID-029","status":"semantic","registryId":"INV-006","kind":"invariant","owner":"Verification","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":148,"end":148,"contains":"Stale leaders and stale agents"}},
    {"id":"AUD-ID-030","status":"semantic","registryId":"INV-007","kind":"invariant","owner":"TerraBase","acceptanceLayers":["L0","L3S","L4","L5"],"citation":{"start":149,"end":149,"contains":"at least three permanent members"}},
    {"id":"AUD-ID-031","status":"semantic","registryId":"INV-008","kind":"invariant","owner":"TerraBase","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":150,"end":150,"contains":"never removes permanent TerraBase members"}},
    {"id":"AUD-ID-032","status":"semantic","registryId":"INV-009","kind":"invariant","owner":"Storage","acceptanceLayers":["L0","L1R","L4"],"citation":{"start":151,"end":151,"contains":"Storage is expand-only"}},
    {"id":"AUD-ID-033","status":"semantic","registryId":"INV-010","kind":"invariant","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S","L4"],"citation":{"start":152,"end":152,"contains":"Secrets and private keys never appear"}},
    {"id":"AUD-ID-034","status":"semantic","registryId":"INV-011","kind":"invariant","owner":"Delivery","acceptanceLayers":["L0","L3S"],"citation":{"start":153,"end":153,"contains":"Builds happen once"}},
    {"id":"AUD-ID-035","status":"semantic","registryId":"INV-012","kind":"invariant","owner":"Operations","acceptanceLayers":["L0","L3S"],"citation":{"start":154,"end":154,"contains":"Observability failure never blocks"}},
    {"id":"AUD-ID-036","status":"semantic","registryId":"INV-013","kind":"invariant","owner":"Integration/contract steward","acceptanceLayers":["L0","L3S"],"citation":{"start":155,"end":155,"contains":"product placement domain"}},
    {"id":"AUD-ID-037","status":"semantic","registryId":"INV-014","kind":"invariant","owner":"Cloud","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":156,"end":156,"contains":"After the signed handoff"}},
    {"id":"AUD-ID-038","status":"semantic","registryId":"INV-015","kind":"invariant","owner":"Integration/contract steward","acceptanceLayers":["review","L0"],"citation":{"start":157,"end":157,"contains":"derive from the same versioned C# contracts"}},
    {"id":"AUD-ID-039","status":"semantic","registryId":"INV-016","kind":"invariant","owner":"Verification","acceptanceLayers":["L0","L3S","L4","L5"],"citation":{"start":158,"end":158,"contains":"single-node-failure tolerant"}},
    {"id":"AUD-ID-040","status":"semantic","registryId":"INV-017","kind":"invariant","owner":"Runtime","acceptanceLayers":["L0","L1R","L3S"],"citation":{"start":159,"end":159,"contains":"Only allowlisted TerraScale"}},
    {"id":"AUD-ID-041","status":"semantic","registryId":"INV-018","kind":"invariant","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S","L4"],"citation":{"start":160,"end":160,"contains":"decision 8A permits benchmarked host sharing"}},
    {"id":"AUD-ID-042","status":"semantic","registryId":"ERR-PHASE0-NOTREADY","kind":"error","owner":"Integration/contract steward","acceptanceLayers":["L0"],"citation":{"start":3,"end":4,"contains":"measured cost/storage/RPO/RTO targets remain deployment-qualification gates"}},
    {"id":"AUD-ID-043","status":"semantic","registryId":"SEC-NO-SECRET-OUTPUT","kind":"security","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S","L4"],"citation":{"start":152,"end":152,"contains":"Secrets and private keys never appear"}},

    {"id":"AUD-SM-001","status":"missing","proposedId":"SM-SELF-UPGRADE","kind":"state-machine","owner":"Runtime","acceptanceLayers":["L0","L1S","L1R","L3S","L4"],"citation":{"start":374,"end":382,"contains":"UpgradePlanned -> ArtifactVerified"}},
    {"id":"AUD-SM-002","status":"missing","proposedId":"SM-NATS-MEMBER-REPLACEMENT","kind":"state-machine","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L2S","L3S","L4"],"citation":{"start":521,"end":533,"contains":"FailureObserved -> QuorumAndPeerSetRead"}},
    {"id":"AUD-SM-003","status":"missing","proposedId":"SM-PULUMI-OWNERSHIP-HANDOFF","kind":"state-machine","owner":"Cloud","acceptanceLayers":["L0","L3S","L4","L5"],"citation":{"start":650,"end":663,"contains":"orchestrator records signed HandoffReceipt"}},
    {"id":"AUD-SM-004","status":"missing","proposedId":"SM-NODE-SCALE-OUT","kind":"state-machine","owner":"Cloud","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":706,"end":725,"contains":"DemandObserved"}},
    {"id":"AUD-SM-005","status":"missing","proposedId":"SM-NODE-SCALE-IN","kind":"state-machine","owner":"Cloud","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":727,"end":745,"contains":"CandidateSelected"}},
    {"id":"AUD-SM-006","status":"missing","proposedId":"SM-VOLUME-CREATE-ATTACH","kind":"state-machine","owner":"Storage","acceptanceLayers":["L0","L1R","L3S","L4"],"citation":{"start":775,"end":783,"contains":"ClaimAccepted -> CapacityAndBudgetChecked"}},
    {"id":"AUD-SM-007","status":"missing","proposedId":"SM-VOLUME-EXPANSION","kind":"state-machine","owner":"Storage","acceptanceLayers":["L0","L1R","L3S","L4","L5"],"citation":{"start":797,"end":815,"contains":"ThresholdSustained"}},
    {"id":"AUD-SM-008","status":"missing","proposedId":"SM-GITOPS-RECONCILIATION","kind":"state-machine","owner":"Delivery","acceptanceLayers":["L0","L3S","L5"],"citation":{"start":943,"end":956,"contains":"Source revision observed"}},

    {"id":"AUD-SEC-001","status":"missing","proposedId":"SEC-MTLS-TRUST-BOUNDARIES","kind":"security","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S","L4"],"citation":{"start":42,"end":51,"contains":"mTLS is required"}},
    {"id":"AUD-SEC-002","status":"missing","proposedId":"SEC-NATS-DUAL-AUTHORIZATION","kind":"security","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S","L4"],"citation":{"start":50,"end":50,"contains":"Neither layer replaces the other"}},
    {"id":"AUD-SEC-003","status":"missing","proposedId":"SEC-CLOSED-ROLE-ADMISSION","kind":"security","owner":"Runtime","acceptanceLayers":["L0","L1S","L3S"],"citation":{"start":444,"end":444,"contains":"cannot supply an arbitrary executable"}},
    {"id":"AUD-SEC-004","status":"missing","proposedId":"SEC-NATS-MONITORING-ISOLATION","kind":"security","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S"],"citation":{"start":512,"end":513,"contains":"monitoring port acceptable"}},
    {"id":"AUD-SEC-005","status":"missing","proposedId":"SEC-PROVIDER-MUTATION-AUTHORITY","kind":"security","owner":"Cloud","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":642,"end":646,"contains":"Tags are inventory and reconciliation evidence, never authorization"}},
    {"id":"AUD-SEC-006","status":"missing","proposedId":"SEC-SURVIVAL-BUNDLE-NO-PLAINTEXT","kind":"security","owner":"Messaging/security","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":683,"end":683,"contains":"never contains plaintext secrets or offline root keys"}},
    {"id":"AUD-SEC-007","status":"missing","proposedId":"SEC-NATIVE-CREDENTIAL-DELIVERY","kind":"security","owner":"Runtime","acceptanceLayers":["L0","L1R","L3S"],"citation":{"start":867,"end":867,"contains":"never ordinary environment variables"}},
    {"id":"AUD-SEC-008","status":"missing","proposedId":"SEC-VAULT-STANDARD-CRYPTO","kind":"security","owner":"Messaging/security","acceptanceLayers":["review","L0","L4"],"citation":{"start":922,"end":922,"contains":"No custom cipher or certificate parser"}},

    {"id":"AUD-ERR-001","status":"missing","proposedId":"ERR-NATS-AMBIGUOUS-STORE-HOLD","kind":"error","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S"],"citation":{"start":521,"end":521,"contains":"ambiguity holds"}},
    {"id":"AUD-ERR-002","status":"missing","proposedId":"ERR-NATS-QUORUM-DESTRUCTIVE-HOLD","kind":"error","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L2S","L3S"],"citation":{"start":532,"end":533,"contains":"fewer than two current peers blocks"}},
    {"id":"AUD-ERR-003","status":"missing","proposedId":"ERR-SNAPSHOT-ANTI-ROLLBACK","kind":"error","owner":"Core","acceptanceLayers":["L0","L3S"],"citation":{"start":548,"end":548,"contains":"refuses an older snapshot"}},
    {"id":"AUD-ERR-004","status":"missing","proposedId":"ERR-COMMAND-ENVELOPE-REJECTED","kind":"error","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L3S"],"citation":{"start":580,"end":580,"contains":"reject expired, stale, wrong-cell"}},
    {"id":"AUD-ERR-005","status":"missing","proposedId":"ERR-CLOCK-SKEW-DESTRUCTIVE-HOLD","kind":"error","owner":"Core","acceptanceLayers":["L0","L3S"],"citation":{"start":589,"end":589,"contains":"wall-clock anomalies hold destructive actions"}},
    {"id":"AUD-ERR-006","status":"missing","proposedId":"ERR-GRU-HA-RESERVE-EXHAUSTED","kind":"error","owner":"Core","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":619,"end":619,"contains":"refuses a deployment or drain"}},
    {"id":"AUD-ERR-007","status":"missing","proposedId":"ERR-PROVIDER-OWNERSHIP-MISMATCH","kind":"error","owner":"Cloud","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":642,"end":642,"contains":"refuses to mutate an unowned or mismatched resource"}},
    {"id":"AUD-ERR-008","status":"missing","proposedId":"ERR-SCALE-IN-METRICS-STALE","kind":"error","owner":"Cloud","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":725,"end":725,"contains":"Missing or stale metrics hold scale-in"}},
    {"id":"AUD-ERR-009","status":"missing","proposedId":"ERR-KNOWN-VOLUME-FORMAT-REFUSED","kind":"error","owner":"Storage","acceptanceLayers":["L0","L1R","L3S","L4"],"citation":{"start":773,"end":773,"contains":"recognized volume is never formatted"}},
    {"id":"AUD-ERR-010","status":"missing","proposedId":"ERR-VOLUME-EXPANSION-HELD","kind":"error","owner":"Storage","acceptanceLayers":["L0","L1R","L3S","L4"],"citation":{"start":814,"end":814,"contains":"failure produces a held operation"}},

    {"id":"AUD-GATE-001","status":"missing","proposedId":"REQ-GATE-PHASE0","kind":"acceptance-gate","owner":"Integration/contract steward","acceptanceLayers":["review","L0"],"citation":{"start":1494,"end":1494,"contains":"Exit gate:"}},
    {"id":"AUD-GATE-002","status":"missing","proposedId":"REQ-GATE-PHASE1","kind":"acceptance-gate","owner":"Verification","acceptanceLayers":["L0","L0C"],"citation":{"start":1509,"end":1509,"contains":"hard pre-deployment thresholds pass"}},
    {"id":"AUD-GATE-003","status":"missing","proposedId":"REQ-GATE-PHASE2","kind":"acceptance-gate","owner":"Messaging/security","acceptanceLayers":["L0","L0C","L1S","L2S","L3S"],"citation":{"start":1522,"end":1522,"contains":"bootstrap, enrollment, renewal"}},
    {"id":"AUD-GATE-004","status":"missing","proposedId":"REQ-GATE-PHASE3","kind":"acceptance-gate","owner":"Runtime","acceptanceLayers":["L0","L1S","L2S","L3S"],"citation":{"start":1536,"end":1536,"contains":"native/container lifecycle contracts"}},
    {"id":"AUD-GATE-005","status":"missing","proposedId":"REQ-GATE-PHASE4","kind":"acceptance-gate","owner":"Cloud","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":1548,"end":1548,"contains":"leadership loss at every provider/handoff checkpoint"}},
    {"id":"AUD-GATE-006","status":"missing","proposedId":"REQ-GATE-PHASE5","kind":"acceptance-gate","owner":"TerraBase","acceptanceLayers":["L0","L1R","L3S","L4"],"citation":{"start":1559,"end":1559,"contains":"clean three-host bootstrap is idempotent"}},
    {"id":"AUD-GATE-007","status":"missing","proposedId":"REQ-GATE-PHASE6","kind":"acceptance-gate","owner":"Delivery","acceptanceLayers":["L0","L3S"],"citation":{"start":1571,"end":1571,"contains":"HTTP acknowledgement means durable acceptance"}},
    {"id":"AUD-GATE-008","status":"missing","proposedId":"REQ-GATE-PHASE7","kind":"acceptance-gate","owner":"Delivery","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":1581,"end":1581,"contains":"exact candidate rolls SFO->FRA->GRU"}},
    {"id":"AUD-GATE-009","status":"missing","proposedId":"REQ-GATE-PHASE8","kind":"acceptance-gate","owner":"Operations","acceptanceLayers":["L0","L3S","L4"],"citation":{"start":1592,"end":1592,"contains":"read-only Grafana cannot authorize a mutation"}},
    {"id":"AUD-GATE-010","status":"missing","proposedId":"REQ-GATE-PHASE9","kind":"acceptance-gate","owner":"Verification","acceptanceLayers":["L3S","L1R","L4"],"citation":{"start":1604,"end":1606,"contains":"Phase 9 cannot pass"}},
    {"id":"AUD-GATE-011","status":"missing","proposedId":"REQ-GATE-PRODUCTION-PLATFORM","kind":"acceptance-gate","owner":"Verification","acceptanceLayers":["L3S","L1R","L4","L5"],"citation":{"start":1633,"end":1646,"contains":"Every external mutation has persisted intent"}},
    {"id":"AUD-GATE-012","status":"missing","proposedId":"REQ-GATE-PRODUCTION-TERRABASE-STORAGE","kind":"acceptance-gate","owner":"TerraBase","acceptanceLayers":["L1R","L3S","L4","L5"],"citation":{"start":1648,"end":1657,"contains":"Full/incremental application backups"}},
    {"id":"AUD-GATE-013","status":"missing","proposedId":"REQ-GATE-PRODUCTION-COMPATIBILITY","kind":"acceptance-gate","owner":"Delivery","acceptanceLayers":["L0","L3S","L4","L5"],"citation":{"start":1659,"end":1667,"contains":"Immutable candidate promotion traverses SFO, FRA, GRU"}},
    {"id":"AUD-GATE-014","status":"missing","proposedId":"REQ-GATE-PREDEPLOYMENT-EVIDENCE","kind":"acceptance-gate","owner":"Verification","acceptanceLayers":["L0","L0C"],"citation":{"start":1114,"end":1122,"contains":"No orchestrator commit may start"}},
    {"id":"AUD-GATE-015","status":"missing","proposedId":"REQ-GATE-MINIMUM-EVIDENCE-THRESHOLDS","kind":"acceptance-gate","owner":"Verification","acceptanceLayers":["L0","L0C"],"citation":{"start":1156,"end":1164,"contains":"100% of declared state-machine transitions"}},
    {"id":"AUD-GATE-016","status":"missing","proposedId":"REQ-GATE-TEST-LAYER-AUTHORITY","kind":"acceptance-gate","owner":"Verification","acceptanceLayers":["L0","L0C","L1S","L2S","L3S","L1R","L4","L5"],"citation":{"start":1183,"end":1192,"contains":"Release authority"}},
    {"id":"AUD-GATE-017","status":"missing","proposedId":"REQ-GATE-PERFORMANCE-CORRECTNESS","kind":"acceptance-gate","owner":"Verification","acceptanceLayers":["L0","L1R","L3S","L4","L5"],"citation":{"start":1277,"end":1290,"contains":"Scheduler produces deterministic placement"}}
  ],
  "stewardRecommendations": [
    "Add statement/source anchors and acceptance-evidence fields to all 43 existing entries; an ID plus owner/layers is not semantic coverage.",
    "Register the 8 explicit transition graphs, 10 externally meaningful errors/holds, 8 independent security rules, and 17 gate families proposed here.",
    "Normalize every registry owner through owner-mapping.json to the 11 exact exclusive lane names; review control-plane, cloud-storage, and delivery-security mappings and use co-review metadata where one primary lane is insufficient.",
    "Keep unresolved questions 1-10 and measurable cost/storage/RPO/RTO values as explicit not-ready dependencies; do not mark Phase 1 contracts frozen.",
    "Split grouped gate IDs further when implementation begins so each independently failing acceptance assertion has one evidence target."
  ]
}


---

# FILE: docs/audits/registry-v2-review/HANDOFF.md

# Registry v2 review handoff

Scope reviewed: integration commit `7deaf74a4d481570e0e45679c0e353c8297ac939`
and all 43 proposed missing IDs.

The complete adversarial findings, per-ID classifications, and ordered steward
patch plan are in [REVIEW.md](REVIEW.md).

No canonical registry, checker, fixture, test, orchestrator source, build file, or
production file was edited. No proposed ID was frozen.

Highest-priority steward actions:

1. Resolve the `REQ-GATE-*` / `acceptance-gate` incompatibility before registering
   any gate proposal.
2. Fix audit-to-registry parity, co-reviewer, root metadata, and evidence-identity
   validation holes.
3. Deduplicate INV-010 and SEC-NO-SECRET-OUTPUT and reclassify
   ERR-PHASE0-NOTREADY.
4. Apply the 43-row disposition table, with owner decisions remaining blocked.


---

# FILE: docs/audits/registry-v2-review/RESPONSE-REVIEW.md

# Re-review of steward response `7893b82`

Reviewed commit: `7893b82f104284a7c8a6cec40b617a86af7889f5`.

## Conclusion

The response materially improves the draft registry and closes the exact original
owner/layer, invalid-co-reviewer, one-character statement/target, and root-version
mutations covered by its five new fixtures. It does **not** fully close C2–C6.
The new checks are useful Phase 0 guardrails, but string length and substring tests
must not be described as semantic or evidence-identity validation.

| Original issue | Result | Evidence and remaining action |
|---|---|---|
| C2 audit/registry parity | **Partially closed** | Owner and ordered acceptance-layer parity are now checked. Mutating `AUD-ID-001.kind` from `requirement` to `security` is still accepted because `finding.kind` is ignored. Validate finding kind against both the ID-derived kind and registry kind. If ordered layers are intentional, document it; otherwise compare a duplicate-free set. |
| C3 co-reviewers | **Partially closed** | Canonicality, uniqueness, and primary-owner exclusion are checked, and the five named cross-lane entries were populated. Removing `coReviewers` from a registry entry is still accepted by the Python checker because absence becomes `[]`. Require the field explicitly in the parser/schema. The response also does not represent co-review approval/provenance, so populated names are routing metadata, not review evidence. |
| C4 evidence targets | **Not closed** | Replacing the first target with `L0 placeholder target` is accepted. Length plus containment of the layer token remains an opaque string/count check; for example `L0` is also a substring of `L0C`. Use structured targets with an exact layer field, stable scenario/test ID, artifact identity, producer, candidate digest, and status; validate uniqueness and exact layer coverage. |
| C5 root metadata | **Partially closed, with lifecycle regressions** | The exact original schema/status/vocabulary mutations are rejected, and C# now types the fields. Python accepts an unknown root field and accepts duplicate contradictory `status: draft` / `status: frozen` keys because it searches only the first textual match. Conversely, semantically equivalent YAML spacing is rejected. Most importantly, removing question 1 after it is answered is rejected because `[1..10]` is hard-coded. Parse one root mapping, reject duplicate/unknown keys according to an explicit schema, validate types/sets semantically, and allow the unresolved-question set to shrink under a recorded decision. Model freeze preconditions separately from forcing `status: draft` forever. |
| C6 semantic quality | **Not closed** | `xxxxxxxxxxxxxxxxxxxx` is accepted as a normative statement. The 20-character threshold closes only the supplied `"x"` fixture; it does not establish fidelity or range completeness. Source commit/document identity and truncated-but-still-containing-range tests remain absent. Keep semantic review provenance and source-revision binding as freeze requirements. |

## Additional observations

- **Confirmed improvement:** both validators now agree on canonical co-reviewer shape,
  root field values for the current draft, statement minimum length, and the current
  layer/target positional convention.
- **Confirmed inconsistency risk:** Python performs root validation with regular
  expressions while C# deserializes YAML. The two validators therefore do not share
  duplicate-key, unknown-key, or formatting semantics.
- **Recommendation:** replace the five heuristic fixtures with adversarial pairs:
  invalid and valid-evolved root documents, missing versus explicitly empty
  co-reviewers, mismatched audit kind, `L0C` used for `L0`, duplicate layers/targets,
  opaque 20-character strings, and a truncated normative range that still contains
  the marker.
- **Recommendation:** retain all evidence states as `missing`. Nothing in this
  response creates an evidence artifact or supports contract freeze.

## Verification

Executed in a detached worktree at exactly `7893b82`:

- `dotnet run --project tools/TerraScale.Orchestrator.Tooling -- registry-audit --negative-fixtures docs/audits/registry/fixtures/negative-cases.json` — PASS, 43 registry entries, 86 findings, 15 fixtures.
- `dotnet restore TerraScale.Orchestrator.slnx --locked-mode` — PASS.
- `dotnet build TerraScale.Orchestrator.slnx --no-restore` — PASS, zero warnings/errors.
- `dotnet test TerraScale.Orchestrator.slnx --no-build` — PASS, 4/4 tests.

Controlled in-memory Python validations (no canonical file edits):

- mismatched semantic audit `kind` — incorrectly accepted;
- omitted `coReviewers` — incorrectly accepted;
- opaque `L0 placeholder target` — incorrectly accepted;
- unknown root field — accepted;
- duplicate contradictory root status — incorrectly accepted;
- semantically equivalent unresolved-question list spacing — incorrectly rejected;
- removing an answered question — incorrectly rejected;
- vacuous 20-character normative statement — incorrectly accepted.


---

# FILE: docs/audits/registry-v2-review/REVIEW.md

# Independent registry v2 review of `7deaf74`

Reviewed integration tree: `7deaf74a4d481570e0e45679c0e353c8297ac939`.

This review does **not** freeze any of the 43 proposed IDs. Labels have the following
strict meanings:

- **Confirmed issue**: behavior reproduced from the integrated files or an internal
  contradiction in the current proposal.
- **Recommendation**: a steward change that improves the contract, but whose exact
  form is not forced by the current source.
- **Blocked owner decision**: a semantic choice that the steward must not invent.

## Executive conclusion

The v2 migration is a useful exact-source-anchor baseline, but it is not yet a
traceability contract. The source-range digests correctly detect a change to a
normalized cited slice. They do not validate semantic adequacy, audit/registry
parity, co-reviewers, root schema metadata, or meaningful evidence identities.
All 43 registered entries still have `evidenceState: missing`, so the audit's
`semantic: 43` means “metadata populated,” not “semantically complete” or verified.

The 43 proposed missing IDs are a discovery inventory, not a freeze-ready registry
patch. State-machine and error candidates are mostly sound families after the
clarifications below. Security proposals need explicit refinement relationships to
existing invariants. All 17 gate proposals require a namespace/kind decision and
per-assertion decomposition.

## Confirmed issues

### C1 — `REQ-GATE-*` contradicts the declared `acceptance-gate` kind

All 17 gate findings propose a `REQ-GATE-*` ID with kind `acceptance-gate`. Both the
Python checker and `RepositoryBoundaryTests` infer `REQ` as kind `requirement`.
Adding any proposal exactly as written therefore fails the current validators.

**Action:** before registration, choose one model: (a) keep `REQ-GATE-*` and use
`kind: requirement` plus an explicit gate subtype/relationship, or (b) add a real
`GATE-*` namespace and update the steward-owned schema and both validators. Do not
silently register the current contradictory pair.

### C2 — audit-to-registry semantic parity is not checked

A controlled mutation changed `AUD-ID-001.owner` from Integration to Cloud and its
layers to `[L0]`, while leaving `REQ-O001` unchanged. The checker returned `ACCEPTED`.
The audit can therefore disagree with its canonical registry entry while passing.

**Action:** for every `semantic` finding, compare kind, owner, acceptance layers,
source anchor, statement identity/digest, evidence state, and evidence targets with
the referenced registry entry. Make ordering semantics explicit for layer lists.

### C3 — `coReviewers` is dead, unchecked contract data

All 43 entries contain `coReviewers: []`, but neither validator parses or validates
the field. A controlled `[NOT-A-LANE]` mutation passed. This is especially unsafe
after collapsing `control-plane`, `cloud-storage`, and `delivery-security` aliases
to one exclusive primary lane.

**Action:** add `CoReviewers` to the typed model and Python parser; require unique
canonical lanes, forbid the primary owner, and populate cross-lane reviews. At a
minimum review REQ-O011 (Storage + Cloud/TerraBase), REQ-O015 (Delivery +
Messaging/security), INV-014 (Cloud + Integration), INV-016 (Verification + affected
production lanes), and INV-018 (Messaging/security + Cloud/Runtime/Storage).

### C4 — evidence targets are only nonempty strings with the right count

A controlled replacement of an evidence target with `"x"` passed. The integrated
targets are generic repetitions such as `L0 evidence bound to the exact integration
tree`; no check binds a target to its layer, scenario, artifact, dependency closure,
or digest. Target count is not evidence identity.

**Action:** use structured targets containing at least `layer`, stable scenario or
test ID, artifact/attestation identity, candidate-tree digest, status, and producing
lane. Validate one unique target per declared layer (or explicitly model many-to-one
authority). Keep every current target missing until an artifact exists.

### C5 — root contract metadata is ignored

A controlled mutation to `schemaVersion: 999`, `status: frozen`, and an invalid
`evidenceStateVocabulary` passed. The C# deserializer ignores these fields entirely.

**Action:** validate the exact supported schema version, allowed registry status,
normative source, unresolved-question shape, and evidence vocabulary in both
validators. Freeze must additionally reject unresolved owner questions and missing
evidence.

### C6 — presence is mistaken for semantic quality

Replacing a normative statement with `"x"` passed. A digest binds the cited bytes,
but the checker proves neither that the statement faithfully summarizes those bytes
nor that the range contains the full normative rule. Coordinated source and digest
changes also pass without a separately recorded source-revision identity.

**Action:** add review provenance (reviewer, source commit, decision/ADR) and a
negative fixture for truncated ranges. Treat the slice digest as drift detection,
not proof of semantic completeness. A document/revision digest is recommended for
freeze attestations.

### C7 — `INV-010` and `SEC-NO-SECRET-OUTPUT` duplicate one rule

They cite the same line, use the same SHA-256, owners, layers, and materially
identical normative statements. This creates two evidence identities for one rule
without a refinement or alias relationship.

**Action:** retain one canonical ID and alias the other, or explicitly model the
security item as a test/control refinement of INV-010 with inherited evidence. Do
not require duplicate proof merely because two taxonomies are useful.

### C8 — the migrated README contradicts the migrated data

The current README says all 43 entries are `id-only`, have alias owners, and carry no
semantic fields. The integrated JSON instead reports 43 `semantic`, zero `id-only`,
and zero owner aliases; the registry has populated statements/digests. Its opening
paragraph was updated, but the next paragraph was not.

**Action:** steward-update the canonical audit README to distinguish 43
source-anchored proposals from zero complete/verified contracts. Add README summary
values to review or generation so this drift cannot recur.

### C9 — `ERR-PHASE0-NOTREADY` is not demonstrated as a stable product error

The entry anchors repository planning status at lines 3–4, not an externally visible
runtime rejection, protocol error, or typed client outcome. This conflicts with the
audit's stated error-family selection rule.

**Action:** either reclassify it as a gate/readiness status or cite the contract that
defines a stable error surface, payload, and consumer. Do not freeze it as an error
based only on planning prose.

## Source-digest assessment

**Confirmed:** Python `splitlines()` + `"\n".join(...)` and C# `ReadAllLines` +
`string.Join('\n', ...)` implement the same normalized-slice SHA-256 semantics.
Exact cited text drift is detected; the added negative fixture exercises it.

**Recommendation:** document that line endings and the final newline are excluded,
and that line-number movement is intentionally breaking. Bind a frozen registry to
a source commit/document digest as well as slice hashes. Add tests for an expanded
range, a truncated-but-still-containing range, duplicate source hashes, and
coordinated audit/registry mismatch.

## Review of every proposed missing ID

“Retain” means retain as a proposal after the global schema/evidence fixes; it does
not mean freeze.

| Finding / proposed ID | Classification | Required steward disposition |
|---|---|---|
| AUD-SM-001 / SM-SELF-UPGRADE | Recommendation | Rename `SM-ORCHESTRATOR-SELF-UPGRADE` to disambiguate the actor; retain the full rollback graph. |
| AUD-SM-002 / SM-NATS-MEMBER-REPLACEMENT | Recommendation | Retain, but parameterize/control-vs-product plane and bind ambiguity/quorum holds as named transitions. |
| AUD-SM-003 / SM-PULUMI-OWNERSHIP-HANDOFF | Recommendation | Retain; add INV-014 relationship and remove L5 unless a soak assertion is identified. |
| AUD-SM-004 / SM-NODE-SCALE-OUT | Recommendation | Retain; require provider-fake transition evidence and explicit idempotent retry states. |
| AUD-SM-005 / SM-NODE-SCALE-IN | Recommendation | Retain; link stale-metric, fencing, drain, and ownership holds to typed outcomes. |
| AUD-SM-006 / SM-VOLUME-CREATE-ATTACH | Recommendation | Rename or split: cited graph also formats and mounts. Preserve irreversible-format recovery as an independently evidenced transition. |
| AUD-SM-007 / SM-VOLUME-EXPANSION | Recommendation | Retain; split provider, guest-rescan, filesystem-growth, and verification failure reasons beneath the family. |
| AUD-SM-008 / SM-GITOPS-RECONCILIATION | Recommendation | Retain; identify the durable-acceptance boundary and remove L5 unless a specific soak assertion exists. |
| AUD-SEC-001 / SEC-MTLS-TRUST-BOUNDARIES | Recommendation | Retain as an umbrella security policy; decompose independently failing trust boundaries into evidence targets. |
| AUD-SEC-002 / SEC-NATS-DUAL-AUTHORIZATION | Recommendation | Retain as a refinement of SEC-MTLS-TRUST-BOUNDARIES; prove both mTLS identity and NATS permission denial separately. |
| AUD-SEC-003 / SEC-CLOSED-ROLE-ADMISSION | Recommendation | Link as a narrower control refinement of INV-017 or merge; avoid parallel evidence for the same admission fact. |
| AUD-SEC-004 / SEC-NATS-MONITORING-ISOLATION | Recommendation | Retain; specify bind address, authorization, and exposure assertions separately. |
| AUD-SEC-005 / SEC-PROVIDER-MUTATION-AUTHORITY | Recommendation | Retain; link to INV-006/INV-014 and require Cloud plus security co-review. |
| AUD-SEC-006 / SEC-SURVIVAL-BUNDLE-NO-PLAINTEXT | Recommendation | Retain only as a scoped refinement of INV-010, with inherited no-secret-output evidence and separate offline-root-key assertion. |
| AUD-SEC-007 / SEC-NATIVE-CREDENTIAL-DELIVERY | Recommendation | Rename `SEC-NATIVE-SYSTEMD-CREDENTIAL-DELIVERY` if the source is intentionally native-only; do not imply container coverage. |
| AUD-SEC-008 / SEC-VAULT-STANDARD-CRYPTO | Recommendation | Retain as review/static-analysis policy; L4 does not itself prove absence of custom crypto/parser code, so identify authoritative evidence. |
| AUD-ERR-001 / ERR-NATS-AMBIGUOUS-STORE-HOLD | Recommendation | Retain; define stable payload/retryability and link to the NATS replacement held transition. |
| AUD-ERR-002 / ERR-NATS-QUORUM-DESTRUCTIVE-HOLD | Recommendation | Retain; distinguish peer-count and quorum/currentness facts in the error detail. |
| AUD-ERR-003 / ERR-SNAPSHOT-ANTI-ROLLBACK | Recommendation | Rename to an outcome such as `ERR-SNAPSHOT-ROLLBACK-REFUSED`; define generation/identity fields. |
| AUD-ERR-004 / ERR-COMMAND-ENVELOPE-REJECTED | Recommendation | Keep a family only if stable reason codes separately identify expired, stale, wrong-cell, wrong-identity, and lower-generation failures; otherwise split. |
| AUD-ERR-005 / ERR-CLOCK-SKEW-DESTRUCTIVE-HOLD | Recommendation | Retain; define measured skew input, held operations, retryability, and operator remediation. |
| AUD-ERR-006 / ERR-GRU-HA-RESERVE-EXHAUSTED | Recommendation | Rename to `ERR-GRU-HA-MARGIN-VIOLATION`; the source is a failure-margin invariant, not necessarily resource exhaustion. |
| AUD-ERR-007 / ERR-PROVIDER-OWNERSHIP-MISMATCH | Recommendation | Retain; differentiate unowned, mismatched cell, generation, and handoff states as stable reasons. |
| AUD-ERR-008 / ERR-SCALE-IN-METRICS-STALE | Recommendation | Retain; bind only to scale-in and state the freshness threshold via an owner-resolved parameter. |
| AUD-ERR-009 / ERR-KNOWN-VOLUME-FORMAT-REFUSED | Recommendation | Retain; define recognized-signature evidence and make destructive override impossible rather than merely operator-configurable. |
| AUD-ERR-010 / ERR-VOLUME-EXPANSION-HELD | Recommendation | Retain as a family only with provider/rescan/filesystem/verification reason codes and resumable operation identity. |
| AUD-GATE-001 / REQ-GATE-PHASE0 | Confirmed issue + blocked owner decision | Resolve C1; split each exit assertion. Satisfaction remains blocked by owner questions 1–10 and unresolved measurable targets. |
| AUD-GATE-002 / REQ-GATE-PHASE1 | Confirmed issue | Resolve C1; model as an aggregate depending on the predeployment and evidence-threshold gates, not duplicate evidence. |
| AUD-GATE-003 / REQ-GATE-PHASE2 | Confirmed issue + blocked owner decision | Resolve C1; split identity/NATS assertions. Final topology/credential choices must remain configurable until owners answer. |
| AUD-GATE-004 / REQ-GATE-PHASE3 | Confirmed issue + blocked owner decision | Resolve C1; split native/container lifecycle assertions and retain the owner-selected default as unresolved. |
| AUD-GATE-005 / REQ-GATE-PHASE4 | Confirmed issue + blocked owner decision | Resolve C1; split provider/handoff/leadership assertions; cost/SLO policy remains owner-owned. |
| AUD-GATE-006 / REQ-GATE-PHASE5 | Confirmed issue + blocked owner decision | Resolve C1; split bootstrap, replication, backup, restore, expansion, and fencing assertions; RPO/RTO/storage choices remain unresolved. |
| AUD-GATE-007 / REQ-GATE-PHASE6 | Confirmed issue | Resolve C1; split durable HTTP acceptance from reconciliation/rollback assertions and relate them to SM-GITOPS-RECONCILIATION. |
| AUD-GATE-008 / REQ-GATE-PHASE7 | Confirmed issue + blocked owner decision | Resolve C1; split immutable promotion, trust-zone, interruption, and rollout assertions; signing/release choices remain owner-owned. |
| AUD-GATE-009 / REQ-GATE-PHASE8 | Confirmed issue + blocked owner decision | Resolve C1; split read-only, telemetry, outage, VPN, orphan, and browser assertions; observability targets remain unresolved. |
| AUD-GATE-010 / REQ-GATE-PHASE9 | Confirmed issue + blocked owner decision | Resolve C1; split each qualification threshold; do not freeze omitted SLO/cost/RPO/RTO values. |
| AUD-GATE-011 / REQ-GATE-PRODUCTION-PLATFORM | Confirmed issue + blocked owner decision | Resolve C1; model as a parent gate over independently named platform assertions, with no duplicated child evidence. |
| AUD-GATE-012 / REQ-GATE-PRODUCTION-TERRABASE-STORAGE | Confirmed issue + blocked owner decision | Resolve C1; split backup/restore/failover/expansion assertions and leave RPO/RTO/storage parameters owner-resolved. |
| AUD-GATE-013 / REQ-GATE-PRODUCTION-COMPATIBILITY | Confirmed issue + blocked owner decision | Resolve C1; split promotion, rollback, upgrade, compatibility, and retirement assertions; retain release-policy choices as unresolved. |
| AUD-GATE-014 / REQ-GATE-PREDEPLOYMENT-EVIDENCE | Confirmed issue | Resolve C1; retain as a parent gate whose children are exact pre-VM assertions, not one opaque evidence string. |
| AUD-GATE-015 / REQ-GATE-MINIMUM-EVIDENCE-THRESHOLDS | Confirmed issue | Resolve C1; split each numeric floor and define denominator semantics (declared, applicable, skipped, quarantined). |
| AUD-GATE-016 / REQ-GATE-TEST-LAYER-AUTHORITY | Confirmed issue | Resolve C1; this is authority policy, not one executable test. Represent per-layer authority rules and gate dependencies. |
| AUD-GATE-017 / REQ-GATE-PERFORMANCE-CORRECTNESS | Confirmed issue + blocked owner decision | Resolve C1; split deterministic placement, latency/resource budgets, recovery, and soak criteria; numeric targets remain owner decisions. |

## Steward patch plan

Apply these as small steward-owned commits; no proposal should be frozen merely by
landing the mechanics.

1. **Correct the migration narrative.** Update the canonical README to 43 semantic
   metadata entries, 43 missing proposals, zero verified/complete entries.
2. **Close validator holes.** Validate root metadata, co-reviewers, semantic
   audit/registry parity, structured evidence identities, and freeze preconditions in
   both Python and C#. Add adversarial fixtures for every C2–C6 mutation.
3. **Resolve taxonomy.** Record an ADR choosing `REQ`+gate subtype or a new `GATE`
   namespace. Add `refines`, `aliasOf`, `parentGate`, and `dependsOn` (or equivalent)
   so aggregate gates/security controls do not duplicate invariant evidence.
4. **Deduplicate current registry.** Resolve INV-010 versus SEC-NO-SECRET-OUTPUT and
   reclassify ERR-PHASE0-NOTREADY before adding IDs.
5. **Restore ownership semantics.** Populate and validate cross-lane co-reviewers;
   owner approval is required for the named high-risk entries and each proposed
   cross-domain family.
6. **Register reviewed SM/SEC/ERR candidates as `proposed`.** Apply the table's
   renames/splits/reason-code decisions. Keep `evidenceState: missing`.
7. **Decompose gates.** Introduce independently failing child assertions and a DAG
   for Phase/production aggregates. Do not create one target per bullet by string;
   create stable evidence identities with explicit authority.
8. **Owner-decision checkpoint.** Keep unresolved parameterized values and gate
   satisfaction blocked. Only a subsequent reviewed freeze commit may change status.

## Verification record

- `dotnet run --project tools/TerraScale.Orchestrator.Tooling -- registry-audit --negative-fixtures docs/audits/registry/fixtures/negative-cases.json` — PASS (43 registry entries, 86 findings, 10 fixtures).
- `dotnet restore TerraScale.Orchestrator.slnx --locked-mode` — PASS.
- `dotnet build TerraScale.Orchestrator.slnx --no-restore` — PASS, zero warnings.
- `dotnet test TerraScale.Orchestrator.slnx --no-build` — PASS, 4/4 tests.
- Controlled in-memory checker mutations C2–C6 — all incorrectly accepted, as
  recorded above. No canonical files were changed to perform those tests.


---

# FILE: docs/audits/runtime/arm64-runtime-readiness.md

# Phase 0 ARM64 host and runtime readiness

- Status: proposal and evidence inventory; no candidate selected or qualified
- Audit date: 2026-07-13
- Target: OCI `VM.Standard.A1.Flex`, Linux `aarch64`
- Machine-readable record: `testlab/pins/arm64-runtime-candidates.json`
- Traces: `REQ-O005`, `REQ-O012`, `REQ-O017`, `REQ-O020`, `INV-009`, `INV-017`

This audit compares candidates and defines their exit evidence. It is not an
ADR, pin, image approval, filesystem choice, package installation, or permission
to start an L1R/L4 environment. The host image, kernel, glibc package,
filesystem, systemd build, containerd, runc, and BuildKit selections all remain
`null` in the machine-readable record.

## Evidence classes

The words in this audit have deliberately narrow meanings:

| Class | Meaning |
|---|---|
| Primary-source claim | A current vendor/upstream page says a family, architecture, package, release, or feature exists. It does not prove the exact image or runtime works for TerraScale. |
| Candidate | A family is plausible enough to enter qualification. It is not selected, mirrored, pinned, security-approved, or supported by measured evidence. |
| Local observation | A non-mutating fact about the current NixOS x86_64 workspace host. It cannot satisfy ARM64, distro, PID-1 adapter, filesystem-growth, L1R, or L4 gates. |
| L1R evidence | Signed results from the exact pre-gated tree on a real aarch64 Linux host with systemd as PID 1 and permissioned scratch storage. It proves Linux/runtime behavior, not OCI provider behavior. |
| L4 evidence | Signed results from an explicitly authorized disposable OCI A1 environment using immutable image identifiers, real IAM/network/block-volume boundaries, and cleanup proof. |

The architecture requires real systemd-as-PID-1 and OCI A1 qualification in
addition to rootless-container integration (`ORCHESTRATOR.md:63-65`). A cross-publish, an x64 run, a
container pretending to be an ARM host, or a package catalog entry is not ARM64
qualification (`ORCHESTRATOR.md:333-368`, `ORCHESTRATOR.md:1734-1751`).

## Current primary-source findings

All current claims below are bounded by the cited official source and the audit
date. Moving package repositories and release pages are discovery evidence;
the eventual pin must record immutable image IDs, artifact hashes/signatures,
package manifests, and internally mirrored artifacts.

- OCI documents Ampere A1 as Arm compute and supports Oracle Linux and Ubuntu
  platform images on Arm ([OCI Arm-based Compute](https://docs.oracle.com/en-us/iaas/Content/Compute/References/arm.htm)).
- OCI's current platform catalog lists Oracle Linux 9 and Ubuntu 24.04 for Arm.
  It explicitly directs Arm users to the standard Ubuntu image rather than
  Minimal Ubuntu ([OCI Platform Images](https://docs.oracle.com/en-us/iaas/Content/Compute/References/images.htm)).
  The separate release-note catalog shows Ubuntu 24.04 aarch64 image families,
  but this audit does not select one ([OCI Ubuntu 24.04 images](https://docs.oracle.com/en-us/iaas/images/ubuntu-2404/)).
- Canonical identifies Ubuntu 24.04 and 26.04 as ARM64 LTS releases, with
  standard maintenance through May 2029 and May 2031 respectively
  ([Ubuntu release cycle](https://ubuntu.com/about/release-cycle)). OCI's cited
  catalog does not currently list 26.04, so 26.04 is a watch item rather than an
  OCI candidate.
- Canonical's Noble package catalogs expose the glibc 2.39 and systemd 255
  families for arm64 ([Noble arm64 libraries](https://packages.ubuntu.com/noble/arm64/libs/),
  [Noble systemd](https://packages.ubuntu.com/noble/systemd)). These are not the
  exact builds in any uninspected OCI image.
- Oracle documents Oracle Linux 9 on aarch64 with UEK
  ([Oracle Linux 9 architectures](https://docs.oracle.com/en/operating-systems/oracle-linux/9/relnotes9.3/ol9-AboutOracleLinux9.html)).
  UEK 8 is available to OL9 aarch64 and is the fresh-install default beginning
  with OL9.6, but only booted immutable-image evidence can establish the actual
  OCI kernel ([UEK 8 availability](https://docs.oracle.com/en-us/iaas/oracle-linux/uek/8/uek8.0-installation-and-availability.htm)).
  The moving OL9 aarch64 BaseOS repository carries glibc 2.34 packages; it is
  not an immutable image manifest
  ([Oracle Linux 9 aarch64 BaseOS](https://yum.oracle.com/repo/OracleLinux/OL9/baseos/latest/aarch64/index.html)).
- containerd's upstream 2.3 line is its first annual LTS track and publishes
  ARM64 artifacts; exact patch, mirror, signature/checksum, and pairing are
  unset ([containerd releases](https://github.com/containerd/containerd/releases),
  [containerd installation](https://github.com/containerd/containerd/blob/main/docs/getting-started.md)).
- runc's supported stable branch must be re-evaluated at freeze. The project
  says official releases are signed and that runc is Linux-only
  ([runc releases](https://github.com/opencontainers/runc/releases),
  [runc project](https://github.com/opencontainers/runc)). Distribution builds
  remain a separate candidate because package versions can differ by
  architecture; Canonical's current Noble page visibly demonstrates that risk
  ([Ubuntu runc](https://packages.ubuntu.com/noble/runc)).
- BuildKit 0.30 is a candidate track, not an LTS selection. Its upstream release
  publishes architecture-specific artifacts and supply-chain metadata; the
  project documents workers, rootless operation, multi-platform output, and
  reproducibility controls ([BuildKit releases](https://github.com/moby/buildkit/releases),
  [BuildKit project](https://github.com/moby/buildkit)).
- Upstream filesystem tools document online mounted growth for ext4 and XFS,
  but neither documentation nor local tool presence proves safe crash recovery:
  [resize2fs](https://git.kernel.org/pub/scm/fs/ext2/e2fsprogs.git/tree/resize/resize2fs.8.in)
  and [xfs_growfs](https://git.kernel.org/pub/scm/fs/xfs/xfsprogs-dev.git/tree/man/man8/xfs_growfs.8).

## Candidate and readiness matrix

### Host image bundles

The host image is evaluated as a bundle. Kernel, glibc, systemd, cloud-init,
boot layout, firewall/link-local rules, package provenance, and filesystem
defaults cannot be mixed from catalog pages to manufacture a qualified stack.

| Candidate | Primary-source eligibility | Provisional strengths | Qualification blockers | Readiness |
|---|---|---|---|---|
| Oracle Linux 9 aarch64 OCI platform image | OCI Arm-supported image family; OL9 aarch64 uses UEK | OCI-native support path; aarch64 UEK; long-lived enterprise family | Immutable regional image IDs; actual booted UEK build; glibc/systemd/package manifest; cgroups v2; A1 boot/reboot/network/block behavior; security-update and generation-rotation policy | Candidate, unqualified |
| Ubuntu 24.04 LTS standard aarch64 OCI platform image | OCI Arm-supported standard image; Canonical ARM64 LTS | Stable LTS family; known glibc/systemd ABI families; broad upstream packaging | Immutable regional image IDs; actual kernel/glibc/systemd builds; standard-versus-Minimal enforcement; A1 boot/reboot/network/block behavior; security-update and generation-rotation policy | Candidate, unqualified |
| Ubuntu 26.04 LTS ARM64 | Canonical LTS exists, but no cited OCI platform-image family | Longer standard support window | OCI image/A1 availability absent from current primary evidence; no immutable image or boot evidence | Watchlist, not an OCI candidate |

No row wins by documentation. Selection needs comparable L1R/L4 results,
security/support review, package/mirror operations, cost/boot/resource evidence,
and an owner-approved ADR.

### Kernel and glibc tracks

Kernel and glibc are not independently selected from their host bundle. The
rows below prevent a family-level source claim from being mistaken for an exact
booted build.

| Host candidate | Kernel candidate track | glibc candidate track | Exact selection | Required proof |
|---|---|---|---|---|
| Oracle Linux 9 aarch64 | Image-supplied UEK. Oracle's current docs establish aarch64 UEK and UEK 8 availability, but OCI catalog/release-note differences make the exact booted branch/build an observation gate. | OL9 glibc 2.34 ABI family | Unset | Immutable image IDs in every target region; booted `uname -r`; kernel package NEVRA/hash/config; command line/modules; glibc package NEVRA/hash and loader; security/update/reboot/rollback policy; A1 runtime and block tests |
| Ubuntu 24.04 LTS standard aarch64 | OCI image-supplied Ubuntu kernel; no version inferred from an amd64, archive, GA, or HWE catalog row | Noble glibc 2.39 ABI family | Unset | Immutable image IDs; booted kernel package/version/config and loader/package manifest; security/update/reboot/rollback policy; A1 runtime and block tests |

A self-contained .NET `linux-arm64` artifact still has a native loader/kernel
boundary. Publishing it on x64 does not prove it starts against either candidate
glibc/image bundle, and an OCI multi-platform index does not prove the selected
ARM64 child runs.

### Filesystems

| Candidate | Known capability | Mandatory comparison | Readiness |
|---|---|---|---|
| ext4 + pinned e2fsprogs | Online growth is supported when kernel/filesystem permit it; `resize2fs` does not grow the underlying block device/partition | Format/mount options, UUID stability, provider-rescan sequence, partition/LVM choice, crash matrix, fsck/recovery, online expansion under load, latency/throughput/IOPS, wrong-device/no-format/shrink rejection | Candidate, unqualified |
| XFS + pinned xfsprogs | `xfs_growfs` expands a mounted filesystem | Same exact identity, rescan, crash, recovery, load, SLO, denial, package/mirror, and operational comparison as ext4 | Candidate, unqualified |

The approved storage SLO and layout are missing. This audit therefore does not
select ext4, XFS, partitions, LVM, mount options, or tool versions.

### Runtime and build stack

| Component/track | Candidate basis | Evidence still required | Readiness |
|---|---|---|---|
| systemd from selected distro | Must be the real system manager; distro bundles are candidate-coupled | PID 1, D-Bus reconnect/transient units, credentials, cgroups v2 CPU/memory/IO/PIDs, journald, watchdog, timeout/drain/restart/rollback/daemon-reexec | Candidate, unqualified |
| containerd 2.3 LTS upstream | ARM64 upstream artifact and LTS line exist | Exact patch/signature/hash/mirror; glibc/static choice; paired runc; configuration/socket; pull-by-digest; snapshot/GC; cgroup/seccomp/mount/user/signal/log lifecycle; N/N-1 | Candidate, unqualified |
| containerd distro package | Vendor package may simplify security updates/integration | Architecture-specific exact build and support; provenance; full same runtime matrix; paired runc; compare update cadence to upstream LTS | Candidate, unqualified |
| runc upstream supported stable | Signed upstream Linux releases exist | Re-evaluate supported branch at freeze; exact ARM64 artifact/signature/mirror; containerd pairing; OCI conformance; capabilities/seccomp/cgroups/mount/user denial; escape regressions; N/N-1 | Candidate, unqualified |
| runc distro package | Vendor package may align with distro security updates | Exact ARM64 build rather than amd64 assumption; provenance/support; same denial/conformance/pairing matrix | Candidate, unqualified |
| BuildKit 0.30 upstream | Current upstream candidate with ARM64 artifacts and provenance/SBOM | Exact patch/signature/hash/mirror; isolated worker threat model; no Docker socket/production credentials; reproducible multi-platform digests; cache/secret/network/cancellation/disk/cleanup adversarial tests | Candidate, unqualified; no LTS claim |

There is an immediate packaging compatibility gate: containerd's current 2.3
release notes say its recommended dynamic binaries are linked against glibc
2.35, while the Oracle Linux 9 candidate is on the glibc 2.34 ABI family. That
dynamic artifact therefore cannot be assumed usable on OL9. The alternatives
(vendor package, reviewed source build, or upstream static artifact) remain
unselected; upstream also notes that the static build is not position
independent, so using it needs an explicit hardening disposition. Ubuntu 24.04's
newer glibc family removes that particular floor mismatch but still requires
exact artifact inspection and L1R/L4 execution.

BuildKit is a CI worker capability, not permission to put a privileged daemon on
production database/control hosts. Worker isolation and runtime selection remain
separate decisions.

## Local observation: x86_64 only

Read-only inspection on 2026-07-13 observed:

| Fact | Observation | Qualification value |
|---|---|---|
| Host | NixOS 26.11, `x86_64`, kernel 6.18.38, glibc 2.42 | Local developer-host context only |
| PID 1 / systemd tools | PID 1 is systemd; `systemctl`, `journalctl`, and `busctl` report systemd 261 | Does not prove a candidate distro, ARM64, orchestrator D-Bus adapter, or L1R |
| Root filesystem | ext4 | Does not prove format/layout, online growth, crash recovery, performance, or OCI volumes |
| Filesystem tools | `resize2fs` 1.47.4 present; `xfs_growfs` absent | Presence/absence only; no scratch device was touched |
| Runtime/build tools | containerd, runc, buildkitd, and buildctl absent from PATH | No runtime qualification exists locally |

Exact command classes are recorded in the machine-readable file. No package was
installed, service/VM was started, filesystem was changed, image was downloaded,
or cloud API was called. Although local PID 1 happens to be systemd, this turn did
not run a unit, D-Bus lifecycle, container, or filesystem test.

## L1R evidence plan

L1R starts only after valid exact-tree L0/L0C pre-deployment evidence exists
(`ORCHESTRATOR.md:1114-1154`). Run each host candidate independently on a real
aarch64 Linux host with systemd as PID 1. Within each host run both filesystem
candidates. Readiness therefore requires this full interaction matrix:

| Host | ext4 | XFS |
|---|---|---|
| Oracle Linux 9 aarch64 | Required L1R report | Required L1R report |
| Ubuntu 24.04 LTS standard aarch64 | Required L1R report | Required L1R report |

Never reuse one host's filesystem result for the other: kernel, block-rescan,
partition/LVM, filesystem-tool, systemd-mount, package, and recovery behavior can
differ. The machine-readable record enumerates all four combinations explicitly.
A later owner-approved ADR may narrow future qualification only by selecting a
coupled host/filesystem pair and revising the record/validator deliberately; a
standalone host or filesystem preference, missing row, or convenient result is
not such a selection.

### Required immutable inputs

- candidate manifest containing image/source digest, package repository snapshot,
  kernel/glibc/systemd/containerd/runc/BuildKit packages and hashes, configuration,
  test-harness tree/digest, and expected architecture;
- internally mirrored and verified runtime/build artifacts;
- a dedicated disposable scratch block device or loop backing file carrying a
  harness-generated nonce and explicit destruction approval; and
- signed `pre-deployment-evidence.json` matching the test tree and binaries.

### Exact fact-capture commands

Run inside the candidate after boot, preserving stdout, stderr, exit code, and
monotonic start/end times in the signed evidence bundle:

```text
uname -m
uname -r
cat /etc/os-release
getconf GNU_LIBC_VERSION
cat /proc/1/comm
systemctl --version
systemctl is-system-running
stat -fc %T /sys/fs/cgroup
systemctl show --property=ControlGroup --value init.scope
findmnt --json
lsblk --json --output NAME,KNAME,TYPE,SIZE,FSTYPE,UUID,MOUNTPOINTS
containerd --version
runc --version
buildkitd --version
buildctl --version
resize2fs -V
xfs_growfs -V
```

The eventual harness must reject unless `uname -m` is `aarch64`, `/proc/1/comm`
is `systemd`, cgroups v2 is mounted, the manifest matches the booted packages,
the scratch device identity/nonce matches exactly, and the pre-deployment
attestation covers the harness and artifacts.

### Scenario command contract

The qualification harness does not yet exist; implementing it is an explicit
blocker, not something this audit fakes. Its stable invocation contract must be:

```text
runtime-qualification l1r verify-inputs --manifest <signed-manifest> --predeployment-evidence <signed-evidence>
runtime-qualification l1r systemd --manifest <signed-manifest> --scenario all
runtime-qualification l1r container --manifest <signed-manifest> --scenario all
runtime-qualification l1r buildkit --manifest <signed-manifest> --scenario all
runtime-qualification l1r filesystem --manifest <signed-host-manifest> --host-candidate <host-candidate-id> --filesystem ext4 --scratch-id <approved-id> --crash-checkpoint each
runtime-qualification l1r filesystem --manifest <signed-host-manifest> --host-candidate <host-candidate-id> --filesystem xfs --scratch-id <approved-id> --crash-checkpoint each
runtime-qualification evidence finalize --layer L1R --output <host-candidate-id>-l1r-evidence.json
runtime-qualification evidence verify <host-candidate-id>-l1r-evidence.json
```

`--scenario all` must include success plus denials, stale generation/fence,
timeout, cancellation, process/daemon crash, reboot, D-Bus/containerd reconnect,
resource exhaustion, signal/drain, credential redaction, log bounds, image-digest
mismatch, cache poisoning, and N/N-1 upgrade/rollback. Filesystem checkpoints
cover cloud/device-size observation (faked only at L1R), guest rescan, partition
or LVM growth if selected, filesystem grow, verification, reboot/fsck, and retry.
Known data is never formatted; shrink requests always fail.

L1R readiness passes only with four complete host-by-filesystem reports—OL9/ext4,
OL9/XFS, Ubuntu/ext4, and Ubuntu/XFS—plus both host/runtime reports. One ext4 and
one XFS report on different hosts is insufficient. A later owner choice may use
these comparable results; the harness must not mark a host or filesystem
selected.

## L4 evidence plan

L4 requires explicit cloud-mutation authorization, a credential scope limited to
fresh disposable resources, approved cost/TTL, default-closed ingress, and a
cleanup/quarantine owner. It repeats relevant L1R commands on the exact OCI A1
image and adds provider boundaries. Until an explicit coupled host/filesystem
selection deliberately narrows the matrix, L4 also requires all four host-by-
filesystem combinations because OCI image kernels, guest tooling, and provider
block integration can change the outcome.

```text
runtime-qualification l4 verify-inputs --manifest <signed-manifest> --predeployment-evidence <signed-evidence> --shape VM.Standard.A1.Flex
runtime-qualification l4 provision --manifest <signed-manifest> --ttl <approved-ttl> --ingress closed
runtime-qualification l4 host --scenario boot-reboot-replace-generation
runtime-qualification l4 orchestrator --artifact <linux-arm64-digest> --scenario start-health-restart-rollback
runtime-qualification l4 container --manifest-digest <multi-platform-digest> --scenario all
runtime-qualification l4 volume --host-candidate <host-candidate-id> --filesystem ext4 --scenario attach-rescan-expand-crash-detach-reattach
runtime-qualification l4 volume --host-candidate <host-candidate-id> --filesystem xfs --scenario attach-rescan-expand-crash-detach-reattach
runtime-qualification l4 boundaries --scenario iam-metadata-network-link-local-wrong-volume-stale-fence
runtime-qualification l4 performance --storage-slo <approved-slo> --runtime-budget <approved-budget>
runtime-qualification l4 cleanup --operation-id <operation-id>
runtime-qualification l4 inventory --operation-id <operation-id> --expect-empty-or-quarantined
runtime-qualification evidence finalize --layer L4 --output <candidate-id>-l4-evidence.json
runtime-qualification evidence verify <candidate-id>-l4-evidence.json
```

The L4 evidence must bind per-region image OCIDs, launch-template generation,
booted package manifest, kernel command line, shape/OCPU/memory, block-volume IDs
in hashed/redacted form, filesystem UUIDs, artifact/platform digests, every
provider work request, scenario results, performance measurements, cost window,
and cleanup inventory. A denied or incomplete inventory cannot claim cleanup.

Qualification fails on x86 execution, emulation standing in for A1, systemd not
being PID 1, mutable image aliases without resolved IDs, package drift, missing
runtime signature/hash, unexpected platform digest, skipped crash checkpoint,
unknown/wrong device, secret output, broad IAM, public ingress, SLO failure, or
unresolved cleanup ambiguity.

## Readiness decision

No component is selected. The only justified state is:

- two host-image candidates, both unqualified;
- ext4 and XFS candidates, both unqualified and unselected;
- all four host-by-filesystem combinations required independently at L1R and L4;
- systemd/containerd/runc/BuildKit tracks requiring exact pins and L1R/L4 proof;
- local x86_64 observation with zero qualification layers; and
- L1R/L4 not run because image/tool selections, harness, approved SLOs,
  pre-deployment evidence, and mutation authority do not yet exist.

The deterministic validator enforces this state and rejects adversarial attempts
to accept/select a candidate, masquerade x64 observation as ARM64 evidence,
remove a filesystem candidate or one required interaction pair, or cite an
unknown source.


---

# FILE: docs/audits/supply-chain/phase0-candidate-pins.md

# Phase 0 supply-chain candidate pins

- Audit date: 2026-07-13
- Status: candidate review only; no tool or signing technology selected
- Scope: official primary-source review plus checked-in deterministic metadata validation
- Execution: no candidate binary/package was downloaded, installed, restored, imported, or executed

## Outcome

The machine-readable candidate set is [`testlab/pins/supply-chain-candidates.json`](../../../testlab/pins/supply-chain-candidates.json). It records 13 version-specific candidates/alternatives and 6 explicit capability gaps. Every entry remains unselected, requires an internal mirror, and is marked not production-qualified. The manifest deliberately keeps artifact signing, evidence signing, and attestation-tool selections `null`.

The same manifest binds the already checked-in baseline without changing central files: .NET SDK `10.0.301`, `rollForward: latestFeature`, TUnit `1.56.18`, Microsoft.Testing.Platform `2.2.3`, and the SHA-256 of every checked-in NuGet lock file. This is observed repository state, not a new selection or qualification.

This distinction is necessary because the existing host audit observed BuildKit, containerd/runc, cosign, Notation, ORAS, Syft, Trivy, and Grype as absent; local presence would not have qualified them anyway ([local audit, lines 8-29](../toolchain/local-toolchain-audit.md#L8-L29)). The specification requires reproducible signed dual-architecture artifacts with SBOM/provenance ([ORCHESTRATOR.md, lines 351-365](../../../ORCHESTRATOR.md#L351-L365)), a broad deterministic verification stack ([ORCHESTRATOR.md, lines 1139-1150](../../../ORCHESTRATOR.md#L1139-L1150)), and exact-tree evidence signing before deployment credentials ([ORCHESTRATOR.md, lines 1175-1179](../../../ORCHESTRATOR.md#L1175-L1179)). A reviewed upstream version is therefore only an input to later selection and qualification.

## Existing checked-in baseline and closure gap

The baseline evidence comes from the checked-in [`global.json`](../../../global.json), [`Directory.Packages.props`](../../../Directory.Packages.props), and test [`packages.lock.json`](../../../tests/TerraScale.Orchestrator.ContractTests/packages.lock.json). The central package declaration pins TUnit `1.56.18`; the test lock resolves that version with its NuGet content hash and resolves the transitive Microsoft.Testing.Platform dependency to `2.2.3` with its content hash. The manifest also records the exact relative path and SHA-256 for every checked-in `packages.lock.json`, so adding, removing, or changing a lock file fails validation until the evidence is deliberately refreshed.

The SDK is **not an exact closure**. Although `global.json` names `10.0.301`, `rollForward: latestFeature` permits selection of the highest installed feature band and patch within the requested major/minor, as specified by the [official .NET `global.json` documentation](https://learn.microsoft.com/en-us/dotnet/core/tools/global-json). The manifest therefore sets `exactClosure` to `false` and makes the unresolved steward decision explicit. The validator rejects an exact-closure claim while these semantics remain checked in.

## Candidate evidence

All current version claims below point to the owning project's official release page or the official NuGet registry. “Candidate” does not mean “chosen,” “safe,” “mirrored,” or “compatible.”

| Capability | Candidate | Primary version evidence | Integrity/provenance observed upstream | Still required |
|---|---|---|---|---|
| Property testing | FsCheck 3.3.3 | [official NuGet package](https://www.nuget.org/packages/FsCheck/3.3.3) | Registry package metadata only in this audit | TUnit adapter, deterministic seeds/replay, locked content hash, mirror, .NET 10 proof |
| Coverage | Microsoft.CodeCoverage 18.7.0 | [official NuGet package](https://www.nuget.org/packages/Microsoft.CodeCoverage/18.7.0) | Registry package metadata only | Test-platform integration, branch denominator/exclusions, normalized deterministic output, content hash/mirror |
| Fuzzing | SharpFuzz 2.3.0 | [official NuGet package](https://www.nuget.org/packages/SharpFuzz/2.3.0) | Registry package metadata only | Native engine pin, ARM64 instrumentation, bounded corpus/replay, content hash/mirror |
| Mutation | dotnet-stryker 4.16.0 | [official NuGet package](https://www.nuget.org/packages/dotnet-stryker/4.16.0) | Registry package metadata only | TUnit/.NET 10 compatibility, stable denominator, safety-mutant policy, content hash/mirror |
| OCI builds | BuildKit 0.30.0 | [official release](https://github.com/moby/buildkit/releases/tag/v0.30.0) | Per-platform release assets advertise digests, SBOM, provenance, and Sigstore material | Exact hashes, independent verification/mirror, rootless/no-Docker-socket profile, cache/credential isolation, ARM64 reproducibility |
| Container daemon | containerd 2.3.3 | [official release](https://github.com/containerd/containerd/releases/tag/v2.3.3) | Official release and integrity assets; dynamic and static distributions differ | Artifact variant/hash, internal signature/mirror, gRPC window, L1R cgroup/seccomp/lifecycle, ARM64 |
| OCI runtime | runc 1.5.0 | [official release](https://github.com/opencontainers/runc/releases/tag/v1.5.0) | Official checksum/signature materials are not yet captured locally | Exact binary/build tags/hash, signature procedure/mirror, containerd matrix, L1R/L4 isolation behavior |
| Signing candidate | cosign 3.1.1 | [official release](https://github.com/sigstore/cosign/releases/tag/v3.1.1) | Official release verification bundles/checksums; not verified here | Owner selection, identity/KMS/trust-root model, offline verification, revocation/DR, Forgejo/OCIR proof, mirror |
| Signing candidate | Notation 1.3.2 | [official release](https://github.com/notaryproject/notation/releases/tag/v1.3.2) | Official signed release and release assets; not verified here | Owner selection, plugin/KMS/trust policy, revocation, Forgejo/OCIR proof, mirror |
| OCI artifact transport | ORAS CLI 1.3.2 | [official release](https://github.com/oras-project/oras/releases/tag/v1.3.2) | Official release assets; exact hashes not recorded here | Mirror/signature, referrer/media-type round trips in Forgejo/OCIR, digest immutability, regional replication |
| SBOM | Syft 1.46.0 | [official immutable release](https://github.com/anchore/syft/releases/tag/v1.46.0) | Checksums plus certificate/signature and SBOM materials | Exact hashes/mirror, SPDX/CycloneDX selection, reproducible normalization, .NET single-file/OCI coverage, license policy |
| Vulnerability | Grype 0.115.0 | [official immutable release](https://github.com/anchore/grype/releases/tag/v0.115.0) | Signed release/checksum/SBOM materials; release notes align its Syft dependency with 1.46.0 | Exact hashes/mirror, offline DB digest/freshness, SBOM fixture, severity/fix/VEX/risk policy |
| Reviewed alternative | Trivy 0.72.0 | [official release](https://github.com/aquasecurity/trivy/releases/tag/v0.72.0) | Later immutable release materials exist, but the project disclosed a 2026 release-pipeline compromise | Independent rebuild/verification and incident-control review before candidacy, mirror, database pin, overlap decision |

The Trivy caution is not inference from third-party reporting. The project's [official GHSA](https://github.com/aquasecurity/trivy/security/advisories/GHSA-69fq-xp46-6x23) states that compromised credentials published malicious Trivy binaries/images and rewrote action tags in March 2026. This audit does not claim 0.72.0 is compromised; it records why normal tag/version trust is insufficient and why the tool remains an alternative pending stronger provenance review.

## Architecture and integrity interpretation

Binary candidates list `linux-x64` and `linux-arm64` only where the official release distribution exposes those platform families. This is distribution availability, not TerraScale qualification. Exact archive/binary hashes have intentionally not been copied from a partial web rendering, and no artifact was downloaded to compute them. Selection must bind exact hashes for both architectures, upstream verification material, licenses, scanner databases, plugins/build tags, and the internally mirrored copies.

NuGet candidates list `any-dotnet` because they are managed packages/tools rather than a claim of native ARM64 qualification. Their official pages show compatible target frameworks, but TerraScale still needs a locked content hash, .NET 10/TUnit execution, deterministic result normalization, and ordinary-Linux/ARM64 evidence.

License fields are candidate metadata, not legal approval. Every license source is version-specific and official; transitive dependency licenses, generated SBOM assertions, unknown licenses, dual licensing, exceptions, and an owner-approved allow/deny policy remain `GAP-LICENSE-POLICY`.

## Explicit non-selections and gaps

No candidate is proposed yet for deterministic model/state-space exploration and systematic concurrency. A plausible library that cannot meet the specification's fixed schedule counts, virtual-clock injection, deterministic schedule replay, .NET 10, and ARM64 runner constraints would be a false pin. The same fail-closed posture leaves secret scanning, license-policy evaluation, and the exact NuGet advisory/deprecation/lock gate open.

Cosign and Notation are deliberately peers in the candidate set. Neither is selected for artifacts or evidence. ORAS is artifact transport and does not make a signing choice. DSSE/in-toto-style evidence is a required architectural shape, but the envelope implementation, signing identity, KMS/isolated-CI custody, roots, connected/offline verification, revocation, recovery, and Forgejo/OCIR compatibility require the future supply-chain ADR. The Phase 0 plan explicitly requires that selection rather than allowing this audit to make it ([ORCHESTRATOR.md, lines 1488-1492](../../../ORCHESTRATOR.md#L1488-L1492)).

Every selected external input also requires a content-addressed internal mirror and TerraScale verification/signature receipt. None exists from this package. Scanner databases are independently mutable inputs and need their own digest, freshness, offline-replay, rollback, and compromise policy; pinning only the scanner executable is insufficient.

## Validator and adversarial fixtures

The [`supply-chain` C# command](../../../tools/TerraScale.Orchestrator.Tooling/TranslatedCommands.cs) validates the candidate manifest, fail-closed qualification state, explicit gaps, checked-in SDK/package/lock sources, and each recorded lock-file SHA-256.

The data-driven [negative fixtures](../../../tools/phase0/supply-chain/fixtures/negative-cases.json) cover signing selection, floating version, `latest` URL, non-primary source, production qualification, false mirror readiness, missing ARM64, erased gaps, duplicate IDs, a synthetic secret-named field, selected status, unknown category, removal of the second signing candidate, SDK version/roll-forward drift, false SDK closure, TUnit/Microsoft.Testing.Platform drift, and lock path/digest drift.

Run:

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/supply-chain-candidates.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- supply-chain
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
```

These checks validate the evidence document, not the candidate tools. They do not satisfy L0, L1R, L3S, L4, signing, mirroring, reproducibility, or production qualification. The hard pre-deployment gate remains unchanged ([ORCHESTRATOR.md, lines 1114-1120](../../../ORCHESTRATOR.md#L1114-L1120)).


---

# FILE: docs/audits/toolchain/local-toolchain-audit.md

# Phase 0 local toolchain audit

- Audit date: 2026-07-13
- Host: NixOS 26.11, Linux 6.18.38, x86_64
- Scope: read-only command/path/version inspection only
- Qualification status: not a production, L1R, L3S, or L4 qualification

No package was installed or upgraded, no service or VM was started, and no cloud API was called. `oci --version` and `pulumi version` are local executable queries, not provider operations. Presence means only that the executable was found; it does not establish an approved pin, configuration, compatibility window, credential boundary, or runtime behavior.

## Findings

| Capability | Local observation | Readiness judgment | Required exit evidence |
|---|---|---|---|
| .NET SDK | `dotnet` 10.0.301 at `/home/mariogk/.local/bin/dotnet`; `global.json` requests 10.0.301 with `latestFeature` roll-forward | Baseline pin present; local NixOS publish is not portable release evidence | Pinned ordinary-Linux hermetic image; locked restore/build/test; reproducible x64/ARM64 digests; real A1 run |
| .NET test packages | TUnit 1.56.18 and YamlDotNet 18.1.0 are centrally pinned | Incomplete for the mandated property/model/fuzz/mutation/static-analysis suite | Select and centrally pin all test, coverage, mutation, fuzz, analyzer, vulnerability, license, and secret-scan tools |
| NATS server | `nats-server` v2.14.3 present | Version is observed but not selected/pinned; CLI `nats` is absent; N/N-1 policy and L0C evidence absent | Pin server/client/CLI and N/N-1 matrix; mirror artifacts; run credential-free L0C conformance |
| containerd/runc | Both absent | Runtime boundary unavailable locally | Pin versions and install only in an approved hermetic L1R image; prove gRPC/runtime/cgroup/seccomp contract |
| systemd | systemd 261 present; its local build-feature banner was recorded | Version observed, but this audit did not inspect PID 1 behavior or run D-Bus/unit tests | Pin production host version/image and run L1R systemd-as-PID-1 D-Bus, credentials, cgroups, journald, and rollback tests |
| BuildKit | `buildctl` and `buildkitd` absent | CI build engine unavailable locally | Pin client/daemon and worker isolation profile; prove rootless/isolated build and cache/publish boundaries |
| Rootless Podman | Replacement selected after this audit; no result is inherited from the retired hypervisor lane | Unqualified until fresh rootless status, version, network, storage-driver, cgroup, image-digest, isolation, resource-limit, and cleanup evidence is recorded | Pin Podman and image manifest digests; prove closed-catalog enforcement, nine-container startup, network isolation, persistence, limits, crash recovery, and orphan-free cleanup |
| OCI CLI | OCI CLI 3.89.1 present | Observed, not pinned; no authentication or cloud call attempted; SDK/API contract unqualified | Pin OCI .NET SDK/CLI used by approved tooling, cite API semantics, and defer mutation evidence to credential-gated L4 |
| Pulumi | Pulumi v3.251.0 present | Observed, not pinned; no stack/login/provider call attempted | Pin CLI/providers/plugins and hermetic runtime; model retain/unmanage/handoff; qualify only on fresh greenfield resources |
| ext4 tools | `resize2fs` 1.47.4 present | Partial local capability; no loop-device or online expansion test | Pin e2fsprogs in L1R image and run every expansion crash checkpoint |
| XFS tools | `xfs_growfs` absent | XFS candidate cannot be evaluated locally | Pin xfsprogs in L1R image and run the same online expansion/crash matrix as ext4 |
| Block discovery | util-linux `lsblk`, `findmnt`, and `blkid` 2.42.2 present | Read-only discovery commands available; not an allowlisted production adapter contract | Define typed allowlist/observations and prove wrong-device/UUID/provider-ID rejection |
| Partition/LVM growth | `growpart` and `parted` absent; `lvm` present but its version query could not access device-mapper as this user | Layout/growth path unqualified | Choose partition/LVM layout, pin required tools, and exercise permissioned loop/block harness in L1R |
| Signing | `cosign`, `notation`, and `oras` absent | No artifact/evidence signing implementation can be qualified | Select signing identity/format/tool, pin and mirror it, protect key/identity, prove verification and revocation |
| SBOM/vulnerability | `syft`, `trivy`, and `grype` absent | No SBOM or vulnerability scanner selected | Select and pin SBOM plus vulnerability/license policy tools; bind outputs into exact-tree evidence |
| ARM64 execution | Host is x86_64; `qemu-aarch64` and `aarch64-linux-gnu-gcc` absent | No local ARM64 execution or cross-toolchain qualification; cross-publish alone is insufficient | Qualify exact ARM64 artifact on approved OCI A1, with selected host loader/kernel/glibc and managed workload images |

## Exact inspection commands

The audit used only these non-mutating classes of command:

```text
uname -srmo
uname -m
read /etc/os-release
command -v <tool>
<tool> --version (or the tool's local version equivalent)
read global.json, Directory.Packages.props, and docs/audits/phase0-build-baseline.md
```

The `lvm version` query returned device-mapper permission errors, so no LVM version or usability claim is made. `resize2fs -V` printed 1.47.4 and then rejected the flag; only the version banner is recorded. Version output was bounded by a five-second timeout. No command used credentials or contacted an external endpoint.

## Blocking selections and measurements

The local machine cannot close Phase 0 toolchain readiness. The repository still needs approved pins for NATS and its N/N-1 window, Podman and image manifests, containerd/runc, BuildKit, host image/kernel/glibc, ext4/XFS tooling and layout, Pulumi/providers, OCI SDK, VPN, DNS, observability backends, regional artifact mirroring, signing/attestation, SBOM/vulnerability/license scanning, and the complete test stack. ARM64 remains an L4 real-A1 boundary.


---

# FILE: docs/audits/traceability/phase1-structured-traceability.json

{
  "schemaVersion": 1,
  "reportKind": "structured-traceability-foundation",
  "claimsAcceptanceEvidence": false,
  "inputSha256": "b34b56f169db742cc5840cbaa344fd7a37eec5e452181fae7743d5c1dba3755c",
  "counts": {
    "registered": 43,
    "gap": 43,
    "linked": 0,
    "acceptanceSatisfied": 0
  },
  "entries": [
    {
      "id": "REQ-O001",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O002",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O003",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O004",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "review",
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O005",
      "owner": "Runtime",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O006",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O007",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O008",
      "owner": "Operations",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O009",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O010",
      "owner": "Cloud",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O011",
      "owner": "Storage",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O012",
      "owner": "Runtime",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O013",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O014",
      "owner": "Delivery",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O015",
      "owner": "Delivery",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O016",
      "owner": "Operations",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O017",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L0C"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O018",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L1S",
        "L2S",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O019",
      "owner": "Cloud",
      "acceptanceLayers": [
        "L0",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O020",
      "owner": "Storage",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L3S",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O021",
      "owner": "Verification",
      "acceptanceLayers": [
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O022",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "review",
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "REQ-O023",
      "owner": "Cloud",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-001",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-002",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-003",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-004",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-005",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-006",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-007",
      "owner": "TerraBase",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-008",
      "owner": "TerraBase",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-009",
      "owner": "Storage",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-010",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-011",
      "owner": "Delivery",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-012",
      "owner": "Operations",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-013",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-014",
      "owner": "Cloud",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-015",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "review",
        "L0"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-016",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-017",
      "owner": "Runtime",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L3S"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "INV-018",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "ERR-PHASE0-NOTREADY",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "L0"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    },
    {
      "id": "SEC-NO-SECRET-OUTPUT",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "status": "gap",
      "gapReason": "complete typed production, test, and evidence links are not yet established",
      "productionLinks": [],
      "testLinks": [],
      "evidenceLinks": [],
      "acceptanceSatisfied": false
    }
  ]
}


---

# FILE: docs/audits/traceability/phase1-traceability.json

{
  "schemaVersion": 1,
  "reportKind": "draft-lexical-traceability",
  "claimsAcceptanceEvidence": false,
  "inputSha256": "96203dd62e54e24d6b0dc5d9fd96a19808411c639bf9957935144368af25514c",
  "counts": {
    "registered": 43,
    "linked": 6,
    "production-only": 0,
    "test-only": 1,
    "unreferenced": 36,
    "unknownReferences": 0
  },
  "unknownReferences": [],
  "entries": [
    {
      "id": "REQ-O001",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O002",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O003",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O004",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "review",
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O005",
      "owner": "Runtime",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O006",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O007",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O008",
      "owner": "Operations",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O009",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O010",
      "owner": "Cloud",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O011",
      "owner": "Storage",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O012",
      "owner": "Runtime",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O013",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O014",
      "owner": "Delivery",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O015",
      "owner": "Delivery",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O016",
      "owner": "Operations",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O017",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L0C"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O018",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L1S",
        "L2S",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O019",
      "owner": "Cloud",
      "acceptanceLayers": [
        "L0",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O020",
      "owner": "Storage",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L3S",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O021",
      "owner": "Verification",
      "acceptanceLayers": [
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O022",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "review",
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "REQ-O023",
      "owner": "Cloud",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-001",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-002",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-003",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-004",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "linked",
      "productionReferences": [
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 15
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 64
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 71
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 73
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 75
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 82
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 87
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 89
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 106
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 111
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 113
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 117
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 132
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 136
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 138
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 152
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 156
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 174
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 187
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 190
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 201
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 202
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 203
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 223
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 235
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 241
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 243
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 259
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 261
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 279
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 283
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 294
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 296
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 299
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 305
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 307
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 309
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 312
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 318
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 319
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 329
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 381
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 396
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 426
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 433
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 436
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 440
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 444
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 458
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 462
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 466
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 469
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 496
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 505
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 509
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 513
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 519
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 529
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 100
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 113
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 134
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 143
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 152
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 158
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 176
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 183
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 241
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 292
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 328
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 360
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 387
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 422
        }
      ],
      "testReferences": [
        {
          "path": "tests/TerraScale.Orchestrator.ControlPlane.Tests/AuthorityEngineTests.cs",
          "line": 371
        },
        {
          "path": "tests/TerraScale.Orchestrator.ControlPlane.Tests/OperationEngineTests.cs",
          "line": 5
        }
      ]
    },
    {
      "id": "INV-005",
      "owner": "Core",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "linked",
      "productionReferences": [
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 27
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 36
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 44
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 48
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 52
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 67
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 91
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 109
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 170
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 172
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 183
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 204
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 220
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 221
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 255
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 257
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 326
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 339
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 342
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 348
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 376
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 378
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 415
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 485
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 527
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 537
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 546
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs",
          "line": 555
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Messaging/MessagingPolicyEngine.cs",
          "line": 8
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 30
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 43
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 53
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 60
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 106
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 119
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 150
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 154
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 156
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 189
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 200
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 221
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 227
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 254
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 256
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 288
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 326
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 333
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 349
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 356
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 358
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 371
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 394
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 402
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 407
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 428
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 443
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 467
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Reconciliation/ReconciliationEngine.cs",
          "line": 7
        },
        {
          "path": "src/TerraScale.Orchestrator.Protocol/CommandValidation.cs",
          "line": 181
        }
      ],
      "testReferences": [
        {
          "path": "tests/TerraScale.Orchestrator.ControlPlane.Tests/OperationEngineTests.cs",
          "line": 5
        },
        {
          "path": "tests/TerraScale.Orchestrator.ControlPlane.Tests/ReconciliationEngineTests.cs",
          "line": 5
        },
        {
          "path": "tests/TerraScale.Orchestrator.Protocol.Tests/CommandEnvelopeValidatorTests.cs",
          "line": 5
        }
      ]
    },
    {
      "id": "INV-006",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "linked",
      "productionReferences": [
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 247
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 262
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 300
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 307
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 313
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 330
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 362
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 435
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 449
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 452
        },
        {
          "path": "src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs",
          "line": 461
        }
      ],
      "testReferences": [
        {
          "path": "tests/TerraScale.Orchestrator.ControlPlane.Tests/OperationEngineTests.cs",
          "line": 5
        }
      ]
    },
    {
      "id": "INV-007",
      "owner": "TerraBase",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-008",
      "owner": "TerraBase",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-009",
      "owner": "Storage",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-010",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-011",
      "owner": "Delivery",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-012",
      "owner": "Operations",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-013",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "L0",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "linked",
      "productionReferences": [
        {
          "path": "src/TerraScale.Orchestrator.Scheduler/Availability/AvailabilityPolicyEvaluator.cs",
          "line": 7
        },
        {
          "path": "src/TerraScale.Orchestrator.Scheduler/DeterministicScheduler.cs",
          "line": 8
        }
      ],
      "testReferences": [
        {
          "path": "tests/TerraScale.Orchestrator.Scheduler.Tests/DeterministicSchedulerTests.cs",
          "line": 12
        }
      ]
    },
    {
      "id": "INV-014",
      "owner": "Cloud",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-015",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "review",
        "L0"
      ],
      "evidenceState": "missing",
      "traceStatus": "test-only",
      "productionReferences": [],
      "testReferences": [
        {
          "path": "tests/TerraScale.Orchestrator.ContractTests/GeneratedSchemaTests.cs",
          "line": 40
        }
      ]
    },
    {
      "id": "INV-016",
      "owner": "Verification",
      "acceptanceLayers": [
        "L0",
        "L3S",
        "L4",
        "L5"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "INV-017",
      "owner": "Runtime",
      "acceptanceLayers": [
        "L0",
        "L1R",
        "L3S"
      ],
      "evidenceState": "missing",
      "traceStatus": "linked",
      "productionReferences": [
        {
          "path": "src/TerraScale.Orchestrator.Contracts/Resources/AdmittedRoles.cs",
          "line": 53
        },
        {
          "path": "src/TerraScale.Orchestrator.Contracts/Resources/RoleDescriptor.cs",
          "line": 222
        }
      ],
      "testReferences": [
        {
          "path": "tests/TerraScale.Orchestrator.ContractTests/GeneratedSchemaTests.cs",
          "line": 30
        },
        {
          "path": "tests/TerraScale.Orchestrator.ContractTests/GeneratedSchemaTests.cs",
          "line": 40
        },
        {
          "path": "tests/TerraScale.Orchestrator.ModelTests/ResourceContractTests.cs",
          "line": 8
        }
      ]
    },
    {
      "id": "INV-018",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "ERR-PHASE0-NOTREADY",
      "owner": "Integration/contract steward",
      "acceptanceLayers": [
        "L0"
      ],
      "evidenceState": "missing",
      "traceStatus": "unreferenced",
      "productionReferences": [],
      "testReferences": []
    },
    {
      "id": "SEC-NO-SECRET-OUTPUT",
      "owner": "Messaging/security",
      "acceptanceLayers": [
        "L0",
        "L0C",
        "L3S",
        "L4"
      ],
      "evidenceState": "missing",
      "traceStatus": "linked",
      "productionReferences": [
        {
          "path": "src/TerraScale.Orchestrator.Contracts/Resources/RoleDescriptor.cs",
          "line": 224
        }
      ],
      "testReferences": [
        {
          "path": "tests/TerraScale.Orchestrator.ContractTests/GeneratedSchemaTests.cs",
          "line": 40
        },
        {
          "path": "tests/TerraScale.Orchestrator.Protocol.Tests/SubjectPermissionTests.cs",
          "line": 19
        },
        {
          "path": "tests/TerraScale.Orchestrator.Protocol.Tests/SubjectPermissionTests.cs",
          "line": 33
        },
        {
          "path": "tests/TerraScale.Orchestrator.Protocol.Tests/SubjectPermissionTests.cs",
          "line": 34
        },
        {
          "path": "tests/TerraScale.Orchestrator.Protocol.Tests/SubjectPermissionTests.cs",
          "line": 35
        }
      ]
    }
  ]
}


---

# FILE: docs/decisions/README.md

# Phase 0 owner decision and SLO packet

Status: owner choices 1A–10A accepted on 2026-07-16 with reliability first; measurable targets and later implementation selections remain pending.

The machine-readable packet is `owner-decision-packet.json`. Its validator binds each decision to the exact table row in `ORCHESTRATOR.md`, including Markdown semantics, source line, and SHA-256 over the four cells joined by ASCII unit separator. The recorded `answer` must match the explicit owner response; the `recommended` field is historical decision context only.

## Owner questions (exact source text)

| # | Question | A — selected | B |
|---|---|---|---|
| 1 | Regional control topology | Three controller candidates plus three control-NATS servers in **each** region: 9 of each across GRU/SFO/FRA, with independent regional JetStream R3 consensus | Three total controllers/NATS servers, one per region; this creates a WAN quorum and requires rewriting the regional-autonomy invariants |
| 2 | GRU/WAN outage deployments | Regions keep serving, healing, replacing/scaling nodes, expanding storage, and renewing existing identities; freeze new global releases/policy changes | Allow each isolated region to accept independent releases/policy changes |
| 3 | Vault authority | Built-in policy/PKI/lease/rotation service with ciphertext/root protection in OCI Vault/KMS initially | Store envelope-encrypted authoritative ciphertext in a dedicated, isolated vault JetStream account/stream from v1; never ordinary subjects or plaintext |
| 4 | Runtime defaults | Native systemd for TerraBase; containers for API/Auth/Dashboard initially; both supported where useful | Choose a different default split |
| 5 | Elastic data cleanup | Never shrink; retain permanent disks; quarantine a removed elastic TerraBase disk for 7 days after verified backup | Immediately delete explicitly disposable elastic disks after safe topology removal |
| 6 | Provider implementation timing | Finish OCI plus a provider-neutral contract first; OCI's catalog must expose at least 20 usable regions, while GRU/SFO/FRA are the first activated/qualified cells; add another adapter when needed | Require a second complete cloud adapter before the first production deployment |
| 7 | CI/CD bootstrap exception | Keep one minimal independent Forgejo workflow/runner solely to build and recover the orchestrator; all product CI/CD is orchestrator-native | Require even orchestrator recovery CI to run inside the orchestrator, accepting the circular outage dependency |
| 8 | “Dedicated NATS” meaning | Dedicated means independent clusters/processes/security/cgroups/stores; both planes may share benchmarked compact-profile hosts | “Dedicated” meant separate physical compute nodes for control NATS and product NATS, increasing the regional floor |
| 9 | Telemetry during long GRU outage | Export all three OTel signals, spool to a fixed encrypted disk budget, then drop oldest/sample with explicit data-loss alerts; product traffic never blocks | Never drop telemetry, requiring another durable regional telemetry store and an explicit maximum outage/cost design |
| 10 | Container count during autoscaling tests | Nine seed node containers are the exact steady-state topology; explicit tests may add temporary `*-elastic-*` containers and must converge back to 3/cell | Nine is a hard ceiling; replacement can be tested, but real scale-out beyond three cannot be demonstrated in the full-region lab |

## Readiness boundary

Questions 1–10 are resolved as A. Cost, per-member storage performance/latency, regional RPO/RTO, security, memory/density, audit retention, and maximum disconnected regional-survival targets remain null until Phase 0 evidence supports honest values. They block the affected deployment and production qualification gates, while pure contracts model them as explicit inputs.

Team size and desired first-production date are Phase 0 planning inputs requested “when available”; they are not falsely promoted to architecture choices. Artifact/evidence signing, DNS, VPN, operator identity provider, regional artifact mirror, ARM64 host image, and NATS N/N-1 policy are explicitly segregated as later Phase 0 implementation selections. They remain null and do not masquerade as answers to the owner questions.

The ADR mappings use the canonical 1–24 IDs from `ORCHESTRATOR.md:1681-1704` and match the Phase 0 readiness map. Gate labels name the specification’s contract freeze, Phase 0 exit, and acceptance layers; they indicate downstream impact, not evidence that a gate passed.

## Recorded owner response

The explicit response governing this packet is:

```text
all A; reliability first
```

Unknown numeric values are filled only from approved evidence. Until then, cost policy may stop non-safety growth but cannot reduce availability, durability, backup, storage-integrity, or security floors.

## Validation

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- owner-decisions
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format docs/decisions/owner-decision-packet.json
git diff --check
```

The adversarial fixtures prove rejection of decision drift, a missing question, an invalid option, a changed unit, exact specification semantic drift, and accidental selection of a later implementation dependency.


---

# FILE: docs/decisions/owner-decision-packet.json

{
  "schemaVersion": 1,
  "status": "owner-choices-accepted-measurable-targets-pending",
  "contract": "ORCHESTRATOR.md decisions 1A-10A accepted 2026-07-16",
  "source": {"path": "ORCHESTRATOR.md", "questionTableLines": "87-98", "planningInputLines": "100-105"},
  "decisionPolicy": {
    "recommendationIsNotDefault": true,
    "unmeasuredTargetsRemainNull": true,
    "allowedAnswers": ["A"],
    "answerOriginRequired": "explicit-owner-response"
  },
  "recordedResponse": {"receivedOn": "2026-07-16", "answer": "all A", "priority": "reliability-first"},
  "questions": [
    {"id": 1, "question": "Regional control topology", "optionA": "Three controller candidates plus three control-NATS servers in **each** region: 9 of each across GRU/SFO/FRA, with independent regional JetStream R3 consensus", "optionB": "Three total controllers/NATS servers, one per region; this creates a WAN quorum and requires rewriting the regional-autonomy invariants", "recommended": "A", "answer": "A", "sourceLine": 89, "semanticSha256": "7f0faabb929de282d9758bd859022e160831b0b2b4871e2f41ec883bf6d4cdc9", "impactedAdrs": [1, 2], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L0C", "L3S"]},
    {"id": 2, "question": "GRU/WAN outage deployments", "optionA": "Regions keep serving, healing, replacing/scaling nodes, expanding storage, and renewing existing identities; freeze new global releases/policy changes", "optionB": "Allow each isolated region to accept independent releases/policy changes", "recommended": "A", "answer": "A", "sourceLine": 90, "semanticSha256": "49bc2a3cfbae259ff93873243f02295eb80154ced4f7eea018b22d41da562273", "impactedAdrs": [1, 21], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L3S", "L4", "L5"]},
    {"id": 3, "question": "Vault authority", "optionA": "Built-in policy/PKI/lease/rotation service with ciphertext/root protection in OCI Vault/KMS initially", "optionB": "Store envelope-encrypted authoritative ciphertext in a dedicated, isolated vault JetStream account/stream from v1; never ordinary subjects or plaintext", "recommended": "A", "answer": "A", "sourceLine": 91, "semanticSha256": "7d5437aa6d8b30b3a0c9c4fbc6c27ae8ef2b963da05f620cc9b2852c4eeec917", "impactedAdrs": [12, 21], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L0C", "L3S", "L4"]},
    {"id": 4, "question": "Runtime defaults", "optionA": "Native systemd for TerraBase; containers for API/Auth/Dashboard initially; both supported where useful", "optionB": "Choose a different default split", "recommended": "A", "answer": "A", "sourceLine": 92, "semanticSha256": "862a158022f8eefe24974673463173565546a3675082716ea03facdde633e03b", "impactedAdrs": [6, 10], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L1R", "L3S", "L4"]},
    {"id": 5, "question": "Elastic data cleanup", "optionA": "Never shrink; retain permanent disks; quarantine a removed elastic TerraBase disk for 7 days after verified backup", "optionB": "Immediately delete explicitly disposable elastic disks after safe topology removal", "recommended": "A", "answer": "A", "sourceLine": 93, "semanticSha256": "a6aae5a7b2a36f5df3027a0c29c1e9fcdb77b5a0fc1d7f242d949113b8381b54", "impactedAdrs": [9, 10], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L3S", "L4", "L5"]},
    {"id": 6, "question": "Provider implementation timing", "optionA": "Finish OCI plus a provider-neutral contract first; OCI's catalog must expose at least 20 usable regions, while GRU/SFO/FRA are the first activated/qualified cells; add another adapter when needed", "optionB": "Require a second complete cloud adapter before the first production deployment", "recommended": "A", "answer": "A", "sourceLine": 94, "semanticSha256": "21ea101380c4d0231b4c312a6d676127b5aeb06f6708c02b0204e9fedbd7d69c", "impactedAdrs": [16, 19], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L4", "L5"]},
    {"id": 7, "question": "CI/CD bootstrap exception", "optionA": "Keep one minimal independent Forgejo workflow/runner solely to build and recover the orchestrator; all product CI/CD is orchestrator-native", "optionB": "Require even orchestrator recovery CI to run inside the orchestrator, accepting the circular outage dependency", "recommended": "A", "answer": "A", "sourceLine": 95, "semanticSha256": "bd27c32cf76a9f23b6eb9ff64ac5ca82f4a8e058a899a4cef8d6fdb27d5ff690", "impactedAdrs": [14], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L3S"]},
    {"id": 8, "question": "“Dedicated NATS” meaning", "optionA": "Dedicated means independent clusters/processes/security/cgroups/stores; both planes may share benchmarked compact-profile hosts", "optionB": "“Dedicated” meant separate physical compute nodes for control NATS and product NATS, increasing the regional floor", "recommended": "A", "answer": "A", "sourceLine": 96, "semanticSha256": "941c98978f807fd22df5059ed1e0141bdcb49b705c1f0132a9809671b2805ac4", "impactedAdrs": [2, 8], "impactedGates": ["contract-freeze", "phase-0-exit", "L0C", "L3S", "L4", "L5"]},
    {"id": 9, "question": "Telemetry during long GRU outage", "optionA": "Export all three OTel signals, spool to a fixed encrypted disk budget, then drop oldest/sample with explicit data-loss alerts; product traffic never blocks", "optionB": "Never drop telemetry, requiring another durable regional telemetry store and an explicit maximum outage/cost design", "recommended": "A", "answer": "A", "sourceLine": 97, "semanticSha256": "8612e50a855e8a2d57c827eb71e3f7c071bcd7d7c2b6d184ab6cfa13572a84c9", "impactedAdrs": [17], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L3S", "L5"]},
    {"id": 10, "question": "Container count during autoscaling tests", "optionA": "Nine seed node containers are the exact steady-state topology; explicit tests may add temporary `*-elastic-*` containers and must converge back to 3/cell", "optionB": "Nine is a hard ceiling; replacement can be tested, but real scale-out beyond three cannot be demonstrated in the full-region lab", "recommended": "A", "answer": "A", "sourceLine": 98, "semanticSha256": "fb7d73640d4fe388f2446b9ab4da284d2dd0d7519d531e98acde4efdc0001433", "impactedAdrs": [10], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L3S"]}
  ],
  "inputs": [
    {"id": "team-size", "readinessStage": "phase-0-planning", "requiredBeforeContractFreeze": false, "value": null, "unit": "people", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [19], "impactedGates": ["phase-0-planning"]},
    {"id": "first-production-date", "readinessStage": "phase-0-planning", "requiredBeforeContractFreeze": false, "value": null, "unit": "ISO-8601-date-or-quarter", "validation": {"type": "string", "pattern": "^(\\d{4}-\\d{2}-\\d{2}|\\d{4}-Q[1-4])$"}, "impactedAdrs": [19], "impactedGates": ["phase-0-planning"]},
    {"id": "maximum-three-region-pre-user-cost", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "BRL/day", "validation": {"type": "number", "exclusiveMinimum": 0}, "impactedAdrs": [5, 8, 19, 24], "impactedGates": ["contract-freeze", "phase-0-exit", "L5"]},
    {"id": "storage-minimum-iops-per-member", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "IOPS", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [2, 3, 5, 8, 9, 10, 19], "impactedGates": ["contract-freeze", "phase-0-exit", "L1R", "L3S", "L4", "L5"]},
    {"id": "storage-minimum-throughput-per-member", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "MiB/s", "validation": {"type": "number", "exclusiveMinimum": 0}, "impactedAdrs": [2, 3, 5, 8, 9, 10, 19], "impactedGates": ["contract-freeze", "phase-0-exit", "L1R", "L3S", "L4", "L5"]},
    {"id": "storage-p95-read-latency", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "ms", "validation": {"type": "number", "minimum": 0}, "impactedAdrs": [2, 3, 5, 8, 9, 10, 19], "impactedGates": ["contract-freeze", "phase-0-exit", "L1R", "L3S", "L4", "L5"]},
    {"id": "storage-p99-read-latency", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "ms", "validation": {"type": "number", "minimum": 0}, "impactedAdrs": [2, 3, 5, 8, 9, 10, 19], "impactedGates": ["contract-freeze", "phase-0-exit", "L1R", "L3S", "L4", "L5"]},
    {"id": "storage-p95-write-latency", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "ms", "validation": {"type": "number", "minimum": 0}, "impactedAdrs": [2, 3, 5, 8, 9, 10, 19], "impactedGates": ["contract-freeze", "phase-0-exit", "L1R", "L3S", "L4", "L5"]},
    {"id": "storage-p99-write-latency", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "ms", "validation": {"type": "number", "minimum": 0}, "impactedAdrs": [2, 3, 5, 8, 9, 10, 19], "impactedGates": ["contract-freeze", "phase-0-exit", "L1R", "L3S", "L4", "L5"]},
    {"id": "regional-rpo", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "seconds", "validation": {"type": "integer", "minimum": 0}, "impactedAdrs": [1, 3, 9, 10, 12, 19, 21, 24], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L0C", "L3S", "L4", "L5"]},
    {"id": "regional-rto", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "minutes", "validation": {"type": "integer", "minimum": 0}, "impactedAdrs": [1, 3, 9, 10, 12, 19, 21, 24], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L3S", "L4", "L5"]},
    {"id": "security-credential-revocation", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "seconds", "validation": {"type": "integer", "minimum": 0}, "impactedAdrs": [11, 17], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L0C", "L3S", "L4"]},
    {"id": "security-workload-certificate-ttl", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "hours", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [11], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L0C", "L3S", "L4"]},
    {"id": "security-certificate-renewal-lead", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "hours", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [11], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L0C", "L3S", "L4"]},
    {"id": "security-break-glass-session-ttl", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "minutes", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [17], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L3S", "L5"]},
    {"id": "security-critical-remediation", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "hours", "validation": {"type": "integer", "minimum": 0}, "impactedAdrs": [11, 17], "impactedGates": ["contract-freeze", "phase-0-exit"]},
    {"id": "memory-orchestrator-rss-per-host", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "MiB", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [7, 8], "impactedGates": ["contract-freeze", "phase-0-exit", "L3S", "L4"]},
    {"id": "density-compact-post-failure-utilization-ceiling", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "percent", "validation": {"type": "number", "exclusiveMinimum": 0, "maximum": 100}, "impactedAdrs": [7, 8], "impactedGates": ["contract-freeze", "phase-0-exit", "L3S", "L4", "L5"]},
    {"id": "audit-hot-retention", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "days", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [3], "impactedGates": ["contract-freeze", "phase-0-exit", "L0C", "L3S"]},
    {"id": "audit-immutable-retention", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "days", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [3], "impactedGates": ["contract-freeze", "phase-0-exit", "L3S", "L4", "L5"]},
    {"id": "maximum-regional-survival-window", "readinessStage": "deployment-qualification", "requiredBeforeContractFreeze": false, "value": null, "unit": "hours", "validation": {"type": "integer", "minimum": 1}, "impactedAdrs": [11, 12, 21], "impactedGates": ["contract-freeze", "phase-0-exit", "L0", "L3S", "L4", "L5"]}
  ],
  "laterImplementationSelections": [
    {"id": "artifact-and-evidence-signing", "readinessStage": "later-phase0-selection", "requiredBeforeContractFreeze": false, "selection": null, "impactedAdrs": [14, 23], "impactedGates": ["phase-0-exit", "L0"]},
    {"id": "dns-implementation", "readinessStage": "later-phase0-selection", "requiredBeforeContractFreeze": false, "selection": null, "impactedAdrs": [15], "impactedGates": ["phase-0-exit", "L3S", "L4"]},
    {"id": "vpn-implementation", "readinessStage": "later-phase0-selection", "requiredBeforeContractFreeze": false, "selection": null, "impactedAdrs": [16], "impactedGates": ["phase-0-exit", "L3S", "L4"]},
    {"id": "operator-identity-provider", "readinessStage": "later-phase0-selection", "requiredBeforeContractFreeze": false, "selection": null, "impactedAdrs": [17], "impactedGates": ["phase-0-exit", "L3S", "L5"]},
    {"id": "regional-artifact-mirror", "readinessStage": "later-phase0-selection", "requiredBeforeContractFreeze": false, "selection": null, "impactedAdrs": [21], "impactedGates": ["phase-0-exit", "L3S", "L4"]},
    {"id": "arm64-host-image", "readinessStage": "later-phase0-selection", "requiredBeforeContractFreeze": false, "selection": null, "impactedAdrs": [22], "impactedGates": ["phase-0-exit", "L1R", "L4"]},
    {"id": "nats-n-minus-one-policy", "readinessStage": "later-phase0-selection", "requiredBeforeContractFreeze": false, "selection": null, "impactedAdrs": [22], "impactedGates": ["phase-0-exit", "L0C", "L3S"]}
  ],
  "recordedCompactResponse": "all A; reliability first"
}


---

# FILE: docs/decisions/tests/fixtures/accidental-default.json

{"name":"accepted decision drift","operation":"set","path":["questions",0,"answer"],"value":"B","expected":"question 1: answer must match the explicit owner selection A"}


---

# FILE: docs/decisions/tests/fixtures/invalid-option.json

{"name":"invalid option","operation":"set","path":["questions",1,"answer"],"value":"C","expected":"question 2: answer must match the explicit owner selection A"}


---

# FILE: docs/decisions/tests/fixtures/invalid-unit.json

{"name":"invalid unit","operation":"set","path":["inputs",2,"unit"],"value":"USD/month","expected":"input maximum-three-region-pre-user-cost: unit must be BRL/day"}


---

# FILE: docs/decisions/tests/fixtures/later-selection-default.json

{"name":"accidental later selection default","operation":"set","path":["laterImplementationSelections",0,"selection"],"value":"cosign","expected":"selection artifact-and-evidence-signing: checked-in selection must remain null"}


---

# FILE: docs/decisions/tests/fixtures/missing-question.json

{"name":"missing question","operation":"delete","path":["questions",4],"expected":"questions must be 1..10 exactly once"}


---

# FILE: docs/decisions/tests/fixtures/source-semantic-drift.json

{"name":"question source semantic drift","operation":"replace-spec","old":"| 1 | Regional control topology |","new":"| 1 | Regional control topology drift |","expected":"question 1: question differs from ORCHESTRATOR.md:89"}


---

# FILE: docs/retirement/workaround-ledger.yaml

schema_version: 1
ledger_version: 2026-07-13
scope:
  predecessor_commit: 9aaa07e
  posture: greenfield
  source_repositories:
    - TerraBase
    - Terrabase.Operator
    - TerraScale.Internals
    - TerraScale.DotNet
    - TerraScale.TypeScript
    - TerraScale.Infrastructure
    - TerraScale.Deploy
    - TerraScale.DevHost
    - Terrascale.Documentation
    - Terrascale.Landingpage
  source_provenance:
    - repository: TerraBase
      head: 349cd1a11e5b252ffc193d3c3cdf059b954828fd
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: Terrabase.Operator
      head: b3b105be880e169d62e3cb4506846b8a11342d5c
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: TerraScale.Internals
      head: 3643df207f9f1129c9f677148e6890d436339141
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: TerraScale.DotNet
      head: 9d98e4e3dc3e05eb955ba06f03b05bf462cfb21b
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: TerraScale.TypeScript
      head: 7d9b629ce5a5d41a3fa457911305b057749e3252
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: TerraScale.Infrastructure
      head: 3bfdb4ee0124fbcce43e7db57cf00045f374fbcb
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: TerraScale.Deploy
      head: cacb596cd0f6f25a40e76160554fecc14f047965
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: TerraScale.DevHost
      head: dd2b8762beb85199578ee41bdfafc199e977a0b4
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: Terrascale.Documentation
      head: ccca078a99f4d0702d4e55ac02d6585277ea08e9
      checkout_state: branch
      branch: develop
      dirty: false
    - repository: Terrascale.Landingpage
      head: 0a763469d3d086e672be673b080a97dbc31dff26
      checkout_state: branch
      branch: develop
      dirty: false
  scan_method: >-
    Read-only repository scan for Kubernetes, OKE, Flux, kubectl, retry and polling,
    manual mutation, duplicated state, certificate copying, fixed region/count,
    autoscaling, storage, observability, Grafana, and deployment glue. Generated
    artifacts were retained as evidence when they are shipped or consumed.
  exclusions:
    - Ordinary customer-facing retry semantics with idempotency and Retry-After are product behavior, not retirement workarounds.
    - TerraBase upstream compatibility code unrelated to orchestration is outside this ledger.
    - The static Landingpage remains externally hosted and is not an orchestrator workload.
  repository_findings:
    TerraBase: Historical release evidence corroborates Flux notification and polling failure modes; native database behavior is preserved.
    Terrabase.Operator: Kubernetes controller, StatefulSet, PVC, Job, webhook, certificate, and polling behavior is covered by WRK-006, WRK-010, and WRK-020.
    TerraScale.Internals: Missing Authentication build inventory is covered by WRK-016; no sibling files were changed.
    TerraScale.DotNet: No orchestration workaround requiring retirement was identified; public retry/idempotency behavior is explicitly preserved.
    TerraScale.TypeScript: Fixed provider-specific region catalog and GRU fallback are covered by WRK-015 and WRK-022.
    TerraScale.Infrastructure: OKE, Flux, admission, secret, autoscaling, observability, VPN, and residual-estate findings are covered by WRK-001 through WRK-018.
    TerraScale.Deploy: Forced reconciliation, kubectl fan-out, polling, and release-writer coordination are covered by WRK-003 through WRK-005 and WRK-019.
    TerraScale.DevHost: No production workaround requiring retirement was identified; it remains a local-only supervisor.
    Terrascale.Documentation: Fixed region and manually synchronized contract documentation are covered by WRK-017, WRK-021, and WRK-022.
    Terrascale.Landingpage: No runtime orchestration workaround was identified; launch-region marketing copy must follow the generated public catalog under WRK-017.

mandatory_fields:
  - id
  - status
  - evidence
  - original_constraint
  - preserved_behavior
  - native_replacement
  - owner_workstream
  - removal
  - regression
  - recovery_boundary
  - cleanup_proof

entries:
  - id: WRK-001
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 66
        detail: Production capacity is defined as three managed OKE node pools with Kubernetes-specific floors.
      - repository: TerraScale.Infrastructure
        path: src/TerraScale.Infrastructure/Program.cs
        line: 13
        detail: Pulumi foundation hard-codes the OCI home region used by the deleted OKE estate.
    original_constraint: Kubernetes required an OKE control plane, CNI/CSI, managed pools, DaemonSets, and duplicate controllers before any product workload could run.
    preserved_behavior: Isolated application, platform, and TerraBase capacity with measured resource admission, failure-domain spread, and elastic growth.
    native_replacement: Direct A1 instances managed by a regional scheduler and one host agent using cgroups v2, systemd, and containerd without a pod ceiling.
    owner_workstream:
      primary: Cloud
      collaborators: [Runtime, Core, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-L3S-host-admission, pr: pending-WRK-001}
    regression: {layer: L3S-and-L4, scenario: compact-profile density, one-host loss, scale-out, scale-in, and seven-day cost gate}
    recovery_boundary: Pulumi retains durable network/IAM/bootstrap ownership; the regional controller resumes concrete node operations from its journal.
    cleanup_proof: Repository scan plus provider inventory show no OKE cluster, node pool, CNI/CSI resource, kubeconfig, or charged orphan remains in the new ownership graph.

  - id: WRK-002
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: gitops/clusters/production-gru/reconciliation.yaml
        line: 70
        detail: Flux Kustomization disables readiness waiting; the same pattern repeats in GRU, SFO, and FRA.
      - repository: TerraScale.Infrastructure
        path: gitops/bootstrap/flux/sync.yaml
        line: 29
        detail: Bootstrap reconciliation also uses wait false.
    original_constraint: Flux dependency health and acknowledgement were insufficiently reliable, so reconciliation returned before dependent workloads were healthy.
    preserved_behavior: Ordered dependencies, asynchronous progress, health gates, and restart-safe acknowledgement.
    native_replacement: Typed dependency and health state machines with a journaled operation receipt that is acknowledged only after the configured durable checkpoint.
    owner_workstream:
      primary: Delivery
      collaborators: [Core, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-native-reconcile-L3S, pr: pending-WRK-002}
    regression: {layer: L2-plus-L3S, scenario: dependency failure and controller restart at every acknowledgement checkpoint}
    recovery_boundary: The regional journal and last accepted CellSpec remain authoritative when Git, GRU, or the controller process is unavailable.
    cleanup_proof: All Flux Kustomizations and bootstrap sync resources are deleted and CI rejects wait-false or Flux API resources.

  - id: WRK-003
    status: identified
    evidence:
      - repository: TerraScale.Deploy
        path: src/TerraScale.Deploy.Cli/Services/ServiceReleasePipeline.cs
        line: 959
        detail: The release pipeline always requests kubectl reconciliation after sending the webhook.
      - repository: TerraBase
        path: bench/TerraBase.Replication.Benchmark/history/20260710T031822Z-production-terrabase-v0.1.35/summary.md
        line: 25
        detail: Historical rollout failed when the Flux receiver token was absent and interval polling became the fallback.
      - repository: TerraScale.Infrastructure
        path: gitops/controllers/flux-image-automation/production-sfo/receivers.yaml
        line: 2
        detail: Per-region Flux Receiver resources expose webhook-triggered reconciliation.
    original_constraint: A webhook did not prove reconciliation, so the pipeline forced a second kubectl action and still depended on interval polling.
    preserved_behavior: Prompt deployment triggering, durable acceptance, safe replay, and a clear operator-visible failure when a trigger cannot be accepted.
    native_replacement: One signed native reconcile command journaled before acknowledgement with generation, deadline, idempotency key, and fenced writer identity.
    owner_workstream:
      primary: Delivery
      collaborators: [Messaging/security, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-command-journal-L3S, pr: pending-WRK-003}
    regression: {layer: L2-plus-L3S, scenario: webhook loss, NATS loss, controller crash, duplicate command, and stale-writer replay}
    recovery_boundary: The command is replayed from regional JetStream and cannot complete under a stale generation or fence.
    cleanup_proof: Flux Receivers, webhook token secrets, forced kubectl reconcile code, related IAM/Vault material, and endpoint/DNS remnants are absent.

  - id: WRK-004
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: gitops/controllers/flux-image-automation/production-gru/image-update-automation.yaml
        line: 45
        detail: Secondary image writers are suspended to approximate single-writer ownership.
      - repository: TerraScale.Infrastructure
        path: gitops/controllers/flux-image-automation/production-sfo/image-update-automation.yaml
        line: 10
        detail: Regional ImageUpdateAutomation writers are statically suspended.
    original_constraint: Multiple image automation controllers could race, so configuration used suspension and rollout-guard coordination to approximate exclusive publication.
    preserved_behavior: Build-once immutable candidates, exact-digest promotion, one release writer, and safe rollback.
    native_replacement: Fenced release writer plus promotion lease and compare-and-swap generation over the immutable candidate digest.
    owner_workstream:
      primary: Delivery
      collaborators: [Core, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-release-fencing-L3S, pr: pending-WRK-004}
    regression: {layer: L2-plus-L3S, scenario: concurrent publishers, lease expiry, stale writer, partial promotion, and adversarial rollback}
    recovery_boundary: A replacement writer resumes only after acquiring a newer fence; accepted digests are immutable.
    cleanup_proof: ImageUpdateAutomation resources, suspend toggles, rollout-guard scripts/controllers, and associated permissions are deleted.

  - id: WRK-005
    status: identified
    evidence:
      - repository: TerraScale.Deploy
        path: src/TerraScale.Deploy.Cli/Services/ServiceReleasePipeline.cs
        line: 280
        detail: Release validation requires kubectl and fans rollout state through Kubernetes contexts.
      - repository: TerraScale.Deploy
        path: src/TerraScale.Deploy.Cli/Notifications/NotifyDeploymentCommand.cs
        line: 384
        detail: Deployment completion is polled on a configurable interval.
    original_constraint: Kubernetes rollout state had to be polled and stitched together with shell phases and per-context kubectl invocations.
    preserved_behavior: Cross-region progress, explicit failure reporting, exact-digest convergence, timeout, and resumable deployment.
    native_replacement: Typed regional deployment operations with explicit checkpoints, idempotent resume, and a global same-digest barrier.
    owner_workstream:
      primary: Delivery
      collaborators: [Operations, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-deployment-state-machine-L3S, pr: pending-WRK-005}
    regression: {layer: L2-plus-L3S, scenario: crash at every phase, regional timeout, WAN loss, partial convergence, and retry}
    recovery_boundary: Each region completes or resumes its own accepted operation; global promotion freezes during WAN loss.
    cleanup_proof: kubectl rollout/context code and shell phase recovery are removed, with no Kubernetes credential packaged into CI or the orchestrator.

  - id: WRK-006
    status: identified
    evidence:
      - repository: Terrabase.Operator
        path: api/v1/cluster_types.go
        line: 7
        detail: The CRD advertises StatefulSet, Service, Ingress, Job, ServiceAccount, and ConfigMap actors.
      - repository: Terrabase.Operator
        path: bundle/terrabase-operator/1.2.0/manifests/terrabase-operator.clusterserviceversion.yaml
        line: 127
        detail: Shipped operator metadata owns StatefulSets.
    original_constraint: Kubernetes objects supplied identity, storage attachment, initialization jobs, admission, upgrades, and process lifecycle.
    preserved_behavior: Stable members and volumes, topology safety, one-member upgrades, backup/restore, health, certificate naming, and autoscaling holds.
    native_replacement: C# TerraBase member, volume, topology, upgrade, backup, and restore state machines over typed TerraBase administration APIs.
    owner_workstream:
      primary: TerraBase
      collaborators: [Runtime, Storage, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-terrabase-L3S-and-destructive-suite, pr: pending-WRK-006}
    regression: {layer: L2-plus-L3S-plus-L4, scenario: port all operator safety tests and crash each destructive checkpoint}
    recovery_boundary: Stable member/volume identity and fenced operation journals survive agent/controller replacement; permanent members are never removed.
    cleanup_proof: CRDs, operator deployment, StatefulSets, Jobs, PVC actors, webhooks, bootstrap ConfigMaps/scripts, RBAC, and images are absent after compatibility proof.

  - id: WRK-007
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: src/TerraScale.Infrastructure/ObservabilityIngestTls.cs
        line: 101
        detail: One observability ingest client certificate is provisioned for edge forwarding.
      - repository: Terrabase.Operator
        path: config/certmanager/certificate.yaml
        line: 2
        detail: cert-manager Certificate resources supply operator webhook identity.
    original_constraint: cert-manager/cainjector automated Kubernetes certificates while edge telemetry shared one client identity.
    preserved_behavior: Automated issuance, DNS names, trust bundles, renewal, revocation, and mutually authenticated privileged channels.
    native_replacement: Regional PKI with unique workload identities, short leases, dual-bundle rotation, revocation, and selective mTLS.
    owner_workstream:
      primary: Messaging/security
      collaborators: [Runtime, Operations, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-PKI-rotation-L3S, pr: pending-WRK-007}
    regression: {layer: L2-plus-L3S, scenario: identity uniqueness, renewal, dual-bundle rotation, revocation, stolen certificate, and captured-output scan}
    recovery_boundary: Existing identities renew regionally during GRU loss; root protection remains in OCI KMS/Vault.
    cleanup_proof: cert-manager, cainjector, shared client certificate, Kubernetes TLS secrets, issuers, RBAC, and related DNS challenges are absent.

  - id: WRK-008
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: gitops/observability/runtime-secrets/production/external-secrets.yaml
        line: 2
        detail: Runtime credentials are materialized through ExternalSecret resources.
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 74
        detail: The historical autoscaler uses instance-principal authentication across discovered pools.
    original_constraint: External Secrets copied durable cloud secrets into Kubernetes, while node-level instance principals needed broad access for generic controllers.
    preserved_behavior: Durable encrypted secret storage, automated delivery/rotation, and cloud-native workload authentication.
    native_replacement: Closed vault policy and lease delivery over workload-scoped identity with compartment-minimal OCI dynamic groups and policies.
    owner_workstream:
      primary: Messaging/security
      collaborators: [Cloud, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-vault-denial-L3S, pr: pending-WRK-008}
    regression: {layer: L2-plus-L3S-plus-L4, scenario: cross-workload denial, stolen node, expired lease, rotation, and OCI IAM negative tests}
    recovery_boundary: Ciphertext/root protection stays in OCI Vault/KMS; regional lease renewal follows the approved GRU-outage contract.
    cleanup_proof: ExternalSecret/SecretStore controllers and CRs, Kubernetes secret copies, broad dynamic groups/policies, and unused Vault entries are removed or quarantined.

  - id: WRK-009
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: gitops/observability/resources/production/prometheus-rules.yaml
        line: 124
        detail: Kyverno is a monitored admission-policy runtime dependency.
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 104
        detail: Kubernetes platform isolation depends on taints, tolerations, and admission policy.
    original_constraint: A generic Kubernetes API required admission policies to reject unsafe arbitrary objects and placements after submission.
    preserved_behavior: Closed role admission, isolation, resource bounds, capability denial, and validation before execution.
    native_replacement: Exhaustive C# role catalog, schema, and compiler that rejects unknown roles, privileges, host paths, devices, and capabilities before persistence.
    owner_workstream:
      primary: Runtime
      collaborators: [Integration/contract steward, Core, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-admission-model-tests, pr: pending-WRK-009}
    regression: {layer: L1-plus-L2, scenario: exhaustive invalid role, capability, device, mount, runtime, and placement manifests}
    recovery_boundary: Only previously validated signed CellSpecs are executable during disconnection.
    cleanup_proof: Kyverno controllers, policies, exceptions, CRDs, RBAC, and admission webhooks are absent and CI rejects Kubernetes admission APIs.

  - id: WRK-010
    status: identified
    evidence:
      - repository: Terrabase.Operator
        path: api/v1/storage_types.go
        line: 79
        detail: TerraBase storage is expressed as a Kubernetes PersistentVolumeClaim source.
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 156
        detail: Documentation promises PVC auto-expansion to the OCI Block Volume limit.
    original_constraint: PVC/CSI exposed a resize request but did not prove provider, attachment, device, filesystem, and TerraBase logical-capacity completion end to end.
    preserved_behavior: Stable single-writer volumes, expand-only storage, online capacity growth, utilization gates, and explicit operator status.
    native_replacement: Journaled provider-to-application expansion state machine with fence, generation, device rescan, filesystem growth, TerraBase verification, and checkpoints.
    owner_workstream:
      primary: Storage
      collaborators: [TerraBase, Cloud, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-destructive-storage-L3S-and-L4, pr: pending-WRK-010}
    regression: {layer: L2-plus-L3S-plus-L4, scenario: crash and stale writer at every cloud, attach, device, filesystem, and application checkpoint}
    recovery_boundary: Volume identity and operation journal survive host loss; expansion never rolls back or attaches to two writers.
    cleanup_proof: StorageClass/CSI/PVC resize glue and claims are deleted and real OCI evidence proves volume, filesystem, and TerraBase capacity agree.

  - id: WRK-011
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 69
        detail: Historical node-pool minima/maxima are encoded independently for app, database, and tools pools.
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 130
        detail: Application HPAs separately encode replica minima and maxima.
    original_constraint: HPA scheduled pods without capacity while Cluster Autoscaler supplied nodes, producing duplicated floors and contradictory ownership.
    preserved_behavior: Demand-based application replicas, TerraBase R3 floor, capacity scale-out, safe scale-in, budget limits, and anti-oscillation.
    native_replacement: One scheduler/provider autoscaler using measured resources, SLOs, topology floors, quotas, storage constraints, and cost budgets.
    owner_workstream:
      primary: Core
      collaborators: [Cloud, TerraBase, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-autoscaling-L3S-and-L4, pr: pending-WRK-011}
    regression: {layer: L2-plus-L3S-plus-L4, scenario: burst, oscillation, capacity denial, orphan cleanup, database floor, and cost ceiling}
    recovery_boundary: Each region scales within pre-authorized limits during GRU/WAN loss and never removes permanent TerraBase members.
    cleanup_proof: HPA, Cluster Autoscaler, node-pool autoscaler tags/IAM, and contradictory replica/pool settings are absent.

  - id: WRK-012
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: gitops/observability/resources/production/prometheus-rules.yaml
        line: 253
        detail: Platform inventory depends on kube-state-metrics.
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 197
        detail: Regional observability explicitly depends on Prometheus Operator, node exporter, and kube-state-metrics.
    original_constraint: Kubernetes labels and ServiceMonitor/PodMonitor discovery were the authoritative target and workload inventory.
    preserved_behavior: Complete server/workload inventory, stable labels, scrape/OTLP discovery, alerts, dashboards, and bounded cardinality.
    native_replacement: Host-agent registry and OTel discovery with canonical TerraScale identity labels and generated targets, dashboards, and alerts.
    owner_workstream:
      primary: Operations
      collaborators: [Runtime, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-full-inventory-L3S, pr: pending-WRK-012}
    regression: {layer: L2-plus-L3S, scenario: all-server inventory, restart, stale target removal, label stability, and cardinality budget}
    recovery_boundary: Edge collectors keep local bounded spool and discovery while GRU telemetry ingest is unavailable.
    cleanup_proof: ServiceMonitor, PodMonitor, kube-state-metrics, pod-label discovery, and Kubernetes scrape RBAC are absent.

  - id: WRK-013
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: gitops/observability/resources/production/terrascale-service-dashboards.yaml
        line: 7
        detail: Grafana dashboards are provisioned through Kubernetes ConfigMaps.
      - repository: TerraScale.Infrastructure
        path: gitops/observability/runtime-secrets/production/external-secrets.yaml
        line: 4
        detail: Grafana administrator state depends on a Kubernetes-projected secret.
    original_constraint: Grafana provisioning/persistence was Kubernetes-local and operational state was inferred indirectly from metrics.
    preserved_behavior: Immutable dashboards, replicated Grafana availability, durable data sources, and exact read-only operational status.
    native_replacement: Immutable replicated Grafana provisioning plus mandatory sanitized orchestrator projection/data source with generation and freshness.
    owner_workstream:
      primary: Operations
      collaborators: [Integration/contract steward, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-GRU-one-node-loss-L3S, pr: pending-WRK-013}
    regression: {layer: L2-plus-L3S, scenario: one-node loss, stale projection, dashboard/data-source rebuild, and unauthorized-field scan}
    recovery_boundary: Grafana is read-only; mutations remain in audited API/CLI and authoritative state stays in replicated control journals.
    cleanup_proof: Kubernetes Grafana Deployment/ConfigMap/PVC/Secret glue is gone and a fresh host rebuild reproduces dashboards and exact status.

  - id: WRK-014
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 54
        detail: Local access assumes Tailscale, while no complete production route-policy lifecycle is identified in repository source.
      - repository: TerraScale.Infrastructure
        path: Pulumi.production-sfo.yaml
        line: 20
        detail: Durable regional connectivity is represented by fixed remote-peering identifiers rather than a complete workload VPN lifecycle.
    original_constraint: Documents assumed private connectivity but did not implement production VPN peer, route, ACL, identity, and secret lifecycle end to end.
    preserved_behavior: Private cross-region control/telemetry paths, least-privilege routes, peer rotation, and regional autonomy.
    native_replacement: Selected established WireGuard implementation managed by a TerraScale route-policy controller and durable Pulumi networking.
    owner_workstream:
      primary: Operations
      collaborators: [Cloud, Messaging/security, Cross-repository cleanup, Verification]
    removal: {phase: qualification-before-production, pr: pending-WRK-014}
    regression: {layer: L3S-plus-L4, scenario: GRU-control loss, peer rotation/revocation, route denial, OCI UDP, and failover}
    recovery_boundary: Existing regional peers/routes continue during GRU loss; new global policy freezes unless break-glass is audited.
    cleanup_proof: Inventory proves obsolete routes, ACLs, keys, endpoints, public IPs, and peering remnants are removed or explicitly retained as independent Pulumi primitives.

  - id: WRK-015
    status: identified
    evidence:
      - repository: TerraScale.TypeScript
        path: src/regions.ts
        line: 15
        detail: The SDK embeds a three-entry OCI-specific region catalog.
      - repository: TerraScale.Infrastructure
        path: src/TerraScale.Infrastructure/Program.cs
        line: 13
        detail: Infrastructure embeds sa-saopaulo-1 as the OCI home region.
    original_constraint: Three launch regions and OCI codes were duplicated as compile-time constants across clients, infrastructure, and documentation.
    preserved_behavior: Stable gru/sfo/fra aliases, client compatibility, residency metadata, and deterministic region selection.
    native_replacement: Signed provider-discovered catalog with stable aliases, eligibility evidence, and at least twenty qualified OCI regions.
    owner_workstream:
      primary: Cloud
      collaborators: [Integration/contract steward, Cross-repository cleanup, Verification]
    removal: {phase: contract-freeze-and-client-cleanup, pr: pending-WRK-015}
    regression: {layer: L1-plus-L2-plus-L4, scenario: catalog signature, alias compatibility, unknown region, provider discovery, and twenty-region eligibility matrix}
    recovery_boundary: Last accepted signed catalog remains usable regionally; activation changes require global authority.
    cleanup_proof: Production code/docs contain no provider-specific fixed trio except explicit compatibility fixtures generated from the catalog.

  - id: WRK-016
    status: identified
    evidence:
      - repository: TerraScale.Internals
        path: .terrascale/deploy.json
        line: 17
        detail: Build targets include API and Dashboard but omit the production Authentication process.
      - repository: TerraScale.Deploy
        path: src/TerraScale.Deploy.Cli/Services/ServiceProfileDiscovery.cs
        line: 18
        detail: Release behavior selects either explicit deploy configuration or repository discovery rather than one exhaustive admitted-role graph.
    original_constraint: CI/release configuration evolved independently by repository and branch, leaving a production role outside the build target inventory.
    preserved_behavior: Affected-change validation, per-role tests, build once, immutable candidates, approval, exact promotion, and bootstrap recovery exception.
    native_replacement: Exhaustive admitted-role/build inventory and one typed native pipeline graph, with a minimal independent orchestrator recovery workflow.
    owner_workstream:
      primary: Delivery
      collaborators: [Integration/contract steward, Runtime, Cross-repository cleanup, Verification]
    removal: {phase: native-pipeline-L3S, pr: pending-WRK-016}
    regression: {layer: L1-plus-L2-plus-L3S, scenario: affected-change matrix, every admitted role built, digest immutability, approval, and bootstrap recovery}
    recovery_boundary: The independent bootstrap lane can rebuild the orchestrator when the orchestrator is unavailable; product pipelines resume from journals.
    cleanup_proof: Conflicting workflows/descriptors are removed, every production role maps to exactly one build target, and no branch rebuilds a promoted digest.

  - id: WRK-017
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: AGENTS.md
        line: 130
        detail: HPA replica values are maintained in prose independently of manifests and verifiers.
      - repository: Terrascale.Documentation
        path: src/content/docs/en/reference/regions.svx
        line: 74
        detail: Public documentation declares a fixed three-region canonical catalog.
    original_constraint: Documentation, manifests, verification code, and dashboards independently encoded RF, replica, region, and storage claims.
    preserved_behavior: Clear public promises, executable validation, localized documentation, dashboards, and operational runbooks.
    native_replacement: Canonical versioned C# contracts generate JSON Schema, docs facts, dashboards, alerts, and fixtures; drift fails CI.
    owner_workstream:
      primary: Integration/contract steward
      collaborators: [Operations, Cross-repository cleanup, Verification]
    removal: {phase: contract-freeze, pr: pending-WRK-017}
    regression: {layer: L1-plus-L2, scenario: generated-artifact cleanliness and deliberate RF, minima, storage, and catalog mutation}
    recovery_boundary: Generated artifacts identify their contract version and remain usable with the last accepted CellSpec.
    cleanup_proof: Hand-maintained duplicate counts/claims are removed or explicitly marked explanatory; regeneration produces a clean tree.

  - id: WRK-018
    status: identified
    evidence:
      - repository: TerraScale.Infrastructure
        path: src/TerraScale.Infrastructure/Program.cs
        line: 366
        detail: Pulumi still derives a Flux receiver webhook credential.
      - repository: TerraScale.Infrastructure
        path: gitops/controllers/flux-image-automation/production-sfo/receiver-secret.yaml
        line: 2
        detail: Deleted-estate credentials are materialized as ExternalSecret resources.
      - repository: TerraScale.Infrastructure
        path: Pulumi.production-gru.yaml
        line: 19
        detail: Historical stack configuration retains concrete regional peer resource identifiers.
    original_constraint: The deleted OKE estate leaves repository configuration and potentially cloud IAM, DNS, secrets, load balancers, volumes, IPs, and documentation outside any live adoption path.
    preserved_behavior: Safe inventory, ownership attribution, unrelated-resource protection, auditable deletion, and quarantine of unknown ownership.
    native_replacement: Greenfield Pulumi state and resource IDs; read-only provider/repository inventory with removal only after positive stale-resource identification and approval.
    owner_workstream:
      primary: Cross-repository cleanup
      collaborators: [Operations, Cloud, Verification]
    removal: {phase: phase-0-inventory-then-approved-cleanup-packages, pr: one-WRK-scoped-PR-per-repository}
    regression: {layer: L1-plus-L3S-plus-L4, scenario: forbidden Kubernetes/Flux parser and credential scan plus provider orphan inventory}
    recovery_boundary: Cleanup PRs are independently revertible; unknown and unrelated resources are quarantined rather than adopted or deleted.
    cleanup_proof: Signed old/new inventory accounts for repository paths and cloud/IAM/DNS/secret artifacts and proves the new runtime has no compatibility path.

  - id: WRK-019
    status: identified
    evidence:
      - repository: TerraScale.Deploy
        path: src/TerraScale.Deploy.Cli/Kubernetes/KubectlRetry.cs
        line: 7
        detail: Fixed transient-discovery delays retry kubectl when Kubernetes API discovery fails.
      - repository: TerraScale.Deploy
        path: src/TerraScale.Deploy.Cli/Services/ServiceReleasePipeline.cs
        line: 20
        detail: A fixed three-second polling interval drives the Flux notification barrier.
      - repository: TerraScale.Deploy
        path: src/TerraScale.Deploy.Cli/Notifications/NotifyDeploymentCommand.cs
        line: 796
        detail: Rollout polling is configured through a deployment environment variable.
    original_constraint: Eventually consistent Kubernetes discovery and Flux status forced CLI-local polling and transient retry policy without a durable operation subscription.
    preserved_behavior: Tolerate transient control-plane unavailability, bounded wait, cancellation, progress, and actionable timeout diagnostics.
    native_replacement: Durable command receipts and event-driven operation observation over NATS with bounded reconnect/backoff and authoritative terminal status.
    owner_workstream:
      primary: Operations
      collaborators: [Delivery, Messaging/security, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-operation-watch-L3S, pr: pending-WRK-019}
    regression: {layer: L2-plus-L3S, scenario: disconnect, reconnect, missed event replay, cancellation, deadline, duplicate terminal event, and controller restart}
    recovery_boundary: Consumers resume from durable sequence and query authoritative state; loss of the watch connection never changes operation ownership.
    cleanup_proof: Kubernetes discovery retries, Flux barrier polling, rollout poll environment variables, and kubectl dependencies are absent from native paths.

  - id: WRK-020
    status: identified
    evidence:
      - repository: Terrabase.Operator
        path: cmd/main.go
        line: 93
        detail: The controller hosts a Kubernetes admission webhook server with mounted serving certificates.
      - repository: Terrabase.Operator
        path: config/default/manager_webhook_patch.yaml
        line: 16
        detail: Webhook TLS is injected through a Kubernetes Secret volume.
      - repository: Terrabase.Operator
        path: api/v1/replication_types.go
        line: 121
        detail: Cross-region database mirroring is driven by a configured polling interval.
    original_constraint: Kubernetes admission and Secret mounts supplied trust/bootstrap, while replication observation used controller polling.
    preserved_behavior: Fail-closed configuration validation, certificate readiness, replication peer trust, mirror convergence, and bounded reconciliation cadence.
    native_replacement: Validate typed TerraBase plans before persistence, deliver certificates through the host identity boundary, and reconcile replication from typed admin state/events with bounded fallback polling only at the TerraBase API boundary.
    owner_workstream:
      primary: TerraBase
      collaborators: [Messaging/security, Runtime, Cross-repository cleanup, Verification]
    removal: {phase: cleanup-after-terrabase-bootstrap-L3S, pr: pending-WRK-020}
    regression: {layer: L1-plus-L2-plus-L3S, scenario: invalid plan, missing/rotated certificate, peer revocation, mirror lag, restart, and stale generation}
    recovery_boundary: A region can validate and renew existing TerraBase identities locally; topology changes remain fenced and journaled.
    cleanup_proof: Admission webhook, serving Secret mount, cert-manager injection, bootstrap hooks, and Kubernetes poll controllers are removed after behavioral parity tests pass.

  - id: WRK-021
    status: identified
    evidence:
      - repository: Terrascale.Documentation
        path: src/content/docs/en/reference/api/index.svx
        line: 20
        detail: Routes without checked-in OpenAPI artifacts are documented manually from endpoint source.
      - repository: Terrascale.Documentation
        path: src/content/docs/en/guides/api-strategy.svx
        line: 77
        detail: The docs sync script copies only a fixed subset of checked-in OpenAPI artifacts.
    original_constraint: Incomplete generated API artifacts required manual documentation and a fixed copy list, creating another source of truth.
    preserved_behavior: Complete public API reference, localized narrative guidance, examples, and stable customer contracts.
    native_replacement: Generate complete public OpenAPI and documentation inputs from the canonical endpoint/contract registry, with coverage and drift gates.
    owner_workstream:
      primary: Integration/contract steward
      collaborators: [Delivery, Cross-repository cleanup, Verification]
    removal: {phase: contract-generation, pr: pending-WRK-021}
    regression: {layer: L1-plus-L2, scenario: every public route represented, no internal route leaked, localization source complete, and clean regeneration}
    recovery_boundary: Published docs remain versioned artifacts independent of control-plane availability.
    cleanup_proof: Manual endpoint-source transcription and fixed OpenAPI copy lists are removed; route inventory equals generated reference inventory.

  - id: WRK-022
    status: identified
    evidence:
      - repository: TerraScale.TypeScript
        path: src/regions.ts
        line: 81
        detail: Empty or invalid region selections silently fall back to GRU.
      - repository: Terrascale.Documentation
        path: src/content/docs/en/reference/regions.svx
        line: 25
        detail: Documentation separately promises the same SDK-specific GRU normalization.
      - repository: TerraScale.TypeScript
        path: src/regions.test.ts
        line: 41
        detail: Tests freeze invalid-region fallback to GRU as expected behavior.
    original_constraint: A compile-time three-region SDK needed a deterministic fallback, but silently treating invalid input as GRU hid catalog and placement errors.
    preserved_behavior: Backward-compatible empty-selection default where contractually approved, canonical aliases, deterministic ordering, and clear validation.
    native_replacement: Catalog-aware selection distinguishes absent preference from invalid/unavailable region, preserves the approved default explicitly, and returns typed placement errors.
    owner_workstream:
      primary: Integration/contract steward
      collaborators: [Cloud, Cross-repository cleanup, Verification]
    removal: {phase: catalog-contract-freeze, pr: pending-WRK-022}
    regression: {layer: L1-plus-L2, scenario: absent selection, invalid alias, unavailable region, stale catalog, compatibility version, and explicit GRU preference}
    recovery_boundary: Last accepted catalog and explicit placement policy determine regional behavior during catalog-authority loss.
    cleanup_proof: No SDK silently converts invalid regions to GRU; docs and generated tests describe the single canonical default/validation contract.

gaps:
  - id: GAP-WRK-001
    disposition: follow-up-required
    detail: No live OCI mutation or inventory was authorized by this package, so cloud/IAM/DNS/secret remnants in WRK-018 are repository-evidenced but not yet provider-proven.
    follow_up: Create a read-only residual-account inventory package, then one explicitly approved cleanup package per positively identified remnant.
  - id: GAP-WRK-002
    disposition: follow-up-required
    detail: Owner decisions 1A-10A are accepted; measurable storage, cost, RPO, and RTO targets remain deployment-qualification gates, not blockers for repository cleanup whose native replacement evidence is green.
    follow_up: Convert each pending cleanup identifier only after its native replacement and repository-local regression gate pass; do not wait on unrelated numeric targets.
  - id: GAP-WRK-003
    disposition: explicit-none-found
    detail: The read-only scan found no distinct production-orchestrator retirement workaround in TerraScale.DotNet, TerraScale.DevHost, or Terrascale.Landingpage beyond cross-repository generated-contract drift already dispositioned above.
    follow_up: Re-scan these repositories when their native workload descriptors or generated catalogs are introduced.


---

# FILE: docs/work-packages/handoffs/phase0-adr-readiness.md

# Phase 0 ADR and toolchain readiness handoff

- Work package predecessor: `de9be9f`
- Branch starting point observed by this lane: `bc04125`
- Scope changed: `docs/adr/**`, `docs/audits/toolchain/**`, and this handoff only
- Destructive/external actions: none

## Result

All 24 initial ADR backlog items are represented exactly once in `docs/adr/readiness-index.yaml`. The readiness distribution is:

- 4 `draft-ready`
- 3 `evidence-required`
- 17 `owner-input-required`
- 0 `accepted`

The four choice-preserving drafts that can proceed now are ADR 4 (Pulumi/provider ownership), ADR 13 (native GitOps), ADR 18 (placement boundary), and ADR 20 (provider-actuator threat model). Draft-ready does not accept their remaining implementation details.

Numbered owner questions 1 through 10 all control at least one mapped ADR. The additional owner planning blockers are team/date, maximum three-region cost, storage performance/latency, regional RPO/RTO, and Phase 0 security/memory/survival targets. No recommendation was converted into an owner decision.

## Local audit summary

Observed locally: .NET SDK 10.0.301, `nats-server` 2.14.3, systemd 261, OCI CLI 3.89.1, Pulumi 3.251.0, ext4 tooling, util-linux block discovery, and LVM with insufficient device-mapper permission for a valid version/usability claim. Rootless Podman qualification replaces the retired hypervisor lane and requires fresh evidence.

Absent locally: NATS CLI, containerd, runc, BuildKit, XFS tools, growpart, parted, cosign, notation, oras, syft, trivy, grype, qemu-aarch64, and an AArch64 compiler. Observed versions are not approved pins unless a checked-in pin says so. ARM64, systemd-as-PID-1, OCI, filesystem, and destructive-operation qualification remain assigned to their required real-system layers.

## Validation commands

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- adr-readiness
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format docs/adr/readiness-index.yaml
git diff --check
```

The validator derives and checks the exact owner lane names and ADR titles against `ORCHESTRATOR.md`. It resolves every local evidence `path:start-end` anchor, rejects missing/out-of-bounds/blank ranges, and requires each `draft-ready` item to cite both the specification and an audit or retirement-ledger range. Adversarial fixtures prove rejection of a missing ADR, stale line anchor, accepted/open-owner conflict, unknown lane, and unknown dependency.

The original tool audit additionally used bounded local `command -v` and version queries plus host/kernel/architecture reads. Its retired hypervisor evidence has been removed and cannot qualify the rootless-container lane. It did not start a service, container, or cloud operation.

## Suggested next work packages

1. Owner-decision and SLO freeze packet for questions 1–10 plus cost/storage/RPO/RTO/team/date/security/memory/survival inputs.
2. Draft the four `draft-ready` ADRs as explicitly proposed records with alternatives and exit gates, leaving implementation selections open.
3. Supply-chain/toolchain pin package covering ordinary-Linux .NET, property/model/fuzz/mutation tooling, signing/attestation, SBOM/security scanning, BuildKit, containerd/runc, and internal mirrors.
4. NATS version/N/N-1 and L0C package covering server/client/CLI pins, JWT permissions, gateways, JetStream durability, snapshot/restore, and peer replacement.
5. ARM64 host/runtime package selecting the LTS image/kernel/glibc/filesystem candidates and defining L1R/L4 evidence.
6. Provider TCO/region/storage benchmark package and sanitized read-only OCI inventory; these unblock ADRs 5, 8, 9, 19, and 24 without granting mutation authority.


---

# FILE: docs/work-packages/handoffs/phase0-arm64-runtime-readiness.md

# Phase 0 ARM64 runtime readiness handoff

- Branch: `docs/phase0-arm64-runtime-readiness`
- Work package: `docs/work-packages/phase0-arm64-runtime-readiness.md`
- Scope changed: `docs/audits/runtime/**`, `testlab/pins/arm64-runtime-*.json`, `tools/phase0/runtime-readiness/**`, and this handoff
- External/destructive actions: none

## Result

The readiness record compares Oracle Linux 9 and Ubuntu 24.04 LTS standard OCI
aarch64 platform-image families without selecting either. Ubuntu 26.04 LTS is a
watch item because Canonical documents ARM64 LTS support but the current cited
OCI platform-image catalog does not list it.

ext4 and XFS remain equally unqualified candidates. systemd remains coupled to
the eventual host image; upstream and distribution containerd/runc tracks and
upstream BuildKit 0.30 remain candidates with exact builds unset. No LTS claim is
made for BuildKit.

The current machine was inspected read-only as NixOS x86_64. Its kernel, glibc,
PID 1, systemd tools, root filesystem, and tool presence are recorded only as
local observations with no qualification layer. No ARM64 execution occurred.

The audit defines fail-closed L1R and L4 command contracts, required immutable
inputs, scenario matrices, evidence bindings, failure criteria, and cleanup
proof. Both layers require OL9/ext4, OL9/XFS, Ubuntu/ext4, and Ubuntu/XFS until a
later explicit coupled selection deliberately narrows the matrix. The
qualification harness is intentionally recorded as missing rather than
represented as runnable.

## Validation

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- runtime-readiness
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/arm64-runtime-candidates.json
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet test TerraScale.Orchestrator.slnx --no-build --no-restore -- --disable-logo --no-progress
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- adr-readiness
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
git diff --check
```

The adversarial overlays prove rejection of an accepted/selected proposal, an
ARM64-qualified local-observation masquerade, a missing filesystem comparison,
an incomplete host-by-filesystem interaction matrix, and an unknown evidence
source.

## Remaining gates

1. Owner-approved host image and filesystem ADR after comparable evidence; this package cannot select them.
2. Immutable per-region image IDs, exact package manifests, mirror/signature policy, and runtime pairing/pins.
3. Approved storage SLO, memory/runtime budget, cost/TTL, and destructive scratch/cloud authorization.
4. Implemented qualification harness and valid exact-tree L0/L0C pre-deployment attestation.
5. Real aarch64 systemd-as-PID-1 L1R for all four host-by-filesystem combinations.
6. Explicitly authorized disposable OCI A1 L4 for all four combinations, runtime boundaries, performance, replacement, and cleanup.

No image was downloaded, package installed, service/VM started, filesystem
changed, cloud API called, or sibling/shared file edited.


---

# FILE: docs/work-packages/handoffs/phase0-ci-descriptor-inventory.md

# Phase 0 CI descriptor inventory handoff

- Branch: `docs/phase0-ci-descriptor-inventory`
- Changed paths: `docs/audits/delivery/**`, `tools/phase0/delivery-inventory/**`, and this handoff
- Sibling effects: none; all evidence used immutable Git objects
- Workflow/build/deploy execution: none

## Result

The deterministic inventory covers 10 pinned sibling repositories, 156 classified first-party descriptors, 2 referenced local build scripts, 9 delivery summaries, 4 production roles, 4 unresolved policy conflicts, and 4 open coverage gaps. Every descriptor is tied to its repository commit, path, Git blob, mode, and type. Exact line citations for roles and conflicts resolve inside pinned blobs. Ten adversarial fixtures include explicit dependency-lock and referenced-script omissions.

TerraScale.Internals' 13-entry dirty worktree was observed and excluded from evidence. It was not modified, cleaned, staged, or incorporated into the immutable inventory.

Authentication is explicitly represented as a production role with no build target. The document distinguishes all observed workflows/descriptors/policies from the proposed build-once native reconciliation; no proposal is accepted.

## Commands

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- delivery-inventory-generate > /tmp/descriptor-inventory.json
cmp /tmp/descriptor-inventory.json docs/audits/delivery/descriptor-inventory.json
rm -f /tmp/descriptor-inventory.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- delivery-inventory-validate
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format docs/audits/delivery/descriptor-inventory.json
dotnet run --project tests/TerraScale.Orchestrator.ContractTests/TerraScale.Orchestrator.ContractTests.csproj --no-restore -- --no-progress --output Detailed
git diff --check
```

## Unresolved work

- Choose and document the authoritative feature-PR validation policy.
- Add Authentication test/build/publish targets for both production architectures.
- Reconcile Internals documentation with the consolidated workflow.
- Define the native descriptor v2 and retain semantic dependency/health/promotion behavior.
- Retire Flux/Helm/Kubernetes targets only after linked native replacement tests pass.
- Resolve owner question 7 before accepting an orchestrator bootstrap/recovery workflow.


---

# FILE: docs/work-packages/handoffs/phase0-cloud-adrs.md

# Phase 0 cloud ADR draft handoff

- Work package predecessor: `ee72a8f`
- Branch: `docs/phase0-cloud-adrs`
- Scope changed: ADR backlog items 4 and 20 plus this handoff only
- Status of both ADRs: `Proposed`
- Cloud, VM, Pulumi, sibling-repository, or other external mutation: none

## Result

Drafted:

- `docs/adr/0004-pulumi-provider-ownership.md`
- `docs/adr/0020-provider-actuator-threat-model.md`

ADR 0004 preserves the specification's two-owner boundary: Pulumi retains durable foundation and transfers an exact fresh-resource inventory through a signed, crash-resumable handoff before the regional actuator becomes the sole lifecycle owner. It rejects continuous dual reconciliation, historical-resource adoption, tag-based authority, and convention-only handoff.

ADR 0020 scopes provider correctness to trusted-code crash-stop failures and defines persisted intent plus same-operation resume. It records the minimum proposed `ProviderOperationContext`, late-call/timeout/leadership-loss recovery matrix, and why tags, IAM propagation, timeouts, or a new epoch cannot fence an already accepted OCI request.

Review identified an ambiguous irreversible commit point in the first draft. The revision now distinguishes provisional `Prepared`/`Held` operations from the atomic `AuthorizedForProviderCall` commit. Pre-commit expiry, stale evidence, approval withdrawal, or leadership loss permits a no-call hold; post-commit leadership/deadline changes may hold dispatch but cannot replace the frozen action, payload, request identity, or terminal target. The context contract and failure matrix use the same boundary.

Both drafts preserve unknown details instead of accepting them. They trace the current requirement/invariant IDs and clearly label state-machine, security, error, and gate identifiers from the registry audit as proposals that are not yet canonical.

## Validation

```text
git diff --check
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- adr-readiness
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- adr-readiness
```

Observed results:

- readiness index validated all 24 ADR backlog entries exactly once;
- all 6 readiness-validator tests passed;
- all 14 exact local source anchors in ADR 0004 resolved to nonblank, in-bounds lines;
- all 12 exact local source anchors in ADR 0020 resolved to nonblank, in-bounds lines;
- no VM, service, container, Pulumi, or OCI command was run.

## Remaining gaps before acceptance

- exact OCI compartment IAM policy and action/resource matrix;
- exact tag namespace and immutability rules;
- primary-source and executable evidence for the chosen Pulumi retain/unmanage transition;
- exact handoff receipt/resource-type/crash-checkpoint model;
- exact OCI SDK retry-token, idempotency, work-request, timeout, cancellation, and eventual-consistency semantics per mutating service;
- controller/adapter leadership-loss model, per-operation ambiguity/compensation table, and independent security review;
- repaired read-only OCI inventory evidence; current discovery is authentication-blocked and proves neither OKE absence nor an empty residual account;
- unresolved owner choices and measurable cost, storage, RPO/RTO, security, and regional-survival targets that control dependent behavior and acceptance evidence.

The drafts grant no deployment or mutation authority. L0, L3S, and L4 evidence described in them remains future acceptance work, and L4 cannot run before the repository's exact-tree pre-deployment gate.


---

# FILE: docs/work-packages/handoffs/phase0-nats-readiness.md

# Phase 0 NATS readiness handoff

- Branch: `docs/phase0-nats-readiness`
- Scope changed: `docs/audits/nats/**`, `testlab/pins/nats-*.json`, `testlab/nats/**`, and this handoff
- External reads: official NATS GitHub releases/documentation and official NuGet package endpoints
- Mutations: one bounded local loopback `nats-server` smoke; no VM, cloud, systemd, container, persistent service, credential, or sibling-repository action

## Result

Five tool candidates are recorded but unselected: servers 2.14.3 and 2.12.7, clients `NATS.Net` 3.0.0 and 2.8.2, and CLI 0.4.0. Linux amd64/arm64 server and CLI asset metadata is pinned to official release URLs, sizes, and SHA-256 digests. Client packages are pinned to official NuGet URLs and locally calculated SHA-256 digests.

The owner-controlled N/N-1 policy remains null and the candidate pair remains unexecuted. Current/prior labels are inventory roles, not compatibility acceptance.

The 27 capability rows contain 3 local x64 smoke passes, 1 partial loopback monitoring result, 22 unexecuted results, and 1 owner-policy-blocked result. Full L0C, ARM64 qualification, and production qualification remain false.

## Validation

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- nats-readiness
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- nats-smoke > /tmp/nats-smoke.json
cmp /tmp/nats-smoke.json testlab/nats/local-x64-l0c-report.json
rm -f /tmp/nats-smoke.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/nats-candidates.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/nats/local-x64-l0c-report.json
dotnet run --project tests/TerraScale.Orchestrator.ContractTests/TerraScale.Orchestrator.ContractTests.csproj --no-restore -- --no-progress --output Detailed
git diff --check
```

The eight adversarial fixtures cover missing architecture support, missing official provenance, implicit tool selection, implicit N/N-1 policy, false full-L0C readiness, incomplete cleanup, specification semantic drift, and stale evidence after a harness change. The report binds and the validator recomputes the exact repository-relative smoke-harness SHA-256.

## Next evidence

1. Owner approval of the compatibility policy and exact mixed-version permutations; no recommendation was accepted here.
2. Internal mirror/signature verification and independent download/hash/SBOM validation for all selected artifacts.
3. Generated dual-plane JWT/TLS/account/permission/gateway configuration before credentialed conformance.
4. Full loopback/temp-directory L0C across R3, gateways, JetStream policies, KV/Object Store, consumer failure, advisories, snapshots, peer replacement, reload/rolling behavior, and selected N/N-1 clients/servers.
5. ARM64 execution and production storage/durability evidence in their mandated later gates.


---

# FILE: docs/work-packages/handoffs/phase0-owner-decision-packet.md

# Phase 0 owner decision and SLO packet handoff

Superseded on 2026-07-16: the owner explicitly selected 1A–10A with reliability first. The machine-readable packet and validator now enforce those choices; only measurable qualification targets and later implementation selections remain unset. The text below records the original blank-packet handoff and is retained as historical evidence.

- Work package predecessor: `f393dc4`
- Branch starting point observed by this lane: `5322e62`
- Scope changed: `docs/decisions/**` and this handoff only
- Destructive/external actions: none

## Result

The packet preserves all ten owner questions and both options exactly as written in `ORCHESTRATOR.md:89-98`. Every record carries its source line and a SHA-256 over the four exact source cells. `recommended: A` represents the table heading only; all ten `answer` fields are null and validation rejects any checked-in default.

There are 38 explicitly unset records:

- 10 owner decisions and 19 measurable targets required before the affected contract/ADR tranche can freeze;
- 2 Phase 0 planning inputs (team size and desired first-production date), explicitly not promoted to architecture decisions;
- 7 later Phase 0 implementation selections, segregated from owner decisions.

The measurable targets cover maximum three-region pre-user BRL/day cost; per-member IOPS, MiB/s, and p95/p99 read/write milliseconds; regional RPO seconds and RTO minutes; credential-revocation seconds, workload-certificate/renewal-lead hours, break-glass minutes, and critical-remediation hours; orchestrator RSS MiB and post-failure compact utilization percent; hot/immutable audit-retention days; and disconnected regional-survival hours. No value was inferred from a recommendation, provisional threshold, historical bill, current implementation, or agent judgment.

## Downstream impact coverage

Every owner question and input maps to canonical ADR IDs 1–24 and at least one canonical readiness/acceptance gate. Collectively the packet directly impacts ADRs 1–3, 5–12, 14, 16–17, 19, 21, and 24. The segregated later selections additionally cover ADRs 15, 22, and 23. ADRs 4, 13, 18, and 20 have no controlling owner/SLO input in the readiness map and are deliberately not given fabricated dependencies.

Gate mapping covers contract freeze, the Phase 0 exit, and the applicable L0, L0C, L1R, L3S, L4, and L5 evidence layers. An impact is not represented as a passing result.

## Validation and adversarial review

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- owner-decisions
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format docs/decisions/owner-decision-packet.json
git diff --check
```

The validator derives exact question text and checksums directly from `ORCHESTRATOR.md`, enforces questions 1–10 exactly once, rejects any checked-in answer/value/selection, checks exact units and validation rules, and enforces canonical ADR/gate mappings. Six data fixtures adversarially mutate the valid packet or a temporary copy of the specification to prove rejection of an accidental recommendation default, omitted question, invalid option, invalid unit, source semantic drift, and accidental later implementation selection. Later selections also fail closed unless their readiness stage, contract-freeze segregation, ADR impacts, and gate impacts match the canonical packet.

## Remaining gaps

- The owner has supplied none of the 10 answers or 21 planning/SLO values in this work package; this lane intentionally cannot reduce that unresolved count.
- The 7 implementation selections still require their own evidence-backed Phase 0 work; this packet only prevents them from being mistaken for owner answers.
- ADR impact mapping is synchronized to the Phase 0 ADR readiness lane but does not accept an ADR or replace its exit evidence.
- The packet validates checked-in unresolved state. A later response-ingestion workflow must validate supplied numeric values, cross-field relations such as p99 not below p95 and immutable retention not below hot retention, record owner provenance, and produce a separate reviewed acceptance record; it must not overwrite this blank template silently.

## Exact compact response

```text
1=_ 2=_ 3=_ 4=_ 5=_ 6=_ 7=_ 8=_ 9=_ 10=_; team-size=_ people; first-production-date=_; maximum-cost=_ BRL/day; storage-iops=_ IOPS; storage-throughput=_ MiB/s; storage-read-p95=_ ms; storage-read-p99=_ ms; storage-write-p95=_ ms; storage-write-p99=_ ms; regional-rpo=_ seconds; regional-rto=_ minutes; security-revocation=_ seconds; certificate-ttl=_ hours; certificate-renewal-lead=_ hours; break-glass-ttl=_ minutes; security-critical-remediation=_ hours; orchestrator-rss=_ MiB; compact-post-failure-utilization=_ percent; audit-hot-retention=_ days; audit-immutable-retention=_ days; regional-survival=_ hours
```

Unknown values should remain `_`; each A/B answer must be an explicit owner choice.


---

# FILE: docs/work-packages/handoffs/phase0-provider-qualification-schema.md

# Phase 0 provider-qualification schema handoff

- Branch: `docs/phase0-provider-qualification-schema`
- Work package: `docs/work-packages/phase0-provider-qualification-schema.md`
- Scope changed: lane-owned provider audit, pin datasets, offline validator/tests/fixtures, and this handoff only
- Cloud credentials/API calls/resource mutation: none
- Price retrieval, provider winner/selection, OCI eligible-region claim, and qualification: none

## Result

Created a fail-closed custom field-contract for the normalized OCI/AWS/GCP/Azure TCO and storage benchmark plus the OCI `>=20` eligible-region matrix. It is deliberately not labeled as JSON Schema. The contract enumerates all cost and region fields named by `ORCHESTRATOR.md`. The blank dataset keeps every empirical value unknown, all provider results incomplete/unqualified, the OCI eligible count at zero, the threshold claim false, and provider winner/selection `null`.

The 26-entry source catalog uses only official Oracle, AWS, Google Cloud, and Microsoft documentation. Every source statement is bounded as discovery input rather than account, capacity, price, performance, service, or region qualification evidence.

## Validation

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/provider-qualification-schema.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/provider-qualification-blank.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/provider-source-catalog.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/phase0/provider-qualification/fixtures/negative-cases.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- provider-qualification
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet build tools/TerraScale.Orchestrator.Tooling
git diff --check
```

The deterministic validator separates reusable structural validation from the stricter checked-in-blank policy. It checks exact field coverage, all four providers, all six evidence topics per provider, official-source hosts and freshness, cost currency/unit/effective-date clarity, complete benchmark/region rows, unique qualified-row recounting, the `>=20` invariant, and winner/selection gating. Eighteen data-driven negative cases cover the requested failure modes. A generated, never-written `synthetic-fixture-only` positive case populates all four normalized provider results and 20 complete OCI rows; it proves the structural path while remaining unable to pass the CLI's committed blank-policy mode.

## Remaining gates

- An authorized later lane must gather current public and negotiated prices, taxes, FX, discounts, exact quantities, and actual billing exports under an owner-approved normalization policy.
- The same immutable ARM64 TerraBase/fio workload must run for each serious provider and publish raw artifacts plus normalized BRL/day, BRL/transaction, and BRL/IOPS sensitivity results.
- OCI needs account-visible subscription, shape/image/service/limit/quota evidence and capacity probes for each named region; public documentation alone qualifies zero rows.
- OCI region rows also need real Block Volume, expansion, failure/recovery, inter-region, residency, and cost evidence. At least 20 fully supported rows must pass before `claimSatisfied` can become true.
- Price alone cannot select a provider. Storage/HA SLO acceptance, measured post-OKE residual cost, negotiated/operational fit, and owner decisions remain external gates.

No artifact from this lane authorizes a cloud call, provider selection, deployment, or production claim.


---

# FILE: docs/work-packages/handoffs/phase0-supply-chain-pins.md

# Phase 0 supply-chain candidate-pin handoff

- Branch: `docs/phase0-supply-chain-pins`
- Work package: `docs/work-packages/phase0-supply-chain-pins.md`
- Scope changed: supply-chain audit, candidate manifest, lane-owned validator/tests/fixtures, and this handoff only
- External mutation: none
- Candidate download/install/restore/import/execution: none
- Signing or attestation selection: none

## Result

Created a fail-closed candidate evidence set for build, runtime, property, coverage, fuzz, mutation, signing, OCI artifact, SBOM, and vulnerability tooling:

- `docs/audits/supply-chain/phase0-candidate-pins.md`
- `testlab/pins/supply-chain-candidates.json`
- `tools/TerraScale.Orchestrator.Tooling/TranslatedCommands.cs`
- `tools/TerraScale.Orchestrator.Tooling/ToolingTests.cs`
- `tools/phase0/supply-chain/fixtures/negative-cases.json`
- `tools/phase0/supply-chain/README.md`

The manifest records 13 version-specific official candidates/alternatives and 6 unresolved capability gaps. Every candidate is unselected, unmirrored, locally unexecuted, and not production-qualified. Artifact signing, evidence signing, and attestation tool selections remain explicitly `null`; Cosign and Notation remain peer candidates.

Following review, the manifest also binds the existing checked-in baseline: SDK `10.0.301` with `latestFeature` roll-forward, TUnit `1.56.18`, transitive Microsoft.Testing.Platform `2.2.3`, their lock content hashes, and SHA-256 provenance for every checked-in lock file. It explicitly records that `latestFeature` permits a higher installed feature band, so the SDK is not an exact closure pending a steward decision. No central package/build file was edited.

Current technical/version claims use only owning-project GitHub release pages or official NuGet package pages. Trivy is a reviewed alternative rather than a recommendation because the owning project published an official March 2026 supply-chain advisory; the audit does not claim its later candidate version is compromised.

## Deterministic validation

Commands:

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format testlab/pins/supply-chain-candidates.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- supply-chain
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
git diff --check
```

The standard-library validator checks exact schema keys, stable/unique IDs, category completeness, version-specific HTTPS sources on official hosts, version/source agreement, license/platform/integrity metadata, Linux x64/ARM64 availability for binary distributions, missing mirrors, explicit qualification gaps, and fail-closed null selections. It also compares the baseline record to `global.json`, the central TUnit declaration, test lock resolutions/content hashes, and the complete recomputed lock-file SHA-256 set. The data-driven adversarial corpus covers 21 negative cases, including floating/wrong versions, false qualification/mirror claims, missing ARM64, erased gaps, duplicate IDs, secret-bearing fields, signing-selection collapse, SDK/package drift, false SDK closure, and lock provenance drift.

## Remaining gates

- The integration steward must decide whether to replace `latestFeature` with exact SDK closure semantics; this lane only records and validates the current checked-in baseline.
- New central package/build-file pins must be made later by the integration steward after selections; this lane changed none.
- Model/state-space plus systematic-concurrency tooling remains unselected pending a .NET 10 deterministic replay spike.
- Secret scanning, license-policy evaluation, and exact NuGet dependency/advisory/lock enforcement remain open.
- Artifact/evidence signing format, tool, identity, KMS/isolated-CI custody, trust roots, offline verification, revocation, and recovery require the future owner-approved ADR.
- Every selected package/binary/plugin/scanner database needs exact digests, upstream verification receipts, a content-addressed internal mirror, TerraScale signatures, and compromise/rollback drills.
- Candidate compatibility and deterministic output need L0; containerd/runc need L1R and ARM64 L4; BuildKit needs isolated worker/cache/credential evidence; signing/OCI tools need Forgejo/OCIR conformance.

No candidate presence, upstream release, schema-valid record, or green validator is production qualification or permission to issue deployment credentials.


---

# FILE: docs/work-packages/handoffs/phase01-provider-handoff-determinism-audit.md

# Phase 0/1 provider handoff determinism audit handoff

## Proven gap and correction

The handoff evaluator already compared Expected, Pulumi, and Regional inventories as sorted set-like projections. All proof checks could therefore accept independently permuted inventories. The emitted `EnableRegionalSelfManagementIntent`, however, retained the three original caller orders. Equivalent fully verified handoffs consequently exposed different adapter-facing sequences.

`FreshBootstrapInventory` now applies the evaluator and fingerprint's canonical order at its defensive-copy boundary: resource ID ordinal, resource kind, then generation. This retains the exact caller items but removes enumeration-order ambiguity before either validation or accepted output. Duplicate resource IDs remain visible and continue to hold handoff readiness.

## Deterministic proof

- All six permutations of three distinct items are varied independently across Expected, Pulumi, and Regional: 216 accepted combinations.
- Cases rotate through Turkish, Arabic, and Japanese cultures and emit one exact canonical sequence in all three retained projections.
- Tests prove exact item-reference retention, mutation isolation for all three source arrays, and equivalent independently reconstructed leaves and scope.
- A duplicate-ID raw inventory pins kind and generation comparator tie-breaks while proving the existing duplicate hold and null intent remain unchanged.
- Reflection exhaustively pins the public decision, intent, inventory, scope, trace, leaf, collection-projection, constructor, accessor, immutable-clone, factory, and sole engine-origin surfaces.
- Focused audit tests passed 4/4; provider-prefixed tests passed 32/32; cross-budget provider properties passed 9/9.
- The Release warnings-as-errors solution build passed with zero warnings and errors.
- All five test executables passed 887/887 (ControlPlane 660, Contract 29, Model 44, Protocol 70, Scheduler 84).

## Remaining completion blockers

This correction does not make the draft registry or product complete.

- Owner questions 1–10 and the cost, storage-performance, RPO, and RTO targets remain unresolved.
- The canonical structured trace report remains at 43 gaps, zero linked requirements, and zero acceptance-satisfied requirements; registry and contract promotion are integration-steward work.
- Action-specific cancellation/compensation recovery and broader native GitOps retry/suspend/prune remain future pure-contract tranches rather than policies invented by this audit.
- NATS L0C generated credentials/configuration and real-server conformance, signing technology and protected keys, Pulumi retain/unmanage qualification, OCI/A1/IAM/storage adapters, rootless container/systemd/containerd labs, deployment, measured cost, and storage-performance evidence require external or later-layer work.
- Networking policy and compute scale-out were explicitly excluded because separate active audits own them.

## Honest boundary

Canonical retained order is not proof that any inventory observation or handoff proof is authentic, signed, durable, or externally enforced. No Pulumi, provider, cloud, filesystem, process, network, NATS, signing, credential, VM, deployment, or other external side effect occurred.


---

# FILE: docs/work-packages/handoffs/phase1-adversarial-model-core.md

# Phase 1 deterministic adversarial model core handoff

- Work package: `docs/work-packages/phase1-adversarial-model-core.md`
- Branch starting point: `d8532f8`
- Scope changed: model-test simulation and regression-corpus paths, the model-test project reference, and this handoff only
- External or destructive actions: none

## Result

The model-test project now has a deterministic, bounded three-node simulator with an explicit virtual clock and identity source, immutable event evidence plus separate delivery scheduling metadata, stable failure-kind ordering, visited-state deduplication, deterministic replay, and replay-validated delta shrinking. The closed schedule catalog covers loss, duplicate, reorder, delay, crash, restart, leader change, partition, and heal. Exploration includes baseline progression and applicable node failures across `n1`, `n2`, and `n3`; a depth-pruned pending state returns `NonConvergent`, not `Completed`.

Inputs are materialized through explicit bounds before execution. Invalid events, arithmetic overflow, and exhausted step or schedule bounds produce typed results. Initial duplicate event IDs, malformed identities and enums, negative scalar values, more than three nodes, duplicate state identities, and caller collection mutation are rejected or isolated. Canonical model state uses length-prefixed strings before SHA-256 hashing so delimiter-shaped identities cannot create ambiguous state encodings.

The reducer fences authorization and create requests to the current active writer, accepts successful mutation only from the active leader at the current epoch, preserves exact operation/generation/epoch/idempotency/resource bindings, records bounded accepted-action evidence independently of gates, makes exact-operation mutation completion terminal/idempotent, prevents a second create after outcome-unknown, rejects critical-node termination, and deduplicates delivery by event ID. Accepted authorization/action evidence records the leader, node writer epoch, crash/partition state, generation, idempotency key, and resource identity observed at acceptance. Invariants inspect those facts independently, so mutation-style stale, unauthorized, unsafe-termination, repeated-create, and duplicate-terminal-success evidence fails audit if an individual reducer gate is removed. Passive provider and delivery observations cannot expose authorization, permit, intent, filesystem, socket, process, random, environment, or mutation capabilities.

Direct probes exercise the existing Authority, Operation, Provider, Compute, and Delivery pure cores. They establish that mutation authority requires an observed CAS, an unprepared operation cannot dispatch, missing regional provider authority cannot mutate, an outcome-unknown create is observed rather than repeated, duplicate delivery is idempotent, and an untrusted product-validation job cannot acquire production-release authority.

The versioned regression corpus is a checked-in JSON file compiled as an embedded resource and loaded only by its fixed logical resource name. Source bytes, entry count, and schedule length are bounded. Loading is strict and deterministic: unknown or duplicate fields, unsupported versions, malformed or mismatched digests, duplicate IDs, invalid schedules, and traversal-shaped IDs are rejected. A saved stale-leader/late-completion schedule is content-addressed, replayed, and checked against its expected invariant by the ordinary test suite.

## Validation

```text
dotnet test tests/TerraScale.Orchestrator.ModelTests/TerraScale.Orchestrator.ModelTests.csproj --no-restore --verbosity minimal
dotnet test TerraScale.Orchestrator.slnx --no-restore --verbosity minimal
git diff --check
```

The focused run passed 38 tests: 17 existing contract/model tests and 21 new adversarial simulator/corpus tests. The full solution run passed 371 tests. It starts no service, VM, container, adapter, network client, provider SDK, or deployment.

## Evidence boundary

The ordinary suite runs only the explicitly named `SmokeShard`. `FeatureMinimum` exposes the required 10,000-schedule floor and `FullMinimum` exposes the 1,000,000-schedule floor for later evidence lanes. This handoff does **not** claim that either threshold ran, does not mint pre-deployment evidence, and does not claim exhaustive coverage of every control-plane domain. Storage, TerraBase, runtime, and other domain engines remain independently tested and are candidates for projection into later aggregate cross-core models.


---

# FILE: docs/work-packages/handoffs/phase1-authority-core.md

# Phase 1 regional authority core handoff

- Branch: `phase1/authority-core`
- Work package: `docs/work-packages/phase1-authority-core.md`
- Scope changed: lane-owned authority source/tests and this handoff only
- External I/O or mutation: none

## Result

Implemented a pure authority reducer for `INV-004`, with `INV-005` referenced
only for append/replay/idempotency behavior proven here. It emits typed
compare-and-set, compare-and-delete, and read intents; it never reads a clock,
NATS, environment, filesystem, network, or policy default.

Each reducer journal is explicitly scoped to one `(AuthorityId, CandidateId)`
attempt history. The regional KV CAS record is the shared authority truth across
candidates. Tests model three candidate journals reading the same baseline,
select one CAS winner, return that winner's exact truth to the losers, and prove
only the winner receives a mutation permit. A later candidate advances the
shared epoch after the prior lease expires, and the stale candidate fences when
it evaluates that higher-epoch truth.

Mutation permission is not cached in `AuthorityState`. A point-in-time typed
`MutationAuthorityPermit` is returned only from an exact successful CAS/read or
explicit evaluation. It binds authority, candidate, lease, epoch, KV revision,
observation identity, supplied server time, and supplied monotonic elapsed
duration. Follower, acquisition-pending, renewal-pending, release-pending,
read-only/held, and fenced states receive no permit. Renewal cannot extend an
epoch until exact CAS success; release removes permission before delete is sent.

The model supports explicit absent genesis `(revision=0, epoch=0, lease=null)`
and advances it to revision/epoch one. All later revisions and epochs are
positive. Epoch, revision, and server-expiry overflow are preflighted before an
impossible mutation intent and produce typed holds. Expiry equality, partition
uncertainty, clock anomaly, CAS uncertainty/failure, mismatched identity,
higher epoch, and stale/out-of-order request results all remove or deny mutation
authority. Held candidates may recover through an exact read; fenced candidates
have no self-unfence command.

Events use a deterministic, type-tagged, length/count-delimited SHA-256 chain.
Replay accepts reordered exact duplicates, rejects conflicting bodies/broken
links, and revalidates request identity, authority scope, CAS evidence, lease
ownership, epoch/revision succession, supplied time, outcome/error mapping, and
terminal fence/hold vocabulary before applying any event.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.ContractTests/TerraScale.Orchestrator.ContractTests.csproj --no-build --no-restore -- --no-progress --output Detailed
git diff --check
```

The authority suite contains 17 focused tests; combined with the existing 14
operation tests, the ControlPlane executable runs 31 tests. Coverage includes
crash/replay at every intent/result boundary, deterministic decision/state
digests, three-candidate CAS interleavings, acquisition/renewal/release/read,
pending-state permission denial, exact and mismatched results, duplicate and
out-of-order observations, stale old leaders, genesis, all overflow classes,
expiry equality, partition and clock anomalies, cross-authority evidence, and
rehashed corrupt journal events.

## Deliberate limitations

- The core models KV observations and emits intents but performs no persistence,
  NATS operation, lease scheduling, or retry.
- Lease duration, renewal timing, server time, monotonic elapsed duration, and
  partition/clock certainty are mandatory caller inputs; no default is encoded.
- The point-in-time permit must be consumed by a coordinator that binds it to
  the corresponding operation decision. It is not a transferable credential.
- NATS KV linearization/conformance and durable journal/CAS adapter behavior
  remain later L0C/runtime evidence.


---

# FILE: docs/work-packages/handoffs/phase1-authority-permit-provenance-audit4.md

# Phase 1 authority mutation-permit provenance audit 4 handoff

## Change summary

- Started from exact central commit `6fb86b534de7c06990f9017fb7645225a552f358` in an isolated worktree.
- Preserved two pre-fix executable counterexamples: different evaluation request identities, and the same request/evidence across different accepted command types.
- Retained the exact accepted `AuthorityCommand` on `MutationAuthorityPermit` and derived all permit projections from it.
- Restricted permit construction to the three successful permit-minting command shapes and made the engine helper command-only.
- Bound the canonical permit/decision digest to command type and every nested command field.
- Extended construction/clone closure, 1,000-case culture replay, and the strict content-addressed authority corpus.

## Review focus

Review the single-source boundary in `MutationAuthorityPermit`, all three `CreatePermit(command)` call sites, and the distinct canonical tags in `AuthorityDigest`. The intended invariant is: a non-null permit retains the exact command object that the pure engine accepted; rejected or held commands never return one.

The public record clone remains an immutable-copy route and deliberately preserves the same authorizing-command reference. No public constructor, setter, deconstructor, or independent factory was introduced.

## Verification and nonclaims

After rebasing onto central `1f73564`, the Release warning-as-error solution build passed with zero warnings/errors. All five test executables passed 870/870: ControlPlane 643, Contract 29, Model 44, Protocol 70, and Scheduler 84. This work performs no external effects and makes no claim about authenticated transport, NATS/KV linearization, adapter correlation, provider execution, or deploy readiness.


---

# FILE: docs/work-packages/handoffs/phase1-authority-policy-completeness.md

# Phase 1 authority policy completeness handoff

## Result

- Replay now rejects a non-renewal acquisition request whose expected epoch or
  KV revision is below the reducer's persisted high-water truth. Exact equality
  and independently newer truth remain valid.
- Acquire, renew, release, and read initiators reject the last completed request
  identity in an otherwise admissible state. This prevents emitting an intent
  whose observation would be swallowed by the existing duplicate-result path.
- Status admissibility remains earlier: acquisition from leader still returns
  `InvalidTransition`. Common journal/command identity validation remains
  unchanged, and malformed replay events retain structural-error precedence.

## Defect evidence

Before the production changes, a content-valid journal could record winner truth
at epoch 9/revision 20, replay a requested and confirmed acquisition at epoch
5->6/revision 10->11, and then obtain a mutation permit for 6/11. The focused
regression failed because replay returned no error.

Separately, renewal using the just-completed acquisition request ID emitted a
new compare-and-set intent. Its result would then hit `LastCompletedRequestId`
and be ignored, leaving the reducer pending after the external KV mutation. The
focused regression failed because the unexpected CAS intent was present.

## Deterministic coverage

- 1,000 epoch-only, revision-only, and combined high-water regression cases,
  with exact prior-state digest/sequence, error, and zero-output assertions;
- 1,000 exact-equality, revision-advance, and epoch-advance replay/permit cases;
- structural-malformation versus regression and active-lease versus regression
  precedence;
- 1,000 cases for each reused/fresh acquire, renew, release, and read path, with
  every fresh intent and request-event field checked;
- leader-state acquisition precedence, malformed reused payload precedence,
  closed statuses/outcomes/errors/commands/events/intents, and `en-US`, `tr-TR`,
  `ar-SA`, and `ja-JP` digest stability.

## Validation

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
All projects are up-to-date for restore.

dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-restore -c Release -- --no-progress --treenode-filter '/*/*/AuthorityPolicyCompletenessPropertyTests/*' --output Normal
Passed: 6, Failed: 0, Skipped: 0

dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-restore -c Release -- --no-progress --output Normal
Passed: 474, Failed: 0, Skipped: 0

dotnet build TerraScale.Orchestrator.slnx --no-restore -c Release -warnaserror
Build succeeded. 0 warnings, 0 errors.

All five Release test executables
Passed: 670, Failed: 0, Skipped: 0 (ControlPlane 474, Contract 24, Model 38, Protocol 65, Scheduler 69).

git diff --check
Passed with no output.
```

## Compatibility and limits

No public DTO, enum value, constructor, digest encoding, or wire surface changed.
The changes narrow only two previously unsafe/stranding inputs. This shard does
not change duplicate observation handling, choose a NATS adapter, or claim a
real lease/CAS integration result.


---

# FILE: docs/work-packages/handoffs/phase1-budget-authorization-basis-audit4.md

# Phase 1 budget authorization basis audit 4 handoff

## Proven gap and correction

The budget engine selected one cell-usage observation, one global-usage observation, one node-class observation, and one price observation under a policy, but discarded those objects when it produced a decision. Two evaluations using different cell/global/node evidence identities and otherwise identical current values returned `Automatic`, `WithinAutomaticBand`, the same nine-field proposal subject, the same public numeric trace, no approval scope, and the same redacted string. The accepted output could not identify which evidence and policy had authorized compute capacity.

Every decision created after successful evidence selection and trace construction now contains a `BudgetDecisionBasis` retaining the exact validated policy and exact four selected observations. This includes non-authorizing approval, forbidden, and traced emergency-held results because basis presence marks the evidence/trace phase, not authorization. Early fail-closed results remain basis-free alongside their existing null trace and subject.

The basis is a sealed construction-closed class with an internal constructor, getter-only exact references, no alternate public factory/deconstructor/clone surface, and an opaque string representation. `BudgetDecisionSubject` continues to bind the proposal separately. No decision arithmetic, band threshold, emergency rule, kind, reason, precedence, trace, approval scope, or enum numeric changed.

## Executable evidence

The regression suite preserves the original legacy-output collision and proves that the new basis fingerprints diverge. It pins exact reference retention across automatic, approval-required, forbidden, provider-limit, emergency-held, and emergency-safety branches; enumerates early basis-null families; exercises evidence identity/value/status/age, price and policy sensitivity; checks permutation and four-culture replay across 1,000 cases; audits the complete public construction surface and redaction; and saves both collision sides in the strict checksum-pinned budget/provider corpus.

## Honest boundary

This closes selected budget policy/evidence provenance only. Exact reference retention does not make an evidence producer authentic, a billing export complete, a price correct, or a policy current; no policy-generation contract was added. A budget decision remains separate from provider authority and cannot itself mutate infrastructure. No provider SDK, billing query, network, filesystem, process, VM, cloud, deployment, or production qualification occurred.


---

# FILE: docs/work-packages/handoffs/phase1-budget-authorization-subject-audit.md

# Phase 1 budget authorization-subject audit handoff

## Scope

This pure-policy audit reviewed budget decision outputs for one replay identity
ambiguity after the budget core, policy-completeness, and property/replay
shards. It performed no price lookup, billing query, provider operation,
filesystem access, network access, process execution, or external mutation.

## Executable counterexample

Two otherwise identical valid proposals targeted `node-42` and `node-43`.
Both returned `Automatic`, `IsAuthorized=true`, no approval scope, and the same
public numeric trace and redacted string representation. The accepted output
therefore did not state which resource proposal had passed budget policy.

The same omission covered the proposal's cell, cost center, node class, price
evidence identity, direction, safety purpose, node count, and delta. A replayed
automatic authorization could not be matched to its exact proposal subject
from the typed decision output.

## Correction

Every decision produced through the traced `BudgetDecision.Create` path now
contains a construction-closed `BudgetDecisionSubject`. Its internal
constructor accepts the already validated `BudgetProposal` and retains exactly:

- resource, cell, cost center, and node-class identities;
- price-evidence identity;
- change direction and safety purpose;
- node count; and
- the immutable delta vector.

This applies to automatic, approval-required, forbidden, and emergency traced
held outcomes. Existing early fail-closed decisions created through
`BudgetDecision.Held` remain trace-free and subject-free. For all current
decision paths, `Subject` is present exactly when `Trace` is present.

No decision kind, reason, enum numeric, band boundary, emergency rule, evidence
precedence, or trace field changed. `BudgetApprovalScope` is unchanged.
`ToString()` remains deliberately redacted and does not print resource or other
proposal identities; replay comparison uses the typed subject fingerprint.

## Verification

The audit tests exercise every traced creation return site and assert exact
subject retention. They independently mutate each of the nine subject fields,
prove canonical typed fingerprint inequality, prove identical replay
fingerprint equality, retain the approval-scope contract, and assert subject
construction closure and secret-safe string output. Early invalid-policy,
malformed, wrong-scope, unknown-class, missing-evidence, and arithmetic-held
paths remain subjectless.

## Deliberate non-claims

This closes proposal-subject identity only. It does not prove that a price is
current or correct, establish currency or fixed-point scale, attest a billing
export, bind an evidence producer or verifier, approve a cost/SLO target, or
grant provider mutation authority. It also does not claim structural equality
for `BudgetDecision`; replay equality here means equality of the canonical
typed subject/output fingerprint under the existing trace semantics.


---

# FILE: docs/work-packages/handoffs/phase1-budget-core.md

# Phase 1 budget core handoff

- Branch: `phase1/budget-core`
- Work package: `docs/work-packages/phase1-budget-core.md`
- Scope: pure budget authorization and inventory/billing anomaly decisions
- Provider prices/actions, billing APIs, clocks, I/O, mutations, and cost/SLO defaults: unchanged

## Implemented model

- Cell, node-class, cost-center, resource, price-evidence, and approval identities are immutable and require explicit positive character bounds.
- `BudgetQuantity` is a checked non-negative `long` fixed-point base-unit value. Changes use an explicit increase/decrease direction plus non-negative magnitude; floating point and negative quantities are absent.
- `BudgetVector` covers CPU, memory, storage, IOPS, throughput, public IPs, load-balancer backends, hourly spend, and daily spend in a fixed invariant order.
- Caller policy supplies per-node-class minimum/warm/maximum counts; cell/global automatic and approval bands; cell/global budget ceilings; cell/global provider/account hard limits; emergency posture; maximum evidence age; maximum evidence count; safety purpose; and typed approval scope.
- Evidence is explicitly scoped and typed for cell/global usage, node-class counts, and price identity. Status and numeric age are caller observations; no wall clock is read.

## Decision behavior

- Missing, null, unknown, stale, over-age, duplicate, conflicting, negative-count, over-limit, or wrong-scope evidence produces `Held`. Enumeration stops at the explicit combined evidence bound.
- Projection uses checked arithmetic. Overflow/underflow holds without wrapping. Node minimum/maximum, warm protection, every automatic/approval/forbidden band, budget ceilings, and provider/account hard limits are evaluated deterministically.
- `Automatic` is the only immediately authorized kind. `ApprovalRequired` is not authorized and contains only a typed immutable approval scope plus the numeric trace; there is no callback, command, arbitrary message, lookup, or provider action.
- The stable invariant trace includes current/projected cell/global usage, delta, every automatic/approval/budget/provider vector, current/projected/minimum/warm/maximum node counts, all evidence ages and maximum age, and binding dimensions.
- In emergency posture, ordinary growth is forbidden and every decrease is held, so this core cannot authorize termination. Availability repair still passes through hard policy. An explicitly classified no-node data-loss-prevention increase may include storage, IOPS/throughput, and associated hourly/daily spend, but no CPU, memory, public IP, or LB backend. It is automatic even beyond budget bands, but never beyond provider/account hard limits.

## Anomaly behavior

The pure anomaly detector accepts an explicit complete-inventory assertion and bounded, scoped, fresh observations. It reports typed findings for:

- owned but undesired/orphaned resources;
- owned unattached resources;
- desired but missing owned resources;
- billing without an owned resource; and
- owned resources missing from billing.

Findings are defensively copied, canonically ordered, secret-safe, and never decide deletion or any other mutation.

## Verification

The 26 focused TUnit tests cover identity/quantity boundaries, culture stability, default closure, policy construction, defensive copies, all nine independent dimensions, exact bands, cell/global budget and hard limits, node min/warm/max, arithmetic limits, approval secrecy, evidence permutations/failures/ages/bounds, emergency safety behavior, and anomaly discrepancy/evidence matrices.

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx --no-restore
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --treenode-filter '/*/*/Budget*/*'
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore
git diff --check
```

Result: solution build passed with zero warnings/errors; focused budget tests passed 26/26; full ControlPlane tests passed 70/70.

## Deliberate semantic choices and limitations

- Fixed-point unit scale is owned by the future versioned policy schema; this core compares only values already expressed in the same caller-selected base units.
- Warm is an approval floor: a decrease below warm but not below minimum requires approval. Minimum/maximum violations are forbidden.
- Emergency termination protection is conservative: every decrease is held because this pure budget input cannot prove that a decrease is non-terminating.
- Early held decisions caused by absent/incomplete evidence have no fabricated numeric trace; all decisions after complete evidence contain the full trace.
- No price estimation, currency conversion, provider quota lookup, billing reconciliation fetch, anomaly deletion policy, or mutation is implemented.


---

# FILE: docs/work-packages/handoffs/phase1-budget-policy-completeness.md

# Phase 1 budget policy completeness handoff

## Defect and correction

`BudgetProposal.IsWellFormed` previously rejected only `BudgetSafetyPurpose.Unspecified`. Undefined values such as `4` were treated as well formed and, under the normal budget posture, could return `Automatic` with a complete authorization trace. The predicate now admits only `OrdinaryCapacity`, `AvailabilityRepair`, and `DataLossPreventionStorageExpansion`.

The pre-fix regression executed against the same source base with only the first property test present: 486 tests ran, 485 passed, and the undefined-purpose property failed because the decision was `Automatic` instead of `Held/MalformedProposal`.

## Deterministic evidence added

- The exact four-value purpose enum inventory and names are pinned; `Unspecified` fails before evidence is enumerated.
- One thousand positive and negative undefined purpose values produce the exact held, non-authorizing, trace-free result.
- One thousand defined-purpose cases cover normal and emergency semantics with exact kind, reason, authorization, trace, delta, binding, and scope nullability.
- Every one of the nine dimensions independently covers provider/account hard limit, budget ceiling, forbidden band, approval band, and inclusive automatic boundary. The shard checks the complete numeric projection, node bounds, evidence ages, binding dimension, and typed approval scope.
- One thousand undefined status/scope/attachment values fail closed with exact budget/anomaly errors and no findings or authorizing outputs.

## Verification

After rebasing onto integration commit `81ad934`:

- Locked solution restore succeeded.
- Warnings-as-errors Release build succeeded with 0 warnings and 0 errors.
- Focused budget completeness shard: 5 passed, 0 failed.
- Complete ControlPlane Release executable: 493 passed, 0 failed.
- All five Release test executables: 692 passed, 0 failed, 0 skipped.
- `git diff --check` passed.

No provider/cloud/billing/price lookup, network, NATS, filesystem, process, VM, deployment, mutation run, or sibling repository was used. This handoff does not claim a current price, measured bill, approved cost target, L0C, real-system evidence, or deployment authority.


---

# FILE: docs/work-packages/handoffs/phase1-ci-decision-properties.md

# Phase 1 CI trust-zone decision property handoff

## Result

Added four deterministic 1,000-case independent-oracle families for the existing pure CI decision surface:

- exhaustive closed job-kind/trust-zone/capability policy decisions;
- ordinal fresh compatible runner selection under generated permutations and Turkish/Japanese culture changes;
- retry authorization versus maximum-attempt precedence with exact generation and idempotency preservation;
- duplicate, stale/unavailable, wrong-zone, and capability-missing runner evidence precedence.

Accepted dispatches assert the exact pipeline, job, runner, tree, generation, attempt, and idempotency subject. Public decision, dispatch/hold intent, error, and trace types remain construction-closed.

The eight-entry replay corpus is capped at 32 KiB and 64 entries, uses a closed scenario catalog, bounded ASCII IDs, unique seeds/IDs, exact fields, and a complete resource SHA-256 of `780cc2d0e5ac5298eeec0dfa1b2d937dda844e2a47c5a4e75fa2be092ad7a967`. Every expected value is an exact SHA-256 fingerprint of the emitted dispatch identity. Mutating a corpus seed changes the replay fingerprint, proving the seed participates in executed inputs and outputs.

## Compatibility and production impact

The completeness audit proved a production trust-boundary defect: a trust-valid job could dispatch to a runner whose capability inventory also carried authority forbidden in that runner's zone. For example, an untrusted product runner with `Compile`, `Test`, and `ProductionDeploy` was accepted because selection checked only the requested subset.

`DeliveryEngine.DecideJob` now confines every fresh requested-zone candidate to the closed runner inventory before required-capability matching: untrusted product permits `Compile`/`Test`; trusted build permits `Compile`/`Test`/`Sign`; production release permits `Promote`/`ProductionDeploy`; control recovery permits only `ControlRecover`. An unsafe candidate does not poison a request when a safe candidate remains.

The independent matrix covers all 16 forbidden zone/capability pairs and all 8 allowed job/capability pairs. Review corrections fixed the initial erroneous forbidden-pair count and split job enum validation from runner enum validation across 10 independent unspecified/undefined modes. Every generated family compares an `en-US` baseline with `tr-TR`, `ar-SA`, and `ja-JP` replays.

## Verification

The pre-fix exact-tree regression failed both safety families because the unsafe runner emitted `DispatchJobIntent` with no error. Post-fix verification is recorded below.

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
Passed

dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore --nologo -m:1 -warnaserror
Build succeeded: 0 warnings, 0 errors

Focused CI completeness properties: 4 passed, 0 failed, 0 skipped
Full ControlPlane suite: 468 passed, 0 failed, 0 skipped

git diff --check
Passed
```

## Non-claims

No runner, process, Git/Forgejo, registry, network, filesystem runtime, NATS, cloud/provider, signing implementation, secret delivery, artifact execution, or deployment was exercised. This does not satisfy L0, L3S, L4, production readiness, or deployment acceptance.


---

# FILE: docs/work-packages/handoffs/phase1-ci-evidence-report-audit4.md

# Phase 1 CI evidence report accepted-output audit 4 handoff

## Proven gap and correction

Two otherwise accepted gate calls could supply different well-formed evidence subjects, matching expected-subject contexts, and the same claimed payload digest. Both passed policy and signature verification, yet their decisions compared equal because `EvidenceDecisionSubject` retained only that digest.

Accepted decision subjects now also retain the exact validated `EvidenceSubject` reference. Their value equality uses the digest plus the subject's existing canonical structural comparison; their hash remains digest-based. This preserves equality for independent exact reconstructions and canonical collection permutations while distinguishing a same-digest report whose accepted content differs. The subject remains construction-closed, getter-only, opaque in string formatting, and available only through the accepted decision. `PreDeploymentEvidenceGate.Verify` remains the sole public engine origin. Holds still carry no subject.

## Proof coverage

- The original executable counterexample varies the accepted tree identity while holding the claimed digest and authorization scope constant.
- Independent accepted variants cover every report leaf with an admissible distinct accepted value, including IDs, digests, architecture assignment, suite and trace counts, fuzz evidence, model corpora, L0C, toolchain, approver, content-reuse fingerprints/change, exclusions, and collection counts.
- Result leaves that have only one accepted value are exercised by the accepted baseline and gate-policy suite; changing them necessarily produces a hold and therefore cannot form an accepted-output collision.
- Exact independently reconstructed reports replay equally across Turkish, Arabic, and Japanese cultures.
- Two-entry permutations cover every report collection, including the paired suite/model domain inventory. Mutation of every caller-owned source array after construction cannot alter the retained report.
- Reflection pins public decision, decision-subject, authorization-scope, numeric-trace, evidence-subject, and collection-projection routes; immutable record clones and accessors are explicit, and no public decision-subject constructor, setter, deconstructor, clone, or alternate factory exists.

## Verification

- Focused audit tests: 3/3 passed.
- Evidence-prefixed tests: 21/21 passed.
- Accepted-output construction-closure tests: 2/2 passed.
- Release solution build: passed with zero warnings and errors.
- All five test executables: 878/878 passed (ControlPlane 651, Contract 29, Model 44, Protocol 70, Scheduler 84).

## Honest boundary

The retained report is exact accepted in-memory evidence, not proof that the caller's canonical digest was independently recomputed, that any artifact or suite actually ran, or that a signer, verifier, CI runner, credential release, deployment, or production environment is qualified. Policy objects, verifier implementation identity, and opaque signature bytes remain outside this audit. No external I/O or mutation occurs.


---

# FILE: docs/work-packages/handoffs/phase1-compute-audit2.md

# Phase 1 compute accepted-output audit handoff

- Base: `c70173a`
- Scope: pure compute contracts, engine, tests, and this handoff
- External I/O or mutation: none

## Defect and correction

The scale-out and scale-in engines validated complete evidence but discarded
part of it when constructing their authorizing outputs.

Two accepted scale-out requests could share a binding and provider create key
while differing in their persisted plan, resource envelope, capacity proofs,
and exact provider-absence observation. Both produced the same publicly
observable `RequestCreateIntent`. The intent now retains the exact validated
`PersistedScaleOutPlan`, `CapacityAuthorization`, and
`ProviderCreateEvidence`; its compatibility `CreateKey` is asserted equal to
the retained evidence key.

Likewise, two accepted stateful scale-in requests could share a target binding
and revocation proof while differing in low-use/availability authorization,
retained-volume proof, and stateful owner. Both produced the same publicly
observable `TerminateNodeIntent`. The intent now retains the exact validated
`ScaleInAuthorization` and revoked-prefix `ScaleInProgress`; its compatibility
`RevocationProof` is asserted equal to the retained progress proof.

The change adds no policy, transition, error, action, trace, or acceptance
path. Existing validation order and denial precedence are unchanged. No
provider adapter or executable operation was introduced.

## Independent regression evidence

- Adversarial accepted pairs differ only in the evidence formerly discarded
  by each output and prove the exact originating references are retained.
- The completeness oracle verifies every new field and the compatibility-field
  equality constraints across generated cases.
- Reflection pins the exact public property shape of all 16 concrete compute
  intents, rejects public setters and constructors, and prevents unrelated
  intent expansion.
- The public observable enum inventory is unchanged: 10 compute triggers,
  7 node roles, 9 scale-out states, 10 scale-in states, 4 provider-create
  statuses, 4 stateful dispositions, 3 volume dispositions, 16 actions,
  20 errors, 16 traces, and 3 requirement codes, each including its sentinel.

## Validation

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo -c Release /warnaserror
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj -c Release --no-build --no-restore -- --no-progress --output Detailed
```

The focused Release run passed 528/528 with zero build warnings and errors.
Final all-suite and diff checks are recorded by the integration handoff.

## Non-claims

This is pure decision-core evidence only. It does not claim provider adapter,
OCI, Pulumi, disconnected replacement, destructive termination, VM, L0C,
rootless container, ARM64, or deployment acceptance.


---

# FILE: docs/work-packages/handoffs/phase1-compute-autoscaling-core.md

# Phase 1 compute autoscaling and regional survival core handoff

- Branch: `phase1/compute-autoscaling-core`
- Work package: `docs/work-packages/phase1-compute-autoscaling-core.md`
- Base: refreshed integrated control-plane commit `2e8d757`
- Scope changed: lane-owned compute source/tests and this handoff only
- External I/O or mutation: none

## Result

Implemented pure scale-out, scale-in, and regional-survival decision engines for
`REQ-O011` and the `INV-005` proof/replay boundary. Inputs are immutable typed
evidence; outputs are closed observe, persist-plan, authorize, request-create,
enroll, ready, cordon, drain, deregister, detach/retain, revoke, terminate,
audit, or hold intents. Every intent, decision, error, and trace has no public
instance constructor and exposes public read-only inspection, so callers cannot
forge an authorized mutation result outside the engine.

Every compute proof binds the exact cell, node class, template, shape,
placement domain, accepted artifact/digest, demand, provider fingerprint,
generation, controller epoch, and operation. Scale-out keeps demand, a
proposed plan, separately persisted-plan evidence, capacity authorization,
provider create observation, and node
progress as distinct evidence. The desired node count and resource envelope
must match across demand, plan, and authorization. Budget, quota, provider
capacity, cost, and placement each fail independently. An unknown provider
outcome emits only observation of the recorded idempotency key; it cannot emit
a second create. Later checkpoints retain and revalidate the full plan,
authorization, exact provider resource, identity attestation, enrollment,
bootstrap/disk checks, placement, and service-health prefix. Each checkpoint
requires every completed proof and rejects any future proof before its state;
the persist-plan intent freezes desired count, resources, and plan identity,
while authorization consumes the exact persistence proof without requiring its
future authorization result.

Stale or missing ordinary demand holds. Future observations always hold, and a
fresh-through position cannot precede its observation. Explicit, bounded
failed-host or safety replacement may continue after an already-observed demand
window expires without a sustained metric window, but still requires
an explicit typed demand and all normal plan/capacity proofs. This exception is
structurally limited to the two closed safety triggers.

Scale-in binds one exact node, provider resource, LB registration, volume,
operation, generation, epoch, and provider fingerprint. It requires fresh
sustained low-use, caller-supplied cooldown and lifetime proof, positive cost
benefit, replacement capacity, availability headroom, healthy regional control
and NATS evidence, no conflicting operation, and explicit stateful approval.
The checkpoint prefix is exact from candidate through cordon, drain,
deregistration, volume handling, revocation, termination, boot-volume absence,
and orphan audit; skipped or future proofs hold. Critical seed/control/NATS/
TerraBase roles retain an R3 floor. Elastic-stateful, control-NATS,
product-NATS, and TerraBase store roles require retained disposition and an
exact controller owner; truly stateless roles require ephemeral disposition
with no owner. No volume-delete, blind pool reduction, adoption, or
orphan-accept intent exists.

Regional survival readiness binds the exact signed/encrypted bundle generation,
provider fingerprint, accepted and rollback artifacts/digests/signatures,
encrypted secret-version identities, full node-class/template/shape/domain
tuples, trust, NATS, DNS, backup, authority epoch, journal/snapshot positions,
and caller-supplied positions ordered snapshot <= journal <= freshness <=
expiry. Disconnected replacement also
binds its exact cell, template tuple, accepted artifact, operation, provider,
idempotent create key, bundle generation, and controller epoch. Ordinary
readiness requires that this irrelevant replacement target be absent;
disconnected authorization requires it to be present and exact. Plaintext secret
material and offline root keys have no representable field.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.ContractTests/TerraScale.Orchestrator.ContractTests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.ModelTests/TerraScale.Orchestrator.ModelTests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.Scheduler.Tests/TerraScale.Orchestrator.Scheduler.Tests.csproj --no-build --no-restore -- --no-progress --output Detailed
git diff --check
```

The compute suite contains 20 focused tests. Coverage includes every scale-out
and scale-in crash checkpoint, lost provider response, stale and bounded safety
demand, cross-authority proof replay, count/resource authorization joins,
budget/quota/capacity/cost/placement vetoes, null and skipped prefixes,
conflicting operations, critical floors, stateful veto/retention, exact LB,
volume, revocation, instance termination, boot absence and orphan audit,
complete/expired/mismatched survival bundles, disconnected target replay,
defensive copies, culture/permutation stability, forbidden surfaces, and public
constructor forgery reflection.
The final direct executable run passed all 317 repository tests: Contract 8,
ControlPlane 209, Model 17, Protocol 42, and Scheduler 41.

## Deliberate limitations

- The engines emit typed intents only. Provider calls, durable operation
  journals, NATS, scheduler placement, agent enrollment, runtime health, LB,
  volume, identity, backup, and orphan adapters remain outside this pure lane.
- Demand windows, safety bounds, cooldown, lifetime, count floors/caps,
  resource/cost envelopes, placement choice, compatibility, bundle freshness,
  expiry, and approval policy are mandatory caller inputs; no default is
  selected here.
- Provider idempotency/work-request semantics, real regional capacity and quota
  conformance, billing evidence, disconnected rootless container recovery, and OCI A1
  replacement remain later integration/deployment evidence.


---

# FILE: docs/work-packages/handoffs/phase1-compute-survival-generation.md

# Phase 1 compute survival-generation anti-rollback handoff

- Final rebased base: `b1e0c76`
- Scope: pure compute survival request/decision, tests, and this handoff
- External I/O or mutation: none

## Defect and correction

Survival validation compared the required bundle with its observed evidence but
had no authoritative current accepted generation. After generation 3 had been
accepted, a fully internally consistent generation-2 bundle, authority proof,
and disconnected replacement target could still emit
`AuthorizeSurvivalIntent` while the older bundle's freshness window remained
open.

`SurvivalRequest` now requires a positive `CurrentAcceptedGeneration`. This
decision consumes an already accepted bundle; it does not advance acceptance.
The required bundle generation must therefore equal that high-water exactly:

- a lower required generation holds with `EvidenceStale`;
- a higher required generation holds with `EvidenceMismatch`, because it is
  being presented as accepted before the authoritative accepted high-water;
- exact equality preserves readiness and disconnected replacement behavior.

Required/observed bundle equivalence is checked before high-water
classification. Once the exact subject is established, generation comparison
precedes completeness, expiry, authority, and replacement-target gates. Thus a
rebound observation remains `EvidenceMismatch`, while internally exact stale
material cannot select a later mutation path by also changing a usability
flag.

The change adds no error, action, trace, intent, factory, provider operation,
or acceptance path. `SurvivalRequest` grows from seven to eight public
properties. Both survival intents already retain the exact bundle, whose
generation must equal the new high-water, so their public shapes are unchanged.

## Regression evidence

- The original executable regression was red: 533 focused tests passed and the
  generation-2 replay test failed because it emitted authorization instead of
  `EvidenceStale`.
- Focused post-fix validation passes 536/536.
- Targeted tests pin zero/negative high-waters as `InvalidInput`, equality for
  readiness and disconnected authorization, lower/higher rejection, and exact
  precedence against rebound, incomplete, expired, and non-authoritative
  evidence.
- A 1,000-case independent lower/equal/higher oracle checks exact outcomes,
  prohibits either survival acceptance intent on rejection, and replays each
  decision across `tr-TR` and `ar-SA` cultures.
- Reflection pins eight `SurvivalRequest` properties and all 16 existing
  compute intent shapes.

## Validation

- Locked solution restore passed after the final rebase.
- Release build with warnings as errors passed with zero warnings and zero
  errors.
- All five executable suites passed: Contract 24, ControlPlane 537, Model 38,
  Protocol 65, and Scheduler 72, for 736/736 total.
- `git diff --check` passed and the worktree was clean.

This is pure decision-core evidence only. It makes no disconnected lab,
provider, OCI, Pulumi, VM, destructive replacement, ARM64, L0C, or deployment
acceptance claim.


---

# FILE: docs/work-packages/handoffs/phase1-control-operation-properties.md

# Phase 1 control/operation property shard handoff

## Result

- Added four deterministic, explicit-seed property families with 1,000 cases each for Authority, Operations, Reconciliation, and their cross-core handoff.
- Added strict, whole-resource- and per-entry-content-addressed embedded minimal counterexamples whose replay behavior is driven by each entry's seed, mutation, delta, and expected outcome.
- Closed public construction of `AuthorityDecision` and `MutationAuthorityPermit`, so accepted authority results and mutation permits can only originate inside the ControlPlane assembly.
- Added a public decision-surface audit and construction-closure assertions.

## Covered invariants

- exact aggregate, operation, resource, target, generation, authorization, executor, and fencing identity
- monotonic epochs/revisions and checked overflow behavior
- durable authorization before dispatch, retry/idempotency behavior, deadlines, compensation preservation, and terminal closure
- stale, unknown, duplicate, conflicting, and reordered observations/journal events
- single-writer fencing and absence of candidate/operation identity leakage in sampled errors
- replay, input permutation, and `tr-TR`/`ar-SA` culture determinism
- reconciliation resource bounds and construction-closed mutation outputs

## Compatibility

`AuthorityDecision` and `MutationAuthorityPermit` keep the same public type names and readable property names/types. Existing consumers that inspect or serialize their public getters remain compatible. Their formerly public positional constructors and positional-record deconstruction surface are intentionally removed; source or binary consumers that directly forged either accepted output must move to decisions returned by `AuthorityEngine`. No wire format is claimed by these in-process contracts.

The cross-core test demonstrates an orchestrated convention, not permit enforcement by the Operations engine. It obtains an authority permit and carries the epoch into the operation journal, but Operations neither consumes nor cryptographically verifies `MutationAuthorityPermit`; an arbitrary epoch is not proven to have originated from `AuthorityEngine` by this shard.

## Validation

```text
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-restore --verbosity minimal
Passed: 291, Failed: 0, Skipped: 0
```

## Evidence boundary

This shard is bounded evidence only. It performs 4,000 generated cases plus corpus and reflection checks without external I/O, networking, process execution, clock reads, cloud actions, or deployment. It does not claim 100,000 cases, exhaustive/full-domain coverage, mutation-score evidence, L0 qualification, or deployment qualification.


---

# FILE: docs/work-packages/handoffs/phase1-delivery-core.md

# Phase 1 delivery core handoff

- Branch: `phase1/delivery-core`
- Work package: `docs/work-packages/phase1-delivery-core.md`
- Scope changed: lane-owned delivery source/tests and this handoff only
- External I/O or mutation: none

## Result

Implemented pure GitOps source, CI runner, artifact promotion, and release
rollout decision engines for `INV-005`. The engines consume caller-supplied
typed evidence and emit closed fetch, verify, plan, dispatch, promote, stage,
advance, rollback, or hold intents. They contain no Git, Forgejo, process,
filesystem, network, clock, signing, approval, or provider implementation.
Every emitted intent, decision, error, and trace has assembly-internal
construction and public read-only inspection, so external callers cannot forge
an authorized-looking mutation result without executing the decision engine.

Source reconciliation binds evidence to the exact source, ref, generation,
commit, tree, manifest, desired digest, signature, schema attestation,
dependency attestation, and complete dependency proof set. Branch movement and
webhook delivery are never authority. Lower generations hold, while same-
generation replay is idempotent only when every source field and dependency is
equal. Dependency order is canonicalized without weakening exact-set checks.

CI decisions validate an explicit closed job-kind/trust-zone/capability matrix,
fresh bounded runner sequence evidence, runner availability, attempts, retry
authorization, and idempotency identity. Selection is ordinal and permutation
and culture invariant. Product-validation work can use only untrusted product
runners and compile/test capabilities; promotion and control recovery have
separate narrowly closed authority surfaces.

Promotion binds qualification evidence to the exact release and generation,
source tree, dependency
lock, generated schema digest, artifact, artifact digest, test/evidence
attestations, signing identity, signature, approval, and compatibility proofs.
Compatibility is explicit for N-to-N and both N/N-1 directions; failure in any
direction denies promotion. A change to any subject dimension invalidates the
entire qualification rather than partially reusing evidence.

Rollout consumes one exact signed artifact and desired generation, an ordered
cell list, exact per-cell forward and rollback availability bound to the release,
operation, generation, artifacts, digests, and both forward and rollback
signatures, disruption and
availability authorization, and staged health proof. Completed-cell evidence
binds operation, release, cell, generation, artifact, digest, signature, and
healthy proof and must form the exact prefix. A lost stage response advances
from exact evidence without restaging. Pending health and process-exit-like
absence of health never advance; failed health deterministically rolls back the
known local digest only when the caller-selected policy permits it.

Reviewer counterexamples were converted into direct regressions: dependency
proof substitution and cross-revision evidence replay; same-generation changes
to ref, manifest, signature, or dependencies; stage evidence from another
operation/signature; bare or mismatched completed-cell claims; promotion proof
replay across release/generation; and availability replay across a rollout or
artifact. Public errors carry only closed requirement and error codes.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.ContractTests/TerraScale.Orchestrator.ContractTests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.ModelTests/TerraScale.Orchestrator.ModelTests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.Scheduler.Tests/TerraScale.Orchestrator.Scheduler.Tests.csproj --no-build --no-restore -- --no-progress --output Detailed
git diff --check
```

The delivery suite contains 16 focused tests covering branch races, duplicate
webhooks, dependency order and substitution, source replay, lower/conflicting
generations, deterministic runner selection, trust-zone escape, explicit retry,
full promotion invalidation, N/N-1 compatibility, staged regional progress,
lost responses, availability, local rollback, exact operation/signature/cell
completion proofs, culture/permutation stability, and reflection-based denial
of executable, secret, callback, process, network, and I/O surfaces. Reflection
also proves that intents, decisions, errors, and traces expose no public
instance constructor. Stage, advance, and rollback payload tests prove exact
operation and forward/rollback signature preservation.
The final direct executable run passed all 247 repository tests: Contract 8,
ControlPlane 139, Model 17, Protocol 42, and Scheduler 41.

## Deliberate limitations

- The core models observations and emits intents; adapters own durable queues,
  Git/OCI resolution, runner lifecycle, artifact transfer, signing, promotion
  leases, journaling, deployment, and health collection.
- Repository placement, manifest schema/defaults, source credentials, runner
  freshness windows, attempt limits, approvals, signing policy, compatibility
  attestations, rollout order/strategy, availability, and rollback policy are
  mandatory caller-owned inputs or upstream evidence. No policy default is
  encoded here.
- Source dependency cycle detection and full cross-repository graph planning
  remain an upstream graph compiler concern; this core proves and freezes its
  exact dependency inputs.
- Durable NATS acknowledgement, one-writer fencing, interruption recovery, and
  real runner/registry/cell conformance remain later integration evidence.


---

# FILE: docs/work-packages/handoffs/phase1-delivery-policy-completeness.md

# Phase 1 Delivery policy completeness handoff

## Defects proven on predecessor `079f4c0`

- An accepted source plan dropped the source signature and schema/dependency attestation identities from `PlanApplyIntent`.
- An accepted promotion consumed but dropped the tests attestation from `PromoteArtifactIntent`.
- Promotion and rollout contracts could not distinguish `linux-arm64` from `linux-x64`, despite architecture-specific artifact/digest promotion requirements.
- Rollout availability, stage, completion, advance, and rollback contracts carried signature references without the expected signing identities.

These were pure accepted-output and evidence-binding defects. No adapter, deployment, cryptographic verification, or external-system behavior was exercised.

## Reviewed resolution

- Added a closed Delivery architecture catalog and exact architecture/signer binding across promotion and rollout inputs and outputs.
- A forward artifact and its rollback artifact for one selected rollout target must use the same target architecture. Shared signature reference IDs remain permitted; no unrelated signature-inequality policy was added.
- Retained the source signature plus schema/dependency attestations in the plan intent and the tests attestation in the promotion intent.
- Added direct denial cases for forward and rollback availability signer mismatch, current-stage signer mismatch, completed-cell signer mismatch, both architecture mismatch directions, and combined-failure precedence.
- Preserved caller-owned rollout order and all existing technical collection limits. No regional order, signer, architecture, or retry default was selected.

## Evidence

- Two deterministic property families execute 1,000 generated cases each. Their cases rotate through 6 source/promotion modes and 23 rollout modes; the count is not 1,000 per individual mode.
- Exact renderings include every field of Plan, Verify, Promote, Stage, Advance, Rollback, Hold, Error, and Trace outputs and compare `en-US` with `tr-TR`, `ar-SA`, and `ja-JP` while restoring both current cultures.
- Undefined observed Delivery enums fail closed before a mutation intent.
- The pre-existing embedded Delivery/TerraBase replay corpus remains content-identical because its expected source outcomes did not change; its construction helper now supplies explicit architecture and signing identities.

## Validation on rebased tree

- `dotnet restore TerraScale.Orchestrator.slnx --locked-mode` — succeeded.
- `dotnet build TerraScale.Orchestrator.slnx --no-restore -c Release -m:1 -warnaserror` — succeeded with zero warnings and zero errors.
- Delivery-focused Release executable — 29 passed, 0 failed.
- Full ControlPlane Release executable — 464 passed, 0 failed.
- `git diff --check` — clean.

This handoff makes no L0, L0C, VM, provider, deployment, or production-acceptance claim.


---

# FILE: docs/work-packages/handoffs/phase1-delivery-source-signature-audit.md

# Phase 1 Delivery source-signature audit

## Finding and correction

Source verification previously compared the proposed and observed opaque
`SignatureId`, but `SourceEvidence` had no result or attestation proving that the
signature was checked. An exact evidence record could mark schema and dependency
verification successful while the source signature was invalid or unchecked, and
the engine emitted `PlanApplyIntent`.

`SourceEvidence` now requires a signature-verification attestation and result.
`DecideSource` emits `VerifySourceIntent` unless signature, schema, and dependency
verification all succeed. An accepted `PlanApplyIntent` retains the exact signature
attestation alongside the existing signature, schema attestation, dependency
attestation, and ordered dependency proofs.

Evidence subject equality still precedes verification-state evaluation. A replay
or mismatched source field remains `EvidenceInvalidated`; an exact but incomplete
or failed verification remains the existing `VerificationRequired` path. No error,
action, trace, or other enum member or numeric value changed.

## Evidence

- The regression counterexample uses an exact proposed and observed forged
  signature ID with successful schema and dependency checks. `SignatureValid=false`
  now produces only `VerifySourceIntent` and never plan/apply authority.
- Null, empty, and overlength signature-attestation identities fail closed as
  invalidated evidence.
- Signature, schema, and dependency verification results are independently gated.
- The plan/apply public-shape inventory and 1,000-case culture-stable output
  fingerprint retain the exact signature attestation.
- The Delivery/TerraBase replay property includes failed signature verification as
  a deterministic source outcome.

## Boundary

This is pure Delivery decision evidence only. It does not implement or qualify a
signature verifier, trust root, signing policy, Git/Forgejo adapter, persistence,
NATS transport, deployment credential, VM, provider, or production acceptance
evidence. It proves only that the pure authorizing boundary can represent and
requires the caller-supplied verification result and retains its attestation.


---

# FILE: docs/work-packages/handoffs/phase1-delivery-stage-output-audit4.md

# Phase 1 delivery stage output audit 4 handoff

## Proven gap and correction

Two otherwise identical accepted staging requests with different valid rollout strategies produced structurally identical `StageReleaseIntent` values. The stage intent flattened artifact identity fields and discarded the validated strategy, rollback policy, ordered-cell policy, and exact selected availability evidence.

Initial staging now retains the exact validated `ReleaseSpec` and the exact `CellArtifactAvailability` selected for the expected cell. All existing compatibility getters derive from those two immutable inputs, including `Cell` from the selected availability. Construction remains internal and `DeliveryEngine.DecideRollout` remains the single public decision route.

Tests pin exact reference retention, existing getter equivalence, defensive ordered-cell snapshot behavior, every release and availability field in an independent length-delimited fingerprint sensitivity matrix, ordered-cell count/order/element sensitivity, all four valid strategies, both rollback policies, 1,000 semantic replays across cultures, hold-only denial paths, and assembly-wide construction closure. The existing 1,000-case Delivery policy suite now compares complete staged provenance. No persisted corpus encoded staged intents, so no replay corpus or checksum changed.

## Honest boundary

This correction retains caller policy and selected in-memory evidence; it does not execute or prove a rollout strategy. It does not prove artifact presence outside the submitted availability record, cryptographic signature validity, registry state, deployment success, health, or external enforcement. Advance and rollback accepted-output shapes are unchanged. No runtime adapter, wire format, deployment, external I/O, or side effect was added.


---

# FILE: docs/work-packages/handoffs/phase1-delivery-terrabase-properties.md

# Phase 1 delivery and TerraBase property/replay handoff

## Result

Added four deterministic 1,000-case property families covering immutable Delivery source evidence, promotion and rollout behavior, TerraBase topology/writer fencing, and backup/restore recovery. Independent mode oracles assert exact actions or closed error codes for stale and conflicting generations, exact digests/signatures, dependency permutation, promotion invalidation, rollout rollback and terminal replay, permanent membership, quorum/loss floors, writer conflicts, chain gaps, terminal backup identity, and restore anti-rollback behavior. Each family is replayed under Turkish and Arabic cultures with stable summaries.

The strict embedded corpus is bounded to 32 KiB and 64 entries, rejects unknown/duplicate/malformed fields, pins the complete resource SHA-256, pins every entry's length-delimited canonical digest, and proves changed replay inputs change the exercised decision.

Production hardening replaces unbounded enumerable materialization with named technical snapshots. Delivery dependencies, trust zones, capabilities, rollout cells/completions/availability are capped, and direct runner evidence lists have an explicit count cap. TerraBase writer and backup inputs use the stricter of the caller maximum and a 4,096-item technical ceiling. Max+1 is detected before reading the extra `Current`; nulls and ordinary iterator failures become generic `ArgumentException` values without source exception text, while `OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException` propagate. Tests cover exact bounds, max+1, infinite inputs, extra-`Current`, all iterator phases, dispose-time mutation, defensive copying, nulls, and fatal propagation.

A follow-up audit found that out-of-catalog enum values at legitimate checkpoints were not distinguished from
defined `Unknown` values. In particular, forged numeric values could reach `Add`, `CatchUp`, `Remove`, `Upgrade`,
or `Restore` outputs. All 44 enum-valued TerraBase evidence fields now reject undefined values as exact
`InvalidInput` holds before mutation. Defined `Unknown` and `Contradicted` values retain the pre-existing checkpoint
precedence. A new bounded shard runs 1,000 independent cases across the complete enum inventory and another 1,000
across all ten scope dimensions for all six planners plus exact all-field authorizing subjects and traces. The shard
reuses the already pinned TerraBase replay corpus; it does not invent duplicate saved examples or acceptance evidence.

## Compatibility impact

- Delivery collections above the new published technical ceilings now throw `ArgumentException` during construction instead of attempting unbounded allocation.
- TerraBase writer/backup inputs above the existing caller maximum now throw `ArgumentException` during construction instead of producing an `IsValid == false` object after fully enumerating the source.
- Existing valid inputs and caller maxima remain unchanged. The constants are technical resource-safety limits, not business rules or deployment claims.

## Verification

```text
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
Build succeeded: 0 warnings, 0 errors

dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --no-progress --output Normal
Passed: 315, failed: 0, skipped: 0

Other executable test projects passed serially: Contract 24, Model 38, Protocol 50, Scheduler 69.
Whole repository total: 496 passed, 0 failed, 0 skipped.

git diff --check
Passed
```

## Non-claims

This shard contains no Git/Forgejo, process, network, filesystem runtime, NATS, cloud/provider, package, signing implementation, or deployment execution. It is unit/property/replay evidence for pure decisions only and does not satisfy L0, L3S, L4, production readiness, or deployment acceptance.


---

# FILE: docs/work-packages/handoffs/phase1-evidence-accepted-scope-audit.md

# Phase 1 evidence accepted-scope audit handoff

## Proven gap and correction

Two otherwise valid evidence-gate calls could use different manifest identities and different matching verified signer identities while retaining the same payload digest, generation, expiry, and numeric counts. Both calls authorized, but their `EvidenceDecision` values compared equal because the accepted output retained only action, code, payload digest, and numeric trace.

Accepted decisions now carry a construction-closed `EvidenceAuthorizationScope` with the exact manifest identity, lane, gate target, signing profile, signing identity, signature identity, generation, and expiry sequence. Hold decisions carry no authorization scope. Subject, policy, signature, generation, expiry, verifier, lane, and action precedence is unchanged, and no error code was added.

Tests pin every retained scope field, exact independently reconstructed replay equality, distinct accepted outputs when any retained field changes, exact retained identity instances and numeric values, null scope on denials, construction closure, and redacted formatting. The existing 1,000-case evidence decision oracle and snapshot/evidence property suite also inspect the accepted scope.

## Honest boundary

This scope retains the signature identity, not opaque signature bytes, verifier implementation identity, or full policy and threshold provenance. It must not be described as complete cryptographic authorization provenance. The change does not qualify a signer, verifier, evidence lane, architecture artifact, credential release, deployment, or production environment, and it performs no external I/O.


---

# FILE: docs/work-packages/handoffs/phase1-identity-network-properties.md

# Phase 1 identity and network deterministic property shard handoff

## Scope

- Adds seven deterministic property families with exactly 1,000 explicit cases each across enrollment, certificate lifecycle, authorization/secret lease, route/peer policy, ingress, and culture/permutation/replay behavior.
- Adds a 23-entry embedded replay corpus, including the later public-HTTP and route-permutation regression seeds. The complete resource is limited to 8,192 bytes and pinned to SHA-256 `435c686afc9495cfcd03796fbdbafbe2d70bd9653363b647a1d59dead5e7213c`; parsing rejects comments, trailing commas, excess depth, unknown/missing fields, excess entries, duplicate identities, and zero seeds.
- Adds independent closed scalar/action oracles and verifies stale, revoked, consumed, missing, duplicate, conflicting, cross-cell, route-leak, and generation evidence fail closed.
- Verifies authorized security intents cannot be publicly constructed and network mutation decisions remain construction-closed; the two public network intent subjects remain typed data only and cannot authorize a decision.

## Production hardening

- Security and networking enumerable inputs now use namespace-local bounded snapshot helpers with a named 4,096-item technical ceiling.
- Existing caller-provided route/prefix/link/cell maxima remain separate input/business constraints and constructor signatures are unchanged.
- Max+1 and infinite inputs reject after `MoveNext` and before reading the extra `Current`. Ordinary `GetEnumerator`, `MoveNext`, `Current`, and `Dispose` failures become generic secret-safe `ArgumentException` values without an inner exception. `OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException` propagate.
- Snapshot tests cover exact maximum, maximum+1, infinite input, extra-`Current`, every iterator phase, dispose mutation, and fatal propagation for both helper families.
- Compatibility impact: no source/binary constructor signature change. Inputs over the technical cap and hostile/failing iterators that previously could run unbounded or leak iterator exceptions now fail closed.

## Verification

- `dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-restore -c Release`: 321/321 passed.
- `dotnet test TerraScale.Orchestrator.slnx --no-restore -c Release`: 502/502 passed.
- `dotnet build TerraScale.Orchestrator.slnx --no-restore -c Release`: succeeded with zero warnings and zero errors.

This is bounded deterministic feature-shard evidence only and does not satisfy the full L0 thresholds. It does not select PKI algorithms, issuer/vault custody, VPN/DNS/LB implementations, retention/lifetime defaults, start external systems, or qualify deployment behavior.


---

# FILE: docs/work-packages/handoffs/phase1-identity-vault-core.md

# Phase 1 identity, PKI, and vault decision core handoff

- Work package predecessor: `a1ecba0`
- Branch starting point: `5315e7d`
- Scope changed: `Security/**`, `Security*.cs` tests, and this handoff only
- Cryptographic operations, secret storage, clocks, files, networks, and external mutations: none

## Result

The control plane now has a pure default-deny decision boundary for enrollment, certificate lifecycle, closed capability authorization, encrypted-secret leases, and regional survival secret references.

Enrollment binds the exact operation, principal, public subject-key identity, cell, role, principal generation, one-time bootstrap audience/status, attestation measurement and policy generation, regional issuer generation, and revocation generation. Consumed bootstrap evidence, stale/missing/conflicting evidence, principal replay, cross-cell reuse, and stale issuer/revocation views cannot emit an identity-issuance intent. Missing but otherwise exact attestation evidence emits only a typed attestation intent.

Certificate issue/renew/rotate/revoke decisions consume explicit caller lifecycle policy and validity evidence. Validity evidence binds certificate, operation, principal, cell, public subject-key identity, usage, trust scope, issuer identity/generation, certificate generation, policy generation, and revocation generation. Regional issuers are structurally cell scoped and cannot request global trust. Renewal and rotation require exact next-generation and caller validity evidence; compromise revocation requires an exact certificate/principal/cell/generation proof.

Authorization requires one complete, unique, consistent principal record; independent expected and current principal generations; independent requested and current policy generations; a current revocation view; one exact current-policy grant; same-cell access; and bounded role/capability semantics. No matching grant is a denial. Untrusted CI cannot read or lease encrypted secrets, and non-operator principals cannot administer global trust even if a forged broader grant is supplied.

Vault decisions contain encrypted metadata only: secret/version/scope/purpose, wrapping-key identity, and ciphertext digest. Grant and renewal bind an exact requested lease identity and require current identity, policy, revocation, exact action-specific grant, retained version, availability, explicit maximum lease duration, and exact existing-lease evidence when applicable. Revocation still requires exact lease/principal/secret digest/scope plus current authorization and revocation evidence, but deliberately does not depend on the encrypted version remaining available/retained, retention-policy expiry, or a duration extension. Regional survival accepts exact encrypted version/digest references only when matching available metadata and a current unexpired retention policy exist.

## Structural exclusions

There is no online root issuer kind, private-key carrier, plaintext/ciphertext byte carrier, secret value, credential value, reveal endpoint, callback, executable text, algorithm choice, crypto operation, clock/time type, storage abstraction, or I/O surface in this package. Subject and wrapping keys are represented only by bounded identities; secret content is represented only by a canonical digest and versioned encrypted metadata.

## Adversarial coverage

Security-prefixed tests cover bootstrap replay and consumption, principal/cell/role/generation replay, stale and missing attestation, duplicate/conflicting evidence, stale issuer and revocation views, cross-cell/global regional issuance, validity-proof replay across principal/key/scope/issuer/operation, renewal/rotation overlap, scoped compromise revocation, authorization default deny and escalation, lower-generation identity evidence even when request and evidence agree, encrypted version rollback, missing/unretained versions, lease duration and expiry, action-specific grants, exact lease renewal/revocation, survival reference mismatch, defensive copies, culture determinism, forbidden shapes, malformed identities/digests, unknown enums, and secret-safe traces.

## Verification

```text
dotnet restore tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --locked-mode
dotnet build tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-restore
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build
git diff --check
```

The final local suite completed with 130 tests passed, 0 failed, and 0 skipped. The build completed with 0 warnings and 0 errors.

## Deferred adapter and owner inputs

No unresolved pure-core authorization gap was identified at handoff. Signature algorithms, certificate lifetimes/windows/overlap values, vault backend and durability, offline/recovery-root procedure, owner retention policy, attestation verification, atomic bootstrap consumption, cryptographic issuance/revocation, lease persistence, and immediate connection termination remain explicit owner or adapter inputs. Adapters must consume these typed intents and return scoped evidence; they may not introduce policy defaults or weaken generation/scope checks.

## Follow-up accepted-output audit

A later independent audit found two accepted-output gaps in the original handoff. First, attestation evidence did not carry the public subject-key identity, so otherwise exact evidence could be replayed while substituting the key in the enrollment request. Attestation evidence now binds that bounded public key identity, and both valid and missing-attestation flows reject substitution before emitting an issue or attestation intent. The complete enrollment trace has fourteen reasons in fixed order; ambiguous evidence still returns only the original three collection reasons.

Second, exact authorization grants did not close the capability/resource-kind pairing. The authorization boundary now permits only enrollment capabilities on enrollment resources, identity lifecycle capabilities on certificate resources, encrypted-secret reads on encrypted-secret resources, lease capabilities on lease resources, and global-trust administration on trust-bundle resources. This remains part of `PrivilegeBounded`; no new principal-role policy was inferred beyond the existing same-cell, untrusted-CI, and operator global-trust restrictions.

The audit inventoried all closed policy catalogs: 6 principal kinds, 9 roles, 8 certificate usages, 2 trust scopes, 2 issuer kinds, 6 evidence statuses, 3 revocation statuses, 4 validity statuses, 4 certificate actions, 10 authorization capabilities, 5 resource kinds, 4 environments, 6 secret purposes, 4 availability states, 3 lease actions, and 3 lease statuses. Outputs remain construction-closed across 27 stable decision codes, 4 outcomes, and 12 intent types. No plaintext, private-key, credential-value, crypto, clock, storage, or I/O surface was added.

After rebasing onto integration commit `05ad65b`, locked restore and the warnings-as-errors Release build completed with zero warnings and zero errors. The focused Security shard passed 35/35, the complete ControlPlane suite passed 485/485, and all five test projects passed 681/681 (Contract 24, ControlPlane 485, Model 38, Protocol 65, Scheduler 69). `git diff --check` passed.


---

# FILE: docs/work-packages/handoffs/phase1-messaging-policy-audit2.md

# Phase 1 Messaging/NATS policy audit handoff

## Scope and baseline

- Audited the pure Messaging/NATS policy at integration baseline `621c37d`.
- Changed only the Messaging replacement decision, its dedicated property tests, and this handoff.
- No NATS process, socket, filesystem, VM, cloud API, or other external system was used.

## Proven defect

`DecideTopology` rejected a critical stream or bucket that did not meet the declared membership floor,
replicated acknowledgement, and acknowledged-write-strict disk-sync contract. The public
`DecideReplacement` entry point did not repeat that safety validation. A caller could therefore supply a
floor-three plane with a critical RF1 stream, present a matching healthy RF1 observation after replacement
catch-up, and receive `RemovePeerIntent`.

The test-only pre-fix regression failed on exact integration head `1ad1769` and again after rebasing because
the returned decision contained no error and reached the remove-peer branch. The regression was retained and
expanded only after adversarial steward review.

## Resolution

- Replacement validation now examines every stream and bucket before an absent or supplied observation can
  produce persistence, add, reattach, or removal output.
- Undefined or out-of-range durability, acknowledgement, or disk-sync values and replica counts above the
  admitted server count return `InvalidInput`.
- A defined critical resource below the caller-declared membership floor, without replicated acknowledgement,
  or without acknowledged-write-strict sync returns `DurabilityViolation`.
- The pre-existing `Replicas <= 0` replacement classification remains `ReplacementConflict`.
- Explicit bounded resources remain permitted below the membership floor. No implicit R3, retention, subject,
  account, timing, storage, or owner-decision default was added.
- Topology and replacement validation share the same narrow critical-durability predicate so the two entry
  points cannot drift on this invariant.

## Completeness inventory

- Input enum families inspected: plane, durability, retention, discard, acknowledgement, disk-sync, peer
  health, store classification, compatibility feature/pair, authority scope, and connectivity.
- Output enum families inspected: messaging action, error code, and trace code.
- Replacement branches inventoried: initial observation, persist, add, catch-up wait, replica-verification wait,
  remove, completion, surviving-store reattach, surviving-store re-observation, and every hold class.
- Other decision outputs inventoried: ordered control/product configuration, regional/global continuation,
  compatibility acceptance, and hold.
- Existing construction-closure reflection covers every exported `MessagingIntent` subtype and
  `MessagingDecision`; no public constructor, setter, deconstructor, or factory outside the four decision
  methods exists.
- Existing dual-plane properties cover shared cluster/server/peer/account/stream/bucket/subject authority,
  product gateways, and control-to-product gateway conflicts. This audit did not weaken those boundaries.

## New deterministic evidence

- 1,000 adversarial cases alternate stream and bucket mutations across below-floor replicas,
  non-replicated acknowledgement, non-strict sync, undefined/out-of-range safety enum values, and replicas
  above the admitted server count. Exact error, hold intent subject, trace tuple, and absence of remove output
  are asserted.
- 1,000 positive cases preserve caller-configurable policy by alternating bounded RF1 stream, bounded RF1
  bucket, and exact-floor critical resources. Exact remove-peer subject and trace tuple are asserted.
- Both matrices replay under distinct cultures and reversed input collection order.
- Invalid replacement resource policy takes precedence before observation handling; existing observation
  duplicate/conflict/stale/future precedence is unchanged.

## Validation

- Focused completeness shard: 3 passed, 0 failed.
- Full Control Plane suite: 488 passed, 0 failed.
- Locked restore succeeded and the warnings-as-errors solution build completed with 0 warnings and 0 errors.
- All five executable test suites passed: Contract 24, Protocol 65, Scheduler 72, Control Plane 488, and
  Model 38; 687 total passed, 0 failed.
- `git diff --check` passed on the exact committed audit head.

## Deliberate boundaries

- This is pure L0 policy evidence only. It does not qualify NATS configuration, JetStream behavior,
  acknowledgement persistence, disk sync, peer administration, or replacement against a real NATS server.
- L0C and the later L2S/L3S/L4 membership, conformance, failure, and recovery gates remain required.


---

# FILE: docs/work-packages/handoffs/phase1-messaging-policy-audit3.md

# Phase 1 Messaging/NATS surviving-store evidence audit handoff

## Scope and baseline

- Audited the pure Messaging/NATS replacement policy on final integration baseline `ec0dc50` after rebasing
  the initially proven `369a3a1` counterexample onto the steward's current tree.
- Changed only Messaging replacement contracts and decisions, their dedicated tests, and this handoff.
- No NATS process, socket, filesystem, VM, cloud API, or other external system was used.

## Proven defect

`ReplacementOperation` bound the failed server and peer but not the store identity or its accepted generation.
An otherwise exact surviving-store observation could therefore substitute an unrelated store owned by the same
server at generation 1 and receive a `ReattachSurvivingStoreIntent` for that substituted store. The retained
pre-fix regression failed because the decision contained no error and authorized the reattachment.

## Resolution

- Every replacement operation now carries the exact failed store and positive current accepted store generation.
- The proposed and persisted operation equality therefore binds both fields before any mutation output.
- A surviving proof for another store is conflicting evidence.
- A proof below the accepted store generation is stale; a proof above it is future evidence. This evaluator does
  not advance store generations, so only exact equality can reattach.
- Validation precedence is structural and scope consistency, store identity, trust-plane isolation, any lower
  membership/ownership/store dimension, any higher dimension, then exact acceptance.
- Existing error and trace enums were not changed.

## Deterministic evidence

- Unit regressions pin arbitrary-store substitution, lower and higher store generations, mixed lower/future
  precedence, malformed operation store fields, persisted-operation mismatch by each added field, and exact
  configure and reattach output fields.
- A 1,000-case property matrix covers exact, different-store, lower-generation, higher-generation, and mixed
  lower/future proofs under distinct cultures and reversed evidence order.
- The Messaging replay fingerprint now includes every public field of `ReattachSurvivingStoreIntent`, including
  store generation and observed membership sequence, so distinct accepted outputs cannot collide silently.

## Validation boundary

This package proves pure L0 decision behavior only. It does not qualify NATS or JetStream persistence, peer
administration, store attachment, disk synchronization, or crash recovery. Real NATS L0C and later L2S/L3S/L4
membership and recovery gates remain required.

## Validation

- Locked restore succeeded.
- Serialized Release warnings-as-errors solution build succeeded with 0 warnings and 0 errors. An earlier
  parallel build lost an MSBuild child process while other agent builds were active; the serialized rerun was
  clean and no source/test failure was involved.
- Focused Messaging policy shard: 27 passed, 0 failed.
- Full Control Plane suite: 554 passed, 0 failed.
- On the exact `ec0dc50`-based audit tree, all five executable suites passed: Contract 24, Protocol 65,
  Scheduler 77, Control Plane 554, and Model 38; 758 total passed, 0 failed.
- `git diff --check` passed.


---

# FILE: docs/work-packages/handoffs/phase1-messaging-policy-properties.md

# Phase 1 messaging policy property shard handoff

## Delivered

- Three deterministic 1,000-case property families cover replacement ordering, regional/global partition authority, and every dual-plane isolation surface, including exact emitted subjects and cross-culture/permutation replay.
- Public authorizing `MessagingIntent` implementations and `MessagingDecision` are construction-closed; reflection coverage enumerates every exported assignable intent type and rejects public constructors/factories.
- Caller-controlled messaging collections are defensively captured with a documented 4,096-item technical bound. Over-bound input is rejected before the extra element's `Current`; ordinary iterator/count failures are generic and secret-safe, while `OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException` propagate.
- Compatibility decisions fail closed as `InvalidCatalog` for hostile counts/enumerators. The pre-existing `MaximumResources` business input remains independent and unchanged.
- The 12-entry embedded replay corpus is strict-schema, duplicate-aware, UTF-8 byte-bounded to 32,768 bytes, whole-file SHA-256-pinned, closed to known family/mode/outcome triples, and verifies input-sensitive replay fingerprints.

## Compatibility

- Intent and decision public types and property getters remain available, and policy-engine decision signatures are unchanged.
- This intentionally breaks source/binary compatibility for callers that directly invoked public positional constructors or positional `Deconstruct` members on intent/decision records. Such callers could forge authorizing outputs; construction is now internal to the control-plane assembly.
- Collections of at most 4,096 non-null items retain their prior values and enumeration order. Larger collections now throw `ArgumentException` during DTO construction instead of being captured without bound. Ordinary hostile iterator details are no longer exposed through exception text or inner exceptions.
- `DecideCompatibility` retains its fail-closed decision style: oversized or ordinarily faulty feature lists yield held `InvalidCatalog`; fatal runtime exceptions still propagate.

## Boundary

Pure policy only. No NATS/process/network/filesystem/cloud execution was added or tested, and no L0C claim is made.


---

# FILE: docs/work-packages/handoffs/phase1-mutation-foundation.md

# Phase 1 mutation-evidence foundation handoff

## Delivered

- Strict machine-readable inventory for all five current production projects.
  The four correctness-critical library projects are mandatory. The only
  exclusion is the exact Phase 0 composition-root source, bound by path and
  SHA-256 to a checked-in proof.
- Closed allowed and forbidden exclusion catalogs. State transitions,
  validators, authority, fencing, deletion, retry, compensation, and adapter
  result classification can never be excluded.
- A zero-claim report cross-checked against the existing supply-chain audit,
  which identifies dotnet-stryker 4.16.0 only as an unselected candidate.
  Every result is null and every acceptance claim is false.
- A standard-library validator that rejects schema drift, duplicate keys,
  unsafe/symlink paths, production-project drift, stale policy/exclusion
  digests, expiration, weakened thresholds, safety survivors, and premature
  selection/execution/acceptance claims.
- Eighteen data-driven negative fixtures plus direct tests for stale reports,
  recursive project/source drift, duplicate JSON keys, unknown fields,
  noncanonical/overlong paths, and symlinked path components.

## Required decision

The owner/toolchain steward must select the mutation tool and exact version.
Before execution is wired, the selection also requires a locked content hash,
internal mirror, .NET 10/TUnit compatibility proof, stable mutant denominator,
deterministic normalized report, and reviewed safety-mutant classification.
The existing candidate record is not that decision.

## Verification

- `dotnet run --project tools/TerraScale.Orchestrator.Tooling -- mutation-evidence --as-of 2026-07-13` —
  passed with the explicit unresolved/zero-claim result.
- `dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test` — passed
  (11/11 tests; 18 named negative fixtures).
- All three JSON documents passed the C# `json-format` command.

## Non-claims

No mutation package was selected, installed, restored, downloaded, or run. No
mutants were generated. This package claims no mutation score, denominator,
safety-invariant closure, L0/L0C completion, full correctness-critical run,
CI credential gate, or deployment evidence. It changes no production code,
central package pin, solution file, or sibling repository.


---

# FILE: docs/work-packages/handoffs/phase1-nats-l0c-foundation.md

# Phase 1 real-NATS L0C foundation handoff

## Delivered

- A 28-case deterministic, machine-readable planned L0C inventory covering dual control/product isolation, JWT/account/subject denials, R3 stream/KV contracts, gateway partitions, duplicate/reorder/ack/redelivery, one-server/quorum loss, both client/server N/N-1 directions, N/N-1 snapshot format behavior, and signed snapshot/replay recovery.
- A dependency-free offline validator with closed object fields and catalogs, a canonical whole-inventory content digest, duplicate-key rejection, repository path containment, every-component no-symlink/regular-file checks, byte/count/string bounds, exact candidate-manifest digest binding, complete category/assertion coverage, and fail-closed candidate-state checks.
- Fifteen data-driven negative mutations—including an otherwise-valid closed-value semantic swap—plus direct duplicate-key, path, leaf/parent symlink, byte, case-count, and string-bound tests.
- An intentionally stale, zero-result report that cannot be confused with current execution or acceptance evidence.

## Pin audit and blockers

The checked candidate manifest has exact version/artifact metadata for two server candidates, two managed client candidates, and one CLI candidate. This is not an executable selected closure:

- every server, client, and CLI `selected` value is false;
- `nMinusOnePolicy` is null and the candidate pair is unexecuted;
- no JWT/NKey generation/administration toolchain is selected or pinned;
- the snapshot signing identity/key technology is unselected;
- no pinned rootless-container toolchain observation currently qualifies the hermetic L0C environment;
- internal mirror and independent verification receipts are absent;
- generated credential, permission, account, stream, KV, gateway, and certificate inputs do not yet exist;
- critical sync/RPO values remain owner inputs.

No NATS or JWT process was started, no binary/package was downloaded or selected, and no network, VM, cloud, credential, or production action occurred.

## Nonclaims

This package proves only that a bounded planned case contract remains structurally complete and honestly blocked. It does not prove any NATS behavior, real L0C, ARM64, N/N-1 compatibility, R3 durability, JWT authorization, gateway partition behavior, snapshot recovery, configuration correctness, or production qualification. It does not satisfy any registry acceptance layer and cannot enter pre-deployment evidence.

## Verification

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- nats-l0c
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/nats-l0c/l0c-cases.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/nats-l0c/l0c-report.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/nats-l0c/negative-cases.json
git diff --check
```


---

# FILE: docs/work-packages/handoffs/phase1-nats-policy-audit3.md

# Phase 1 NATS policy accepted-observation audit 3 handoff

## Proven defect and resolution

The pure replacement policy accepted distinct operations while collapsing their initial or repeated observation
commands to the same executable value whenever operation ID, cluster, and observation bounds matched. In
particular, changing only the accepted authority epoch produced an equal `ObserveClusterIntent`, erasing the
provenance needed to distinguish the authorized operation.

`ObserveClusterIntent` now retains the exact accepted `ReplacementOperation` under `Replacement`. Its existing
operation-ID, cluster, and sequence-bound properties are derived from that retained value, so the prior read surface
continues to expose the same values. Both policy construction sites pass the accepted operation directly. No
validation, numeric comparison, error/trace catalog, decision precedence, or replacement progression changed.

## Deterministic evidence

- The focused regression pins exact reference retention and all sixteen replacement-operation fields.
- Sixteen independently accepted substitutions prove output and canonical-fingerprint inequality, including the
  original authority-epoch substitution.
- Identical replay remains equal and its complete fingerprint is invariant under Turkish and Arabic cultures.
- The surviving active-attachment re-observation branch retains the same exact operation under reversed peer and
  replica evidence order.
- The 1,000-case replacement property oracle now requires exact replacement retention, and the embedded Messaging
  corpus fingerprint serializes every retained operation field.
- Existing reflection coverage continues to prove that intents and decisions expose no public constructors,
  setters, deconstructors, or alternate public factories.

## Scope boundary and nonclaims

This binds accepted replacement-operation provenance only. The intent does not retain the cluster observation,
surviving-store proof, rejected evidence, response authenticity, or the complete selection/authorization context.
It performs no NATS, network, process, credential, filesystem-administration, VM, cloud, or deployment action.

The real-NATS L0C foundation remains an intentionally stale, zero-result plan. This audit neither executed it nor
proves NATS/JetStream persistence, membership administration, response authenticity, R3 durability, gateway
isolation, snapshot recovery, compatibility, ARM64 readiness, or production qualification.

## Validation

- Offline Release build with existing locked restore artifacts: 0 warnings, 0 errors.
- Focused observation provenance, re-observation permutation, 1,000-case replacement property, embedded replay
  corpus, and construction-closure tests: passed.
- `git diff --check`: passed.


---

# FILE: docs/work-packages/handoffs/phase1-nats-policy-core.md

# Phase 1 dual-NATS policy core handoff

## Delivered

- Pure typed control/product plane policies for cells, clusters, servers, peers, placements, accounts, subject roots, streams, buckets, routes, gateways, retention, discard, acknowledgement, disk-sync/RPO classification, and compatibility features.
- Explicit caller bounds and values throughout; there is no R3, storage, timing, sync, retention, or compatibility default.
- Closed scalar-safe identities and enum catalogs with `Unspecified=0` rejected throughout, positive generation/epoch/sequence validation, and overflow-safe arithmetic.
- Subject roots use a canonical lowercase token grammar with an optional terminal `>` only; empty tokens, uppercase, embedded `*`, embedded `>`, and malformed wildcards are rejected before any overlap decision.
- Control/product isolation rejects shared cluster/server/peer/account/stream/bucket/subject authority, product gateways, overlapping account namespaces, and stream/bucket subjects outside their owning account.
- Critical durability rejects singleton or below-floor replicas, non-replicated acknowledgement, and non-strict acknowledged-write classification. Caller-supplied route sets must be unique, known, non-self, and strongly connected; a complete directed mesh is not assumed. Explicit membership floors are validated.
- Configure intents carry the complete immutable typed plane policy rather than generated NATS text or an under-specified flag.
- Lost-peer replacement progression is observation-driven and ordered: observe, persist exact operation, add one replacement, wait for catch-up, verify exact stream/bucket replicas, then remove the exact failed peer. A lost add response that is visible in membership never emits a second add.
- Observed peers must match admitted policy or the exact replacement; unknown peers cannot satisfy membership floors. Failed-process fencing is separate from positive current-peer ownership proof.
- Partition decisions allow only caller-authorized regional work at the exact current regional epoch and accepted global generation during global disconnection. Regional quorum loss holds. Global work requires connectivity, current global authority, and exact global epoch/generation.
- N/N and both directional N/N-1 outcomes are required for every closed compatibility feature; missing, duplicate, unknown, or unavailable outcomes hold.
- Stable numeric/code-only errors and trace, defensive copies, culture/input permutation determinism, and no free-form message, callback, payload, executable data, credentials, NATS object, clock, or I/O.

## Steward-approved contract expansion

The package output list initially omitted the `ReattachSurvivingStore` branch required by `ORCHESTRATOR.md`. The steward explicitly approved a closed `ReattachSurvivingStoreIntent`. It binds:

- exact operation, plane, cell, cluster, recorded server/peer, and replacement placement evidence;
- surviving store identity and positive observed store generation;
- exact observed membership sequence and ownership epoch;
- recorded owner, compatibility proof, and absence of a conflicting active attachment.

Wrong-plane, incompatible, stale/future proof, a conflicting attachment, or any attempted server/peer identity swap holds. Reattachment targets the recorded failed server and peer identity at the replacement placement; it never invents a peer and never enters the remove-peer path. When an observation proves a lost reattach response already restored that same recorded identity and its replicas are healthy, replay completes without emitting another reattach.

## Files

- `src/TerraScale.Orchestrator.ControlPlane/Messaging/MessagingContracts.cs`
- `src/TerraScale.Orchestrator.ControlPlane/Messaging/MessagingPolicyEngine.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/MessagingPolicyEngineTests.cs`

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --no-progress
git diff --check
```

- Solution build: 0 warnings, 0 errors.
- Control Plane suite: 75 passed, 0 failed (15 messaging tests plus 60 existing authority, operation, reconciliation, and snapshot tests).
- All five repository test executables: 183 passed, 0 failed (Contract 8, Control Plane 75, Model 17, Protocol 42, Scheduler 41).

## Deliberate boundaries

- The core does not generate NATS configuration text, contact a server, inspect a store, attach storage, retry, select versions, choose RPO/SLO values, or persist/execute intents.
- Store compatibility, ownership, attachment, and membership observations must come from a separately authenticated adapter/coordinator boundary; this core only validates and freezes that evidence.
- Disaster recovery with fewer than N-1 current owned peers is not authorized here. It holds for a separately tested and explicitly authorized recovery workflow.


---

# FILE: docs/work-packages/handoffs/phase1-networking-output-provenance-audit4.md

# Phase 1 networking accepted-output provenance audit 4 handoff

## Delivered

- Route accepted subjects retain the exact accepted scope, observed generation and epoch, and complete route evidence.
- Endpoint accepted subjects retain the exact accepted scope and evidence plus the semantic planner route: registration, removal, or emergency withdrawal.
- Legacy subject accessors remain available and derive from the retained scope, preventing two independent representations from drifting.
- Route evidence equality and hashing are structural and culture-independent. Semantic collection ordering is ignored, but duplicate count, typed identity, binary prefix, route ownership, peer linkage, trust plane, topology shape, proof state, and partition state are all preserved.
- Every held networking decision remains non-authorizing and has a null subject.
- Public construction remains closed to the four planner entry points. One allowlisted return-route inventory covers decisions, base and concrete subjects, retained scopes/evidence/trace, record clones, and route-evidence collection projections. Decision default/value copy and subject record clone routes cannot add authority or replace retained basis references.
- Sensitivity proofs independently vary every route-scope leaf, destination address width and prefix length, and both retained observation ordinals; otherwise-identical emitted decisions remain unequal when either observation ordinal changes.

## Verification evidence

- Pre-correction counterexample run: 3/3 failed with accepted-output equality collisions.
- Post-review focused provenance suite: 12/12 passed.
- Post-review ControlPlane suite: 655/655 passed.
- Test-project warnings-as-errors build: 0 warnings and 0 errors.
- Strict replay corpus: 25 entries, whole-file SHA-256 pinned.

Final Release solution and five-suite verification are performed after the required exact-central rebase; record those final counts in the coordinating review.

## Boundaries

The implementation remains a pure L0 policy core. It performs no VPN, peering, route, DNS, load-balancer, firewall, provider, network, cloud, VM, process, filesystem, or clock effect. Adapters must durably persist the exact retained scope/evidence and map the fixed semantic plan kind without weakening policy.


---

# FILE: docs/work-packages/handoffs/phase1-networking-policy-core.md

# Phase 1 networking policy core handoff

## Delivered

- Bounded typed identities with no public mutation/clone-forgery path, canonical defensive-copy binary addresses/prefixes, ports, positive generations/epochs, closed policy catalogs, stable numeric traces, and exact route/endpoint intent subjects.
- Route/tunnel authorization binds cell, network, subnet, route, peer, tunnel, trust plane, route kind, prefix, generation, epoch, and operation. It rejects stale/future authority, duplicate or ambiguous routes, overlaps, leaks, reflection, trust-plane crossover, and wrong-cell evidence.
- Topology evidence includes a bounded defensive-copy cell inventory and explicit directed peer links. Launch full mesh requires exactly three cells and every directed non-self pair. Hub/spoke requires exactly one hub, bidirectional links to every inventory spoke, no spoke-to-spoke links, and exact linear edge cardinality; explicit replication remains linearly bounded. Route scopes must name inventory members and non-local routes must prove their adjacency. Partition operation cannot acquire global authority and is restricted to an explicitly approved local product route.
- Tunnel changes stage configuration before traffic/health proof and route activation; contradicted proof emits deterministic rollback.
- Endpoint policy binds cell/workload/service/endpoint/node/LB/backend/DNS/certificate/exposure/protocol/port/generation/epoch/operation. Default deny, readiness, backend health, trust, certificate, production gate, owner approval, and tested withdrawal gate public ingress.
- Administration and monitoring endpoints are private-only. DNS lost responses observe convergence without duplicate updates. Deregistration precedes drain. Emergency withdrawal deterministically removes DNS before LB and separates requests from observed convergence.
- All planner entry points totalize null, malformed observation fields, and out-of-domain enum values into typed non-authorizing decisions. Endpoint process liveness is an enforced registration prerequisite.
- Adversarial tests cover replay, stale/future state, identity and scope forgery, malformed/null evidence, invalid enums, reflection, overlap/leak/crossover, disguised quadratic mesh, missing scope cells, inventory bounds, partition locality, process liveness, partial tunnel failure, stale health, public/admin denial, certificate mismatch, registration crash steps, drain ordering, and emergency withdrawal.

## Boundaries

This is a pure policy core. It contains no VPN/provider/DNS/LB client, config text, key material, credential, command, callback, SDK, socket, process, filesystem/network I/O, clock, address pool, health threshold, or default exposure implementation.

## Verification

- `dotnet build TerraScale.Orchestrator.slnx --no-restore` — passed with 0 warnings and 0 errors.
- `dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build -- --minimum-expected-tests 100` — passed (204/204).

## Contract gaps

No additional gap was proven by this focused locality audit. Adapters must persist request and convergence checkpoints and preserve exact typed subjects; provider-specific address pools, routing priorities, certificates, exposure approvals, and health thresholds remain caller inputs.

## Second policy audit correction

The adversarial audit proved that `RouteKind.Local` was only a caller-supplied label. A scope with `Cell=gru` and `PeerCell=sfo` could therefore bypass the cross-cell adjacency requirement and, while partitioned, emit a remote `ConfigureTunnel` intent when local product policy was proven. Connected operation had the same structural relabeling weakness.

Locality is now an identity invariant: every `Local` route must have `PeerCell == Cell`. A connected relabeled remote route holds with `WrongEvidenceScope`. During a partition, the existing `LocalPolicyRequired` precedence remains first and a policy-proven relabeled remote route holds with `PartitionAuthorityDenied`. Valid self-cell local routes and explicitly linked cross-cell peer routes retain their accepted behavior; a non-local self-cell route remains impossible because valid topology evidence cannot contain a self link.

This correction adds no public member, factory, enum value, numeric code, trace field, or accepted subject field. It preserves the closed inventories and uses the existing denial codes. The policy remains pure and performs no VPN, provider, DNS, load-balancer, socket, process, filesystem, cloud, VM, or deployment operation.

Post-rebase verification on the central candidate:

- locked restore: all projects up to date;
- Release solution build with warnings as errors: 0 warnings and 0 errors;
- focused networking core: 8/8 passed;
- ControlPlane: 534/534 passed;
- all five suites: 733/733 passed (`534 + 24 + 38 + 65 + 72`).


---

# FILE: docs/work-packages/handoffs/phase1-networking-policy-properties.md

# Phase 1 networking policy completeness shard handoff

## Scope

- Exercises the pure route/tunnel, endpoint registration, removal, and emergency-withdrawal planners with independent 1,000-case state and denial-precedence oracles.
- Checks exact action/target/code tuples, every accepted subject field, every numeric trace field, generation/epoch and evidence-scope binding, deterministic replay, and full rendering across `en-US`, `tr-TR`, `ar-SA`, and `ja-JP`.
- Inventories the only public decision factories and proves decisions and intent subjects have no public constructor, setter, deconstruction, or unreviewed factory surface.
- Exercises all four caller-controlled route-evidence collections at the shared 4,096-item technical capture boundary and proves maximum-plus-one rejection occurs before the extra `Current` read. The earlier identity/network snapshot shard remains the ordinary/fatal iterator-phase and disposal-mutation evidence.

## Production correction

The audit proved that an otherwise approved public Product endpoint using plaintext `Http` reached `Verify/Completed`. Public customer HTTP is required to use ordinary server-authenticated TLS, so the registration planner now rejects public `Http` with the existing `ForbiddenExposure` denial before admission or readiness evaluation. Public `Https`, `Tcp`, and `Udp` preserve their reviewed behavior because the pure contract has not selected a policy for non-HTTP transports; private and workload `Http` also remain caller policy.

The audit also proved that reversing two invalid route observations could change the denial from `WrongEvidenceScope` to `TrustPlaneCrossover`. Route validation now evaluates each existing denial class over the complete bounded snapshot in stable precedence order, so collection order cannot select the reported reason. Single-failure semantics and the existing precedence remain unchanged.

Both discovered failure seeds are retained in the existing embedded identity/network regression corpus. The corpus now has 23 entries and is whole-file pinned to SHA-256 `435c686afc9495cfcd03796fbdbafbe2d70bd9653363b647a1d59dead5e7213c`.

## Boundary

This is bounded deterministic feature-shard evidence for pure policy only. It performs no VPN, DNS, load-balancer, socket, process, filesystem, NATS, provider, cloud, VM, or deployment operation; selects no VPN/DNS/LB implementation or address/health default; and makes no L0, L0C, L3S, L4, production-readiness, or deployment-authority claim.


---

# FILE: docs/work-packages/handoffs/phase1-observability-projection-audit3.md

# Phase 1 observability projection checkpoint audit

## Finding

The Grafana projection decision previously checked that desired state and inventory
shared one candidate generation and inventory sequence. It did not receive the
last projection checkpoint accepted by the authoritative journal. Replaying an
older, internally exact request could therefore authorize create, update, or
delete changes after a newer projection had been accepted.

## Contract correction

`GrafanaProjectionRequest` now requires the current accepted generation and
sequence. A candidate generation or sequence below either accepted high-water
mark is rejected. Equality remains valid for idempotent replay, and a forward
candidate remains valid when every existing inventory, scope, access, generation,
and ownership rule also passes.

The append-only decision codes are
`ProjectionGenerationNotRollback = 18` and
`ProjectionSequenceNotRollback = 19`. Inventory completeness and candidate
exactness remain first in the trace; the two checkpoint decisions precede scope,
access, observed-generation, and ownership decisions. `ProjectionExact` appears
only on an authorized result. The authorized intent retains the exact request,
including both accepted checkpoint values.

## Evidence and boundary

The focused unit and property coverage exercises independently stale generation,
independently stale sequence, both stale, equality, and forward progress. It pins
the exact trace order and numeric catalog, observed/required values, exact request
retention, and 1,000 deterministic checkpoint cases. Projection replay
fingerprints include both checkpoint fields and the full reason trace.

This pure contract does not read or persist the journal, contact Grafana, or
perform backend I/O. A downstream coordinator must supply the trusted accepted
checkpoint and atomically advance it with accepted projection work. This audit
does not claim adapter, Grafana HA, operator API, deployment, or production
qualification completion.


---

# FILE: docs/work-packages/handoffs/phase1-observability-projection-core.md

# Phase 1 observability and Grafana projection core handoff

- Work package: `docs/work-packages/phase1-observability-projection-core.md`
- Predecessor: `069fccf`
- Integration base: `3e2f747`
- Scope changed: `src/TerraScale.Orchestrator.ControlPlane/Observability/**`, `tests/TerraScale.Orchestrator.ControlPlane.Tests/ObservabilityDecisionTests.cs`, and this handoff
- External/destructive actions: none

## Result

The control plane now has four pure observability decisions: bounded telemetry admission, regional metric/log/trace health aggregation, immutable Grafana desired-state projection, and alert routing. Every authorization binds exact operation, tenant, cell, signal, schema/rule digest, generation, and independently scoped completeness evidence applicable to that decision. Authorized decisions contain only passed trace reasons.

Telemetry admission accepts only cataloged label keys and values classified as bounded public data. Unknown, forbidden, unbounded, cross-tenant/cell, stale, out-of-order, incomplete, schema-replayed, and over-budget inputs fail before an admit intent. Cardinality arithmetic does not increment or overflow an attacker-controlled counter; admission requires the current complete scope to remain below its explicit caller-selected limit.

Regional health requires the closed Metric/Log/Trace policy set and exactly one current observation for each signal. Persistence, retention, ingest replicas, query replicas, and encrypted local-spool policy are evaluated independently. Central loss preserves regional evidence and produces a typed degraded ingest finding. Missing, duplicate, stale, future, policy-mismatched, under-replicated, or exhausted-spool evidence produces typed findings but cannot authorize promotion. Spool exhaustion records explicit data loss without representing product readiness as dependent on telemetry.

Grafana projection reconciles only reviewed datasource, folder, dashboard, alert, contact-point, and least-privilege access catalog selections. Tenant, cell, and global access use a closed subject union; the projection boundary and exact tenant/cell/global authority subject must match, and one user cannot receive merged duplicate assignments. A complete inventory proof is independently bound to operation, owner, tenant, cell, generation, and current observation sequence. Create, update, delete, and drift changes carry that exact inventory/CAS proof plus desired and, where applicable, observed material. Unmanaged or conflicting resources are reported and are never adopted or deleted. Scope crossover, access escalation, stale/future inventory, or ownership mismatch holds all mutation.

Alert routing requires fresh complete dedupe evidence bound to the exact operation, tenant, cell, signal, rule digest, generation, sequence, contact identity/catalog, severity, and state. Delivery keys use alert identity plus state, so a firing event routes once, its resolved transition remains routable, and the exact same transition cannot be delivered twice.

The completeness audit found that the initial route intent validated all of that material but exposed only alert and contact identifiers. That made firing and resolved outputs indistinguishable to a downstream adapter and discarded the evidence needed to persist the exact authorized route. `RouteAlertIntent` now retains the immutable `AlertRoutingRequest`; its alert/contact convenience properties are exact projections of that request. A 1,000-case property alternates firing/resolved and warning/critical events, verifies every request/evidence field and delivered-event snapshot, and proves opposite transitions have distinct adapter-facing output.

No query/config text, JSON provisioning blob, endpoint, URL, credential, password, secret value, private key, callback, process, filesystem, network, database, clock, client SDK, or I/O surface is accepted or used. Retention, cardinality, persistence, HA replica requirements, spool capacity/overflow policy, alert route, catalog selections, and collection limits have no implementation defaults. Label, catalog/value, observation, desired/observed resource, and delivered-event collections stop and reject at caller-supplied positive bounds before materializing boundary-plus-one data.

## Adversarial coverage

The focused tests cover label/secret/cardinality attacks, tenant/cell/operation/schema replay, stale/future/out-of-order evidence, missing and duplicate signal observations, independent ingest/query loss, GRU reachability loss, persistence/retention mismatch, spool exhaustion and data loss, closed signal policies, Grafana create/update/delete/report drift, unmanaged collision, incomplete/replayed/future inventory, scope/access escalation, alert route/dedupe replay across every subject dimension, state transitions, defensive copies, culture/permutation stability, authorized-trace consistency, malformed enums/identities/quantities, forbidden public shapes, intent forgery, and secret-safe traces.

An additional 1,000-case construction-closure property inventories all six concrete observability intent families, exercises each of the four authorizing output families, recursively walks their public type graph, and rejects any path to authority, operation, provider-mutation, permit, or authorization-decision types. Hold and drop outputs remain in the exact closed inventory even though they never authorize work.

## Validation

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet test TerraScale.Orchestrator.slnx --no-build --no-restore -- --disable-logo --no-progress
git diff --check
```

The two focused completeness properties pass. The current control-plane project passes 481 tests, and the locked whole solution passes 677 tests with zero failures or skips. The Release build completes with warnings treated as errors and reports zero warnings or errors.

## Integration boundary

This package emits typed decisions and projection intents only. OTel collection/export, local spool storage, metrics/log/trace backends, Grafana provisioning delivery, immutable replica operation, query execution, alert delivery, operator authentication, and persistence/event application remain downstream adapters. Those adapters must not weaken evidence scope, synthesize missing health, broaden access, adopt unmanaged resources, delete without exact observed proof, or introduce hidden defaults.


---

# FILE: docs/work-packages/handoffs/phase1-observability-properties.md

# Phase 1 observability projection and authorization property shard

## Scope

- Adds five deterministic families with exactly 1,000 materially seeded cases each for telemetry label/metric admission and cardinality, Grafana dashboard projection and ownership, alert routing/deduplication, culture/permutation/replay, and duplicate/conflicting evidence.
- Independent oracles bind exact intent/change types plus `ObservabilityDecisionCode` outcomes for stale/future generation, budget exhaustion, secret-bearing labels, scope mismatch, stale inventory, dedupe replay, operation mismatch, and conflicting alert evidence.
- Seeds vary operation, tenant, cell, signal, metric, dashboard, alert, release, and generation identities. Replay verifies exact reconstructed fingerprints rather than intent type alone.
- Telemetry admission is exercised across 1,000 cases and can only produce the closed admit/drop/hold intent family; reflection proves no observability intent is or returns an authority/operation/provider-mutation permit or decision type, and construction checks prove callers cannot create `ObservabilityDecision` or any observability intent.
- Positive admission binds the exact operation/tenant/cell/service/signal/metric/schema/label subject, alert routing binds exact alert/contact, and Grafana drift distinguishes unmanaged from conflicting observed ownership.
- Adds a 17-entry embedded whole-file corpus pinned to SHA-256 `0fd10baee8c38d2a133e1be28f26b169aa25bb6542fc10badeaa00d761965795`, with an 8,192-byte reader and strict shape, canonical ID, bounded seed, closed `(kind,variant,expected)` vocabulary, complete declared-variant coverage, and adversarial parser tests.

## Production hardening

- `ObservabilityGuards.CopyBounded` now manually captures enumeration after `MoveNext` and checks the effective bound before the extra `Current`.
- `ObservabilityTechnicalLimits.MaximumCapturedItems = 4096` is public and explicitly technical, separate from cardinality, retention, alert, and projection policy; the smaller caller `EnumerationLimit` remains authoritative.
- Constructor signatures, null/item validation, and decision behavior are unchanged for valid inputs. Exact maximum succeeds, max+1 and literal endless sources fail before extra `Current`, ordinary iterator failures are generic and secret-safe, OOM/SO/AV propagate from every iterator phase, and dispose mutation cannot change the snapshot.

This is bounded deterministic feature-shard evidence, not full L0 or deployment qualification. It starts no adapter, process, network, VM, or cloud resource.

## Verification

- Focused ControlPlane Release tests: 360/360 passed.
- Full solution Release tests: 541/541 passed.
- Full solution Release build: succeeded with zero warnings and zero errors.


---

# FILE: docs/work-packages/handoffs/phase1-operation-core.md

# Phase 1 fenced operation core handoff

- Branch: `phase1/operation-core`
- Work package: `docs/work-packages/phase1-operation-core.md`
- Scope changed: lane-owned ControlPlane source/tests and this handoff only
- External I/O or mutation: none

## Result

Implemented a pure, append-only operation reducer for `INV-004`, `INV-005`, and
the stale-writer protection in `INV-006`. Immutable commands carry explicit time,
generation/resource version, observation identity, writer epoch, target,
idempotency key, payload digest, and deadline. No wall clock, environment,
filesystem, network, NATS, provider SDK, or arbitrary callback enters the public
decision API.

The journal models prepare, irreversible authorization, dispatch, recovery,
observation, terminal, and resumable safety-hold records. Every event is
sequence-bound to the prior SHA-256 digest. Replay canonicalizes reordered exact
duplicates, rejects conflicting same-sequence bodies and broken links, validates
the irreversible authorization gates again, and produces a deterministic state
digest. Canonical values are type-tagged, invariant-culture, count/length
delimited, and timestamps normalize to UTC ticks.

Only a committed authorization can produce a provider dispatch intent. Its
action, target, desired generation/terminal state, payload digest, idempotency
key, authorization digest, and deadline come exclusively from the frozen
record. A strictly higher epoch after dispatch appends a recovery transfer and
emits only a read-only reconciliation intent; it does not issue another provider
mutation and fences the old epoch. Unknown/in-progress outcomes likewise emit a
reconciliation intent rather than interpreting timeout as failure.

The TUnit suite has 14 adversarial tests covering crash/restore after every
required checkpoint, deterministic decision/state digest equality, stale
epochs/generations, every authorization gate, complete prepared-intent equality,
deadline equality, hold re-evaluation, higher-epoch recovery, reordered and
duplicated delivery, corrupt hashes, duplicate sequence IDs with different
bodies, undefined enum values, null journal entries, malformed compensation and
work-request identities, observation before dispatch, inconsistent target truth,
unknown-outcome reconciliation, and contradictory terminal observations.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --no-progress --output Detailed
dotnet run --project tests/TerraScale.Orchestrator.ContractTests/TerraScale.Orchestrator.ContractTests.csproj --no-build --no-restore -- --no-progress --output Detailed
git diff --check
```

The locked solution restore/build passes with zero warnings. The focused
ControlPlane suite passes 14/14. The repository-wide `dotnet test` command also
runs the passing ControlPlane and Contract suites, but currently exits 8 because
the pre-existing Protocol and Scheduler test executables contain zero tests;
this lane does not own those projects.

## Deliberate limitations

- The core emits persistence/adapter intents but performs no persistence or I/O.
- Provider-specific retry-token, work-request, ambiguity, and compensation
  policy remains unresolved by ADR 0020 and is not fabricated here.
- A pre-dispatch authorization held because its deadline expired preserves the
  committed operation, but cannot resume mutation without a future explicit,
  action-specific recovery policy; read-only post-dispatch reconciliation is
  already supported after deadline.
- The cryptographic digest proves deterministic content equality inside this
  core; journal authenticity/signature and durable CAS belong to later adapters.


---

# FILE: docs/work-packages/handoffs/phase1-operation-policy-completeness.md

# Phase 1 operation policy completeness handoff

## Result

This audit closes five pure operation-policy gaps for `INV-004`, `INV-005`, and
`INV-006` without performing provider, NATS, filesystem, process, clock, or any
other external I/O.

- A persisted dispatch replayed at or after its deadline now emits only the
  narrow read-only provider reconciliation intent. It does not repeat the
  mutation.
- Replaying an exact persisted `Unknown` or `InProgress` observation re-emits
  that read-only reconciliation intent from the persisted provider work-request
  data. A crash between journal append and output handling therefore cannot
  strand the operation.
- An observation identity cannot be rebound to a nonidentical provider result.
  Both command handling and journal replay reject that conflict with the
  existing `ConflictingTerminalObservation` code.
- A persisted `DeadlineExpired` hold cannot be bypassed with a regressed
  decision time. Authorization or first dispatch stays exactly held until a
  future explicit action-specific recovery policy exists. Forged journal events
  after that hold fail as `InvalidJournal`.
- Malformed persisted authorization/hold records with null nested evidence or
  error values fail closed without changing the prior state. Fatal runtime
  failures are not translated into ordinary input errors.

The mutation-bearing `DispatchProviderIntent` now exposes the exact frozen
aggregate, desired generation/resource version, authorizing observation
identity/resource version, and ordered permitted-compensation allowlist. The
allowlist is defensively copied and read-only. Because this changes the
canonical shape, its digest domain is explicitly `dispatch-intent-v2`.

`ReconcileProviderIntent` deliberately remains a narrow read-only query
boundary: operation, target, desired generation, idempotency key, optional
provider work-request ID, and authorization sequence/digest. It cannot mutate a
provider and therefore does not duplicate the six mutation-context additions.

## Deterministic evidence

The operation inventories are hard-pinned at seven checkpoints, five provider
outcomes, thirteen errors, five commands, seven events, and two intents. Exact
public fields are pinned for both accepted intents.

Two new 1,000-case deterministic families independently exercise:

- exact mutation output and pre-deadline idempotent replay;
- post-deadline read-only reconciliation;
- crash replay for both non-final provider outcomes and optional work-request
  identity;
- command and replay rejection of rebound observation identities;
- authorization and dispatch deadline holds at equality and after equality;
- regressed decision time and forged post-hold authorization/dispatch events;
- defensive ordered compensation capture and exact state preservation.

Focused regressions separately cover null authorization evidence, null nested
observation, null held error, fatal enumeration propagation, closed inventories,
and exact accepted-output fields.

## Evidence boundary

`PermittedCompensations` is only a frozen authorization allowlist. This tranche
does not implement, select, or claim compensation execution, cancellation, or
an action-specific recovery policy. It does not claim L0/L0C, adapter
conformance, provider correctness, destructive acceptance, or deployment
authority.

## Verification

On the exact rebased tree rooted at `6084068`:

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --configuration Release --no-restore --nologo -warnaserror
Build succeeded: 0 warnings, 0 errors

Focused regressions: 10/10 passed
Operation completeness properties: 2/2 passed (2,000 generated cases)
ControlPlane: 505/505 passed
Contract: 24/24 passed
Protocol: 65/65 passed
Scheduler: 72/72 passed
Model: 38/38 passed
All suites: 704/704 passed
git diff --check: clean
```


---

# FILE: docs/work-packages/handoffs/phase1-operations-audit3.md

# Phase 1 operations work-request continuity handoff

## Result

The pure operation engine now preserves a provider work-request identity once an `Unknown` or
`InProgress` observation establishes one. A later observation with a different or missing identity is
rejected with `ConflictingTerminalObservation`; the engine emits no event or intent. If no identity was
previously supplied, a later observation may keep it absent or establish it once.

Command handling and journal replay share the conflict order: exact observation replay, same
observation-ID rebinding, established work-request continuity, then replacement of final provider truth.
This keeps the more specific observation-identity error ahead of the new continuity check and preserves
the prior final-observation rule.

## Deterministic evidence

The focused regression fixture covers:

- established non-null identity changed or removed;
- absent identity remaining absent or becoming established;
- immutability after first establishment;
- one work request progressing from pending to success;
- same observation-ID rebound precedence;
- forged journal events changing or removing the identity while preserving prior state;
- event and decision digests changing with the provider work-request identity.

`OperationDigest` already encoded `ProviderWorkRequestId` in observation events and reconciliation
intents, so no digest-domain or accepted-output shape change was necessary.

## Evidence boundary

This closes only the proven pure-policy replay gap. It does not establish that a provider adapter returns
an authentic work-request identity, does not add cryptographic verification, and does not claim L0C,
provider conformance, mutation coverage, VM/cloud execution, or deployment readiness.


---

# FILE: docs/work-packages/handoffs/phase1-predeployment-evidence-core.md

# Phase 1 pre-deployment evidence core handoff

## Delivered

- Bounded, immutable identities and defensive-copy SHA-256/signature values for the source tree, dependency lock, generated schema, test binaries, architecture artifacts, suites, requirement trace, fuzz/model corpora, L0C result, approver, signing profile/identity, signature, and manifest. Caller enumerables are consumed only through a maximum-plus-one bounded snapshot and iterator failures become invalid evidence.
- A canonical, permutation-stable subject binds every declared digest and metric: exact x64/arm64 artifacts, suite test/property/model/seed/flake counts, trace counts, coverage and mutation results, fuzz duration/cases/corpus, model corpus, opaque L0C result, static/dependency/vulnerability/license/secret-scan outcomes, pinned toolchain, exclusions, execution kind, and approver.
- Caller-supplied feature/full policies define required domains and architectures, cold-run/reuse rules, every quantitative floor, and permitted exclusions. The evaluator always rejects safety/authorization/durability/deletion and other correctness-critical exclusions, surviving safety mutants, failed checks, missing/duplicate domains, architecture substitution, bounds violations, and checked arithmetic overflow.
- Content-addressed reuse proof is itself bound into reused subjects and compares source, transitive-contract, test, corpus, dependency, generator, schema, and toolchain digests exactly. Shared-contract, security, toolchain, and first-candidate changes force full execution.
- Signed envelopes bind the canonical payload digest, profile, signing identity, signature identity, generation, and expiry sequence. An injected typed opaque verifier is the only signature-verification boundary; invalid, unknown, exceptional, stale, future, and expired results fail closed.
- Construction-closed decisions expose only a closed action/code, exact payload-digest subject, and numeric trace. Feature evidence may allow dependency conformance but can never authorize L1S credential release; only an exact, policy-complete full manifest with verified envelope can do so.
- Adversarial tests cover defensive copying, bounded and throwing enumerators, duplicate identities, malformed/default enums, culture/permutation/replay, every subject field family, every policy threshold, digest and architecture substitution, missing/duplicate domains, forbidden exclusions, safety mutants, reuse fingerprint substitution, overflow, stale/future/expired envelopes, verifier ordering plus invalid/unknown/exception outcomes, secret-safe formatting, and every public output-forgery barrier.

## Boundary and non-claims

This is only the pure manifest, caller-policy, content-addressed-reuse, opaque-verification, and deployment-gate decision core. It performs no process, filesystem, network, environment, clock, CI, provider, signer, KMS, credential, or deployment mutation operation.

It does **not** claim that an L0 or L0C lane has actually executed, that a production signer or KMS/CI identity has been qualified, that either architecture artifact is reproducible, or that any manifest/envelope is a deployable production attestation. All evidence values and policy thresholds remain caller inputs; adapters and protected environments must obtain and enforce real evidence later.

## Verification

- `dotnet build TerraScale.Orchestrator.slnx --no-restore` — passed with 0 warnings and 0 errors.
- `dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build -- --minimum-expected-tests 100` — passed (260/260).


---

# FILE: docs/work-packages/handoffs/phase1-protocol-fuzz-shard.md

# Phase 1 deterministic protocol fuzz shard handoff

- Base: `origin/chore/phase0-bootstrap` at `366c145`
- Branch: `phase1/protocol-fuzz-shard`
- External or destructive actions: none

## Result

The protocol test project now runs deterministic generated valid and malformed inputs from explicit SplitMix-style seeds across every current public protocol parsing/validation family: positive numeric factories, opaque byte factories, concrete subjects, permission patterns and matching, grammar limits, permission-policy construction and authorization, and command-envelope validation. A reflection inventory closes the current surface and confirms that no public header or snapshot parser/validator exists on this base; future additions make the inventory test fail until registered.

Every target family executes at least 10,000 cases. Generated categories have exact acceptance/error oracles, explicit branch/error-hit counts, randomized identities/byte shapes within each category, replay digests, culture-independent reruns, and permutation checks. The shard covers malformed/default/unknown numeric and enum values, unknown protocol versions and corpus fields, validity windows, stale generations/epochs, digest/signature failures, truncation/extension, subject size/token/count/unicode/wildcard boundaries, permission count limits, null/duplicate/cross-set patterns, redacted output, and construction-closed default results.

`SubjectPermissionPolicy.TryCreate` now totalizes caller enumerables through the review-approved narrow production expansion. `EnumerationFailed` closes exceptions from `GetEnumerator`, `MoveNext`, `Current`, and `Dispose`, discards partial values, and exposes no exception text. Tests cover failures before and after a valid item, current/dispose failure, exact maximum, finite maximum+1, and infinite unique prefixes for both allow and deny inputs.

Three minimal malformed seeds are checked in under `test-corpus/protocol` and compiled as a fixed-name embedded resource. The loader bounds bytes, JSON depth, entry count, and field lengths; rejects unknown/duplicate fields, versions, malformed content, duplicate identities, and digest tampering; and uses invariant UTF-8 byte-length prefixes for every string in its canonical digest. Each typed mutation is parsed and replayed from its recorded input with its explicit seed controlling the deterministic replay count.

## Validation

```text
dotnet test tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --no-restore --verbosity minimal
dotnet test TerraScale.Orchestrator.slnx --no-restore --verbosity minimal
git diff --check
```

The focused protocol run passed 50 tests, including eight new fuzz/corpus/iterator-boundary tests. The full solution run passed 422 tests.

## Evidence boundary

This is deterministic generated-case replay, not a time-based fuzz campaign. It does not claim the ORCHESTRATOR 60-second feature budget, full fuzz budget, L0C, NATS conformance, or deployment evidence. It starts no network, process, NATS server, VM, container, or adapter.

Opaque payload, digest, and signature factories currently declare no maximum byte length. The shard samples lengths 0 through 256 and proves copy, empty-input, equality, truncation, extension, and redaction semantics; it does not invent or claim a production size ceiling. A separate caller-policy/API decision must select payload and cryptographic material limits.


---

# FILE: docs/work-packages/handoffs/phase1-protocol-negotiation-completeness.md

# Phase 1 protocol-negotiation completeness handoff

- Branch: `phase1/protocol-audit2`
- Base: central `chore/phase0-bootstrap` at `1eac098`
- External or destructive actions: none

## Result

The pure N/N-1 compatibility decision now returns an immutable, construction-closed acceptance that binds the exact adjacent current/previous versions and the exhaustive compatibility matrix it proved. Matrix order is canonical by numeric feature and direction and is independent of caller ordering and culture. Rejected compatibility decisions and all other messaging decision families carry no compatibility acceptance. Existing trace behavior and all enum values remain unchanged.

The pre-fix regression demonstrated that fully compatible `2/1` and `1000/999` windows had identical complete public output (`CompatibilityAccepted:Configure`). The accepted output now differs by exact version scope without selecting a wire representation, byte ceiling, signing policy, or compatibility default.

## Evidence

- 1,000 accepted version windows, including the maximum positive `long` boundary, pin the exact 12-item canonical matrix and input/culture/permutation independence.
- 1,000 rejected mutations pin invalid-catalog, incomplete-observation, duplicate-evidence, and compatibility-unavailable precedence and prove acceptance absence.
- Reflection pins constructor/setter/factory/deconstructor/clone closure.
- Existing topology, replacement, and partition property loops pin the new property to `null` outside successful compatibility evaluation.

## Validation

- Focused negotiation audit: 3/3 passed.
- Messaging policy/engine focus: 15/15 passed.
- Complete ControlPlane project: 513/513 passed.
- Complete solution: 712/712 passed.
- Complete solution build: zero warnings and zero errors.
- `git diff --check`: clean.

No external system was contacted or started, and this handoff makes no L0C, NATS, wire-schema, process-interoperability, or deployment-readiness claim.


---

# FILE: docs/work-packages/handoffs/phase1-protocol-primitives.md

# Phase 1 protocol primitives handoff

- Branch: `phase1/protocol-primitives`
- Work package: `docs/work-packages/phase1-protocol-primitives.md`
- Scope: pure immutable contracts, protocol validation, and TUnit tests only
- Infrastructure, serialization, signing algorithm, wall clock, NATS, registry, build/package, and composition-root changes: none

## Implemented behavior

The tranche implements the draft `INV-005` command-admission model from `ORCHESTRATOR.md:580` without freezing a wire contract:

- Strong non-empty `CellId`, `AggregateId`, `OperationId`, and `IdempotencyKey` values reject null, empty, whitespace-only, and embedded-NUL identities while preserving caller spelling exactly.
- `ProtocolRevision`, `DesiredGeneration`, `WriterEpoch`, and `DeliveryAttempt` accept only positive `long` values; their default value remains invalid.
- `OpaquePayload`, `PayloadDigest`, and `OpaqueSignature` defensively copy source bytes, expose only read-only spans, compare by content, and never render contents. Digest and signature factories reject empty input without selecting an algorithm-specific width.
- `CommandEnvelope` is immutable and carries protocol version, cell, aggregate, desired generation, writer epoch, operation, idempotency identity, issued/expiry timestamps, attempt, opaque payload, payload digest, and opaque signature. Its formatting redacts payload, digest, and signature.
- `CommandSignedMaterial` exposes the complete signature-covered field set except the signature itself. The caller-supplied verifier owns canonical serialization, algorithm, trust roots, and signer-identity policy and must authenticate every field.
- `CommandValidationContext` explicitly supplies expected cell/aggregate, minimum generation/epoch, accepted protocol revisions, clock-skew tolerance, digest verifier, and signature verifier. Accepted revisions are defensively copied; there is no default tolerance or verifier.
- `CommandEnvelopeValidator` takes `now` explicitly and returns only `CommandValidationResult` plus the closed `CommandValidationError` catalog. Verifier exceptions are collapsed into typed verification-failure errors; exception messages are never returned.

## Deterministic order and boundaries

Validation is fail-fast in this order:

1. validation context
2. envelope structure/non-empty digest and signature
3. accepted protocol revision
4. `IssuedAt <= ExpiresAt`
5. not-yet-valid time bound
6. expiry time bound
7. expected cell
8. expected aggregate identity
9. minimum desired generation
10. minimum writer epoch
11. payload digest
12. signature

Clock skew is caller-supplied. Equality at `now + skew` for issue time and `now - skew` for expiry is accepted; one tick beyond is rejected. Subtraction-based comparisons avoid `DateTimeOffset` addition/subtraction overflow at extreme timestamps. Equal issue and expiry timestamps are structurally valid, while a reversed interval is rejected before skew evaluation. Generation and epoch equal to the context minimum pass; lower values are stale.

Validation is intentionally stateless. Replaying the identical envelope returns the same accepted result and re-runs digest/signature verification. Durable operation idempotency and completion re-read belong to the future operation journal/coordinator, not this value-object validator.

## Signer identity

This tranche does not invent a signer identifier, algorithm, trust store, or key format. Wrong-signer rejection is enforced by the concrete `ICommandSignatureVerifier` injected into the validation context for the expected authority. It receives `CommandSignedMaterial` containing protocol, cell, aggregate, generation, epoch, operation/idempotency identities, timestamps, attempt, payload, and payload digest plus the opaque signature separately. An identity/trust-policy mismatch returns `VerificationOutcome.Invalid`, which becomes `InvalidSignature`.

## Tests

The TUnit suite covers:

- invalid/default and positive-boundary value objects;
- defensive copying, content equality, empty digest/signature rejection, and secret-safe formatting;
- all envelope fields and redacted envelope formatting;
- malformed envelopes and contexts before verifier invocation;
- accepted-revision collection mutation after context construction;
- deterministic error precedence;
- equal/reversed validity windows, inclusive skew boundaries, one-tick failures, and extreme timestamp arithmetic;
- wrong cell/aggregate, lower versus equal generation/epoch, digest mismatch, wrong signer/invalid signature, and typed verifier failures;
- complete signed-material projection; and
- identical-envelope replay.

Verification commands:

```text
dotnet restore src/TerraScale.Orchestrator.Contracts/TerraScale.Orchestrator.Contracts.csproj --locked-mode
dotnet restore src/TerraScale.Orchestrator.Protocol/TerraScale.Orchestrator.Protocol.csproj --locked-mode
dotnet restore tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --locked-mode
dotnet build tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --no-restore
dotnet test tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --no-build --no-restore
git diff --check
```

## Deliberate limitations

- This is not a serializer or frozen wire schema. Canonical bytes, unknown-field preservation, compatibility fixtures, and N/N-1 serialization remain steward-owned follow-up work.
- Digest/signature algorithms and widths remain verifier policy; this layer enforces only non-empty opaque values.
- Clock-skew tolerance and accepted protocol revisions remain mandatory caller inputs.
- Aggregate identity is the admission target. Operation and idempotency identities are strongly valid but their durable uniqueness/replay result is operation-journal state.
- The validator accepts generations/epochs above the supplied minimum. Authoritative generation re-read and future-epoch acquisition proof belong to coordinators and fenced journal state.
- No payload/identifier size ceiling is selected here; the future wire/transport contract must impose reviewed resource bounds before accepting untrusted serialized input.
- No production signing, serialization, transport, or deployment evidence is claimed by these L0 unit tests.


---

# FILE: docs/work-packages/handoffs/phase1-provider-create-observation-audit4.md

# Phase 1 provider create-observation audit 4 handoff

## Proven gap and correction

The same exact absent `ProviderCreateObservation` authorized independent create operations in different cells and compartments. Create evidence retained its key, generation, state, and resolved resource but no regional authority scope, so exact local authority and call evidence could not detect replay of the observation itself.

Create observations now require immutable cell and compartment values. The create authorization branch requires both to equal the operation context before its existing generation/state gate can pass. Same-key observations whose scope differs are conflicting as well as duplicate evidence and remain held without intent. Resolved-create intents retain the exact scope objects from the observation, preventing accepted output from discarding the new provenance.

The regression shard covers cross-cell and same-cell/cross-compartment replay, exact absent and resolved acceptance, rejected trace/no-intent/no-durable output, null scope rejection, defensive request snapshots, exact resolved-intent reference retention, and conflicting multi-observation evidence. A 1,000-case property alternates absent/resolved evidence and both scope-replay dimensions while preserving all existing action-path coverage.

## Fingerprint and replay boundary

There is no provider ownership replay corpus or separate canonical projection containing `ProviderCreateObservation`. `ProviderOperationContext.Fingerprint` intentionally excludes current observations: it identifies the persisted authorized operation and binds call evidence and durable resume, while ownership/create observations are fresh evidence re-evaluated on every authorization request. Adding observation scope to that operation fingerprint would incorrectly turn a current evidence snapshot into operation identity. Every actual representation of the create observation itself—its immutable model, conflict projection, authorization comparison, and resolved-create output—now retains or checks both scope fields.

## Honest evidence boundary

This correction does not claim a create key is globally unique or bind an observation to an operation ID. It does not prove provider observation authenticity, adapter or journal provenance, provider SDK behavior, OCI/cloud behavior, filesystem/network/runtime behavior, deployment, L4, or production acceptance. No external provider or deployment side effect occurred.


---

# FILE: docs/work-packages/handoffs/phase1-provider-ownership-completeness.md

# Phase 1 provider ownership completeness handoff

## Result

The audit proved a durable-authorization forgery path in the previous pure model: `ProviderCallEvidence` carried only a status and optional work-request ID, so accepted-like evidence from one operation could be replayed into another operation and mint a durable authorization for the second context. A pre-fix regression demonstrated that the unrelated request authorized successfully.

The evidence contract now retains the exact public immutable `ProviderOperationContext` it attests. Authorization compares the complete internal fingerprint before it may emit any intent or expose durable authorization. The fingerprint covers operation, cell, compartment, controller epoch, resource kind, action, exact target/create key, expected generation and observation, terminal state, approvals, deadline status and generation, idempotency key, compensations, and closed action parameters. `CallEvidenceMatches` is a distinct stable trace reason; an ambiguous-evidence short circuit still emits the complete trace in the same policy order.

## Adversarial coverage

- 1,000 deterministic cross-operation replay cases rotate accepted-like statuses and all 16 fingerprint dimensions; each case mutates one dimension and requires the exact 15-reason trace order, `CallEvidenceMatches=Rejected`, no intent, no authorization, and no durable capture.
- 1,000 call-lifecycle cases pin `NotCalled`, `Accepted`, `ResponseLost`, and `Completed`, with and without a work-request ID where representable. They prove exact typed mutation/read/observe outputs, no repeat after an accepted-like result, and exact higher-epoch durable resume with evidence still bound to the original context.
- 1,000 closed-action cases inventory every `ProviderAction` and require only its compatible exact typed intent and original context.
- 1,000 handoff cases vary all six proof statuses/scopes plus resource identity, kind, generation, uniqueness, expected/Pulumi/regional exactness, and scope binding. Only the exact fresh-bootstrap tuple enables self-management.
- A later audit found that a fully self-consistent older handoff tuple could still replay after a newer bootstrap generation had been accepted. `HandoffRequest` now requires the current accepted bootstrap generation, and `HandoffGenerationNotRollback=25` rejects lower candidates after inventory/scope checks and before the six proof reasons. Equal-generation retries and greater-generation handoffs remain valid.
- The accepted `EnableRegionalSelfManagementIntent` retains the exact current-generation high-water used by the decision. This keeps forward handoffs authorized against different accepted histories distinguishable at the output boundary. A separate 1,000-case lower/equal/greater property pins the exact ten-reason trace, rejection, forward progress, and output shape.
- Existing property, pinned-corpus, construction-closure, hostile-enumerable, max-plus-one, defensive-copy, ordinary-failure redaction, and fatal-propagation tests remain the non-duplicated evidence for those already-covered branches.

## Evidence boundary

This is pure policy and deterministic test evidence only. It closes the demonstrated stale bootstrap-handoff packet replay in this decision core; it does not establish journal persistence or adapter correctness. No provider, OCI, Pulumi runtime, cloud inventory, network, process, filesystem, NATS L0/L0C, rootless container, ARM64, L3S, L4, deployment, acceptance, mutation, or cost evidence was executed or claimed.


---

# FILE: docs/work-packages/handoffs/phase1-provider-ownership-core.md

# Phase 1 provider ownership core handoff

- Work package predecessor: `85db082`
- Branch starting point: `7b1800a`
- Scope changed: provider-neutral ownership/handoff models and engine, provider-prefixed control-plane tests, and this handoff only
- Provider calls, Pulumi operations, files, clocks, retries, and external actions: none

## Result

The control plane now has a pure fail-closed authorization boundary for provider operations. An immutable operation context binds the exact operation, regional scope, controller epoch, existing provider identity or idempotent create key, expected observation and generation, desired terminal state, approvals, caller-supplied deadline evidence, idempotency key, and permitted compensations. Bounded identities support both TerraScale canonical tokens and case-sensitive provider-native resource/work-request identifiers.

Authorization requires complete, unique, consistent evidence; exact regional authority; current epoch or an exact durably authorized irreversible resume; authoritative ownership; expected observation/generation; valid deadline evidence; complete approvals; compatible resource/action/terminal state; and consistent tags when tags are present. Tags remain typed reconciliation evidence and can never supply authority. Every denial has a stable closed numeric trace and emits no intent.

Successful decisions emit one closed typed intent. Accepted or response-lost calls are read by work-request ID when available and otherwise re-observed, so an accepted mutation is never blindly repeated. A higher-epoch leader can resume only the identical durably authorized irreversible context and cannot replace its terminal target or compensation set.

Action-critical inputs are a closed immutable union and are included in that durable identity: node template, placement, and bootstrap-envelope digest; volume size and performance; expansion target; attachment volume and node; and backend identity. Typed mutation intents expose only their matching parameter type. Create authorization additionally requires an exact create-key observation proving absence; unrelated resource observations or an already-resolved create key cannot authorize another create call.

Fresh bootstrap handoff requires exact, duplicate-free agreement among expected, Pulumi, and regional inventories plus verified retain/unmanage, regional R3 journal receipt, provider readiness, trust readiness, backup readiness, and activated regional fence evidence. Every proof carries the exact cell, compartment, bootstrap generation, operation, and expected-inventory fingerprint, preventing cross-cell, stale-generation, or different-inventory replay. Only then is a typed self-management intent emitted with the exact scoped, defensively copied inventory. The model exposes no historical/adoption input.

## Adversarial coverage

Provider-prefixed tests cover tag-only denial; mismatched and duplicate tags; stale/future epochs and generations; expected-observation mismatch; missing authority; wrong scope; incomplete/unknown evidence; approval and action incompatibility; duplicate/conflicting ownership observations; durable higher-epoch resume; conflicting terminal supersession; lost responses; accepted-call no-repeat; leadership loss after acceptance; provider-native identities; exact and defective handoffs; defensive copies; unknown/default values; culture/permutation determinism; and free-text, executable, I/O, and secret-safe surfaces.

## Validation

```text
dotnet restore tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --locked-mode
dotnet build tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-restore
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build
git diff --check
```

The final local test run completed with 66 tests passed, 0 failed, and 0 skipped. The build completed with 0 warnings and 0 errors.

## Adapter boundary

This package deliberately does not choose a provider, template, placement, retry policy, timeout, approval default, or compensation policy. A later adapter may consume the typed intents, recheck authority immediately before its call, and return typed call/observation evidence; it must not add provider SDK or I/O concerns to this core.


---

# FILE: docs/work-packages/handoffs/phase1-reconciliation-core.md

# Phase 1 reconciliation core handoff

## Scope delivered

- Pure immutable desired/observed contracts with bounded scalar-safe identity, kind, digest, dependency, observation-freshness, resource-count, and generation-floor validation. External scalars reject whitespace, controls, and unpaired surrogates.
- Closed caller-supplied kind catalog and caller-supplied bounds; the engine contains no domain kinds or policy defaults.
- Deterministic ordinal topological planning independent of desired, observed, or dependency input order.
- Typed `ObserveResourceIntent`, `ReconcileResourceIntent`, `HoldResource`, and `ConvergedResource` results.
- Exact convergence requires a fresh, ready observation with the same identity/kind, generation, and digest.
- Missing and freshness-stale observations produce only `ObserveResourceIntent`, including when a dependency needs reconciliation in the same wave.
- Older-generation drift produces a reconcile intent only when every dependency is exactly converged in the current observed input. A dependency reconcile emitted by this plan is not treated as convergence and cannot unlock same-wave dependent mutation.
- Reconcile intents freeze resource identity, kind, desired generation/digest, the exact seven-field validated target observation proof that authorized drift repair, and sorted exact seven-field observations for every converged dependency. Each proof binds observed identity, kind, generation, digest, observation ID, freshness sequence, and condition so an adapter executing the persisted intent does not depend on a surrounding plan object. Intents contain no callback, arbitrary payload, executable data, policy snapshot, or infrastructure behavior.
- Newer observations, same-generation digest conflicts, failed/held observations, missing dependencies, self-edges, cycles, invalid catalogs, non-positive observations, generation regression, duplicates, and identity mismatches hold or reject fail-closed.
- Failed/held/missing dependency root identity and reason propagate transitively without being replaced by a generic dependent failure.
- Stable ordinal plan order, error order, trace sequence, closed error/reason codes without public free-form messages, defensive collection copies, and no input mutation.
- Fatal malformed input returns code-only errors and no steps/traces, so rejected unsafe scalars are never reflected into intents, holds, or trace data.

## Files

- `src/TerraScale.Orchestrator.ControlPlane/Reconciliation/ReconciliationContracts.cs`
- `src/TerraScale.Orchestrator.ControlPlane/Reconciliation/ReconciliationEngine.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/ReconciliationEngineTests.cs`

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --no-progress
git diff --check
```

- Solution build: 0 warnings, 0 errors.
- Control Plane suite: 47 passed, 0 failed (16 reconciliation tests plus 31 existing operation/authority tests).
- All five repository test executables: 133 passed, 0 failed (Contract 5, Control Plane 47, Model 17, Protocol 42, Scheduler 22). The solution-level `dotnet test` entrypoint discovers zero executable TUnit tests, so each project was invoked directly with `dotnet run`.
- The benchmark-style test plans a reversed and forward 10,000-resource chain non-recursively and compares the complete stable signature.

## Deliberate boundaries

- This core does not own retry, backoff, timeout, suspend/resume, domain health policy, prune, artifact resolution, persistence, adapter execution, NATS, files, clocks, or provider/runtime behavior.
- `MinimumFreshnessSequence` and generation floors are opaque caller evidence. A coordinator/adaptor must derive them from its authoritative journal/observation protocol; this core does not invent freshness or time semantics.
- A cycle-blocked downstream resource receives a typed cyclic hold. The core does not attempt remediation or choose an edge to remove.


---

# FILE: docs/work-packages/handoffs/phase1-reconciliation-evidence-audit.md

# Phase 1 reconciliation dependency-evidence audit

## Finding and correction

An eligible reconcile intent previously retained the target resource's complete
observation, but each converged dependency proof retained only desired identity,
generation, and digest. Two otherwise identical plans whose dependency
observations had different observation IDs or freshness sequences therefore
produced equal adapter-facing intents.

`DependencyProof` now has internal construction and retains the exact completed
dependency observation: identity, kind, generation, digest, observation ID,
freshness sequence, and condition. Proofs remain ordered by dependency identity.
The planner constructs them only from dependency steps already classified as
exactly converged, so every emitted dependency condition is `Ready`.

The error and reason catalogs, their numeric values, and evaluation precedence
are unchanged.

## Evidence

- A focused regression varies only dependency observation ID and freshness and
  proves that the resulting reconcile intents no longer collide.
- A 1,000-case valid-graph property family compares all seven retained fields,
  ordinal proof order, and the required `Ready` condition.
- Reconciliation replay and cross-operation fingerprints include every proof
  field.
- The accepted-output closure inventory now treats `DependencyProof` as an
  accepted evidence type and enforces its lack of public constructors, setters,
  and deconstruction.

Focused Release verification passed 37 reconciliation tests and 2 accepted-
output construction-closure tests with a warnings-as-errors solution build.

## Boundary

This audit changes only the pure reconciliation output contract and tests. It
does not add persistence, dispatch, NATS, adapter, runtime, or deployment
evidence, and it does not claim that an adapter has persisted or revalidated
these proofs. The caller remains responsible for deriving the freshness floor
from authoritative state.


---

# FILE: docs/work-packages/handoffs/phase1-reproducible-publish-audit3.md

# Phase 1 reproducible-publish provenance audit 3 handoff

## Proven defect and resolution

The public pure observation verifier could mint a successful `ReproduciblePublishResult` from entirely
caller-authored process and file observations. Nonpublic result constructors therefore did not provide the claimed
construction closure: an external caller could report successful fake ELF digests without running the publisher or
reading an artifact.

`PublishObservationVerifier` and its `Evaluate` method are now internal. Only the exact
`TerraScale.Orchestrator.ContractTests` assembly receives friend access, preserving deterministic offline verifier
coverage without exporting an evidence factory. Public request and observation DTOs remain unchanged for
compatibility. `ReproduciblePublisher.RunAsync` remains the sole exported originating factory whose return type
wraps `ReproduciblePublishResult`. The sealed record's compiler-generated clone is explicitly non-originating: it
requires an existing result and no result property exposes a public setter or init route.

## Deterministic evidence

- Reflection enumerates every declared public static and instance method, including property accessors, on all
  exported types and correctly inspects `Task<ReproduciblePublishResult>`.
- It proves one asynchronous originating result route; permits only the exact non-originating sealed-record clone;
  and proves no public result setter/init route, synchronous or alternate originating factory, or exported verifier.
- It also pins nonpublic result constructors, public observation DTOs, and one exact friend assembly.
- It pins the unchanged public signatures of `ReproduciblePublisher.RunAsync`, `Program.Main`, and
  `Program.TryParse`.
- Existing tests continue to exercise the internal verifier with synthetic observations across success, output
  shape, RID/root replay, ELF, process, digest, diagnostic, enumerable, and symlink cases.
- No failure code, precedence, CLI argument, canonical output field, publish invocation, environment, input digest,
  or artifact verification behavior changed.

## Evidence boundary and nonclaims

Internal observations are trusted execution/test seams; they are not independently usable artifact evidence.
Successful public output proves only the copied-tree and double-publish observations made by `RunAsync`.

This audit performed no restore, publish, network, registry, signing, credential, deployment, VM, or cloud action.
It does not prove ARM64 runtime behavior, signing or pre-deployment attestation, registry state, deployment safety,
L4 qualification, release approval, or broader toolchain provenance. The earlier cross-publish handoff retains its
explicitly bounded and stale-tree evidence statement.

## Validation

- Offline Release build using existing locked restore artifacts: 0 warnings and 0 errors.
- Focused construction-closure and signature regressions: passed.
- Full ContractTests executable and exact cross-publish test shard: passed.
- `git diff --check`: passed.


---

# FILE: docs/work-packages/handoffs/phase1-reproducible-publish.md

# Phase 1 reproducible dual-architecture publish handoff

## Result

The reviewed .NET publish verifier completed a real double publish for `linux-x64` and `linux-arm64` from two byte-identical isolated input copies. Both per-RID repeat artifacts were byte-identical, and the architecture artifact digests were distinct.

This is cross-publish evidence only. The ARM64 artifact was not executed. This handoff does not provide ARM64 runtime or L4 qualification, signing, release approval, or pre-deployment attestation.

## Pre-commit worktree observation

- Captured diagnostic counts: stdout `2496` characters; stderr `0` characters
- `linux-x64`: length `72410776`; SHA-256 `251dae53e0464d8f46bafa296a3d0e22403dd8d01aef37d7b8650aa2a37e7c88`; repeat SHA-256 `251dae53e0464d8f46bafa296a3d0e22403dd8d01aef37d7b8650aa2a37e7c88`
- `linux-arm64`: length `81024186`; SHA-256 `ca924e17aa9d1af613eff01580c53c1305a3e88f7ddc1a526564109c1bd80892`; repeat SHA-256 `ca924e17aa9d1af613eff01580c53c1305a3e88f7ddc1a526564109c1bd80892`

These values came from a successful real double publish in the uncommitted implementation worktree. The verifier checked each single-file payload as a 64-bit little-endian ELF executable/shared-object with the expected machine value (`EM_X86_64` or `EM_AARCH64`) and at least one Unix execute bit. No produced binary was normalized or rewritten.

This observation is not evidence for the final commit: recording results in this handoff changes the input tree, so embedding a purported final-tree digest would be self-referential and stale. CI or the release operator must run the command below cold on the exact committed tree and retain the externally reported canonical input digest and artifacts as the final evidence.

## Reproduction command

Run after a successful locked restore of the source tree. Output roots must not exist or must be empty, and must be outside the source tree.

```bash
set -euo pipefail
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build tools/reproducible-publish/TerraScale.ReproduciblePublish.csproj --no-restore --nologo

tree_digest=$(dotnet tools/reproducible-publish/bin/Debug/net10.0/terrascale-reproducible-publish.dll --compute-input-digest "$PWD")
base=$(mktemp -d /tmp/terrascale-repro-publish.XXXXXX)

dotnet tools/reproducible-publish/bin/Debug/net10.0/terrascale-reproducible-publish.dll \
  --source-root "$PWD" \
  --first-output-root "$base/first" \
  --repeat-output-root "$base/repeat" \
  --tree-digest "$tree_digest" \
  --configuration Release \
  --rid linux-x64 \
  --rid linux-arm64 \
  --timeout-seconds 900 \
  --diagnostic-character-limit 200000 \
  --output-item-limit 100 \
  --source-date-epoch 1700000000
```

The digest mode reads the source tree with the same canonical path/content/mode algorithm used for each isolated copy. A publish succeeds only when both copied-tree digests equal each other and the supplied digest, preventing substitution of an unrelated claimed identity.

The tool itself performs no restore, network, Git, signing, credential, deployment, or source-tree mutation. It invokes the fixed `dotnet publish` argument list with `--no-restore`, clears the child environment and supplies only reviewed entries, captures only bounded diagnostic counts, and emits a canonical result to stdout. The shell shown above is caller-side setup and evidence capture; it is not executed by the tool.

## Remaining external evidence

- Execute and qualify the ARM64 artifact on the owner-approved ARM64 host image/kernel/glibc combination.
- Complete L4/runtime qualification.
- Apply the owner-controlled signing profile and release approval.
- Produce the required pre-deployment attestation.


---

# FILE: docs/work-packages/handoffs/phase1-resource-contracts.md

# Phase 1 resource-contract handoff

Branch: `phase1/resource-contracts`

## Implemented boundary

This tranche implements provider-neutral metadata and a closed abstract v1 role
catalog under the draft `INV-017` admission boundary. It does not freeze a wire
format or mark registry evidence verified.

Metadata uses explicit immutable objects for the exact v1 API version, bounded
canonical stable IDs, positive generation and resource version, typed ownership and
creation actor, and a bounded canonical opaque audit-correlation ID. The audit ID is
deliberately not mandated to be UUID/GUID/ULID because the architecture selects no
such syntax. Null, default, unknown, noncanonical, and out-of-bound inputs fail.

The role union contains exactly 18 sealed v1 cases behind an abstract base with an
internal-only constructor; consumers cannot subclass it or provide an arbitrary
kind. Metrics storage, regional telemetry, and VPN cases require an
`ApprovedImplementationCatalogKey` tagged for the correct domain. A catalog key is a
typed logical `ResourceId`, not a raw executable, image/tag, unit, package URL, or
command field. No concrete metrics, telemetry-agent, or VPN product is selected.

Descriptors require an explicit nonempty allowed-runtime set and expose only typed
ports, closed role capabilities, closed volume purposes, typed secret-profile
references, health signals, placement constraints, scaling-controller ownership,
and bounded resources. There is no executable/argument, image pull tag, host path,
unit text/directive, privileged flag, Linux capability, or NATS permission surface.
This satisfies representability constraints only; an adapter must still enforce the
built-in mapping.

`RoleDescriptor` construction is assembly-internal. External manifests/clients can
read reviewed descriptors but cannot synthesize combinations such as an API role
with control authority, NATS storage, and unrelated secret profiles. Model tests
receive narrowly scoped friend access. A later same-assembly built-in catalog must
publish the reviewed instances; manifests may reference only those catalog entries.

Collections are defensively copied, duplicate-rejected, enum-validated, and sorted.
String-key ordering is explicitly ordinal; construction, projection, and structural
hashes are identical under invariant, `ar-SA`, and `tr-TR` cultures.
Canonical UTF-8 projections are independent of input ordering and include only
secret-profile references, never secret values, supporting the
`SEC-NO-SECRET-OUTPUT` boundary.

## Verification coverage

Model tests cover every role, metadata invalid/default cases, unknown API version,
default/unknown enum values, wrong implementation domains, missing implementation
inputs, invalid catalog-key syntax, collection duplicates, mutation isolation,
resource-bound inversion, stable projection/equality, and safe secret-reference
projection. Reflection tests prove the union is externally closed, every case is
sealed, and descriptor surfaces expose no raw string collection, `Type`, delegate,
process, arbitrary execution, privilege, host-path, Linux-capability, or NATS-
permission field.

## Intentional limitations

- Serialization, unknown-optional-field round-tripping, and a schema generator are
  steward-owned later work; this tranche freezes none of them.
- Catalog approval/storage is external to these value objects. Possessing a
  well-formed logical key is not proof that an implementation was approved.
- Runtime defaults, concrete metrics/telemetry/VPN products, ports, resources,
  placement, health, and scaling policy remain explicit descriptor inputs.
- Descriptors contain no secret bytes and do not retrieve secrets; adapters consume
  typed references under their separate security contract.
- These tests are L0 model evidence only. The draft registry remains draft with
  missing evidence; no deployment or adapter behavior is claimed.


---

# FILE: docs/work-packages/handoffs/phase1-resource-projection-audit3.md

# Phase 1 resource projection audit 3 handoff

## Proven gap and correction

Two accepted built-in metrics descriptors selecting different catalog entries had distinct C# canonical identities but could only be described as the same enum-only `MetricsStore` role in the generated read-only descriptor projection. The projection also lost the selected domain and had `additionalProperties: false`, so the missing provenance could not be added by a consumer.

The generator now builds one closed admitted-role shape for both the standalone admitted-role schema and the descriptor's nested role. The nested form omits only the redundant API version. It requires exact domain and catalog-entry provenance for metrics, regional telemetry, and VPN selections; it forbids implementation data for ordinary roles and retains closed unknown-kind/unknown-field rejection. The standalone admitted-role artifact remains byte-for-byte unchanged.

Contract tests interpret the generated constraints and cover distinct catalog identifiers, every sealed role case, all three exact domain mappings, missing or mismatched implementation data, ordinary-role implementation rejection, unknown kinds and fields, shared standalone/nested semantics, and checked-in generator artifact equality. Re-running the generator produces an identical descriptor-schema digest.

## Honest evidence boundary

This is a breaking correction only to the draft internal read-only documentation projection. It does not freeze or implement a serializer or runtime wire contract, admit a manifest, prove that a catalog entry received owner approval, choose a concrete metrics/telemetry/VPN product, execute a runtime, or provide deployment evidence. The C# contracts and enum numerics are unchanged.


---

# FILE: docs/work-packages/handoffs/phase1-runtime-cleanup-audit.md

# Phase 1 runtime cleanup audit handoff

## Scope

- Audits only the pure runtime lifecycle and self-update policy against `ORCHESTRATOR.md`.
- Starts no process, unit, container, VM, network, filesystem, provider, deployment, or sibling-repository action.
- Selects no runtime driver, artifact, timeout, compatibility, retention, or rollout default.

## Production defects proven and corrected

`CleanupRuntimeIntent` previously retained only its operation identity and a derived array of ephemeral volume identities. It discarded the exact validated lifecycle request, including allocation, node, writer epoch, generation, admission policy, workload/config/artifact identities, and the retention evidence from which cleanup authority was derived. That was insufficient persisted authorization context for an external deletion.

The derived array was also exposed as `IReadOnlyList<RuntimeVolumeId>`. The runtime type remained `RuntimeVolumeId[]`, so a caller could cast it back to the array and replace an authorized ephemeral identity after the decision.

Cleanup now retains the exact immutable `RuntimeLifecycleRequest` and exposes its derived ephemeral-only allowlist through one non-castable read-only collection. Retained volume identities remain absent. The decision engine, authorization results, reason trace, enum values, and numeric IDs are unchanged.

## Adversarial coverage

- A valid stopped allocation reaches the cleanup intent and preserves the exact validated request reference.
- The cleanup allowlist exactly matches the ephemeral subset of the captured specification and excludes its retained volume.
- The public allowlist cannot be cast to its backing array, rejects indexed mutation, and remains unchanged after the attempt.
- Every mutating lifecycle intent retains its exact request. The read-only health-check, executor-observation, and hold intents are explicitly excluded.

## Contract inventory

- `RuntimeDecisionCode`: 21 values with IDs `1..21`, unchanged.
- `RuntimeDecisionOutcome`: 4 values, unchanged.
- Runtime intent subtypes: 21, unchanged.
- Lifecycle phases/actions/executor call statuses: 10/4/4, unchanged.
- Normal lifecycle trace: 15 entries in the existing order; duplicate/conflicting health evidence still returns the existing two-entry hold trace.
- Self-update contracts and trace are unchanged.

## Evidence boundary

This is pure feature-shard evidence only. It does not implement or qualify executor adapters, persistence, systemd, containerd, filesystem deletion, VM/cloud behavior, L0/L0C, mutation testing, deployment, or production acceptance.


---

# FILE: docs/work-packages/handoffs/phase1-runtime-health-intent-audit.md

# Phase 1 runtime health-intent audit handoff

## Scope

This audit reviewed the pure Runtime lifecycle and self-update decisions for one
remaining accepted-output ambiguity after the cleanup-context and self-update
soak-evidence audits. It did not add an executor adapter or perform process,
filesystem, network, containerd, or systemd I/O.

## Proven counterexample

Two authorized self-update requests for the same operation, node, allocation,
and epoch but successive `5 -> 6` and `6 -> 7` updates both produced the equal
output:

```text
CheckRuntimeHealthIntent {
  OperationId = operation-1,
  AllocationId = allocation-1
}
```

The red regression required those outputs to differ and failed with exact
record equality. A persisted health-check work item therefore did not state the
node, fencing epoch, generation, timeout, or required health dimensions that
the adapter must measure.

## Correction

`CheckRuntimeHealthIntent` remains construction-closed and is now created only
from the accepted `RuntimeLifecycleRequest` or `SelfUpdateRequest`. It binds:

- operation, allocation, and node identities;
- the accepted fencing epoch;
- the lifecycle spec generation or self-update target generation;
- the accepted health timeout; and
- a defensive immutable health-dimension list.

Self-update health checks use the canonical enum-order dimensions `Liveness`,
`LocalReadiness`, and `DependencyReadiness`. Lifecycle checks retain the
accepted spec's required dimensions. Identical request replay produces equal
intents and equal hashes, while successive generations no longer collide.

No decision code, error, outcome, or trace precedence changed. The correction
only enriches an intent after the existing authorization and hold/reject gates
have selected health observation work.

## Verification

The focused Runtime suite proves both lifecycle construction paths
(`Started`/`Serving`, including the held-readiness branch) and both self-update
`ProcessRestarted` arms use request-bound construction. It also covers exact
field identity, successive-generation inequality, identical replay equality,
defensive immutability, construction closure, and 1,000 seeded output-scope
cases. Runtime decision serializers include every added field.

## Deliberate non-claims

This closes only the proven health-check execution-scope collision. The intent
does not retain the complete accepted request and this audit does not claim to
bind admission, artifacts, inventory, current-generation high-water marks,
verifier identity, or the full lifecycle/self-update policy provenance. Real
systemd/containerd health collection and production boundary qualification
remain later-phase work.


---

# FILE: docs/work-packages/handoffs/phase1-runtime-observe-output-audit4.md

# Phase 1 runtime executor-observation output audit 4 handoff

## Proven gap and correction

Two fully valid response-lost lifecycle requests for the same operation and allocation but different executor nodes produced equal authorized `ObserveExecutorIntent` values. The intent retained only operation and allocation, so persisted recovery work could not distinguish which validated executor boundary to query. Epoch, generation, action, observation, workload specification, admission, inventory, and health evidence were discarded as well.

`ObserveExecutorIntent` now retains the exact validated `RuntimeLifecycleRequest`. Its inherited operation identity and allocation compatibility getter derive from that request, with no redundant flattened state. The engine passes the already validated request only after existing rejection and response-safety checks.

Tests cover `Accepted` and `ResponseLost` across start, stop, drain, and cleanup paths; exact request and compatibility-reference retention; every top-level request property; a complete length-delimited nested request fingerprint; 1,000 culture-stable and evidence-permutation replays; rejected Hold-only behavior; defensive input capture; opaque output; and assembly-wide public construction, accessor, immutable-clone, and real `EvaluateLifecycle` route closure.

Review hardened that evidence with single-field and single-element mutants for every nested specification, native/OCI payload, admission, observation, health, inventory, conflict, port, and volume getter. Permutation replay now reverses two distinct allocation entries and each nested collection. Construction closure includes all exported public declared methods and accessors whose output can be the exact intent, the `RuntimeIntent` union, or `RuntimeDecision`, with only the two real engine origins, the decision projection, and immutable record copies allowlisted.

A final coupled-field review found that the OCI-to-native variant changed both driver and descriptor. A separate Native-to-Native pair now keeps every shared payload field and driver identical while changing only `NativeUnitDescriptor`, proving that leaf is independently retained.

The strict checked-in Runtime replay corpus models self-update decisions. Its observation case is `ObserveUpdateIntent`, which already retains an exact `SelfUpdateRequest`; it does not encode lifecycle `ObserveExecutorIntent`. No corpus bytes, checksum, or self-update fingerprint changed.

## Honest boundary

This closes only pure accepted-output provenance. Retaining a request does not perform or prove executor observation, response recovery, PID/start-time/invocation/cgroup verification, process state, systemd/containerd behavior, artifact authenticity, persistence, or deployment qualification. No adapter or external side effect was added.


---

# FILE: docs/work-packages/handoffs/phase1-runtime-selfupdate-completeness.md

# Phase 1 runtime self-update completeness shard handoff

## Scope

- Audits only the pure A/B self-update policy and its immutable inputs/outputs.
- Starts no process, systemd unit, container, VM, network, filesystem, provider, deployment, or sibling-repository action.
- Selects no signing implementation, timeout, soak duration, compatibility generation, architecture, or rollout default.

## Production defects proven and corrected

1. Exact, explicitly `Incompatible` N/N-1 evidence after local verification was classified as a generic denial. The local-known-good rollback policy now authorizes one typed rollback at `LocalHealthVerified`, `RegionalCompatibilityVerified`, `SlotCommitted`, or `OldSlotRetainedUntilSoak`. Earlier activation phases, rollback phases, terminal rollback failure, mismatched compatibility scope, and `Missing`/`Unknown` compatibility remain denied.
2. A failed target-generation health result could emit `RollbackUpdateIntent` before held evidence was examined. That allowed rollback authorization even when the required rollback artifact was missing. Once an in-flight executor call has been safely classified, every held prerequisite is now denied before either health- or compatibility-triggered rollback.

`CompatibilityExact=Rejected` remains an honest trace for an explicit incompatible result: it says the compatibility acceptance gate did not pass. The engine treats only an exact-scope, explicit `Incompatible` result at one of the four rollback-eligible checkpoints as a recoverable failure. It does not treat a replayed scope or absent/unknown evidence as a rollback authorization.

## Independent deterministic coverage

- 1,000 distinct seeded operations independently mutate every forward and rollback evidence field: release, artifact, digest, signature, signing profile, architecture, generation, availability, and verification. Each mutation binds the exact denial/hold code, outcome, closed trace cardinality, and operation identity.
- 1,000 cases distribute exact incompatibility across all four rollback-eligible checkpoints and compare every trace entry, outcome, observed value, and required value against an independent oracle. The emitted rollback intent retains the exact immutable request.
- 1,000 cases distribute incompatibility across every pre-local-verification and rollback/terminal phase and prove none can mint rollback.
- 1,000 mixed-precedence cases cover `Accepted`/response-lost observation, failed health plus missing rollback material, digest/signature mismatch, stale epoch, non-next generation, simultaneous exact compatibility and health failure, replayed compatibility scope, terminal rollback failure, and missing/unknown compatibility.
- 1,000 identical-input cases compare the complete decision rendering under `en-US` and `tr-TR`/`ar-SA`/`ja-JP`, changing both current culture and UI culture and reversing health enumeration order.

The pre-existing hostile-enumerable runtime snapshot shard remains the canonical coverage for exact-limit, maximum-plus-one, endless, iterator-phase failure, fatal exception propagation, and dispose-mutation behavior; this shard does not duplicate it.

## Verification

- Focused ControlPlane Release tests: 441/441 passed after rebasing the latest central branch.
- `git diff --check`: clean.

This is bounded feature-shard evidence only. It is not full L0/L0C, mutation, deployment, runtime-boundary, or acceptance evidence.


---

# FILE: docs/work-packages/handoffs/phase1-runtime-selfupdate-core.md

# Phase 1 runtime lifecycle and self-update core handoff

- Work package: `docs/work-packages/phase1-runtime-selfupdate-core.md`
- Predecessor: `5315e7d`
- Scope changed: `src/TerraScale.Orchestrator.ControlPlane/Runtime/**`, `tests/TerraScale.Orchestrator.ControlPlane.Tests/RuntimeDecisionTests.cs`, and this handoff
- External/destructive actions: none

## Result

The control plane now has a pure, closed runtime decision boundary for reviewed native-systemd and digest-pinned OCI workloads. Inputs bind workload, allocation, node, operation, epoch, generation, architecture, host image, runtime version, artifact/signature/signing profile, configuration, secret versions, volumes, ports, admission policy, health policy, and complete node-inventory evidence. OCI activation binds the selected platform image digest independently from its manifest-list digest.

Lifecycle decisions progress through one typed fetch, verify, stage, mount, start, health, drain, stop, or cleanup action. Accepted or response-lost executor calls emit observation rather than repeating an action. Serving requires exact liveness, local-readiness, and dependency-readiness evidence; process exit success cannot substitute. Stop, drain, and cleanup remain available as safety actions when health has failed. Cleanup exposes only explicitly ephemeral volume identities, making retained-volume deletion unavailable to the adapter.

Self-update inputs independently bind the desired and observed forward and local rollback artifacts, exact A/B slot orientation, protocol/schema N/N-1 evidence, health/soak durations, compatibility window, and rollback policy. Persisted checkpoints resume deterministically through inactive-slot staging, rollback arming, one switch, health and regional checks, commit, old-slot soak, or local rollback. Later checkpoints revalidate target-generation health. Rollback is observed rather than re-emitted, and completes only with exact old-generation health; failed rollback is terminal and denied.

No runtime decision reads time or performs process, filesystem, network, or other I/O. No command, shell text, unit text, container-spec blob, host path, privileged flag, capability list, secret value, private key, callback, retry, timeout default, runtime default, or release default is accepted.

## Adversarial coverage

The focused tests cover native/OCI lifecycle parity, selected OCI platform digest binding, admission replay, every lifecycle and update checkpoint, future/stale evidence, scoped complete conflict inventory, port/volume conflicts, contradictory process/phase evidence, exit-zero/readiness separation, failed and replayed health, safety stop on failed health, lost executor/update responses, independent artifact-subject substitution, architecture/signature/rollback availability, incompatible protocol/schema evidence, A/B alias and orientation replay, later-checkpoint health regression, rollback convergence, terminal completion, defensive copies, culture/permutation stability, malformed/unknown inputs, forbidden execution/I/O shapes, public intent forgery, and secret-safe traces.

## Validation

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx --no-restore --nologo
dotnet test TerraScale.Orchestrator.slnx --no-build --no-restore -- --disable-logo --no-progress
git diff --check
```

The focused control-plane project passes 198 tests. The locked whole solution passes 306 tests with zero failures or skips and builds with zero warnings or errors.

## Integration boundary

This package deliberately emits intents only. Executor/bootstrap adapters, persistence/event application, real systemd/containerd behavior, artifact verification implementations, health probe execution, timeout/soak timing, and release policy selection remain downstream work and must preserve the exact typed evidence carried here.


---

# FILE: docs/work-packages/handoffs/phase1-runtime-soak-audit.md

# Phase 1 runtime self-update soak audit handoff

## Scope

- Audits only the pure A/B self-update decision and its immutable evidence.
- Starts no process, unit, container, VM, network, filesystem, provider, deployment, or sibling-repository action.
- Selects no soak duration, timeout, artifact, architecture, compatibility, or rollback default.

## Production defect proven and corrected

`SelfUpdateRequest.SoakDuration` was captured but never evaluated. A healthy update at `OldSlotRetainedUntilSoak` immediately emitted `CompleteSelfUpdateIntent`, so one second and the required duration were indistinguishable. The pure policy could therefore complete the A/B update without evidence that its caller-selected soak elapsed.

Completion now requires typed `UpdateSoakEvidence` bound to the exact operation, node, allocation, writer epoch, target generation, and committed active slot. Missing evidence and insufficient elapsed duration hold. Replayed scope is rejected. Evidence supplied before the soak phase is rejected rather than cached as future proof.

Soak is only a healthy-completion prerequisite. An exact target-health or compatibility failure at the soak checkpoint still emits rollback immediately, even when soak evidence is missing, stale, or incomplete. This preserves the local-known-good recovery policy.

## Adversarial coverage

- Missing soak and the exact 599-second boundary hold a configured 600-second soak.
- Exact 600-second and greater 601-second evidence complete.
- Operation, node, allocation, epoch, target-generation, and active-slot replay are independently rejected.
- Prepopulated evidence at every non-soak phase is rejected.
- Exact health and compatibility failures bypass the soak gate and retain rollback authority.
- Existing 1,000-case artifact, recovery, precedence, and culture/property families use the appended reason and preserve their exact prior trace prefix.

## Contract inventory

- `RuntimeDecisionCode`: 22 values with existing IDs `1..21` unchanged and `SoakComplete=22` appended.
- Self-update trace: 14 entries; the prior 13-entry trace is an exact prefix.
- Runtime intent subtypes: 21, unchanged.
- Update phases/slots: 12/2, unchanged.
- Lifecycle traces, decisions, and enum inventories are unchanged.

## Evidence boundary

This is pure feature-shard evidence only. It does not qualify clock/timer adapters, persisted event application, A/B filesystem slots, systemd rollback timers, L0/L0C, mutation testing, deployment, or production acceptance.


---

# FILE: docs/work-packages/handoffs/phase1-runtime-upgrade-properties.md

# Phase 1 runtime self-upgrade deterministic property shard handoff

## Scope

- Chooses A/B self-upgrade as the cohesive high-risk shard because its pure decision authorizes orchestrator binary activation, slot switching, commit, retention, and rollback.
- Adds four independent deterministic families with exactly 1,000 seeded cases each: every persisted A/B checkpoint, exact artifact/rollback/compatibility/epoch/operation fences, lost-response versus failed-health recovery, and culture/health-permutation replay.
- Seeds materially reconstruct operation, node, allocation, release, artifact, signature, generation, and evidence identities; 1,000 distinct operation identities are asserted. Corpus replay compares an exact reconstructed fingerprint, proves emitted intents retain the request operation, and proves a mutated seed changes the fingerprint.
- Invalid variants bind exact `RuntimeDecisionCode` and outcome. Recovery variants bind exact observe/rollback intent and `CallSafe`/`ReadinessComplete` evidence.
- Adds a 19-entry embedded replay corpus pinned as a whole file to SHA-256 `d869460ff66604d33babe48d443351ce3de201ab046789e55afe985b27279376`. Its bounded reader and strict parser reject over 8,192 bytes, comments, trailing commas/data, excess depth/entries, field drift/duplicates, duplicate identities/seeds, zero/negative/out-of-range/type-invalid seeds, and an invalid closed `(variant, expected)` pair. Replay IDs use a canonical lowercase ASCII token grammar with an exact 64-character boundary. The terminal rollback-failed checkpoint is pinned to a denied `RollbackPossible` outcome.
- Proves `RuntimeDecision` has no public constructor or non-operator factory and no `RuntimeIntent` subtype has a public constructor, so caller code cannot mint an accepted activation.

## Production hardening

- Replaces unbounded caller-enumerable capture in `RuntimeEnums.Copy` and `CopyDistinct` with one shared snapshot helper and public documented `RuntimeTechnicalLimits.MaximumCapturedItems = 4096`.
- The cap is technical denial-of-service protection, not health, lifecycle, soak, compatibility, or rollout policy.
- Constructor signatures and post-capture null/enum/duplicate semantics are unchanged. Exact maximum succeeds; max+1/infinite sources reject before the extra `Current`; ordinary iterator failures become generic secret-safe `ArgumentException` without inner exceptions; `OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException` propagate from every iterator phase; dispose mutation cannot alter the captured request.

## Verification

- Focused ControlPlane Release tests: 330/330 passed.
- Full solution Release tests: 511/511 passed.
- Full solution Release build: succeeded with zero warnings and zero errors.

This is bounded deterministic feature-shard evidence, not full L0 or deployment qualification. It starts no process, VM, network, cloud, filesystem adapter, or sibling-repository change and selects no artifact signing technology, timeout, compatibility, or rollback policy value.


---

# FILE: docs/work-packages/handoffs/phase1-scheduler-audit2.md

# Phase 1 scheduler capacity/completeness audit handoff

## Defect and correction

The availability evaluator previously treated all resource rows as not applicable
when `ReserveDisposition.MayConsume` was selected. Those rows combined two distinct
questions: whether the placement itself fit and whether an additional reserve
remained. As a result, a placement could request more of a resource than the target
reported available and still return `Admitted=true`.

The evaluator now keeps the original twenty trace rows and IDs unchanged, appends
`CapacityCpu` through `CapacityHugePages` as IDs/rows 21 through 28, and evaluates
available-versus-requested resources for every placement. Reserve rows retain their
existing remaining-versus-reserve semantics. `MayConsume` makes only reserve rows
not applicable. Maintenance and drain make both resource groups not applicable.
Held and invalid-target paths use the same explicit twenty-eight-code order as normal
evaluation; they no longer derive the surface with an enum range or `Skip` rule.

## Evidence

- The pre-fix regression requested CPU 2 from a target reporting CPU 1 with a
  consumable reserve and observed `Admitted=true`; the corrected result rejects the
  exact `CapacityCpu` row with observed 1 and required 2.
- A 1,000-seed property rotates the shortage across all eight dimensions, proves
  exact-fit admission, exact one-dimension rejection, independent reserve
  applicability, and exact observed/required values.
- A 1,000-seed surface property covers placement, maintenance, drain, incomplete
  evidence, and invalid targets while requiring the stable twenty-row prefix plus
  the eight appended capacity rows exactly once and in exact order.
- A 1,000-seed caller-hold property inventories all five `CandidateVetoCode` values,
  including the previously omitted `VolumeLocalityMismatch`, and binds the exact
  rejection reason.

## Non-claims

This is pure L0 scheduler evidence only. It selects no reserve, quorum, topology,
weight, node-class, criticality, or disruption default; does not authorize a
stateful move; does not establish deployment evidence; and performs no provider,
runtime, NATS, network, filesystem, process, or wall-clock action.


---

# FILE: docs/work-packages/handoffs/phase1-scheduler-audit3.md

# Phase 1 scheduler observation-generation audit handoff

## Defect and correction

The availability evaluator previously received completeness and structural checks
for a replica observation snapshot but no snapshot generation or accepted-generation
high-water mark. A healthy generation-3 snapshot could authorize maintenance, a
newer generation-4 snapshot could show one replica already disrupting and correctly
reject the same maintenance, and replaying generation 3 would authorize the second
disruption again.

`AvailabilityEvaluationRequest` now requires positive `ObservationGeneration` and
`CurrentAcceptedObservationGeneration` values. The evaluator consumes evidence
already accepted by its caller, so only exact equality can authorize a change. A
lower generation is held as rollback evidence; a higher generation is held because
it has not yet become the caller's accepted snapshot.

## Compatibility and precedence

Availability reason IDs and trace rows 1 through 28 retain their exact numeric
values and order. Two rows are appended explicitly:

- `ObservationGenerationNotRollback = 29`
- `ObservationGenerationNotFuture = 30`

Both rows carry the candidate generation as `Observed` and the accepted high-water
mark as `Required`. Their hold status participates with the five existing evidence
integrity rows before change-target evaluation. For compatibility, the rows are
emitted after the established 28-row prefix: a generation hold makes target row 6
and policy rows 7 through 28 held/not-applicable exactly like other unavailable
evidence, then rows 29 and 30 expose whether the mismatch was lower or higher.
Equal-generation requests leave the first 28 serialized rows unchanged and append
two passed, generation-distinct rows.

## Evidence

- The concrete generation-3/generation-4 replay history now rejects the stale
  generation at row 29 before maintenance arithmetic can authorize it.
- Lower, equal, and higher generations are exercised across 1,000 deterministic
  placement, maintenance, and drain cases, reversed observations, and `tr-TR` and
  `ar-SA` cultures.
- Tests pin enum values 1 through 30, exact trace order, observed/required values,
  zero and null rejection, existing constructor callers, the unchanged 28-row
  equal-generation prefix, and both appended rows in the canonical numeric
  availability signature.
- Existing fixed replay-corpus inputs now supply equal accepted generations. The
  corpus JSON and content hash remain unchanged because its stored expectations are
  classification labels; the canonical decision serializer includes rows 29/30.

## Non-claims

This is pure L0 policy evidence. It does not accept, sign, timestamp, persist, or
replicate an observation generation and does not prove adapter wiring or deployment
evidence. The caller must obtain the current high-water mark from its authoritative
accepted state. No topology, quorum, disruption, reserve, provider, runtime, NATS,
network, filesystem, process, or wall-clock behavior is selected or exercised.

## Exact-tree verification

After the branch was rebased onto integration commit `369a3a1`, locked restore and
the complete Release build with warnings as errors succeeded with zero warnings and
zero errors. The focused Scheduler suite passed 77/77. All five executable suites
passed 750/750: Contract 24, ControlPlane 546, Model 38, Protocol 65, and Scheduler
77. `git diff --check` and the final clean-worktree check passed.


---

# FILE: docs/work-packages/handoffs/phase1-scheduler-availability.md

# Phase 1 scheduler availability handoff

Branch: `phase1/scheduler-availability`

## Implemented boundary

The availability evaluator is a pure hard-policy layer. Callers explicitly provide
service/replica/node/failure-domain identities, observation completeness, desired,
minimum-available, quorum, maximum concurrent disruption and required-domain counts,
criticality, one-per-host policy, reserve resources, and whether that reserve must be
preserved. No topology, count, cost, timing, SLO, or reserve default exists.

Placement, node drain, and replica maintenance are closed action types. Placement
checks desired count, every still-allocated replica for one-per-host conflicts,
projected available failure domains, and all eight reserve dimensions. Drain counts
every available service replica on the target node. Maintenance requires one exact
currently available target. Disruption arithmetic is checked and quorum is the exact
caller value; the evaluator never computes an implicit majority.

An admitted planned placement contributes one checked unit to both projected replica
count and projected availability. This lets an explicit placement restore a supplied
minimum/quorum while `ulong.MaxValue + 1` fails closed rather than wrapping.

Observation completeness is explicit because an absent whole observation cannot be
inferred from the remaining records. Duplicate IDs, conflicting duplicate records,
missing node/domain identity, wrong service identity, and an incomplete set hold
before policy arithmetic. Exact duplicates and conflicts are separately visible.

Every decision contains the same 20 ordered reasons. Codes/outcomes are closed enums
and observed/required values are unsigned counts only; constructors are internal and
there is no caller text/secret channel. Observations are ordinally ordered, so output
is invariant to enumeration order and culture.

## Verification coverage

Focused TUnit coverage includes explicit 2-of-3 quorum, second loss, one-at-a-time
maintenance, last-domain margin, placement anti-affinity, unavailable allocations,
multi-replica drain, exact reserve boundary and one-unit shortage in each of CPU,
memory, block IO, ephemeral disk, bandwidth, PIDs, file descriptors and huge pages,
explicit reserve consumption, duplicate/conflicting/missing observations, wrong
service, zero/maximum/overflow counts, invalid targets, defensive copying, all
three-replica permutations under `en-US`/`tr-TR`/`ar-SA`, unknown enums, canonical
identity validation, fixed trace order, and secret-safe trace reflection.

## Intentional limitations

- Criticality is an explicit classification, not permission to invent topology or
  reserve policy. The caller separately supplies one-per-host, domain, and reserve
  disposition inputs.
- Stateful move/volume/quorum semantics beyond supplied counts remain domain-
  controller vetoes. The evaluator does not decide TerraBase or NATS move safety.
- Product/project geography is not represented or inferred (`INV-013`).
- Resource capacity must already reflect caller-owned reservations/headroom. This
  layer only proves preservation of the supplied additional reserve.
- This is L0 pure-policy evidence only. It does not freeze draft registry entries or
  establish deployment/adapter evidence.


---

# FILE: docs/work-packages/handoffs/phase1-scheduler-core.md

# Phase 1 scheduler core handoff

Branch: `phase1/scheduler-core`

## Implemented boundary

The scheduler is a pure regional decision kernel. It accepts only supplied node
candidates, workload constraints, capacities already reduced by caller-owned
reservations/headroom, and a mandatory caller-supplied least-waste policy. It does
not inspect infrastructure or infer product/database geography, topology safety,
stateful moves, disruption policy, or cloud ownership.

Hard checks run for every candidate in this stable order: caller veto, architecture,
node class, labels, trust/network/secret zones, allowed failure domain, affinity,
anti-affinity, ports, optional caller cap, then CPU, memory, block IO, ephemeral disk,
bandwidth, PIDs, file descriptors, and huge pages. Every check is recorded even when
an earlier check rejects the candidate. Score and selection records complete the
22-item trace; candidates themselves are globally ordered by ordinal ID.

Caller vetoes use a closed `CandidateVetoCode` enum. No arbitrary caller detail can
enter a reason trace, preventing secret leakage and newline/control-character
injection through the veto path. Optional strings distinguish null/absent from an
invalid supplied blank; optional string collections likewise reject blank members.

Resource quantities are non-negative `long` values. Vector addition is checked,
subtraction fails closed on underflow, and exact score calculation uses `BigInteger`.
There is no floating-point/decimal division or overflow-dependent comparison. The
caller supplies every dimension exactly once with a non-negative weight and an
explicit component tie-break order; there is deliberately no production default.
Ranking is weighted waste, then ordered remaining components, then ordinal candidate
ID.

The optional allocation cap is also caller-owned and supplies current and maximum
counts. Admission uses `current < maximum` without increment arithmetic. Omitting it
adds no allocation-count limit.

## Verification coverage

TUnit covers exact-fit and one-unit-short boundaries for all eight resources,
zero-request/zero-capacity, negative values, checked overflow/underflow, near-maximum
weights and quantities, ports and duplicate ports, all label/zone/architecture/class/
failure-domain constraints, affinity/anti-affinity, veto, omitted/present/maximum
caps, least waste, score and ID ties, every candidate permutation, complete trace
order, typed unschedulable output, ambiguous duplicate IDs/facts, and defensive-copy/
no-mutation behavior.

## Limitations intentionally left to callers

- Weight values and component order are contract/policy inputs; this lane selects no
  production weighting.
- Capacities must already subtract system/NATS/controller reservations and HA
  headroom. The kernel neither measures nor guesses them.
- Callers translate topology spread, disruption budgets, volume locality,
  single-writer/stateful safety, and controller decisions into supplied facts,
  candidate sets, reservations, or vetoes.
- Port checks are exact host-port set conflicts. Network namespaces or future port
  scopes require an explicit contract extension.
- This is L0 pure-domain evidence only; it is not deployment or stateful safety
  evidence and freezes no unresolved owner decision.


---

# FILE: docs/work-packages/handoffs/phase1-scheduler-property-shard.md

# Phase 1 scheduler deterministic property/replay shard handoff

## Delivered

- Deterministic explicit-seed generators for valid placement and availability inputs plus invalid cases spanning all placement hard constraints and public validation families.
- Fourteen scheduler/availability property families execute 1,000 cases each for deterministic replay/permutation/culture, independent weighted-score selection and ordinal ties, resource/count conservation, capacity and constraint safety, quorum/minimum/disruption/topology/anti-affinity/reserve floors, typed caller safety holds, incomplete/conflicting evidence holds, generator diversity, and invalid-input rejection.
- Generator distribution assertions require every hard-constraint case to appear at least 50 times, every scheduler validator family at least 50 times, and every availability validator family at least 70 times. These checks prevent an accidentally vacuous or collapsed generator.
- A six-entry, maximum-32 strict embedded JSON replay corpus covers minimal hard-constraint, caller-hold, availability-floor, observation-conflict, and reserve-boundary seeds. Its canonical bytes are SHA-256 pinned; fixed resource name, version, shape, unknown fields, duplicate properties/identities/seeds, byte/count bounds, and positive seeds are validated before every entry reproduces its exact expected rejection.
- Mutation-sensitive assertions bind exact rejected checks, independently calculated scalar/BigInteger resource remainders and weighted-waste tuples, exact ordinal winners, exact availability reason codes, and neighboring reserve dimensions. Oracle subtraction does not call production `ResourceVector` arithmetic.
- Availability decisions and reasons are verified construction-closed with immutable public observations. Placement `ScheduleResult` records remain public caller-constructible DTOs in the existing production contract; the shard treats them as explanatory results, not mutation authority.
- The audit found unbounded `IEnumerable` materialization in the production placement and availability input surfaces. A shared maximum-plus-one snapshot now exposes named 4,096 candidate/observation, 1,024 port/fact/label, and exact-eight score-dimension technical limits; exact bounds remain accepted, while maximum+1, infinite, GetEnumerator/MoveNext/Current/Dispose failures reject secret-safely before any partial decision. A dedicated trap proves the extra element's `Current` is never read. Fatal runtime exceptions (`OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException`) are deliberately not translated. Canonical ordering and defensive snapshots are regression-tested. These are technical input bounds, not business capacity caps.

## Boundary and non-claims

The existing placement API has no generation or fencing epoch. This shard proves rejection of stateful stale/fencing observations only through the scheduler's closed caller-veto codes and proves incomplete/duplicate/conflicting availability evidence is held before policy arithmetic. It does not claim an intrinsic scheduler generation validator that does not exist.

This is scheduler-only feature evidence. It performs no filesystem/network/process/cloud/environment/clock operation, uses no nondeterministic randomness or new package, and does not claim full-domain/full-L0 thresholds, mutation coverage, fuzz/model evidence, or deployment authority.

## Verification

- `dotnet build TerraScale.Orchestrator.slnx --no-restore` — passed with 0 warnings and 0 errors.
- `dotnet test tests/TerraScale.Orchestrator.Scheduler.Tests/TerraScale.Orchestrator.Scheduler.Tests.csproj --no-build -- --minimum-expected-tests 20` — passed (69/69).


---

# FILE: docs/work-packages/handoffs/phase1-security-authorization-output-audit3.md

# Phase 1 security authorization output audit 3 handoff

## Proven gap and correction

Two exact accepted capability requests could use the same operation, principal ID, capability, resource scope, and generation numbers while proving different principal kinds and roles with different matching grants. Their traces and `AuthorizeCapabilityIntent` values were equal because the intent retained none of the selected evidence or grant provenance.

Accepted authorization intents now retain the exact selected `PrincipalAuthorizationEvidence`, exact selected matching `AuthorizationGrant`, and the accepted expected/current principal, policy/current-policy, and current-revocation generation objects. Existing operation, principal ID, capability, and resource-scope projections remain unchanged. The engine passes the already selected evidence and grant only after every existing gate; no enum, code, trace, policy, or precedence changed. The intent uses a redacted string representation.

Tests pin exact reference retention, semantic replay equality/hash stability, independent principal-kind, role, and generation-group sensitivity, nested evidence/principal/grant fingerprints, hold-only denial paths, construction closure, redaction, and strict corpus/checksum replay.

## Honest boundary

This closes only accepted authorization-intent provenance. The intent retains the selected matching grant, not the full candidate grant set, and neither selection nor identifiers prove external grant or identity authenticity. This work does not perform or qualify cryptography, secret handling, immediate connection termination, certificate/vault adapters, runtime enforcement, deployment, L3S, L4, or production behavior. No external I/O occurs.


---

# FILE: docs/work-packages/handoffs/phase1-security-enrollment-generation-audit4.md

# Phase 1 security enrollment generation audit 4 handoff

## Proven gap and correction

Enrollment previously compared the expected principal generation only with the selected bootstrap and attestation generations. A request whose three values were coherently generation 4 could therefore authorize issuance even when the authoritative current principal generation was 5. The same gap allowed the missing-attestation branch to authorize an attestation intent for a stale principal, and a coherently future generation had the same request-local consistency problem.

`EnrollmentRequest` now requires a non-null, get-only `CurrentPrincipalGeneration`. The existing `GenerationCurrent` gate requires the expected principal, bootstrap, attestation, and current-principal high-water to agree before either accepted intent can be constructed. The trace keeps its established code number and order and now records principal generation as observed and the high-water as required. Exact accepted issue and attestation outputs retain the request and high-water by reference.

The executable proof covers exact acceptance, coherent lower and future denial, stale missing-attestation denial, null construction, `ulong.MaxValue`, stable reason order and culture-independent replay. Reflection pins exactly one public ten-parameter constructor in the declared order, no optional/default parameters, and no public static factory returning `EnrollmentRequest`. The completeness model adds all three adversarial variants, exercises them across 1,000 cases, updates accepted-output and input fingerprints, and saves variants 16, 17, and 18 in the strict whole-file SHA-256 replay corpus.

## Honest boundary

This closes only request-to-current-principal generation closure inside the pure enrollment decision model. Callers remain responsible for obtaining an authoritative current generation; supplying a dishonest or stale high-water is outside this model. `SecurityGeneration` is not the deferred `SecurityEpoch`. Nothing here performs identity verification, cryptographic attestation, certificate issuance, vault/KMS access, durable replay storage, distributed consensus, immediate connection termination, external I/O, or production deployment.


---

# FILE: docs/work-packages/handoffs/phase1-security-policy-properties.md

# Phase 1 security policy property shard

## Scope

This shard strengthens the pure `SecurityDecisionEngine` contract for enrollment, certificate lifecycle, capability authorization, secret leases, and regional survival-secret references. It is primarily property/replay evidence and includes one narrow certificate-scope policy correction. It does not exercise a real issuer, KMS/Vault, NATS, network, process, filesystem, cloud resource, or deployment boundary and therefore makes no L0C or production-readiness claim.

Allowed paths for the shard are the security property tests and embedded replay corpus, the ControlPlane test project resource declaration, and this handoff. Reconciliation and cross-domain construction-closure files are excluded.

## Independent properties

- 1,000 materially distinct enrollment cases cover exact bootstrap/attestation identity, operation, cell, role, generation, issuer hierarchy, issuer generation, revocation generation, single-use status, duplicate/conflicting evidence, and the separately authorized attestation intent.
- 1,000 certificate cases cover issue, renew, rotate, and compromise-backed revoke; exact operation/principal/cell/key/usage/scope/issuer evidence; principal, issuer, policy, certificate, and revocation generations; expiry/action state; and exact intent subjects.
- 1,000 capability-authorization cases cover evidence completeness, duplicate/conflicting principal evidence, principal and generation binding, revocation, policy generation, exact grant cardinality, cell-bounded privilege, default denial, and the exact accepted authorization subject.
- 1,000 lease cases cover grant, renew, revoke, retained versions, availability, expiry evidence, duration, principal/policy/revocation/lease generations, exact grant and existing-lease binding, and the intentional revoke precedence that makes availability, retention, and current-policy checks not applicable.
- 1,000 survival-secret cases cover reference/metadata/policy uniqueness, cell/environment/purpose/version/digest equality, availability, policy generation, retention, expiry evidence, missing material, and exact accepted operation/request subjects.
- Another 1,000 cases replay conflicting authorization and multi-secret survival inputs across permutations and `en-US`, `tr-TR`, `ar-SA`, and `ja-JP` cultures.

`SecurityEpoch` currently exists as a primitive but none of these five request contracts carries an epoch. This shard therefore makes no epoch-coverage claim and does not invent a public contract expansion. Whether and where an epoch belongs in the security request bindings remains an explicit future contract decision; all generations currently modeled by the requests are covered here.

## Input and output safety

The audit found that all caller-controlled security enumerables already pass through `SecurityInputSnapshot.Copy`. The public `SecurityTechnicalLimits.MaximumCapturedItems` cap is a technical denial-of-service limit distinct from certificate, lease-duration, or retention policy. Tests prove the maximum-plus-one element is rejected before reading its `Current`, disposal occurs, ordinary failures in `GetEnumerator`, `MoveNext`, `Current`, and `Dispose` become opaque `ArgumentException`, and `OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException` propagate from every enumerator phase.

Construction-closure assertions cover the immutable public-constructor boundary for `SecurityDecision` and every `SecurityIntent` subtype; the central architecture guard owns the exported factory inventory. A bounded strict JSON replay reader pins the whole-file SHA-256, exact schema and object fields, canonical lowercase ASCII IDs, unique IDs and case tuples, per-family variant vocabulary, complete seed-sensitive input/evidence fingerprints, and full authorized/intent/subject/ordered-trace output fingerprints. Parse accepts only the exact input fingerprint and engine-replayed output fingerprint for the recorded `(kind, variant, seed)` tuple; the generated property families separately provide independent trace and subject oracles. Unknown, duplicate, zero, out-of-range, noncanonical, wrong-nonempty fingerprint, commented, trailing-comma, and trailing-content inputs fail closed.

## Compatibility and production changes

The audit found one production policy defect: the global-administrative issuer branch validated the issuer's own scope but not the requested certificate scope, allowing that capability to sign a cell-scoped certificate. `EvaluateCertificate` now requires a `GlobalAdministrativeIntermediate` request to carry `TrustScope.GlobalAdministration`. This is a deliberate behavior correction for callers that previously attempted the cross-scope combination; it changes no public type or signature. The embedded test resource declaration is the only project-file change.

## Verification

Run the ControlPlane test executable serially in Release mode. The shard requires all five 1,000-case policy families, the 1,000-case culture/permutation family, enumerable safety, construction closure, corpus replay, and parser rejection tests to pass alongside the existing ControlPlane suite.


---

# FILE: docs/work-packages/handoffs/phase1-snapshot-core.md

# Phase 1 snapshot core handoff

- Branch: `phase1/snapshot-core`
- Work package: `docs/work-packages/phase1-snapshot-core.md`
- Scope: pure immutable snapshot material, validation, and anti-rollback restore planning
- Algorithms, canonical serializers, NATS, filesystems, clocks, compatibility defaults, and composition: unchanged

## Implemented behavior

- Authority, stream, snapshot, schema, and signing-key identities require caller-supplied positive character bounds. They reject empty, whitespace/control-containing, over-bound, and malformed Unicode scalar values.
- Epoch, stream sequence, and snapshot generation are explicit positive `ulong` values. Zero/default instances fail closed; maximum values remain representable.
- State digests and signatures are nonempty opaque byte values with caller-supplied positive byte bounds, defensive input copies, fixed-time equality, and redacted formatting.
- `SnapshotSignedMaterial.TryCreate` requires every typed field and produces the complete algorithm-neutral projection passed to the signature verifier. It selects no serialization or signing algorithm.
- `SignedSnapshotValidator` requires explicit expected authority, stream, signing key, current schema, current accepted epoch and stream position, expected state digest, schema compatibility evaluator, and signature verifier.
- Validation rejects wrong scope/key, unknown or incompatible schema, compatibility/verifier failures, stale epochs, older or equal stream positions, digest mismatch, and invalid signatures through closed typed errors. Verifier exception text is discarded.
- `SnapshotRestorePlanner` performs no mutation or I/O. An accepted plan carries the snapshot/generation identity, expected restored epoch/digest, and replay start exactly one sequence after the signed snapshot position. `ulong.MaxValue` fails with a typed replay-overflow error.

## Review-sensitive semantic choice

The core treats every candidate stream sequence less than or equal to the current accepted sequence as rollback, including when the candidate epoch is newer. Epoch is checked first, so an older epoch reports `StaleEpoch`; otherwise non-advancing stream position reports `StreamRollback`. This assumes one monotonic sequence space per typed stream identity and should be retained unless a future explicitly versioned stream-reset contract says otherwise.

## Adversarial coverage

The 13 focused TUnit tests cover:

- all identity and byte bounds, malformed surrogate sequences, defensive copies, and secret-safe formatting;
- zero and `ulong.MaxValue` numeric boundaries;
- omission of each signed-material field and malformed envelope material/signature;
- exact verifier projection of all nine authenticated fields;
- wrong authority/stream/key, unknown/incompatible schema, stale epoch, older/equal stream position, digest mismatch, invalid signature, unknown verifier outcomes, and exception closure;
- a tamper-one-field matrix for every material field plus the signature; and
- deterministic replay planning, cross-epoch monotonic anti-rollback, exact replay start, expected digest/epoch, and overflow closure.

Verification:

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx --no-restore
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore -- --treenode-filter '/*/*/Snapshot*/*'
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build --no-restore
git diff --check
```

Result: solution build passed with zero warnings/errors; snapshot tests passed 13/13; full ControlPlane tests passed 44/44.

## Deliberate limitations

- The caller owns canonical serialization, digest calculation, signature algorithm/key lookup, schema catalog/compatibility, and durable current-position observations.
- Character bounds are .NET UTF-16 code-unit bounds. Transport adapters must separately impose explicit serialized byte limits.
- The planner is decision material only: it does not read snapshot content, replay events, mutate accepted state, or perform any NATS/file operation.
- No wall clock, schema window, crypto algorithm, identity maximum, digest/signature size, or fresh-store bootstrap default is selected.


---

# FILE: docs/work-packages/handoffs/phase1-snapshot-policy-completeness.md

# Phase 1 snapshot policy completeness handoff

## Result

The audit found one accepted-output anti-rollback defect. `SnapshotSignedMaterial.Generation` was authenticated and copied into an authorizing restore plan, but validation had no current accepted generation and therefore accepted a lower state generation hidden behind a later signed stream position.

`SnapshotValidationContext` now requires `CurrentAcceptedGeneration`. Validation reports `GenerationRollback` only when the candidate generation is lower. Equal generation remains accepted when the stream position advances and all remaining gates pass. The deterministic precedence is epoch, stream position, generation, state digest, then signature after the pre-existing scope and schema gates. `GenerationRollback` is appended at numeric value 15, preserving every pre-existing validation-code value.

## Evidence

- The pre-fix focused regression failed because generation 2 produced a restore plan over accepted generation 3 at a later stream position.
- The paired regression proves equality is intentionally valid and asserts the exact restore plan.
- A 1,000-case independent oracle varies epoch, stream position, generation, digest, schema compatibility, and signature outcome. Every accepted case checks snapshot ID, generation, restored epoch, replay start, and digest exactly under four cultures and deterministic replay.
- Precedence tests prove compatibility and signature delegate call counts, exact schema arguments, and suppression at earlier denials.
- Catalog tests pin all three schema outcomes, both signature outcomes, 16 validation codes, four restore-plan codes, 11 material codes, invalid/default accepted generation, and construction-closed authorizing outputs.

## Deliberate limits

Snapshot generation is not required to advance for every new snapshot. A later journal checkpoint may retain the current state generation. The caller still owns canonical serialization, digest calculation, signature policy, schema compatibility, durable accepted baselines, snapshot content retrieval, replay execution, and atomic persistence.

No real signature, snapshot bytes, journal, NATS server, filesystem, process, network, cloud resource, VM, container, or deployment was exercised. This evidence does not claim L0/L0C completion, the required fuzz budget, mutation score, persistence correctness, or production qualification.


---

# FILE: docs/work-packages/handoffs/phase1-storage-compute-property-shard.md

# Phase 1 storage and compute property/replay shard handoff

## Delivered

- Nine deterministic generated property families execute 1,000 cases each across Storage and Compute capacity, generation/fencing, deletion, scale safety, replay, culture, and survival permutation behavior.
- Independent expected-code and arithmetic/floor oracles bind exact failure reasons and ensure denied cases never emit an unsafe mutation intent.
- A strict eight-entry, maximum-32, maximum-8,192-byte embedded JSON replay corpus rejects wrong version, unknown/duplicate fields, duplicate identities, non-positive seeds, unsupported domains, empty/oversized sets, and content-address drift. Its loader uses a fixed maximum+1 buffer and is regression-tested with non-seekable partial reads, so the byte limit applies before parsing. Every entry invokes the real pure core and reproduces its exact closed error code in file order.
- Authorizing Storage/Compute outputs remain construction-closed and their public observable enums are explicitly finite.
- `RegionalSurvivalBundle` now snapshots its caller enumerables with named technical bounds. Regressions cover exact maximums for both inputs, maximum+1 for both inputs, infinite inputs, a maximum+1 extra-`Current` trap, GetEnumerator/MoveNext/Current/Dispose failures, secret-safe translation, fatal propagation at every iterator phase, and mutation during disposal.

## Compatibility impact

The public constructor signature is unchanged. Callers that supplied more than 4,096 secret-version identities or node templates, infinite enumerables, null elements, or ordinary-failing enumerators previously risked unbounded work or leaked exception details; they now receive a generic `ArgumentException`. No autoscaling, capacity, replica, deletion, or survival-readiness business policy changed.

## Verification

- Locked solution restore passed.
- Full solution build passed with 0 warnings and 0 errors.
- Focused ControlPlane executable suite passed 302/302.
- `git diff --check` passed.

## Non-claims

This is bounded feature-shard evidence. It makes no full-L0, 100,000-case, coverage, mutation, integration, real-provider, destructive-storage, or deployment-authorization claim.


---

# FILE: docs/work-packages/handoffs/phase1-storage-create-output-audit4.md

# Phase 1 storage create output audit 4 handoff

## Proven gap and correction

Two fully valid provider-volume creation requests differing only in encryption-key reference produced equal accepted `Create` decisions. Equivalent collisions existed for placement, storage domain, and mount purpose. `StorageVolumeRecord` validated those fields, but `Trace` omitted them when constructing `StorageIntentScope`.

`StorageIntentScope` now retains the exact `StorageDomain`, `EncryptionKeyReference`, `StoragePlacementId`, and `StorageMountPurpose` already present on the validated volume. All trace-produced accepted and held decisions share that complete structural subject. Existing projections and planner decisions are unchanged.

Tests independently distinguish every corrected field, pin exact key and placement references, check the complete subject across 1,000 cases for create, format, reattachment, expansion, deletion, and hold paths, and retain culture-stable semantic replay and opaque rendering. Assembly-wide reflection inventories every public declared method and accessor: the five Storage planners remain the only decision origins, while trace/scope exposure is limited to existing getters and immutable equal-but-distinct record copies.

The checked-in JSON replay corpus contains planner inputs and expected action/target/code outcomes, none of which changed. Its complete accepted-trace fingerprint and expected assertion were updated to include the four corrected fields; the historical JSON bytes and checksum therefore remain unchanged by design.

## Honest boundary

This closes only pure accepted-output provenance. It does not prove that the referenced key exists or is authorized, that a provider honors encryption or placement, that storage is formatted or mounted correctly, or that TerraBase is safe. It adds no adapter, schema, external I/O, destructive operation, lab qualification, or deployment evidence.


---

# FILE: docs/work-packages/handoffs/phase1-storage-lifecycle-core.md

# Phase 1 storage lifecycle and expansion core handoff

## Delivered

- Pure, immutable storage identity, authority, intent, and numeric-trace model under `ControlPlane/Storage`.
- Restartable create/classify/format/mount and bounded single-writer reattach authorization. Recognized filesystems require identity proof and cannot enter the formatting path.
- Ordered expansion authorization with persisted checkpoints, caller-declared conflict serialization, checked arithmetic, no shrink, convergence checks, and replay protection for provider extension, guest rescan, and filesystem growth.
- Retention-aware deletion authorization. Permanent retention always holds. Elastic and explicitly disposable volumes require their distinct policy proof plus all common topology, quorum, reference, backup, retention, owner/fence, and audit-readiness proofs.
- Defensive-copy, replay, permutation, culture, wrong-authority, crash-matrix, overflow, disagreement, conflict, retention, and secret-redaction tests.
- Every proof aggregate is structurally bound to the complete decision-relevant evidence scope: ownership tuple, provider/attachment/device/filesystem identities, filesystem/layout, requested size, retention/backup, operation/fence, generation, and writer epoch. Format classification and its blank/filesystem proofs are one immutable scoped aggregate.

## Deletion contract interpretation

`PostDeleteAuditReady` is a pre-delete capability/readiness proof and gates the exact `Delete` intent. It is deliberately distinct from `PostDeleteAuditPassed`. Terminal completion requires both observed provider absence and the actual post-delete audit proof. A readiness proof can therefore never masquerade as deletion completion.

## Boundaries

The core contains no device paths, mount or shell commands, callbacks, provider/filesystem SDK types, clock, thresholds, defaults, or I/O. Filesystem, layout, performance/SLO values, forecast, requested growth, retention, and every observation remain explicit caller inputs. The returned intents authorize work but do not execute it.

## Verification

- `dotnet build TerraScale.Orchestrator.slnx --no-restore` — passed with 0 warnings and 0 errors.
- `dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build -- --minimum-expected-tests 100` — passed (114/114).

## Contract gaps

None found within the assigned pure-core boundary. Provider adapters must preserve the exact typed intent scope and persist each proof checkpoint before advancing; that integration is intentionally outside this work package.


---

# FILE: docs/work-packages/handoffs/phase1-storage-policy-audit2.md

# Phase 1 storage expansion policy audit 2 handoff

## Proven defects and corrections

- Accepted expansion outputs previously omitted `FilesystemType` and `Layout`. An XFS/LVM volume and an ext4/partition volume could therefore authorize byte-for-byte equal `Grow` decisions even though their adapters require different typed operations. `StorageIntentScope` now carries both closed fields for every trace-created output.
- `StorageEvidenceScope` previously omitted the observed provider, device, filesystem, capacity, forecast, and performance snapshot. A proof aggregate from before provider growth compared equal to the scopes after provider growth, guest rescan, and filesystem growth. The scope now binds all seven observed byte fields and the complete `StoragePerformance` value.
- Evidence-scope validation now rejects unknown and undefined filesystem, layout, retention, and performance-tier values before evaluating checkpoint proofs.

## Preserved behavior

- Authority and failure precedence remains authority, exact evidence scope, conflicts, proof closure/order, anti-shrink and arithmetic checks, then the first unproven expansion checkpoint.
- All existing action, target, decision-code, proof, conflict, and checkpoint numeric values are unchanged. `StorageAction` remains the exact 14-value sequence `0..13`.
- Expansion remains pure and expand-only. This work adds no filesystem command, device path, provider call, adapter, default, external I/O, or deployment acceptance claim.

## Evidence

- Adversarial regression proves XFS/LVM and ext4/partition growth decisions are distinct and expose their exact typed subject.
- Capacity replay regressions distinguish provider growth, guest rescan, filesystem growth, each of the seven byte fields, and every performance component.
- Changed snapshots fail with `WrongEvidenceScope` and cannot authorize mutation. Undefined closed enums fail at the same scope-validation precedence.
- The existing generated crash/replay properties retain the exact first-unproven-step action, target, code, numeric trace, and checkpoint sequence.

## Non-claims

This is Phase 1 pure-policy evidence only. It does not qualify provider, block-device, ext4/XFS, TerraBase, systemd, OCI, rootless container, or destructive-storage behavior and does not mint deployment authority.


---

# FILE: docs/work-packages/handoffs/phase1-storage-policy-audit3.md

# Phase 1 storage destructive-output audit 3 handoff

## Proven defect and correction

- Exact deletion evidence already bound the volume retention policy and verified backup identity, but the accepted intent subject discarded both values. Consequently, an elastic-quarantine deletion and an explicitly-disposable deletion could emit equal `Delete` decisions after satisfying different destructive policy gates. The same collision existed between decisions authorized against different verified backup identities.
- `StorageIntentScope` now retains the exact `StorageRetention` value and `StorageBackupId` instance copied from `StorageVolumeRecord`. All decisions constructed from a volume trace, including holds and non-deletion actions, preserve the same closed subject shape.

## Preserved behavior

- Authority, permanent-retention, evidence-scope, proof-closure, retention-specific, provider-convergence, and post-delete-audit precedence is unchanged.
- No action, target, decision-code, proof, checkpoint, or enum numeric value changed. The intent subject is the exact 15-property closed shape.
- Intent and trace rendering remains opaque; the verified backup identifier is not written by `ToString()`.

## Evidence

- Adversarial regressions prove retention-policy-only and backup-identity-only deletion decisions are unequal, while retaining the exact accepted values and backup object instances.
- The generated storage oracle checks retention and backup identity across every create, format, reattach, expansion, deletion, and hold/action path it exercises.
- The fixed replay trace fingerprint includes retention and backup, and construction-closure tests prevent callers from minting accepted decisions, traces, or intent subjects.

## Non-claims

This closes only the pure-policy binding of the accepted retention and verified-backup subject. It does not qualify a deletion adapter, provider API, filesystem, backup system, destructive lab run, or deployment acceptance, and it does not claim that every possible storage acceptance concern has been audited.


---

# FILE: docs/work-packages/handoffs/phase1-structured-trace-foundation.md

# Phase 1 structured traceability foundation handoff

## Outcome

The repository now has a strict structured trace-link manifest and validator. All 43 registry IDs occur exactly once with owner and ordered acceptance-layer data checked against `requirements/registry.yaml`.

All entries intentionally remain `gap`: current lexical matches do not provide a complete typed production-symbol, exact test-identifier, and evidence-artifact chain. No link was invented and no item was promoted. The canonical report therefore records 43 gaps, zero linked entries, zero acceptance-satisfied entries, and `claimsAcceptanceEvidence: false`.

## Validation boundary

Future `linked` entries must pass bounded closed-shape validation, canonical no-symlink path confinement, exact regular-file existence, unique non-comment/non-string C# symbol and test occurrences, globally unique link identities, and allowed evidence kind/layer plus exact evidence identifier checks. A linked association still does not establish acceptance in this tranche.

The existing lexical report remains checked in as a separate gap-discovery aid. Its six `linked` and one `test-only` lexical classifications are text-occurrence labels only and cannot affect the structured manifest or acceptance state.

## Verification

- Structured generation and stale check: pass; `registered=43`, `gap=43`, `linked=0`, `acceptanceSatisfied=0`.
- Lexical stale check: pass; `registered=43`, `linked=6`, `test-only=1`, `unreferenced=36`, `unknownReferences=0`.
- Traceability unit tests: 18 passed.
- Negative fixtures cover duplicate/unknown/missing IDs, owner/layer drift, traversal/absolute/symlink paths and report outputs, non-regular registry input, missing/ambiguous/comment/string-only and forged-qualified identifiers, partial promotion, orphan links, collection and byte bounds, malformed/duplicate-key YAML, evidence and acceptance forgery, link reuse, unknown fields, and stale/symlinked reports.

## Remaining work

Owners may replace a gap with `linked` only when exact production, test, and typed evidence artifacts exist and the declared identifiers are unique. Acceptance promotion requires a separate authorized evidence tranche and is not implied by this foundation.


---

# FILE: docs/work-packages/handoffs/phase1-subject-grammar.md

# Phase 1 subject grammar handoff

- Branch: `phase1/subject-grammar`
- Work package: `docs/work-packages/phase1-subject-grammar.md`
- Scope: infrastructure-free subject syntax, wildcard matching, permission decision, and focused TUnit tests
- NATS packages, accounts, roots, streams, actual permissions, package/build files, registry, and composition root: unchanged

## Implemented behavior

`ConcreteSubject` and `SubjectPermissionPattern` are deliberately separate immutable types:

- Concrete subjects require one or more nonempty dot-separated tokens and reject whitespace, control characters, unpaired UTF-16 surrogates, empty tokens, and either wildcard character anywhere.
- Permission patterns apply the same bounded token grammar, allow `*` only as an entire one-token wildcard, and allow `>` only as the final entire token.
- `SubjectPermissionPattern.Matches` performs ordinal, case-sensitive token walking. It uses no regular expression and allocates nothing per match. `*` consumes exactly one token; terminal `>` consumes one or more tokens, matching the [official NATS subject semantics](https://docs.nats.io/nats-concepts/subjects).
- `SubjectGrammarLimits` is mandatory caller input. Its validated positive fields cap total .NET string length, token count, token length, and combined permission-pattern count. There is no production default.
- Parsing checks total length before allocating token strings. Policy construction stops enumeration at the explicit count bound, rejects null/duplicate/cross-set patterns, copies the caller's collections, and sorts both sets using ordinal canonical order.
- `SubjectPermissionPolicy.Authorize` checks every deny before any allow. A deny match wins; an empty allow set, no allow match, or invalid subject denies. `SubjectPermissionDecision` returns a stable enum reason and never contains the untrusted subject text (`SEC-NO-SECRET-OUTPUT`).

The implementation does not claim the broader `INV-018` separation invariant: it provides only grammar and deny-first decision primitives for future generated policies.

## Determinism and allocation bounds

Parse failures use the closed `SubjectGrammarError` catalog. Limit validation occurs first, followed by empty input and total length. The bounded left-to-right scan then rejects empty/excess tokens, whitespace/control characters, malformed Unicode scalar sequences, and token length before the concrete/pattern-specific wildcard pass.

Matcher work is linear in the bounded number of tokens. A nonterminal pattern must have exactly the concrete token count. A terminal `>` pattern requires at least as many concrete tokens as pattern tokens because `>` consumes one or more. Literal comparison uses `StringComparer.Ordinal`; culture and current locale cannot affect matching, equality, duplicate detection, or ordering.

Policy construction uses one combined maximum count across allow and deny. Exact duplicates within either set and exact patterns appearing in both sets are rejected. Case-distinct patterns remain distinct because NATS subjects are case-sensitive.

## Tests

The 19 focused TUnit tests cover:

- invalid and exact-boundary limit policies;
- concrete subject total/token/count boundaries;
- null, empty, leading/trailing/consecutive-dot, whitespace, control, unpaired high/low surrogate, wildcard, and injection-like malformed corpora;
- valid `*`, terminal `>`, mixed wildcard patterns, and invalid embedded/nonterminal variants;
- literal, single-token, multi-token, case-sensitive, and regex-metacharacter-as-literal matching;
- deny precedence, empty-allow/no-match default deny, invalid subject, and stable credential-like-text non-echoing reasons;
- null, duplicate, cross-set, and excess permission patterns;
- caller collection mutation after construction; and
- ordinal canonical ordering and case-sensitive duplicate behavior.

Verification:

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx --no-restore
dotnet test tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --no-build --no-restore -- --treenode-filter '/*/*/Subject*/*'
dotnet test tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --no-build --no-restore
git diff --check
```

## Deliberate limitations

- No actual subject root, account, stream, import/export, allow, or deny is selected. Generated policy ownership remains a later steward/identity lane.
- Limits count .NET UTF-16 characters. A future serializer/transport adapter must add an explicit UTF-8 byte ceiling and real-server conformance fixtures without weakening this grammar.
- The grammar accepts non-control, non-whitespace Unicode literally and performs no normalization. A future generated naming policy may choose a narrower token alphabet; this layer never silently rewrites identity.
- No NATS client/server behavior, JWT configuration, L0C conformance, or verified registry evidence is claimed by these pure tests.


---

# FILE: docs/work-packages/handoffs/phase1-terrabase-audit2.md

# Phase 1 TerraBase accepted-output audit 2 handoff

## Result

The audit found and closed three accepted-output classes plus an adjacent expected-parameter hole:

- All seven entrypoints now reject a runtime-null or structurally invalid expected scope as `InvalidInput` before
  constructing a trace. Valid caller intent paired with null, malformed, or mismatched evidence remains
  `WrongEvidenceScope` and cannot emit a subject.
- Upgrade current/target releases and restore ID, terminal backup, and target generation are validated as caller
  intent before evidence matching. Null evidence identities cannot enter an authorizing subject.
- Add/remove intents require a positive replication position. Removal requires exact `CaughtUp` replication before
  leadership transfer or topology removal; unknown, lagging, conflicting, and future observations hold.
- Add, remove, upgrade, rollback, and restore checkpoints reject downstream proof that appears before its producing
  operation. Conflicting/future replication retains safety precedence, and contradiction after an applicable
  checkpoint remains a non-mutating observation or typed safety hold.

No enum member or numeric ID changed. Existing exact subject/trace closure remains intact.

## Evidence

Three new deterministic 1,000-case property families cover:

1. ten malformed scope dimensions, runtime-null expected scope, ten valid mismatches, and all seven entrypoints;
2. twenty topology modes spanning add/catch-up/transfer/remove/observe/verify, replication states, position validity,
   future proofs, role ordering, exact actions/codes/targets/traces, and authorizing topology subjects;
3. twenty-one upgrade/rollback/restore modes spanning every ordered checkpoint outcome used by the planners.

The families replay under `en-US` and `tr-TR` or `ar-SA`. Focused regressions additionally pin invalid expected
release/restore parameters and exact error precedence. Existing 44-field undefined-enum and 65-mode exact
scope/authorizing-output properties continue to pass.

## Verification

```text
Focused TerraBase second-audit shard: 8 passed, 0 failed, 0 skipped
ControlPlane tests: 518 passed, 0 failed, 0 skipped
Contract tests: 24 passed
Model tests: 38 passed
Protocol tests: 65 passed
Scheduler tests: 72 passed
Whole repository: 717 passed, 0 failed, 0 skipped
Solution build: 0 warnings, 0 errors
git diff --check: passed
```

## Remaining contract RFCs

- There is no explicit clean bootstrap-once/join-twice planner.
- The surface has no elastic tag/rank inventory from which reverse-order `3 -> 4 -> 3` removal can be proven.
- Six directed replication routes, placement generations, conflict reconciliation, and empty-cell recovery have no
  dedicated TerraBase decision surface.
- Restore has no explicit conflicting-operation proof.
- A contradicted post-rollback health proof can only remain an observation; there is no distinct terminal
  rollback-failure code/state.

These are implementation-readiness gaps, not claims satisfied by this pure bugfix/property shard.

## Non-claims

This is pure L0-style decision evidence only. It does not run TerraBase, storage, NATS, Linux, a VM, cloud APIs, or
deployment infrastructure and does not satisfy L0 aggregation, L3S, L4, or production acceptance.


---

# FILE: docs/work-packages/handoffs/phase1-terrabase-audit3.md

# Phase 1 TerraBase accepted upgrade output audit 3 handoff

## Proven gap and correction

Two fully successful upgrades on the same evidence scope but with different exactly matched current and target releases produced equal `Verify / Release / Completed` decisions. The equivalent post-apply health-observation branch had the same collision. Both branches discarded the `TerraBaseUpgradeIntentSubject` already constructed after exact scope and release-pair validation.

The planner now reuses that same construction-closed subject for post-apply `Observe / Application / NextStep` and terminal `Verify / Release / Completed` outputs. Upgrade, rollback, rollback observation, and rollback completion already retained it. No input contract, enum numeric, action, target, code, trace, validation, or precedence changed, and all hold decisions remain subject-free.

Tests pin exact scope/current/target instances on both corrected branches, independent current and target inequality, identical replay equality and hash stability, subject-free holds, culture-stable 1,000-case output oracles, and deterministic release-pair fingerprinting.

## Honest boundary

This closes only accepted upgrade release-pair provenance. It does not authenticate application-health evidence, execute a TerraBase upgrade, qualify a TerraBase administrative API or runtime adapter, or provide VM, cloud, deployment, L3S, L4, or production evidence. No external I/O occurs.


---

# FILE: docs/work-packages/handoffs/phase1-terrabase-core.md

# Phase 1 TerraBase topology and recovery core handoff

## Delivered

- Bounded typed identities, positive quantities, closed catalogs, evidence scopes, numeric traces, and administration decisions.
- Exact topology evidence binds cell, database, member, node, retained volume, fence, database/topology generations, authority epoch, and operation. Cross-subject replay fails closed.
- Permanent `a`, `b`, and `c` removal protection, caller-proved quorum/replication floors, serialized topology changes, restartable add/remove checkpoints, and conflicting/future replication holds.
- Defensively copied retained-volume writer inventories, split-writer denial, exact volume/fence adoption proof, detached convergence, and strictly increasing authority epochs.
- Restartable one-failure-domain upgrades gated by N/N-1 compatibility, leadership transfer, rollback material, process health, readiness, and catch-up; contradictory post-upgrade proof emits typed rollback.
- Full/incremental backup-chain validation with exact database/topology generation, contiguous parent sequence, digest/object/key references, application consistency, and verification proof.
- Side-by-side restore with source/target generation anti-rollback and distinct chain, digest, topology, query, and promotion gates.
- Closed immutable intent subjects now carry every action-specific administration parameter: topology member/position, retained-volume epoch, current/target release pair, backup request destination/key/parent, accepted segment chain, and restore ID/generations/terminal backup chain.
- Completed backup acceptance emits non-mutating `Verify`; backup mutation is authorized separately from an exact request. Incrementals require a validated exact parent chain and matching terminal backup/sequence.
- Elastic leader removal first emits an exact leadership-transfer intent. Catch-up and transfer are classified as mutations and carry the exact topology subject.
- Upgrade rollback is restartable through rollback-applied and post-rollback-health checkpoints; release-pair replay and contradictory checkpoint order fail closed.

## Boundaries

This is a pure decision core. It contains no TerraBase client, SQL/admin text, endpoint, credential value, arbitrary payload, callback, process, network/filesystem access, clock, thresholds, default releases, or mutation.

## Verification

- `dotnet build TerraScale.Orchestrator.slnx --no-restore` — passed with 0 warnings and 0 errors.
- `dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build -- --minimum-expected-tests 100` — passed (159/159).

## Contract gaps

No gap found inside the assigned pure-core boundary. Real admin/backup adapters must persist each applied checkpoint before replay and preserve the complete typed evidence subject.


---

# FILE: docs/work-packages/handoffs/phase1-terrabase-topology-provenance-audit4.md

# Phase 1 TerraBase topology provenance audit 4 handoff

## Delivered

- Accepted topology subjects distinguish add from remove and retain the exact accepted topology-evidence object.
- Existing scope, member-kind, and replication-position accessors derive from that single retained basis.
- Mutation, observation, and completion outputs across every existing add/remove branch use the same exact construction-closed subject shape.
- Holds remain non-authorizing and subject-free. No action, target, code, trace, validation, or error precedence changed.

## Verification before final rebase

- Pre-correction counterexamples: 3/3 failed with equality collisions.
- Post-correction focused audit suite: 8/8 passed.
- Post-correction ControlPlane suite: 680/680 passed.
- Warnings-as-errors test-project build: 0 warnings and 0 errors.
- Existing strict Delivery/TerraBase replay corpus remained accepted with all four entries unchanged.

Final Release solution and all-five-assembly verification are performed after the required root diff review and exact-central rebase.

## Honest boundary

This is pure L0-style topology decision evidence only. It performs no TerraBase administration, storage, process, filesystem, network, NATS, VM, cloud, credential, or deployment operation. The previously recorded bootstrap, reverse elastic ordering, multi-region replication placement, restore-conflict, rollback-failure, owner-decision, SLO, adapter, and real-system gaps remain open and are not disguised as complete.


---

# FILE: docs/work-packages/phase0-adr-readiness.md

# Phase 0 work package: ADR and toolchain readiness map

- Predecessor commit: `de9be9f`
- Contract version: proposed architecture dated 2026-07-13; recommendations are not owner decisions
- Requirement scope: Phase 0 ADR backlog items 1-24, tool/artifact pins, host/runtime prerequisites, and open owner/SLO inputs
- Allowed paths: `docs/adr/**`, `docs/audits/toolchain/**`, lane-owned notes under `docs/work-packages/handoffs/**`
- Prohibited paths: solution/build/package files, canonical registry, `ORCHESTRATOR.md`, production source, sibling repository files, installed tools/configuration
- Deliverable: ADR index and readiness matrix for all 24 backlog items with status, controlling owner question/SLO, evidence already available, missing measurement/primary source, dependency, owner lane, and exact exit evidence. Add draft ADR templates only where they preserve unresolved choices rather than selecting them.
- Toolchain audit: non-mutating local inspection of .NET, NATS, Podman, containerd, systemd, BuildKit, filesystem tools, OCI CLI, Pulumi, signing/SBOM, and ARM64 availability. Record absent tools and unqualified versions without installing or changing anything.
- Verification: all 24 ADRs accounted for exactly once; canonical lanes only; every `ready` status backed by local evidence or a primary source; no open owner choice represented as accepted.
- Destructive actions: none; no installs/upgrades, services, VMs, cloud calls, or sibling edits.
- Handoff: commit lane changes and report SHA, commands, readiness counts, blocking decisions, and suggested next work packages.


---

# FILE: docs/work-packages/phase0-arm64-runtime-readiness.md

# Phase 0 work package: ARM64 host and runtime readiness

- Scope: evidence matrix for ARM64 LTS host image/kernel/glibc, filesystem candidates, systemd/containerd/runc/BuildKit/runtime prerequisites, and L1R/L4 qualification gaps.
- Allowed paths: `docs/audits/runtime/**`, `testlab/pins/arm64-runtime-*.json`, lane-owned scripts/tests under `tools/phase0/runtime-readiness/**`, and a handoff under `docs/work-packages/handoffs/**`.
- Prohibited paths: canonical registry, ADR readiness index, central package/build files, `ORCHESTRATOR.md`, production source, sibling repositories, image downloads, VM/cloud mutation, and an accepted host-image/filesystem selection.
- Deliverable: compare viable candidates from primary sources, bind local observations precisely, identify x64-only evidence and missing ARM64/systemd-PID1/filesystem/runtime proof, and define reproducible L1R/L4 acceptance commands. Keep the ARM64 host-image selection unset.
- Verification: deterministic schema/fixture validation, adversarial negative cases, exact citations, and explicit separation of proposal, local observation, and qualified evidence.


---

# FILE: docs/work-packages/phase0-ci-descriptor-inventory.md

# Phase 0 work package: runtime/build descriptor and CI policy inventory

- Scope: exhaustive read-only inventory of product runtime/build descriptors and conflicting feature/develop/main release rules across sibling repositories.
- Allowed paths: `docs/audits/delivery/**`, lane validation/tests under `tools/phase0/delivery-inventory/**`, and a lane handoff.
- Prohibited paths: sibling edits, canonical registry, shared build files, ORCHESTRATOR.md, workflow execution, credentials, and external mutation.
- Deliverable: pin every cited sibling commit; enumerate roles/build targets/descriptors/workflows and gaps (including Authentication); distinguish observed policy from proposed reconciliation; emit a deterministic machine-readable inventory and adversarial validator.
- Verification: exact path/line/commit provenance and fail-closed completeness checks against the pinned sibling trees.



---

# FILE: docs/work-packages/phase0-draft-cloud-adrs.md

# Phase 0 work package: draft cloud ownership ADRs 4 and 20

- Predecessor commit: `ee72a8f`
- Scope: initial ADR backlog items 4 and 20 only
- Allowed paths: `docs/adr/0004-*.md`, `docs/adr/0020-*.md`, lane-owned handoff under `docs/work-packages/handoffs/**`
- Prohibited paths: ADR readiness index/validator, canonical registry, build files, `ORCHESTRATOR.md`, production/sibling source
- Deliverable: proposed, choice-preserving ADR drafts for Pulumi/provider ownership and provider-actuator crash-stop/irreversible-operation fencing. Capture context, safety invariants, alternatives, provisional direction already stated by the specification, unresolved exact IAM/tag/SDK details, consequences, rejected unsafe interpretations, and required L0/L3S/L4 evidence.
- Constraint: `Proposed`, never `Accepted`; do not make cloud calls or turn tags/IAM propagation into a fencing guarantee.
- Verification: exact citations resolve; both drafts trace ADR readiness entries, relevant REQ/INV/SEC/ERR/SM proposals, and explicitly retain owner/SLO dependencies.



---

# FILE: docs/work-packages/phase0-draft-delivery-placement-adrs.md

# Phase 0 work package: draft GitOps and placement ADRs 13 and 18

- Predecessor commit: `ee72a8f`
- Scope: initial ADR backlog items 13 and 18 only
- Allowed paths: `docs/adr/0013-*.md`, `docs/adr/0018-*.md`, lane-owned handoff under `docs/work-packages/handoffs/**`
- Prohibited paths: ADR readiness index/validator, canonical registry, build files, `ORCHESTRATOR.md`, production/sibling source
- Deliverable: proposed, choice-preserving ADR drafts for native GitOps/Flux retirement and project-placement versus host-scheduling ownership. Capture context, preserved behavior, alternatives, provisional direction already stated by the specification, cleanup sequencing, consequences, rejected compatibility/source-of-truth traps, and required L0/L3S/cross-repository evidence.
- Constraint: `Proposed`, never `Accepted`; historical Kubernetes/Flux is evidence only and no sibling cleanup/edit is authorized.
- Verification: exact citations resolve; both drafts trace ADR readiness entries, relevant REQ/INV/WRK items, and explicit compatibility/cleanup gates.


---

# FILE: docs/work-packages/phase0-nats-readiness.md

# Phase 0 work package: NATS pins, compatibility, and L0C readiness

- Scope: server/client/CLI candidate pins, N/N-1 compatibility evidence, JWT/TLS/gateway/JetStream capability matrix, and credential-free local L0C readiness.
- Allowed paths: `docs/audits/nats/**`, `testlab/pins/nats-*.json`, lane-owned scripts/tests under `testlab/nats/**`, and a handoff under `docs/work-packages/handoffs/**`.
- Prohibited paths: canonical registry, ADR readiness index, central package/build files, `ORCHESTRATOR.md`, production source, sibling repositories, cloud/VM mutation, and persistent services.
- Deliverable: evidence-backed candidate matrix without selecting the owner-controlled N/N-1 policy; fail closed on missing primary provenance, architecture support, or unexecuted behavior. A bounded ephemeral local NATS process is allowed for read-only/credential-free conformance and must be cleaned up.
- Verification: deterministic validation and adversarial fixtures; if executable checks run, cover process cleanup and label results honestly as local x64 L0C evidence rather than ARM64 or production qualification.



---

# FILE: docs/work-packages/phase0-oci-readonly-inventory.md

# Phase 0 work package: read-only OCI residual inventory

- Predecessor commit: `de9be9f`
- Contract version: proposed architecture dated 2026-07-13; no owner choice may be inferred
- Requirement scope: `REQ-O002`, `REQ-O010`, `REQ-O019`, `REQ-O020`, `REQ-O023`, `WRK-018`
- Allowed paths: `tools/phase0/oci-inventory/**`, `docs/audits/oci/**`, lane-owned notes under `docs/work-packages/handoffs/**`
- Prohibited paths: solution/build/package files, canonical registry, `ORCHESTRATOR.md`, composition root, sibling repository files, OCI configuration and credentials
- Inputs: local OCI CLI/config and read-only OCI APIs. Never print or persist tenancy/user/fingerprint/key material, auth headers, secret values, full OCIDs, public IPs, DNS names, or customer/resource names; hash stable identifiers when correlation is needed.
- Deliverable: a reusable fail-closed read-only inventory command/script plus sanitized report that establishes which APIs/permissions are available, proves or disproves OKE cluster/node-pool absence, inventories residual resource categories needed by Phase 0, and distinguishes `observed-empty`, `observed-present`, `permission-denied`, `not-queried`, and `query-failed`.
- Cost boundary: query billing/cost APIs read-only if permitted; report the exact time window and whether a seven-day residual bill can actually be established. Never estimate missing billing data as measured cost.
- Verification: syntax/static checks, deterministic sanitization tests using fixtures, and a live read-only run where credentials permit. A partial permission result is valid evidence but not a completion claim.
- Destructive actions: absolutely none. No create/update/delete/tag/cleanup, no Pulumi operation, no instance or VM start, no secret/Vault read, no network/DNS mutation, and no policy change.
- Handoff: commit lane changes and report commit SHA, exact read-only commands, permission gaps, sanitized category counts, and follow-up authority needed.



---

# FILE: docs/work-packages/phase0-owner-decision-packet.md

# Phase 0 work package: owner decision and SLO freeze packet

Status: completed as an unanswered packet, then superseded on 2026-07-16 when the owner explicitly selected 1A–10A with reliability first. The measurable targets remain evidence-derived deployment-qualification inputs.

- Predecessor commit: `f393dc4`
- Contract version: proposed architecture dated 2026-07-13; all answers remain unset unless explicitly supplied by the owner
- Requirement scope: owner questions 1–10; team/date/cost/storage/RPO/RTO inputs; security, memory/density, audit-retention, and regional-survival targets required by the Phase 0/ADR readiness map
- Allowed paths: `docs/decisions/**`, lane-owned notes under `docs/work-packages/handoffs/**`
- Prohibited paths: canonical registry, solution/build/package files, `ORCHESTRATOR.md`, production source, sibling repository files
- Deliverable: human-readable and machine-readable decision packet containing the exact ten questions/options/recommendations, unset answer fields, measurable planning/SLO fields with units, validation constraints, impacted ADRs/gates, and a compact owner response format. It must distinguish required-before-contract-freeze inputs from later implementation selections.
- Safety: never fill an answer from a recommendation, current implementation, historical estate, or agent judgment. Unknown stays explicitly unset. Do not invent cost/storage/RPO/RTO values.
- Verification: exact question/option text or stable semantic checksum against `ORCHESTRATOR.md`, questions 1–10 exactly once, required planning fields exactly once, units and validation rules present, no accepted/default answer, canonical ADR IDs, and adversarial fixtures for accidental defaulting/omission/invalid option/unit.
- Destructive actions: none; no cloud/API calls, service/VM execution, installs, or sibling edits.
- Handoff: commit lane changes and report SHA, commands, unresolved count, downstream impact coverage, and the exact compact response the owner can provide.


---

# FILE: docs/work-packages/phase0-provider-qualification-schema.md

# Phase 0 work package: provider/TCO and OCI region qualification schema

- Scope: fail-closed data contracts and current primary-source evidence map for the normalized provider TCO/storage benchmark and >=20-row OCI eligibility requirement.
- Allowed paths: `docs/audits/provider/**`, `tools/phase0/provider-qualification/**`, `testlab/pins/provider-*.json`, and a lane handoff.
- Prohibited paths: cloud login/calls, price or region qualification without complete evidence, owner cost/SLO selection, canonical registry, shared build files, and production code.
- Deliverable: schema/blank dataset that requires every cost and regional qualification field named by ORCHESTRATOR.md; current official source catalog for OCI/AWS/GCP/Azure; deterministic validator/adversarial fixtures that reject partial rows, stale evidence, currency/unit ambiguity, false >=20 claims, or a cheapest-provider claim without normalized results.
- Verification: official primary sources only; no credentialed API or resource mutation; all unknown values remain null/not-qualified.



---

# FILE: docs/work-packages/phase0-registry-coverage-audit.md

# Phase 0 work package: requirement and state-machine coverage audit

- Predecessor commit: `de9be9f`
- Contract version: proposed architecture dated 2026-07-13; owner questions and SLOs remain unresolved
- Requirement scope: all `REQ-O*`, contract invariants, named state machines, security rules, errors/holds, and acceptance layers in `ORCHESTRATOR.md`
- Allowed paths: `docs/audits/registry/**`, lane-owned notes under `docs/work-packages/handoffs/**`
- Prohibited paths: `requirements/registry.yaml`, solution/build/package files, global schemas/generators, composition root, `ORCHESTRATOR.md`, production source, sibling repository files
- Deliverable: independent machine-readable coverage audit comparing the current draft registry with every explicit requirement, invariant, named transition graph, security rule, hold/error class, and acceptance gate in the specification. Propose stable IDs and owners for missing items without editing the canonical registry.
- Evidence standard: every finding cites exact `ORCHESTRATOR.md` lines; distinguish exact requirements from inferred implementation suggestions. Do not declare semantic coverage solely because an ID exists.
- Verification: deterministic parser/checker or checked fixture, unique proposed IDs, canonical owner lanes, acceptance-layer validation, and negative fixtures proving omissions are detected.
- Destructive actions: none; do not start VMs, contact cloud services, or edit sibling repositories.
- Handoff: commit lane changes and report SHA, commands, complete/incomplete counts, and the steward changes recommended for the canonical registry.



---

# FILE: docs/work-packages/phase0-registry-v2-review.md

# Phase 0 work package: independent semantic registry v2 review

- Scope: independently review integration commit `7deaf74` and the 43 still-missing proposed state-machine/error/security/gate families.
- Allowed paths: `docs/audits/registry-v2-review/**` and a lane handoff.
- Prohibited paths: canonical registry, registry checker/tests, ORCHESTRATOR.md, shared build files, and production code.
- Deliverable: adversarial review of source-digest semantics, owner/evidence modeling, duplicate SEC/INV meaning, co-review gaps, audit migration correctness, and proposed-ID naming/granularity. Provide exact actionable findings and a steward patch plan; do not silently freeze proposed IDs.
- Verification: reproduce current validators, inspect exact source ranges, and label every conclusion as confirmed issue, recommendation, or blocked owner decision.


---

# FILE: docs/work-packages/phase0-source-contract-audit.md

# Phase 0 work package: product contract source audit

- Predecessor commit: `9aaa07e`
- Contract version: proposed architecture dated 2026-07-13; all owner questions remain configurable
- Requirement scope: `REQ-O005`, `REQ-O012`, `REQ-O016`, `REQ-O017`, `REQ-O023`
- Allowed paths: `docs/audits/**`, lane-owned notes under `docs/work-packages/handoffs/**`
- Prohibited paths: solution/build files, canonical registry, `ORCHESTRATOR.md`, composition root, sibling repository files
- Inputs: read-only primary-source anchors listed in `ORCHESTRATOR.md` and each repository's `AGENTS.md`
- Deliverable: evidence-backed runtime/build/health/release contract inventory, highlighting contradictions and the missing Authentication target without resolving owner-policy choices silently
- Verification: every claim has repository-relative file/line evidence; missing files are recorded as gaps
- Destructive actions: none; no edits, cleanup, Git operations, or cloud operations in sibling repositories
- Handoff: commit lane changes and report commit SHA, review commands, contradictions, and suggested owner decisions


---

# FILE: docs/work-packages/phase0-supply-chain-pins.md

# Phase 0 work package: supply-chain and verification tool pins

- Scope: evidence-backed candidate pins and gaps for build, test, signing, attestation, SBOM, scanning, and OCI image tooling.
- Allowed paths: `docs/audits/supply-chain/**`, `testlab/pins/supply-chain-*.json`, lane-owned validation scripts/tests under `tools/phase0/supply-chain/**`, and a handoff under `docs/work-packages/handoffs/**`.
- Prohibited paths: central build/package files, canonical registry, ADR readiness index, `ORCHESTRATOR.md`, production code, sibling repositories, credentials, and external mutation.
- Deliverable: distinguish locally observed tools from reviewed candidate pins; use primary-source provenance for every proposed version; record architecture/platform support, integrity/provenance status, mirror/signing requirements, license, and the exact evidence still needed before selection. Artifact/evidence signing remains unset.
- Verification: deterministic schema/fixture validation, negative cases, exact citations, and no claim that tool presence or a proposed version qualifies production.



---

# FILE: docs/work-packages/phase0-workaround-ledger.md

# Phase 0 work package: historical workaround ledger

- Predecessor commit: `9aaa07e`
- Contract version: proposed architecture dated 2026-07-13; owner questions remain configurable
- Requirement scope: `REQ-O014`, `REQ-O016`, `REQ-O018`, `REQ-O023`, `WRK-001` through `WRK-018`
- Allowed paths: `docs/retirement/**`, lane-owned notes under `docs/work-packages/handoffs/**`
- Prohibited paths: solution/build files, `requirements/registry.yaml`, `ORCHESTRATOR.md`, composition root, sibling repository files
- Inputs: read-only sibling repositories and their local `AGENTS.md` files
- Deliverable: exhaustive evidence-backed YAML ledger with stable IDs, source locations, preserved behavior, native replacement, owner lane, removal phase, regression layer, recovery boundary, and cleanup proof
- Verification: parse YAML; validate every entry has all mandatory fields; report unreadable/missing evidence without inventing it
- Destructive actions: none; no cloud mutations, cleanup, commits, pushes, or edits in sibling repositories
- Handoff: commit lane changes and report commit SHA, validation commands, gaps, and proposed follow-up packages



---

# FILE: docs/work-packages/phase01-provider-handoff-determinism-audit.md

# Phase 0/1 provider handoff determinism audit

## Goal

Close the proven pure-output gap where equivalent verified greenfield Pulumi handoff inventories authorized regional self-management but retained caller-dependent enumeration order in the accepted adapter intent.

## Requirement mapping

- `REQ-O010`: exact ownership/handoff receipt and regional ownership boundary.
- `INV-014`: concrete regional resources transfer to the regional orchestrator only after the signed handoff.
- Hard pre-deployment L0 gate: deterministic replay/permutation and greenfield Pulumi handoff behavior must be covered before any adapter receives mutation authority.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Providers/ProviderModels.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/CompletionGapAudit2CounterexampleTests.cs`
- `docs/work-packages/phase01-provider-handoff-determinism-audit.md`
- `docs/work-packages/handoffs/phase01-provider-handoff-determinism-audit.md`

## Contract

`FreshBootstrapInventory` defensively copies and canonically orders each Expected, Pulumi, and Regional sequence by provider resource identity using ordinal comparison, then resource kind, then generation. The same exact inventory-item objects are retained. Bounds, input exceptions, duplicate detection, inventory fingerprints, proof validation, decision trace and precedence, public signatures, and accepted or held outcomes do not change.

## Boundary

This is a pure in-memory snapshot/output correction. It does not sign a handoff, run Pulumi, adopt or mutate a resource, call a provider, start NATS, create a VM, choose an owner option or provider policy, or provide L0/L3S/L4 acceptance evidence.


---

# FILE: docs/work-packages/phase1-accepted-output-construction-closure.md

# Phase 1 accepted-output construction-closure audit

## Goal

Prevent callers outside the ControlPlane assembly from minting decisions, permits, mutation intents, or intent subjects without passing through the owning pure decision engine.

## Inventory and fixes

- Authority: closed the three `AuthorityIntent` constructors. `AuthorityDecision` and `MutationAuthorityPermit` were already closed.
- Operations: closed both `OperationIntent` constructors and the `OperationDecision` constructor.
- Reconciliation: closed the complete `ReconciliationOutput` hierarchy, including observe, reconcile, hold, and converged outputs, plus the containing accepted step and plan.
- Networking: closed both concrete `NetworkIntentSubject` constructors as defense-in-depth. A subject alone cannot mint a `NetworkDecision`: the decision constructor is private and `Emit` is internal. Closing subjects nevertheless keeps accepted intent payloads assembly-owned and prevents a future public composition path from turning caller-forged subjects into accepted decisions.
- Compute, Delivery, Provider, Runtime, Observability, Security, Budget, Storage, TerraBase, Evidence, and snapshot decisions/intents/permits were already construction-closed.
- Messaging decisions and intents are also construction-closed by the dedicated messaging property shard; the architecture test applies the same checks without an exception.

The architecture test inventories exported `*Decision`, `*Permit`, and `*Intent` types plus the reconciliation and decision-subject hierarchies. It rejects public constructors, setters/init setters, and positional deconstruction on accepted outputs. It also inventories every public static or instance method on every exported ControlPlane type whose return type is protected, and compares exact method kind, declaring type, parameter types, and return type against an explicit reviewed allowlist of pure engine/planner entrypoints. The only non-engine capture entrypoint is `ProviderAuthorizationDecision.CaptureDurableAuthorization`, which derives an exact durable token only from an accepted mutation decision.

Compiler-generated record clone methods are intentionally ignored. Cloning requires possession of an already accepted instance, while the no-public-setter/init-setter guard prevents a `with` expression from changing authority-bearing state; an unchanged clone therefore cannot mint new authority.

## Reconciliation input capture boundary

`ReconciliationTechnicalInputLimits.MaximumCapturedItems` publicly documents a 16,384-item technical snapshot ceiling. It is an acquisition-safety limit, not the `MaximumResources` or `MaximumDependenciesPerResource` business policy. A shared bounded helper now snapshots `DesiredResource.Dependencies`, `ReconciliationPolicy.AllowedKinds`, `ReconciliationPolicy.GenerationFloors`, and both `ReconciliationRequest.Desired` and `.Observed`. It checks the bound after `MoveNext` and before `Current`, copies before exposing the collection, converts ordinary iterator failures (including disposal) into secret-safe `ArgumentException` values without inner exceptions, and permits `OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException` to propagate.

## Compatibility impact

This is an intentional source and binary compatibility break for the Authority, Operations, Reconciliation (including step/plan), and Networking output constructors. Those outputs remain public and read-only for inspection and pattern/property access, but external `new` expressions no longer compile and existing binaries that call the old public constructors must be rebuilt. Rewriting positional records as nominal records also removes their generated public `Deconstruct` methods; external positional deconstruction must change to property access. Equality and public property names/types remain available. No input/evidence DTO, business rule, decision ordering, adapter, or system boundary changes.


---

# FILE: docs/work-packages/phase1-adversarial-model-core.md

# Phase 1 deterministic adversarial model core

## Predecessor

- Contract steward commit: `3e2f747` plus the reviewed compute, networking, and observability pure-core commits.
- Production policies, timeouts, retry budgets, topology defaults, and qualification thresholds remain explicit inputs.

## Goal

Implement the deterministic L0 model simulator, reusable failure schedules, and replay corpus required by `ORCHESTRATOR.md:1114-1180` and the Phase 1 exit gate. The lane exercises existing pure cores and never executes an adapter or performs deployment.

## Allowed paths

- `tests/TerraScale.Orchestrator.ModelTests/Simulation/**`
- `tests/TerraScale.Orchestrator.ModelTests/RegressionCorpus/**`
- `tests/TerraScale.Orchestrator.ModelTests/TerraScale.Orchestrator.ModelTests.csproj`
- `docs/work-packages/handoffs/phase1-adversarial-model-core.md`

## Required behavior

- A deterministic virtual clock, deterministic identity/epoch source, immutable event queue, and closed loss/duplicate/reorder/delay/crash/restart/leader-change/partition/heal schedule catalog. No wall clock, random global, thread timing, callback, socket, file mutation, NATS client, provider SDK, or production adapter.
- A bounded three-node state-space runner with canonical state digests, stable schedule ordering, visited-state deduplication, explicit step/schedule bounds, and deterministic shrinking/replay of a failing seed. Overflow, exhausted bounds, invalid events, and non-convergence are typed failures rather than exceptions or free text.
- Reusable fake delivery/provider observations that preserve exact operation, generation, epoch, idempotency key, resource identity, and observation sequence. They may model outcome-unknown and late completion but cannot authorize an action or forge accepted domain output types.
- Cross-core adversarial scenarios prove no two accepted writers, no stale successful mutation, no unauthorized action, no unsafe deletion/termination, no quorum-floor violation, no second create after outcome-unknown, and identical digest after snapshot/replay under explored schedules.
- Every saved failure case is a canonical, culture-independent, content-addressed checked-in corpus entry with a versioned schema and expected invariant/error. Corpus loading is deterministic and rejects unknown fields, duplicate IDs, malformed digests, unsupported versions, and path traversal.
- Tests cover permutation/culture/replay, canonical digest stability, queue ordering, bound enforcement, schedule shrinking, all failure-event kinds, stale leader and late provider completion, duplicate delivery, partition/heal, crash/restart, corpus tamper/unknown-field rejection, and reflection/architecture proof that the simulator cannot acquire mutation capabilities.
- The feature-branch suite runs a deterministic bounded shard suitable for ordinary tests. The implementation exposes explicit larger bounds for later evidence lanes but does not falsely claim the required 10,000/1,000,000 schedule evidence unless those executions actually occur.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ModelTests/TerraScale.Orchestrator.ModelTests.csproj`


---

# FILE: docs/work-packages/phase1-adversarial-model-provenance-audit3.md

# Phase 1 adversarial model accepted-event provenance audit

## Scope and base

- Base: central `chore/phase0-bootstrap` at `710689fb2464504981863ff8d3868239bdf596a9` after the required final rebase.
- Allowed paths: deterministic model simulation contracts/reducer, model tests, and this work package.
- Pure deterministic L0 model work only; no adapter, NATS server, filesystem, process, network, systemd, container, VM, cloud/provider, credential, or deployment action.

## Executable defect

Two accepted authorization events with the same event ID and authorization subject but different replay coordinates produced equal accepted evidence, equal canonical state, and equal state digest:

```text
E1: Sequence=1, ObservationSequence=1
E2: Sequence=9, ObservationSequence=99
```

The reducer validated all eleven event fields before acceptance, but `AcceptedActionEvidence` retained only selected operation and authority facts. Once the event left the queue, its sequence, due tick, kind, and observation sequence were absent from accepted evidence; the delivered-ID set preserved only its ID. A saved final digest therefore could not identify the complete event that the model had accepted.

## Correction

`AcceptedActionEvidence` now retains the exact immutable `ModelEvent` passed to the reducer's single evidence helper. Every event-derived compatibility projection—including action kind, operation, node, generation, idempotency key, resource, and event epoch—is derived from that retained event rather than independently supplied. There is no compatibility constructor or factory that can synthesize accepted evidence without a complete event.

The canonical state projection uses the existing complete, length-delimited `ModelState.EventCanonical` helper for retained accepted events. It therefore binds sequence, due tick, event ID, model-event kind, node, operation, generation, epoch, idempotency key, resource, and observation sequence without maintaining a second manual event serializer. The same reducer helper serves every currently reachable accepted kind: authorization, create, and mutation. The termination branch also calls that helper if a future valid model state makes its existing acceptance path reachable.

Tests separately prove exact event reference retention and record-value replay semantics. Every individual event-field mutation changes accepted evidence, canonical state, and digest; equivalent reconstructed events remain value-equal and digest-equal across cultures. Existing authority-evidence mutants now replace the retained event fields, preserving their independent invariant checks.

`ModelState` validates the retained event before accessing any derived projection. A missing event and an otherwise valid event kind that maps to no accepted action both fail deterministically at the state boundary with `ArgumentException`; neither can be accidentally accepted or surface a null dereference.

## Compatibility and behavior

No event, failure, invariant, provider-outcome, accepted-action, or failure-code enumeration or numeric value changed. No reducer gate, scheduling rule, result/error precedence, queue ordering, exploration bound, invariant rule, corpus schema/version/content address, or saved expectation changed. This correction changes only accepted evidence and the state digest that intentionally commits to it.

## Evidence boundary

The retained value proves which caller-supplied immutable model event the in-process reducer recorded as accepted. It does not prove that an observation sequence was fresh or authentic, that a provider/delivery action occurred, that an external verifier or policy was correct, or that the current bounded model covers every production interleaving. Event identity, ordering coordinates, and acceptance-time authority facts remain modeled inputs, not external attestations.

This work does not claim the Phase 1 million-schedule deployment-bound budget, mutation/fuzz thresholds, complete requirement trace, real NATS L0C, snapshot/persistence correctness, adapter correctness, VM/cloud qualification, or deployment readiness.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.ModelTests/TerraScale.Orchestrator.ModelTests.csproj -c Release --no-build --no-restore -- --no-progress
git diff --check
```

Recorded after the final rebase: Release solution build passed with zero warnings and errors; focused audit tests passed 6/6; Model tests passed 44/44; all five executables passed 821/821 (ControlPlane 601, Contract 29, Model 44, Protocol 70, Scheduler 77).


---

# FILE: docs/work-packages/phase1-authority-core.md

# Phase 1 regional authority core

## Goal

Implement the pure regional-authority lease/epoch decision state machine described at `ORCHESTRATOR.md:454` and `545-550`. It models KV CAS intents/observations but performs no NATS or clock I/O.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Authority/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Authority*.cs`
- `docs/work-packages/handoffs/phase1-authority-core.md`

## Required behavior

- Immutable authority/candidate/lease identities, positive KV revision and epoch, explicit supplied server time and monotonic lease duration.
- Closed states for follower, acquisition pending, leader, renewal pending, release pending, read-only/held, and fenced; closed typed errors and CAS/read/delete intents.
- Acquisition advances epoch and becomes leader only after an exact matching successful CAS observation. Stale/mismatched/duplicate/out-of-order results never grant authority.
- Renewals preserve epoch and require exact lease/revision ownership. Failure, expiry, uncertainty, or a higher epoch immediately removes mutation authority; a fenced state cannot self-unfence.
- Release is compare-and-delete and never claims success without matching observation. Partition/clock anomaly inputs hold destructive authority.
- Deterministic reducer/replay digest, crash at every intent/result boundary, three-candidate interleaving exploration, stale old-leader commands, overflow, equality-at-expiry, and permutation/duplicate observation tests.
- No wall clock, NATS, filesystem, network, environment, randomness, or policy defaults.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`


---

# FILE: docs/work-packages/phase1-authority-permit-provenance-audit4.md

# Phase 1 authority mutation-permit provenance audit 4

## Scope and base

- Exact starting base: central commit `6fb86b534de7c06990f9017fb7645225a552f358`.
- Production scope: Authority contracts, pure engine, and canonical digest encoding.
- Evidence scope: focused regressions, authority/operations property corpus, accepted-output construction closure, and this work package.
- No NATS, KV, clock service, provider, SDK, network, filesystem, process, VM, deployment, or sibling-repository effects.

## Executable defects

`MutationAuthorityPermit` previously projected lease and evaluation coordinates but erased the accepted command that minted it. Two accepted `EvaluateMutationAuthority` commands with different request identities and otherwise identical evidence produced record-equal permits and equal decision digests.

Binding only `RequestId` was insufficient. A successful `ObserveAuthorityCas`, a successful leader-resume `ObserveAuthorityRead`, and an `EvaluateMutationAuthority` could use the same request identity, observation, and health while representing different accepted authorization acts. The flattened permits again compared equal. Both collisions were captured as executable failing tests before production changed.

## Correction

The construction-closed permit now retains the exact immutable `AuthorityCommand` object accepted by the engine. Its internal constructor admits only the three permit-producing shapes:

- successful `ObserveAuthorityCas` with non-null observation and lease;
- successful `ObserveAuthorityRead` with non-null observation and lease;
- `EvaluateMutationAuthority` with non-null lease evidence.

All existing permit projections and the derived `RequestId` come from that one command. The private engine helper accepts only the command, so no caller can pair one command identity with another observation or health value. Rejected, held, uncertain, failed, null-observation, null-lease, and unrelated command paths do not mint a permit.

The `mutation-permit-v1` digest binds a distinct command-type tag and every command field using the existing length- and type-framed canonical encoder. This includes all identities, request identity, CAS outcome, nullable observation shape, revision, epoch, observation identity, nested lease fields, server and monotonic time, and both certainty flags. Exact replay is culture-independent; independently changing any admitted command field or command type changes the digest.

## Construction and replay closure

Public accepted-output factories remain exactly `AuthorityEngine.Decide`/`Replay` and `OperationEngine.Decide`/`Replay`. Authority and operation decisions, mutation permits, and concrete intents retain non-public construction and public get-only state. Public positional commands and journal events remain input/replay DTOs and cannot independently mint an accepted output; engine replay still validates journal digest, sequence, identity, and transition semantics.

The permit has no public constructor, public setter, positional deconstructor, or independent static factory. The compiler-generated record `<Clone>$` is the only public copy route. It copies an already accepted immutable permit, retains the exact authorizing-command reference, and cannot alter a get-only coordinate.

The evidence suite covers exact-reference retention for all three mint routes, null-permit iff proofs for rejected/held shapes, independent field/type/null-shape sensitivity, 1,000 deterministic cross-culture cases, and a strict content-addressed authority replay-corpus entry for request-provenance separation.

## Evidence boundary

The retained command proves which pure-engine input authorized this in-memory accepted output. It does not authenticate the command, prove NATS KV linearization, establish adapter correlation, or make the permit a transferable provider authorization. Those properties require later adapter/integration evidence.

No enum values, numeric assignments, state transitions, or error-precedence rules changed.

## Verification after final central rebase

```text
dotnet build TerraScale.Orchestrator.slnx --no-restore
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build -- --no-progress
git diff --check
```

Recorded after rebasing onto central `1f73564`: the Release solution build passed with zero warnings and errors. All five test executables passed 870/870: ControlPlane 643, Contract 29, Model 44, Protocol 70, and Scheduler 84. This includes the two saved counterexamples, construction closure, deterministic properties, and strict corpus replay.


---

# FILE: docs/work-packages/phase1-authority-policy-completeness.md

# Phase 1 authority policy completeness shard

## Base and scope

- Base: central `chore/phase0-bootstrap` after reviewed provider and delivery integration.
- Production scope: `src/TerraScale.Orchestrator.ControlPlane/Authority/AuthorityEngine.cs`.
- Evidence scope: `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/AuthorityPolicyCompletenessPropertyTests.cs` and the matching handoff.

## Goal

Prove that replay cannot regress below already persisted epoch or KV-revision
truth and that a completed request identity cannot start an authority action whose
result handling would necessarily treat it as an old duplicate. Preserve the
existing status, identity, structural-validation, lease, recovery, renewal,
release, and read precedence.

The deterministic shard independently covers epoch-only, revision-only, and
combined replay regressions; exact high-water equality; independent monotonic
advancement; structural-error precedence; all four initiating commands; exact
fresh intents/events; the closed authority vocabulary; and culture-stable
decisions.

## Evidence boundary

This is bounded pure-decision evidence. It performs no NATS, clock, filesystem,
network, process, cloud/provider, VM, deployment, or sibling-repository action.
It does not claim full-domain 100,000-case evidence, mutation coverage, L0/L0C,
adapter conformance, deployment qualification, or production authority.


---

# FILE: docs/work-packages/phase1-authority-read-provenance-audit3.md

# Phase 1 Authority read-intent provenance audit

## Scope and base

- Base: central `chore/phase0-bootstrap` at `e009eec` after final rebase.
- Allowed production paths: Authority contracts, digest encoding, and pure engine; focused/property tests and this work package.
- No NATS, clock, filesystem, process, network, provider, VM, deployment, or sibling-repository operation.

## Executable defect

An accepted leader read that can later restore a mutation permit and an ordinary genesis follower read emitted equal adapter-facing values:

```text
ReadAuthorityIntent { AuthorityId = regional-authority, RequestId = shared-read }
```

The same output also collided across candidates. Although the complete decisions and journal events differed, the persisted execution intent erased the candidate, resume posture, accepted epoch/revision high-water, and confirmed observation. The intent alone therefore could not prove which candidate or known authority truth authorized the read.

## Correction

`ReadAuthorityIntent` is now assembled internally from the already validated `RequestAuthorityRead`, replayed `AuthorityState`, and computed resume status. It retains:

- exact candidate identity;
- exact follower/leader/read-only-held resume posture;
- accepted highest epoch and KV revision;
- the exact nullable confirmed observation.

The authority decision digest includes all five coordinates. Exact immutable replay remains equal; changing any one coordinate changes both intent equality and the decision digest. Follower, leader, ordinary held, and held-leader recovery read sites are covered. Read requests still emit no mutation permit, and existing response handling still replays state and performs its exact safety checks before a leader read can restore a permit.

No public constructor, setter, positional deconstructor, or independent public factory was added. Because `ReadAuthorityIntent` remains a nominal C# record in the existing `AuthorityIntent` hierarchy, the compiler-generated `<Clone>$` can copy an already accepted immutable intent without changing its get-only properties. This audit tests and records that precise copy surface rather than claiming it is clone-free; removing it would require broader hierarchy churn unrelated to the provenance defect.

## Evidence boundary

These fields are accepted-read execution and provenance coordinates. They are not adapter-enforced conditional-read parameters, proof of response authenticity, a transferable mutation authorization, or evidence of NATS KV linearization. The adapter and journal coordinator must still correlate and authenticate the result, and real NATS behavior remains L0C/integration evidence.

All existing enums, numeric values, errors, transitions, and validation precedence are unchanged.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj -c Release --no-build --no-restore -- --no-progress
git diff --check
```

Recorded after the final rebase: Release solution build passed with zero warnings and errors; focused Authority passed 28/28; all five executables passed 782/782 (ControlPlane 573, Contract 24, Model 38, Protocol 70, Scheduler 77).


---

# FILE: docs/work-packages/phase1-budget-authorization-basis-audit4.md

# Phase 1 budget authorization basis audit 4

## Goal

Close the proven budget-to-compute accepted-output collision where distinct selected policy/evidence provenance produced the same typed automatic authorization output.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Budgets/BudgetDecision.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/BudgetFourthAuditRegressionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/BudgetDecisionSubjectCompletenessPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/BudgetProviderPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/BudgetProviderReplayCorpus.v1.json`
- `docs/work-packages/phase1-budget-authorization-basis-audit4.md`
- `docs/work-packages/handoffs/phase1-budget-authorization-basis-audit4.md`

## Contract

Every `BudgetDecision` produced after successful evidence selection and trace construction retains a construction-closed `BudgetDecisionBasis`. The basis holds exact references to the validated `BudgetPolicy` and selected cell-usage, global-usage, node-class-usage, and price-evidence observations. This phase boundary applies to automatic, approval-required, forbidden, and traced emergency-held decisions; it does not depend on authorization alone.

Early decisions that do not construct a trace or establish selected evidence retain `Basis = null`, in lockstep with their existing null trace and subject. The existing proposal-bound `BudgetDecisionSubject`, approval scope, policy arithmetic, decision kinds/reasons, precedence, trace fields, and enum numerics do not change.

`BudgetDecisionBasis` has no public constructor, setter, deconstructor, clone path, or alternate public factory. Its string representation is opaque and redacted.

## Validation matrix

- Distinct selected usage evidence IDs with otherwise identical accepted input: basis fingerprints differ.
- Automatic, approval-required, forbidden, provider-limit, emergency-held, and emergency-safety decisions: exact policy and four evidence references retained.
- Invalid policy/proposal/scope/class, missing/unknown/stale/duplicate/conflicting/over-limit evidence, and arithmetic failure before trace creation: basis remains absent.
- Independent evidence identity, value, age, status, price, and policy changes: accepted basis follows the exact selected objects or fails closed under existing rules.
- Reordered usage evidence, repeated evaluation, and `en-US`, `tr-TR`, `ar-SA`, and `ja-JP`: deterministic basis over 1,000 cases.
- Strict whole-file SHA-256 corpus: original and substituted evidence-identity failure seeds replay exactly.
- Reflection: construction closure, getter-only surface, no record-clone/deconstruct/factory path, and redacted output.

## Boundary

This is a pure in-memory authorization-output provenance correction. It does not authenticate evidence producers, prove billing exports or price accuracy, add a policy generation, choose a provider, establish a cost target, or grant provider mutation authority. It performs no provider SDK, billing, network, filesystem, process, VM, cloud, deployment, or other external side effect.


---

# FILE: docs/work-packages/phase1-budget-core.md

# Phase 1 budget and cost decision core

## Predecessor

- Contract steward commit: `85db082`
- Draft Phase 1 contracts; no owner cost target or provider price is selected.

## Goal

Implement the pure budget authorization and anomaly decision core from `ORCHESTRATOR.md:746-756`. It classifies typed resource/spend changes without estimating prices or performing provider actions.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Budgets/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Budget*.cs`
- `docs/work-packages/handoffs/phase1-budget-core.md`

## Required behavior

- Immutable bounded cell, node-class, cost-center, resource, price-evidence, and approval identities; checked non-negative fixed-point quantities only—no floating point.
- Explicit caller policy for per-node-class min/max/warm counts; per-cell and global CPU, memory, storage, IOPS/throughput, public-IP, LB-backend, hourly and daily spend ceilings; automatic, approval-required, and forbidden bands; emergency posture; evidence freshness; and safety purpose.
- Authorize or hold/reject a proposed delta against complete current cell/global usage. Unknown, stale, incomplete, duplicated, conflicting, negative, overflowed, or wrong-scope observations fail closed.
- Emergency budget may reject non-safety growth but may not authorize termination and may not block an explicitly classified data-loss-prevention storage expansion inside hard provider/account limits.
- Emit closed `Automatic`, `ApprovalRequired`, `Forbidden`, or `Held` decisions and a complete stable numeric trace. Approval-required output contains typed approval scope only; no callback, command, arbitrary text, price lookup, or provider behavior.
- Detect orphan/unattached resource and desired-vs-owned-vs-billing discrepancies as typed anomaly findings without deciding deletion.
- Defensive copies, culture/input permutation determinism, exact-boundary and every-dimension tests, maximum/overflow tests, missing/duplicate/conflicting evidence tests, emergency safety tests, and secret-safe output.
- No cost/SLO defaults, wall clock, provider SDK, billing API, filesystem, NATS, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-budget-policy-completeness.md

# Phase 1 budget policy completeness

## Scope

- Base: integration commit `621c37d` or its final reviewed successor.
- Production: `src/TerraScale.Orchestrator.ControlPlane/Budgets/BudgetEvidence.cs` only.
- Tests: `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/BudgetPolicyCompletenessPropertyTests.cs`.
- Handoff: `docs/work-packages/handoffs/phase1-budget-policy-completeness.md`.

## Goal

Close the budget proposal's open enum boundary and add deterministic completeness evidence for the pure budget/cost policy. A proposal may use only the three explicitly declared nonzero safety purposes. `Unspecified` and every undefined underlying enum value fail before evidence collection and cannot emit an authorizing trace or approval scope.

The property shard pins the exact purpose inventory, all nine budget dimensions, provider/account-limit then budget-ceiling then forbidden-band then approval-band precedence, exact trace and approval-scope fields, and undefined usage-status/scope/resource-attachment handling.

## Boundaries

This shard selects no owner cost target, price, currency, unit, SLO, provider, or emergency default. Price evidence remains an explicit caller-supplied current/unknown/stale identity; the shard performs no price lookup or estimation. It uses no provider/cloud API, billing export, NATS, filesystem, network, process, VM, systemd, containerd, rootless container, deployment, or sibling-repository operation.

The result is L0 pure-policy evidence only. It does not claim mutation completeness, NATS L0C, real billing reconciliation, a measured cost gate, deployment qualification, or deployment authority.


---

# FILE: docs/work-packages/phase1-budget-provider-property-shard.md

# Phase 1 budget and provider ownership property/replay shard

## Goal

Exercise the existing budget/cost and provider ownership/handoff pure cores with deterministic generated and replayed inputs. This shard strengthens caller-input capture where hostile enumeration could otherwise escape the existing fail-closed boundary.

## Scope

- At least 1,000 explicit cases per arithmetic, evidence-ordering/status, generation/ownership/fencing, permutation/culture, and handoff exactness property.
- Independent `BigInteger` budget-vector projection checks and independent expected provider authority outcomes.
- Stale, unknown, duplicate, conflicting, reordered, wrong-generation, wrong-owner, and wrong-epoch evidence.
- Construction-closed authorizing decisions and provider intents.
- Durable provider-resume authorization derived only from accepted-like evidence for an exact mutation; planned, held, rejected, and observe-only decisions cannot mint it.
- Strict, bounded, whole-file SHA-256-pinned, input-sensitive embedded replay corpus.
- Named technical snapshot bounds with maximum-plus-one handling before `Current`, defensive copies, ordinary iterator failure closure, and fatal runtime exception propagation.

## Boundary and non-claims

The technical snapshot limits are denial-of-service/input-safety bounds. They are separate from monetary bands, capacity ceilings, approval thresholds, provider quotas, or inventory policy. This shard performs no cloud/provider API, network, filesystem, process, live-price, or package-selection operation. It does not claim a cheapest provider, current cost, NATS L0/L0C evidence, deployment qualification, full-domain property coverage, mutation score, or deployment authority.


---

# FILE: docs/work-packages/phase1-ci-decision-properties.md

# Phase 1 CI trust-zone decision property shard

## Goal

Audit and complete the existing pure CI job scheduling decision in `DeliveryEngine.DecideJob`, with independent trust-policy, runner-selection, retry, and failure-precedence oracles. Prevent a job from being dispatched to a runner whose full capability set exceeds its declared trust zone.

## Allowed paths

- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/CiDecision*`
- `src/TerraScale.Orchestrator.ControlPlane/Delivery/DeliveryEngine.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`
- `docs/work-packages/phase1-ci-decision-properties.md`
- `docs/work-packages/handoffs/phase1-ci-decision-properties.md`

## Required evidence

- At least 1,000 explicit cases per property family.
- Closed job-kind/trust-zone/capability matrix independent of the production switch.
- Deterministic fresh compatible runner selection across permutations and cultures.
- Exact retry/attempt precedence and preservation of job, tree, generation, attempt, and idempotency identities.
- Duplicate, stale, unavailable, wrong-zone, and capability-missing runner evidence precedence.
- Strict byte-bounded whole-file-pinned replay with exact input-derived fingerprints.
- Construction-closed accepted decisions and intents.
- Exact trust-zone confinement for every capability carried by selected runner evidence.

## Exclusions

No runner process, Forgejo, Git, network, filesystem runtime, signing, secrets, package/tool selection, deployment, NATS, cloud/provider, or sibling repository changes. This shard is pure unit/property/replay evidence and cannot claim L0 or deployment qualification.


---

# FILE: docs/work-packages/phase1-ci-dispatch-provenance-audit3.md

# Phase 1 CI dispatch provenance audit

## Scope and base

- Base: central `chore/phase0-bootstrap` at `6ea6200` after the required final rebase.
- Allowed paths: CI delivery contracts/engine, CI decision tests/corpus, and this work package.
- Pure deterministic decision work only; no runner, Forgejo, Git, registry, NATS, filesystem, network, process, signing service, provider, VM, or deployment action.

## Executable defect

A valid ProductValidation request in `UntrustedProduct` using runner sequence 20/capability `Compile` and a distinct valid TrustedBuild request in `TrustedBuild` using the same runner identity at sequence 80 with `Compile/Test/Sign` produced the same complete adapter-facing dispatch fields:

```text
pipeline|job|shared-runner|tree|7|1|key
```

The accepted output retained the execution IDs but erased the exact job trust policy, sequence window/retry context, selected runner zone/sequence/availability/capability inventory, and identity-length policy that passed validation. A reused or re-enrolled runner ID could therefore be relabeled without detection from the persisted dispatch intent.

## Correction

`DispatchJobIntent` is now assembled internally only from the already validated `JobRequest`, selected `RunnerEvidence`, and explicit maximum identity length. It retains those exact immutable instances and policy value. Existing compatibility getters derive from them rather than duplicating independently mixable constructor parameters.

`JobRequest` and `RunnerEvidence` already defensively snapshot their caller-supplied zone and capability sequences. Mutation of the source arrays after construction cannot change the retained dispatch. The canonical test fingerprint is length/count-delimited and covers every request field/list in order, every selected-runner field/list in order, and the maximum identity length. The pinned replay corpus was regenerated against this complete fingerprint.

The request/evidence DTOs are nominal classes with reference equality. Therefore the supported replay assertion is canonical full-fingerprint equality for semantically identical immutable values, not structural object equality. The intent itself remains construction-closed with no public constructor, setter, deconstructor, or factory.

## Compatibility and precedence

No input DTO, enumeration, numeric value, error, trace, policy, or selection behavior changed. Existing compatibility getters remain available. Precedence remains runner-input acquisition bound, job validation, retry denial, exhausted attempts, job trust policy, runner validation, duplicate evidence, freshness/availability, zone, runner-zone confinement, capability match, ordinal selection, then dispatch.

## Evidence boundary

This accepted output binds the execution subject and caller-supplied selected runner evidence used by the pure decision. The evidence is validated input, not an attestation or proof of runner authenticity, enrollment, capability possession, network/process isolation, or real trust-zone enforcement. Rejected and alternate candidates are intentionally not retained, so this is not complete ordinal-selection provenance. Real runner/Forgejo/NATS behavior remains later conformance and integration evidence.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj -c Release --no-build --no-restore -- --no-progress
git diff --check
```

Recorded after the final rebase: Release solution build passed with zero warnings and errors; focused CI passed 14/14; all five executables passed 793/793 (ControlPlane 584, Contract 24, Model 38, Protocol 70, Scheduler 77).


---

# FILE: docs/work-packages/phase1-ci-evidence-report-audit4.md

# Phase 1 CI evidence report accepted-output audit 4

## Goal

Close the proven accepted-output collision where distinct, fully validated evidence reports with the same claimed canonical payload digest produced equal authorized evidence decisions.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Evidence/EvidenceGate.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/CiEvidenceReportAudit4CounterexampleTests.cs`
- `docs/work-packages/phase1-ci-evidence-report-audit4.md`
- `docs/work-packages/handoffs/phase1-ci-evidence-report-audit4.md`

## Contract

Every accepted `EvidenceDecisionSubject` retains the exact validated `EvidenceSubject` report reference in addition to its payload digest. Decision equality compares the digest and the report's canonical structural content, so exact independently reconstructed or collection-permuted reports replay equally while distinct reports cannot collapse merely because a caller supplied the same digest. Holds remain subject-free.

The existing manifest/signing authorization scope is unchanged. This audit does not retain the policy, verifier identity, or opaque signature bytes and does not change validation, policy, signature, freshness, lane, target, action, code, trace, or precedence behavior.

## Boundary

This is a pure in-memory accepted-output provenance correction. It does not calculate or authenticate the claimed canonical digest, qualify evidence producers or signers, release a credential, dispatch CI work, or perform process, filesystem, network, NATS, VM, cloud, registry, signing, deployment, or other external operations.


---

# FILE: docs/work-packages/phase1-compute-accepted-completion-provenance-audit.md

# Phase 1 compute accepted-completion provenance audit

- Exact audit base: `f93051a4f324604424b18cb6962f9e47a76c6d42`
- Requirements: `REQ-O011`, `INV-005`
- Scope: pure compute decision output, independent L0 regression evidence, and this note
- External I/O or mutation: none

## Counterexample

Two complete, valid scale-out requests could differ in controller generation,
artifact/template/demand/operation identity, persisted plan and capacity proofs,
provider result, work request, resource/node identity, and completed progress,
yet both publicly returned only an empty intent/error set and
`Completed:Ready`. The exact accepted input could not be recovered from the
decision, so the terminal output was not a sufficient generation-bound replay
receipt.

The executable counterexample was run before the production change and failed
with both public fingerprints equal to `trace:1:Completed:Ready`.

## Narrow repair

`ComputeDecision.AcceptedScaleOutRequest` is a getter-only nullable reference.
`ComputeEngine.DecideScaleOut` attaches the identical validated request to
every error-free decision, including intent-producing and terminal states.
Every held/error scale-out result and every scale-in or survival decision keeps
the property null. One centralized wrapper applies that iff rule after the
existing scale-out core returns.

No action, intent, trace, error, transition, validation order, acceptance path,
policy threshold, public factory, boolean authorization alias, adapter, or side
effect was added. Existing intent payloads and compatibility properties remain
unchanged.

## Independent evidence

- Exact-reference and iff coverage spans all eight defined scale-out states.
- All nine scale-out error families are represented and keep the accepted
  request null; accepted and held scale-in/survival decisions are also null.
- Forty-two independently accepted mutations cover every variable request
  family, nested authority identity, count/resource join, plan/persistence and
  authorization proof, provider observation, and completed progress proof.
- The independent canonical fingerprint is culture-, reflection-discovery-
  order-, and replay-stable. The existing content-addressed storage/compute
  failure corpus remains byte-compatible.
- Reflection exhaustively inventories exported compute decision/intent origins,
  collection/request accessors, record clone, constructors, and setters.

## Requirement mapping and limits

This is the pure L0 boundary required by `REQ-O011` and the generation-bound,
crash-safe replay property in `INV-005`. It strengthens the Phase 1 requirement
that immutable input plus pure decision output be sufficient for deterministic
adapter execution and replay. It does not select an unresolved owner answer,
cost/storage/RPO/RTO target, provider policy, or destructive-operation policy.

This audit does not claim OCI, Pulumi, provider work-request, VM, rootless container, NATS,
L0C, ARM64, deployment, or full pre-deployment evidence acceptance.


---

# FILE: docs/work-packages/phase1-compute-autoscaling-core.md

# Phase 1 compute autoscaling and regional survival core

## Predecessor

- Contract steward commit: `069fccf`
- Demand windows, cooldown/lifetime, node floors/caps, fallback order, cost/SLO targets, and survival-bundle expiry values remain explicit inputs.

## Goal

Implement the pure regional compute scale-out/scale-in/replacement and survival-readiness state machines from `ORCHESTRATOR.md:623-756`. It composes typed scheduler/budget/provider evidence but performs no provider action.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Compute/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Compute*.cs`
- `docs/work-packages/handoffs/phase1-compute-autoscaling-core.md`

## Required behavior

- Immutable bounded cell/node/node-class/template/shape/domain/artifact/secret-version/bundle/demand/operation identities; checked counts/resources/generations/epochs; closed trigger, lifecycle, readiness, veto, and action catalogs.
- Scale-out follows DemandObserved through persisted plan, budget/quota/capacity authorization, provider request recording, identity attestation, enrollment, bootstrap/disk checks, readiness, placement, service health, and completion. Lost provider response never emits a second create.
- Scale-in requires sustained explicit low-use/cooldown/lifetime evidence, replacement capacity and availability headroom, fresh regional control/NATS health, no conflicting operation, caller-owned stateful approvals, exact LB/volume/revocation proofs, exact instance termination, boot-volume absence, and orphan audit. Seed/control floors cannot reach zero and blind instance-pool count reduction is unrepresentable.
- Missing/stale demand may permit only explicitly bounded safety scale-out and always holds scale-in. Failed host replacement is fenced and preserves retained stateful volumes for their owning controllers.
- Regional survival readiness binds signed/encrypted bundle metadata, exact accepted+rollback artifacts and encrypted secret versions, templates, provider/trust/NATS/DNS/backup references, authority/snapshot positions, and explicit freshness/expiry evidence. Plaintext secrets/offline roots are unrepresentable. Disconnected replacement is allowed only when bundle/current regional authority proofs are complete.
- Emit closed observe/persist-plan/authorize/request-create/enroll/ready/cordon/drain/deregister/detach/revoke/terminate/audit/hold intents with exact proofs and stable code/numeric trace; no provider/runtime/network command, secret, callback, SDK, or I/O.
- Defensive copies; culture/permutation/replay; every scale transition crash; stale demand; conflicting operations; floor/quorum/budget veto; stateful veto; lost response; failed seed replacement; bundle missing/expired/rollback gaps; disconnected GRU; and secret-safe tests.
- No provider/NATS/runtime/filesystem/network/clock package, trigger/cooldown/floor/fallback/default policy, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-compute-autoscaling-property-shard.md

# Phase 1 compute autoscaling property shard

- Owner: `phase1_compute_properties`
- Allowed production paths: `src/TerraScale.Orchestrator.ControlPlane/Compute/**`
- Allowed test paths: `tests/TerraScale.Orchestrator.ControlPlane.Tests/ComputePolicyCompletenessPropertyTests.cs`, narrowly scoped fixture correction in `ComputeEngineTests.cs`
- Requirements: `REQ-O009`, `REQ-O010`, `REQ-O011`; invariants 4-8 and 14
- Boundary: pure `DecideScaleOut`, `DecideScaleIn`, and `DecideSurvival` policy only. No provider, cloud, NATS, network, process, filesystem, deployment, or lab execution.

## Deliverable

Audit existing example and property coverage, then add generated independent-oracle cases for ordered authorization denial, exact checkpoint prefixes, authority epochs/generations, critical floors, N+1 availability, stateful drain/reclaim semantics, and regional survival authorization. Any production hardening must be tied to a reproduced pure-policy defect and preserve construction-closed outputs.

## Evidence boundary

Focused in-process tests are evidence for pure policy behavior only. They do not qualify OCI, NATS, systemd, rootless container, regional failover, or any deployment acceptance level.


---

# FILE: docs/work-packages/phase1-control-operation-properties.md

# Phase 1 control/operation deterministic property shard

## Base and scope

- Base: `origin/chore/phase0-bootstrap`
- Deterministic property/replay tests under `ControlPlane.Tests/Properties/Operations/**`
- Bounded embedded corpus under `test-corpus/control-operations/**`
- Review-approved construction-closure expansion in `Authority/AuthorityContracts.cs`

## Goal

Run at least 1,000 explicit-seed cases per Authority, Operations, Reconciliation, and cross-core property family. Independently oracle identity, generation/epoch fencing, durable-before-dispatch, idempotency, deadline/retry/compensation closure, stale/unknown/duplicate/reordered evidence, single-writer behavior, replay/culture/permutation stability, checked arithmetic, closed accepted outputs, and secret-safe errors.

The cross-core family exercises an orchestrated handoff convention: it obtains a permit, carries its epoch into operation preparation/authorization, proves durable authorization precedes dispatch, and binds the dispatched identity into reconciliation. Operations does not consume or cryptographically verify `MutationAuthorityPermit`; this shard therefore does not claim that an arbitrary operation epoch is enforced as authority-derived.

The shard uses no external property or mutation package and performs no filesystem I/O, networking, process execution, clock reads, cloud action, or deployment. It does not claim 100,000 cases, full-domain property evidence, a mutation score, L0, or deployment qualification.

## Verification

```text
dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-restore --verbosity minimal
Passed: 291, Failed: 0, Skipped: 0
```

See `docs/work-packages/handoffs/phase1-control-operation-properties.md` for the compatibility report and evidence boundary.


---

# FILE: docs/work-packages/phase1-delivery-core.md

# Phase 1 native GitOps, CI, and release decision core

## Predecessor

- Contract steward commit: `a1ecba0`
- Repository placement, signing technology, approval policy, rollout windows, and retention values remain explicit owner/caller inputs.

## Goal

Implement pure GitOps source reconciliation, CI trust-zone scheduling, artifact promotion, and release/CD correctness state machines from `ORCHESTRATOR.md:924-1010`. It emits typed source/runner/release intents only.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Delivery/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Delivery*.cs`
- `docs/work-packages/handoffs/phase1-delivery-core.md`

## Required behavior

- Immutable bounded source/ref/commit/tree/manifest/pipeline/job/runner/trust-zone/artifact/digest/signature/attestation/release/cell/operation identities; positive generations/attempts; closed source/job/promotion/rollout/rollback states.
- GitOps accepts immutable commit/tree/digest evidence, validates schema and dependency proofs, produces deterministic plan/apply intent, and never treats branch movement or webhook delivery as authority. Same desired generation/digest is idempotent; lower/conflicting generations fail closed.
- CI schedules jobs only onto compatible explicit trust zones/capabilities with fresh runner evidence; untrusted product code cannot receive production secrets/provider authority or mutate the control plane. Interrupted jobs are retried only under explicit attempt/idempotency policy.
- Promotion requires exact source tree, dependency lock, generated schemas, tests/evidence attestation, artifact digest, signing identity, approval, and compatibility proof. Any source/dependency/schema/binary change invalidates evidence.
- CD uses exact signed artifact and desired generation, local forward+rollback availability, staged health proof, disruption/availability authorization evidence, and deterministic rollback/hold rules. Process exit alone is never success.
- Emit closed fetch/verify/plan/dispatch/promote/stage/advance/rollback/hold intents with exact proofs and stable code/numeric trace; no Git command, script, pipeline text, secret, callback, process, network, or I/O.
- Defensive copies; culture/permutation/replay determinism; branch race; duplicate webhook; dependency ordering; trust-zone escape; lost runner; evidence invalidation matrix; N/N-1 compatibility; staged failure/rollback; and secret-safe/reflection tests.
- No Git/Forgejo/process/filesystem/network/clock, signing implementation, rollout default, approval default, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-delivery-policy-completeness.md

# Phase 1 Delivery policy completeness shard

## Scope

- Pure Delivery source, promotion, and rollout contracts under `src/TerraScale.Orchestrator.ControlPlane/Delivery/**`.
- Delivery-only completeness properties in `tests/TerraScale.Orchestrator.ControlPlane.Tests/DeliveryPolicyCompletenessPropertyTests.cs`.
- No Git, Forgejo, NATS, process, filesystem, network, provider, signing implementation, deployment, or acceptance evidence.

## Contract map

- `ORCHESTRATOR.md:354-367`: promotion and rollout bind the selected architecture and its exact digest; ARM64 and x64 artifacts are not interchangeable.
- `ORCHESTRATOR.md:924-956`: source verification retains the accepted signature through the typed plan/apply boundary.
- `ORCHESTRATOR.md:968-997`: promotion retains the exact test attestation and N/N-1 compatibility proof; rollout reuses one exact signed candidate and locally available rollback artifact.
- `ORCHESTRATOR.md:1134-1135`: pure Delivery decisions cover staged promotion, rollback, one-writer release rules, and exact-artifact reuse.
- Accepted `phase1-delivery-core` handoff: authorizing outputs carry exact proofs, rollout order is caller-owned, and policy defaults remain outside this shard.

## Changes and evidence boundary

- Add a closed `DeliveryArchitecture` catalog and bind it across promotion subjects, release specifications, availability observations, stage/completion evidence, and stage/advance/rollback intents.
- Require forward and rollback architecture equality for one rollout target; a rollout cannot substitute an x64 rollback on an ARM64 target or the inverse.
- Retain source signature in `PlanApplyIntent` and tests attestation in `PromoteArtifactIntent` instead of dropping accepted proof at the authorizing boundary.
- Add two deterministic 1,000-case independent-oracle families covering every output field, all trace fields, forward/rollback availability and stage/completion signer mismatch, architecture mismatch, denial precedence, completion order, terminal replay, exact rollback, input permutation, and en-US/tr-TR/ar-SA/ja-JP stability.
- Reject every undefined observed Delivery enum before a mutation intent.

The existing embedded Delivery/TerraBase replay corpus is unchanged: its Delivery source behavior and expected outcomes are unaffected, and its helper now supplies the explicit architecture required by the strengthened contract.


---

# FILE: docs/work-packages/phase1-delivery-stage-output-audit4.md

# Phase 1 delivery stage output audit 4

## Goal

Close the proven accepted-output collision where initial staging discarded the validated release strategy, rollback policy, ordered-cell policy, and selected cell-availability evidence.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Delivery/DeliveryContracts.cs`
- `src/TerraScale.Orchestrator.ControlPlane/Delivery/DeliveryEngine.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/DeliveryFourthAuditRegressionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/DeliveryPolicyCompletenessPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/DeliveryStageFingerprint.cs`
- `docs/work-packages/phase1-delivery-stage-output-audit4.md`
- `docs/work-packages/handoffs/phase1-delivery-stage-output-audit4.md`

## Contract

An accepted initial `StageReleaseIntent` retains the exact validated `ReleaseSpec` and exact selected `CellArtifactAvailability`. Existing release, operation, cell, generation, forward artifact, rollback artifact, digest, signing, signature, and architecture projections remain and derive only from those retained inputs. Denied decisions retain only the hold intent. Error numerics, trace order, rollout decisions, validation, precedence, advance behavior, and rollback behavior do not change.

## Boundary

The retained strategy, rollback policy, and ordered cells are caller policy provenance. Retention does not claim that this decision engine has executed, qualified, or externally enforced a canary, rolling, blue-green, or ordered-stateful rollout. The selected availability is accepted in-memory evidence, not proof of registry contents, signature authenticity, deployment success, or runtime health. This work adds no wire schema and performs no process, network, signing, registry, VM, cloud, credential, filesystem deployment, or CI-dispatch operation.


---

# FILE: docs/work-packages/phase1-delivery-terrabase-properties.md

# Phase 1 delivery and TerraBase property/replay shard

## Goal

Add deterministic, bounded property and saved-counterexample coverage for the existing pure Delivery/GitOps/release and TerraBase topology/recovery decision cores. Harden their caller-controlled collection snapshots without selecting business policy.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Delivery/**`
- `src/TerraScale.Orchestrator.ControlPlane/TerraBase/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/DeliveryTerraBase*`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`
- `docs/work-packages/phase1-delivery-terrabase-properties.md`
- `docs/work-packages/handoffs/phase1-delivery-terrabase-properties.md`

## Required evidence

- At least 1,000 generated cases per property family with independent expected outcomes.
- Identity, generation, digest, signature, stale/conflicting/duplicate/reordered evidence, rollback, terminal replay, quorum/membership, culture, and permutation checks where exposed by the existing cores.
- Strict, bounded, whole-file-content-addressed embedded replay corpus whose input changes affect replay.
- Technical collection caps, max/max+1 and hostile iterator coverage, defensive copies, generic secret-safe ordinary failures, and fatal exception propagation.
- Construction-closed authorizing outputs and closed observed enum catalogs.
- A follow-up TerraBase completeness shard must set every enum-valued evidence field to an out-of-catalog value,
  reject it before any mutation, preserve the defined `Unknown`/`Contradicted` checkpoint precedence, bind every
  evidence-scope dimension in every TerraBase planner, and compare every field of authorizing subjects and traces
  under English and non-English cultures.

## Exclusions

No Git, process, filesystem runtime, network, cloud, package/tool selection, deployment, or L0 evidence. Technical caps are not rollout-cell, dependency, runner, member, quorum, or backup business policy.


---

# FILE: docs/work-packages/phase1-evidence-accepted-scope-audit.md

# Phase 1 evidence accepted-scope audit

## Goal

Close the proven collision where two authorized pre-deployment evidence decisions with different manifest and verified signing provenance produced equal accepted outputs.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Evidence/EvidenceGate.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/EvidenceCoreTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/EvidencePolicyCompletenessPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SnapshotEvidencePropertyTests.cs`
- `docs/work-packages/phase1-evidence-accepted-scope-audit.md`
- `docs/work-packages/handoffs/phase1-evidence-accepted-scope-audit.md`

## Contract

An accepted decision retains its exact manifest identity and lane, gate target, signing profile, signing identity, signature identity, generation, and expiry sequence. Rejected decisions retain no authorization scope. Existing error codes and evaluation precedence do not change.

## Boundary

This is a pure accepted-output change and adversarial test shard. It performs no signing, verification implementation, credential, process, filesystem, network, NATS, VM, cloud, or deployment action.


---

# FILE: docs/work-packages/phase1-evidence-policy-completeness.md

# Phase 1 evidence policy completeness shard

## Goal

Adversarially complete the existing pure pre-deployment evidence policy without claiming or executing any deployment evidence lane.

## Scope

- Require every suite declared by an evidence subject to meet the caller-supplied test, property, branch, mutation, model-schedule, and flake floors, including suites outside the minimum required-domain set.
- Require the declared suite-domain and model-corpus-domain inventories to match exactly so an orphan suite or corpus cannot be carried by an authorizing manifest.
- Exercise 1,000 deterministic cases for every suite floor, suite/corpus domain parity under permutation, and exact generation/expiry/signing denial outputs with complete numeric traces.
- Retain caller ownership of domain requirements and all numeric thresholds. No threshold, signer, verifier, clock, credential, or execution result is invented.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Evidence/EvidencePolicy.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/EvidencePolicyCompletenessPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SnapshotEvidencePropertyTests.cs`
- `docs/work-packages/phase1-evidence-policy-completeness.md`

## Boundary and non-claims

This shard changes only pure policy evaluation and pure tests. It performs no filesystem, process, network, NATS, VM, cloud, credential, deployment, signing, or KMS action. It does not claim that L0, L0C, dual-architecture, mutation, fuzz, model, signature, or deployment evidence has executed or passed.


---

# FILE: docs/work-packages/phase1-identity-vault-core.md

# Phase 1 identity, PKI, and vault decision core

## Predecessor

- Contract steward commit: `a1ecba0`
- PKI algorithms, lifetimes, renewal windows, vault backend/storage, offline-root procedure, and owner secret-retention policy remain explicit inputs.

## Goal

Implement pure enrollment, certificate/identity lifecycle, authorization, revocation, and encrypted-secret lease decisions from `ORCHESTRATOR.md:881-923`. No cryptographic provider or secret store is used.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Security/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Security*.cs`
- `docs/work-packages/handoffs/phase1-identity-vault-core.md`

## Required behavior

- Immutable bounded cell/node/workload/role/issuer/key/certificate/secret/version/lease/operation/attestation identities; positive epochs/generations/sequences; closed principal, usage, trust-scope, revocation, lease, and authorization catalogs.
- Enrollment binds one-time bootstrap evidence, machine/workload attestation, expected cell/role/node generation, current issuer/revocation generation, and single-use operation. Replay, wrong scope/role/generation, stale attestation, or consumed token holds/rejects.
- Issue/renew/rotate/revoke decisions receive explicit caller policy and validity evidence. Regional intermediates cannot issue outside their cell/scope; offline roots cannot be represented as online signing capability; revoked/stale/lower-generation identities never authorize.
- Authorization maps closed principal/role/capability/resource scope only. Default deny; unknown enum, incomplete/duplicate/conflicting evidence, cross-cell access, privilege escalation, or stale revocation view rejects.
- Vault decisions handle encrypted secret metadata/version availability and short-lived lease grant/renew/revoke without accepting plaintext secret bytes or key material. Regional survival may reference exact encrypted versions only inside explicit retention/expiry policy.
- Emit closed typed attest/issue/renew/revoke/grant-lease/renew-lease/revoke-lease/hold intents and stable code/numeric trace. No signature algorithm, crypto operation, private key, plaintext secret, credential, arbitrary claim/text, callback, time read, storage, or I/O.
- Defensive copies; culture/permutation determinism; token replay; cross-cell issuer; stale revocation; rotation overlap; compromise revocation; authorization matrix; secret version rollback; lease expiry evidence; forbidden-shape reflection; and secret-safe tests.
- No crypto/vault/NATS/filesystem/network/clock package, lifetime/default algorithm, owner retention choice, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-messaging-policy-properties.md

# Phase 1 messaging policy property/replay shard

## Goal

Add deterministic, independently-oracled property and saved-counterexample coverage to the existing pure messaging topology, replacement, and partition decision core. Harden only caller-controlled collection capture defects proven during that audit.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Messaging/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/MessagingPolicy*`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`
- `docs/work-packages/phase1-messaging-policy-properties.md`
- `docs/work-packages/handoffs/phase1-messaging-policy-properties.md`

## Required evidence

- At least 1,000 generated cases each for replacement precedence, partition authority/generation precedence, and dual-plane isolation.
- Independent expected outcomes, exact intent subjects, permutation and culture replay, and construction closure for all authorizing intents and decisions.
- A strict UTF-8 byte-bounded, whole-file SHA-256-pinned embedded replay corpus with input-sensitive replay fingerprints.
- Defensive capture at the public technical cap, rejection before reading an extra `Current`, literal endless and disposal-mutation sources, secret-safe ordinary iterator failures, and fatal exception propagation.
- Hostile `IReadOnlyList` count/enumerator behavior in compatibility decisions while preserving `MaximumResources` as separate business policy.

## Exclusions

This shard contains no NATS client/server package, process, socket, filesystem runtime, network, cloud, retry loop, or version selection. It does not claim L0C or any real NATS evidence. The 4,096-item snapshot limit is a non-business technical memory bound, not a membership, replica, resource, rollout, or quorum policy.


---

# FILE: docs/work-packages/phase1-mutation-foundation.md

# Phase 1 mutation-evidence foundation

## Goal

Create a deterministic, fail-closed mutation project inventory, exclusion
policy, and zero-claim report while the mutation tool remains unselected. Do
not choose, install, restore, or run a candidate tool and do not claim a score.

## Allowed paths

- `tools/mutation/**`
- `docs/audits/mutation/**`
- `docs/work-packages/phase1-mutation-foundation.md`
- `docs/work-packages/handoffs/phase1-mutation-foundation.md`

## Required behavior

- Cross-check the mutation candidate/version/status against the existing Phase
  0 supply-chain audit and reject selection or execution claims while that
  source remains `candidate-unselected`.
- Inventory every production project and fail on additions, removals, duplicate
  entries, unsafe paths, and symlinks.
- Require mutation testing for every current correctness-critical project.
- Permit exclusions only for generated code, immutable DTO accessors, or proven
  trivial composition wiring; bind excluded source by exact path and SHA-256.
- Never permit exclusions for state transitions, validators, authority,
  fencing, deletion, retry, compensation, or adapter result classification.
- Preserve the specification's 85% score and zero safety-survivor thresholds
  without claiming either has passed.
- Validate exact schemas, bounded collections, policy/source digests, review
  freshness, and explicit null/false zero-claim results.
- Exercise adversarial fixtures for fabricated results, weakened policy,
  forbidden exclusions, drift, staleness, duplicate keys, and unsafe paths.

## Verification

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- mutation-evidence --as-of 2026-07-13
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/mutation/mutation-policy.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/mutation/mutation-evidence.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/mutation/fixtures/negative-cases.json
```


---

# FILE: docs/work-packages/phase1-nats-l0c-foundation.md

# Phase 1 real-NATS L0C foundation

## Boundary

- Base: `origin/chore/phase0-bootstrap` at `709347e`.
- This package defines a credential-free, non-executing conformance inventory. It does not start, contact, download, install, select, or qualify NATS, NATS CLI, JWT/NKey tooling, a VM, or any external service.
- Candidate artifact metadata is not a selected toolchain. Full L0C and every acceptance claim remain blocked.

## Allowed paths

- `tools/nats-l0c/**`
- `docs/work-packages/phase1-nats-l0c-foundation.md`
- `docs/work-packages/handoffs/phase1-nats-l0c-foundation.md`

## Deliverable

Provide a deterministic machine-readable L0C case inventory for dual-plane isolation; JWT/account/subject denial; JetStream stream and KV policy; three-region control gateways; duplicate, reorder, acknowledgement, and redelivery behavior; local R3 failure; N/N-1 compatibility; and snapshot/restore recovery.

The dependency-free validator must enforce a closed schema, technical byte/count/string bounds, safe repository-relative regular-file inputs, exact pin-manifest binding, complete category/assertion coverage, and an explicitly stale non-acceptance report. It must fail if candidate metadata is promoted to a selection or if an L0C/ARM64/production claim appears.

## Verification

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- nats-l0c
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/nats-l0c/l0c-cases.json
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- json-format tools/nats-l0c/l0c-report.json
git diff --check
```


---

# FILE: docs/work-packages/phase1-nats-policy-audit3.md

# Phase 1 NATS policy accepted-observation audit 3

## Boundary

- Audit the pure Messaging/NATS replacement decision and its typed observation intent.
- Prove that an accepted observation request retains the exact replacement operation that authorized it.
- Preserve existing validation, error and trace catalogs, precedence, numeric boundaries, and replacement progression.
- Perform no NATS, network, process, credential, filesystem-administration, VM, cloud, or deployment operation.

## Proven counterexample

Two otherwise valid replacement operations could share operation ID, cluster, and observation sequence bounds but
carry different authority epochs. Both were accepted, yet both emitted an equal `ObserveClusterIntent` because the
intent retained only those four shared projections. Operation generation, plane, cell, authority epoch,
configuration generation, failed-store identity and generation, failed and replacement peer identities, and
replacement placement were discarded at the executable boundary.

The collision applied both to the initial observation request and to the re-observation branch for an active
surviving-store attachment whose membership or replica view remained incomplete.

## Required correction

- `ObserveClusterIntent` retains the exact accepted `ReplacementOperation` as `Replacement`.
- Existing `Operation`, `Cluster`, `MinimumSequence`, and `MaximumSequence` members remain derived projections for
  consumers of the previous surface.
- Identical semantic replay remains equal; substituting any retained replacement-operation field produces a
  distinct output and canonical replay fingerprint.
- The output remains construction-closed and can be produced only by the pure policy engine.

## Evidence

- Pin the exact retained replacement reference and every replacement-operation field.
- Prove the original authority-epoch collision and sensitivity to every other retained field.
- Cover initial observation and surviving-store re-observation, including observation-order permutation.
- Prove invariant canonical fingerprints across cultures and update every Messaging replay serializer that handles
  the observation intent.
- Preserve holds, rejected/default inputs, no-intent completion, trace order, and all unrelated decisions.

## Nonclaims

The correction binds accepted replacement-operation provenance only. It does not retain or authenticate a cluster
observation, surviving-store proof, rejected evidence, response, NATS server, or complete selection/authorization
context. It does not verify response authenticity or qualify NATS/JetStream behavior. The planned real-NATS L0C
inventory remains unexecuted and supplies no acceptance evidence.


---

# FILE: docs/work-packages/phase1-nats-policy-core.md

# Phase 1 dual-NATS policy and membership core

## Predecessor

- Contract steward commit: `0a54a0f`
- NATS server/client/sync selections and owner RPO/SLO values remain unresolved and must stay explicit inputs.

## Goal

Implement the pure dual-NATS topology, stream/bucket policy, membership replacement, and partition decision core from `ORCHESTRATOR.md:448-590`. It emits configuration/operation intents only and never starts or contacts NATS.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Messaging/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Messaging*.cs`
- `docs/work-packages/handoffs/phase1-nats-policy-core.md`

## Required behavior

- Immutable bounded cell, cluster, server, account, stream, bucket, peer, placement, operation, and observation identities; positive epochs/generations/sequences; closed control/product cluster and durability/action catalogs.
- Explicit caller policy for independent control/product clusters, exact membership floor, route/gateway peer sets, account isolation, stream/bucket replicas, retention, maximum age/bytes, discard, placement, duplicate window, acknowledgement, disk-sync/RPO classification, and compatibility feature availability. No implicit R3, timing, storage, or sync default.
- Reject any subject/account/stream overlap between control and product planes, cross-plane peer/server identity, singleton critical durability, incomplete/duplicate/conflicting/stale observations, unknown features, and config that loses the declared floor or acknowledged-write policy.
- Pure replacement state machine: observe failed peer, persist exact replacement operation, add/catch up replacement, verify current membership and stream/bucket replicas, then remove the exact failed peer. Never remove first, reuse an unproven identity, or emit two replacements after a lost response.
- Partition decisions preserve regional ownership: a disconnected region may continue caller-authorized local operations at a current regional epoch but cannot claim global authority or accept stale/lower-generation global commands.
- Outputs are closed typed configure/observe/add-peer/wait-catchup/remove-peer/hold intents with exact proofs only. Complete stable numeric/code trace, no arbitrary message, callback, config text, credentials, NATS client/server object, or I/O.
- Defensive copies; culture/input permutation determinism; control/product isolation; N/N-1 feature matrices; 3-peer one-loss replacement; lost response/replay; remove-before-catchup denial; duplicate/conflict/stale/future evidence; partition authority; maximum/overflow; and secret-safe tests.
- No NATS package/process/socket/filesystem/clock, retry loop, version selection, SLO/RPO value, or topology default.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-nats-policy-provenance-audit4.md

# Phase 1 NATS replacement decision provenance audit 4

## Scope and initial base

- Initial audited base: central `chore/phase0-bootstrap` at `3f283065a68957f0530f312c9308cd97512fad40`.
- Allowed paths: pure Messaging/NATS contracts and policy engine, Messaging policy tests, and this work package.
- Pure deterministic L0 policy only. No NATS server, JetStream, network, process, credential, filesystem, VM, cloud, provider, or deployment action was performed.

## Executable defect

Audit 3 bound an initial or repeated `ObserveClusterIntent` to its exact replacement operation. It did not cover accepted decision branches whose intents flatten the operation or whose successful terminal result contains no intent.

Two fully valid completed replacements differed in operation ID, authority epoch, failed-store identity, replacement server/peer/placement, observation identity, and corresponding peer evidence. Both returned this complete public decision:

```text
Intents       = []
Errors        = []
Trace         = [1:ReplacementComplete:Observe]
Compatibility = null
```

The executable red test fingerprint for each was exactly `||1:ReplacementComplete:Observe|`. A persisted completion could therefore not prove which validated request reached the terminal state. The decision-level gap also affected provenance around flattened add, wait, remove, and reattach intents even when those intents retained the minimum fields needed for their immediate action.

## Correction

`MessagingDecision.AcceptedReplacementRequest` retains the exact immutable `ReplacementRequest` reference on every successful `DecideReplacement` result. One private `ReplacementDecision` helper is the only production path that attaches it. All successful branches use that helper, including:

- initial observation and persisted-operation requests;
- add-peer, catch-up wait, replica-verification wait, and failed-peer removal;
- terminal completion after the failed peer is absent;
- surviving-store reattach, active-attachment re-observation, and active-attachment completion.

Every held/error result and every topology, partition, or compatibility decision retains null. No admitted boolean, flattened duplicate request state, public constructor, or public factory was added. Existing intents, errors, compatibility acceptance, trace codes, numeric values, ordering, precedence, validation, and replacement progression are unchanged.

The request already owns defensive immutable snapshots for policy and observation collections. Retaining it therefore binds plane policy, proposed and nullable persisted operations, maximum identity length, cluster observation, peer/store proof, and replica evidence without rebuilding an incomplete parallel DTO.

## Deterministic evidence

The focused tests prove exact request-reference retention over every existing eight-mode replacement property path plus surviving-store reattach, active-attachment re-observation, and active-attachment completion. The no-intent collision is now distinct. Invalid replacement input is null, and successful/held partition, compatibility, and topology examples also prove that no non-replacement decision can acquire replacement provenance.

A generic test-only canonical walker uses runtime-type and property-name tags plus invariant length framing. Enumerable items are independently framed and ordinal-sorted, so policy, peer, proof, and replica permutations are semantically stable. Exact public-property inventories pin every field of `ReplacementRequest`, `PlanePolicy`, `ServerPolicy`, `RouteLink`, `AccountPolicy`, `StreamPolicy`, `BucketPolicy`, `ReplacementOperation`, `ClusterObservation`, `PeerObservation`, `SurvivingStoreProof`, and `ReplicaObservation`.

An independent sensitivity matrix changes exactly one semantic leaf or collection family per mutant. It covers policy plane/cell/cluster/generation/floor; count and item mutations for servers, routes, gateways, accounts/subject roots, streams, and buckets; every server, route, stream, and bucket field; all sixteen proposed-operation fields; persisted null and a differing persisted field; request maximum identity length; all observation scalars and collection counts; every peer scalar and nullable proof; every surviving-store proof field; and all stream/bucket replica fields. Every mutant has a distinct hash from the baseline and from every other mutant. Canonical material remains replay-stable under English, Turkish, and Arabic cultures and differs across every accepted branch, including nullable persisted/observation state.

The 1,000-case replacement and surviving-store properties require exact accepted-request references for normal and reversed evidence. Held resource-safety cases require null. Topology and partition properties require null. Replacement corpus replay fingerprints now include the complete accepted-request hash.

The historical corpus remains byte-identical with SHA-256 `2dbee32886e47ab9ee7a59f515a5183f9db764f10d788f34e2be592399f536af`. Its existing v1 entries/outcomes are unchanged; Audit 4 strengthens the test-side replacement output fingerprint without claiming that the old fixture schema independently enumerated all request fields.

## Construction closure

The exported hierarchy contains one abstract and ten concrete `MessagingIntent` records plus `MessagingDecision`. Every concrete output is sealed. Every output exposes getter-only public properties and has no public constructor or deconstructor. Exhaustive inspection covers every exported type's declared public static and instance method/accessor returning a decision, an intent, an enumerable/collection projection of intents, or a replacement request. The exact allowlist is the four real static `MessagingPolicyEngine` decision originators; the non-originating zero-argument same-type compiler clones for the decision, intent hierarchy, and replacement request; `MessagingDecision.get_Intents`; and `MessagingDecision.get_AcceptedReplacementRequest`. Clone invocation proves that it preserves the exact immutable intent/error/trace snapshots and accepted request reference rather than transforming or minting them.

## Evidence boundary and nonclaims

This proves only which caller-supplied immutable request passed the pure replacement policy. It does not authenticate observations or surviving-store proofs, persist a journal checkpoint, make an adapter call, or prove that NATS performed an operation. It does not qualify NATS/JetStream response authenticity, membership administration, R3 durability, disk synchronization, gateway isolation, snapshot/restore, compatibility, ARM64, L0C, L3S/L4, or production deployment.

It adds no NATS SDK, socket, endpoint, credential, secret, filesystem path, process, clock, provider permission, VM, cloud, or deployment surface.

## Verification before actual-diff review

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore --nologo -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj -c Release --no-build --no-restore -- --disable-logo --no-progress
git diff --check
```

The focused audit passed 3/3, the focused review correction passed 2/2, and the pre-correction ControlPlane executable passed 626/626 with zero failures or skips before final integration rebase. Final exact-tree whole-solution counts are recorded in the integration handoff.


---

# FILE: docs/work-packages/phase1-networking-output-provenance-audit4.md

# Phase 1 networking accepted-output provenance audit 4

## Basis and scope

- Exact central basis: `215fb482a2f29ec96c37f5f7c85ef9ea26de29b5`.
- Bounded surface: pure networking route/tunnel and endpoint decision outputs, deterministic replay, and public construction/accessor/clone closure.
- Excluded: VPN, peering, routing, DNS, load-balancer, firewall, cloud, VM, process, socket, filesystem, clock, or any other external effect.

## Proven counterexamples

The pre-production executable counterexamples exposed three accepted-output collisions:

- two successful `ConfigureTunnel` decisions with the same scope and observations but different accepted route evidence compared equal;
- two successful `Register` decisions with the same scope but different accepted endpoint evidence compared equal;
- successful registration and removal plans over the same scope and evidence produced equal endpoint subjects, erasing the semantic planner route.

All three failed before the correction and pass afterward.

## Correction

- Every accepted route subject retains the exact accepted scope reference, observed generation, observed epoch, and evidence reference. Existing flattened getters are projections of that scope.
- Every accepted endpoint subject retains a fixed plan kind (`Register`, `Removal`, or `EmergencyWithdrawal`) plus the exact accepted scope and evidence references. Existing flattened getters are projections of that scope.
- Route evidence now has structural equality and hashing over every scalar and every captured collection. Routes, approved prefixes, topology links, and topology cells use order-insensitive multiset semantics: permutation is ignored, while duplicate cardinality and every typed leaf remain significant.
- Held decisions retain no accepted subject. No new public factory, public constructor, public setter, or deconstruction route was introduced.

## Proof inventory

Executable proofs cover all five accepted route branches, all five registration branches, all four removal branches, and all five emergency-withdrawal branches. They also cover exact-reference retention, reconstructed evidence equality and hashing, actual multi-entry permutations, duplicate cardinality, every route-evidence scalar and collection leaf, all 15 independently varied route-scope leaves (including destination address, address bit length, and prefix bits), both subject observation ordinals, all endpoint-scope and endpoint-evidence fields, and default/value-copy/record-clone behavior.

A single exact signature allowlist inventories every exported public declared method or accessor returning a decision, base or concrete subject, retained route/endpoint scope, retained route/endpoint evidence, numeric trace, or route-evidence collection projection. It pins the four planner origins, decision and subject accessors, base and concrete record clones, and legitimate input projections; concrete subject clones are invoked and proven to retain the exact basis references.

The strict whole-file-pinned replay corpus now includes route-evidence provenance and endpoint-plan provenance cases. A separate 1,000-case replay proves stable accepted provenance across `tr-TR` and `ar-SA` cultures with unique typed operations and generations.

## Nonclaims

This audit proves only pure decision and intent provenance. It does not configure, persist, observe, or reconcile any concrete network resource. Provider implementation, durable Pulumi reconciliation, credentials, address allocation, routing priorities, certificates, exposure approvals, and health thresholds remain outside this work package.


---

# FILE: docs/work-packages/phase1-networking-policy-core.md

# Phase 1 networking, VPN, DNS, and ingress policy core

## Predecessor

- Contract steward commit: `069fccf`
- VPN implementation, address pools, DNS/LB provider, exposure policy, route priorities, certificate policy, and health thresholds remain explicit inputs.

## Goal

Implement pure network intent, peering/VPN route ownership, DNS/LB backend, and exposure authorization decisions from `ORCHESTRATOR.md:873-879,1096-1110`. It emits typed network intents only.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Networking/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Networking*.cs`
- `docs/work-packages/handoffs/phase1-networking-policy-core.md`

## Required behavior

- Immutable bounded cell/network/subnet/node/workload/service/endpoint/route/peer/tunnel/DNS/LB/backend/certificate/operation identities; canonical address/prefix/port values; positive generations/epochs; closed exposure, protocol, route, tunnel, backend, health, and action catalogs.
- Exact desired/observed route and tunnel ownership; reject overlapping/conflicting address spaces, ambiguous longest-prefix ownership, cross-cell authority, stale/future generations, duplicate peers/routes, route leaks, and product/control trust-plane crossover.
- VPN/peering changes are staged and reversible until explicit traffic/health proof. A partition never grants global authority; regional survival routes remain bounded to the caller-approved local policy.
- DNS/LB registration binds exact service generation, admitted endpoint, certificate reference, health/readiness, cell, exposure, and operation. Deregistration precedes drain/termination. Monitoring/admin endpoints cannot be public/workload-exposed.
- Backend health is distinct from process liveness; stale/missing health holds removal/promotion as appropriate. Public exposure requires exact approval and certificate/trust proof; default deny.
- Emit closed observe/configure-route/configure-tunnel/register/deregister/promote/DNS-update/rollback/hold intents with typed parameters and stable code/numeric trace; no config text, key material, credential, command, callback, SDK, socket, or I/O.
- Defensive copies; culture/permutation/replay; prefix overlap; route leak; wrong authority; tunnel partial failure; stale health; backend drain ordering; public admin denial; certificate mismatch; DNS lost response; and forbidden-shape/secret-safe tests.
- No VPN/provider/DNS/LB/network/filesystem/clock package, address/exposure/health/default implementation, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-observability-projection-core.md

# Phase 1 observability and Grafana projection core

## Predecessor

- Contract steward commit: `069fccf`
- Metrics/log/trace implementation selections, persistence topology, retention, cardinality budgets, alert thresholds, and Grafana delivery mechanism remain explicit inputs.

## Goal

Implement pure telemetry admission/cardinality, regional aggregation health, alert routing, and exact immutable Grafana projection decisions from `ORCHESTRATOR.md:1041-1095`. It emits typed projection intents only.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Observability/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Observability*.cs`
- `docs/work-packages/handoffs/phase1-observability-projection-core.md`

## Required behavior

- Immutable bounded cell/tenant/service/signal/metric/label/dashboard/datasource/folder/alert/contact/role/user/release/operation identities; checked cardinality/retention/generation quantities; closed signal, persistence, access, projection, and action catalogs.
- Telemetry admission receives explicit label-key/value catalogs and per-scope cardinality budgets. Unknown/unbounded labels, secret-bearing fields, raw credentials/keys, tenant crossover, stale generation, or budget overflow rejects before ingest intent.
- Regional metrics/log/trace health is evaluated independently with caller-selected HA/persistence/retention policies; GRU loss cannot erase regional evidence. Missing/stale observations hold promotion and produce typed degraded findings, not fabricated health.
- Grafana projection is an exact deterministic function of accepted roles/cells/datasources/dashboards/folders/alerts/contact points/access policy. Drift emits create/update/delete intent only under exact generation/ownership; unmanaged resources are reported and never silently adopted/deleted.
- Dashboard/query/provisioning executable text is not accepted as arbitrary caller input; projections select reviewed catalog entries plus typed parameters. Operator roles are least privilege and tenant/cell scopes cannot broaden by merge.
- Emit closed admit/drop/aggregate/project/create/update/delete/report-drift/route-alert/hold intents and stable code/numeric trace; no query/config JSON blob, credential, secret, callback, Grafana/OTel client, network/filesystem/clock, or I/O.
- Every accepted output preserves the exact immutable request/evidence that authorized it. In particular, alert routing must retain the complete event and dedupe snapshot so firing and resolved transitions cannot collapse to the same adapter-facing intent.
- Defensive copies; culture/permutation/replay; cardinality explosion; secret label; tenant isolation; signal outage; stale persistence; exact projection drift; unmanaged resource; access escalation; alert dedupe/routing; and secret-safe/reflection tests.
- Construction-closure evidence inventories every concrete observability intent and recursively proves that none can carry authority, operation, or provider-mutation permits/decisions.
- No telemetry/Grafana SDK, database/network/filesystem/clock, implementation/retention/cardinality/threshold/default catalog, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`


---

# FILE: docs/work-packages/phase1-observability-projection-provenance-audit4.md

# Phase 1 observability managed-projection provenance audit 4

## Scope and base

- Initial audited base: central `chore/phase0-bootstrap` at `a4c561d502dbf3b18aac4e39c86c9eafc36eed65`.
- Final rebased integration base: central `chore/phase0-bootstrap` at `e3cf9f0494aeaa4bdd205c2669322cf5d3d2ad07`.
- Allowed paths: pure observability/Grafana contracts and decision engine, ControlPlane observability tests, and this work package.
- Pure deterministic L0 projection policy only. No Grafana, telemetry backend, plugin, database, network, filesystem, process, provider, VM, cloud, or deployment side effect was performed.

## Executable defect

`ObservedGrafanaResource` previously represented only resource identity, scope, generation, digest, broad projection kind, and ownership. It could not represent the release or exact reviewed catalog selection that produced a resource. Reconciliation nevertheless treated a managed resource as exact when only kind, digest, and generation matched.

Consequently, an exact managed observation for dashboard `d`, generation `5`, digest `A`, and broad kind `Dashboard` authorized an empty projection for both of these distinct desired resources:

```text
release-a / Dashboard.FleetOverview
release-b / Dashboard.CellHealth
```

Changing only the release or only the same-kind catalog selection still emitted `ProjectionExact = Passed` and no update. `ProjectGrafanaIntent` retained the distinct requests, so this was not an identical-complete-output claim. It was an exact-projection authority defect: the accepted inventory could not prove the release/catalog identity whose checkpoint was allowed to advance.

## Correction

`ManagedGrafanaProjectionProvenance` carries the exact immutable `ObservabilityReleaseId` and structural `GrafanaCatalogSelection`. `ObservedGrafanaResource` enforces one state:

- `ManagedExact` ownership requires non-null managed provenance;
- every non-managed ownership requires null managed provenance; and
- managed provenance selection kind must equal the independently observed broad kind.

Exact managed reconciliation now requires release and full structural selection equality in addition to the existing kind, digest, and generation checks. A release or selection mismatch emits `UpdateGrafanaResource` through the existing authorized path. That change continues to retain the exact desired resource, observed resource, inventory evidence, and request. Unmanaged and conflicting resources remain report-only and can neither be adopted nor deleted.

No decision code, numeric value, trace row, trace order, precedence, authorization entry point, or change kind was added. The correction does not claim that the caller-supplied digest cryptographically binds catalog implementation bytes.

## Evidence

The audit tests execute release-only and same-kind selection-only counterexamples, exact no-op behavior, and all six selection families: dashboard, datasource, folder, alert, contact point, and access policy. Access provenance independently varies entry, access level, role identity, user identity, and subject. A length-delimited invariant fingerprint covers release identity, concrete selection type, kind, catalog entry, every access field, and every closed access-subject variant/identity. Replay is stable across `en-US`, `tr-TR`, and `ar-SA`; desired and inventory permutations converge to the same canonical output.

Constructor tests prove managed ownership if and only if provenance exists, reject kind/provenance disagreement, and preserve unmanaged/conflicting drift behavior. Assembly-wide construction closure enumerates every declared public static and instance method/accessor on every exported type. It permits exactly the four real `ObservabilityDecisionEngine` decision originators plus the sealed decision record's non-originating compiler clone. Every abstract and concrete intent/change record contributes only its exact non-originating compiler clone; the decision's exact getter is the only other public method returning an observability output. Every concrete decision/intent/change record is sealed, has no public constructor or deconstructor, and exposes getter-only public properties, so a clone can copy trusted immutable output but cannot transform it. The observed-resource provenance constructor surface is independently pinned.

The historical replay corpus remains byte-identical with SHA-256 `b725a4b56e7b7afc33a2554d2596713ec84989ca64f70dc9d67f3a507dbdf2e8`. Its v1 projection fingerprint covers the historical change/trace/checkpoint surface and intentionally does not claim managed release/catalog provenance. Audit 4's dedicated complete fingerprint and counterexamples provide that evidence; rewriting the historical fixtures would overstate their original coverage.

## Evidence boundary and nonclaims

This audit proves only how the pure evaluator classifies caller-supplied immutable managed inventory. It does not prove that an adapter can obtain, authenticate, persist, or atomically checkpoint Grafana release/catalog metadata. It does not implement or qualify Grafana provisioning, a data-source plugin, operator authentication, OIDC, telemetry ingestion/query/storage, HA, alert delivery, journal persistence, checkpoint atomicity, ARM64, L0C, L3S/L4, or production deployment.

It introduces no query or configuration text, URL, credential, secret, callback, filesystem path, backend/client SDK, clock, I/O, authority permit, provider mutation, VM, cloud, or deployment surface.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode --nologo
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore --nologo -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj -c Release --no-build --no-restore -- --disable-logo --no-progress
git diff --check
```

Before the final integration rebase, the focused provenance audit passed 7/7, the focused construction-closure review passed 2/2, and the pre-correction ControlPlane executable passed 619/619 with zero failures or skips. Final exact-tree whole-solution counts are recorded in the integration handoff.


---

# FILE: docs/work-packages/phase1-operation-core.md

# Phase 1 fenced operation core

## Goal

Implement a pure operation decision core for `INV-004` and `INV-005`: desired/observed reconciliation, fencing, durable journal decisions, and deterministic replay. It emits intents only and performs no I/O.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/**`
- `docs/work-packages/handoffs/phase1-operation-core.md`

## Required behavior

- Immutable desired and observed inputs with stable aggregate ID, generation/resource version, writer epoch, and observation identity.
- Closed operation states and typed errors. Accept exactly one owner epoch; stale generations/epochs and conflicting idempotency keys hold or reject without emitting mutation.
- Model prepare/authorize/dispatch/observe/terminal checkpoints so an authorized irreversible intent is resumed, never superseded by a conflicting new operation.
- Decisions are append-only journal events plus typed adapter intents. Replaying identical history and input yields structurally identical output and state digest.
- Deadlines and time are explicit inputs. No wall clock, NATS, filesystem, environment, sockets, provider SDKs, or arbitrary callbacks.
- Tests for duplicate/reordered events, stale writer, crash at each checkpoint, deadline edges, conflicting terminal observations, and restoration digest equality.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`


---

# FILE: docs/work-packages/phase1-operations-audit3.md

# Phase 1 operations work-request continuity audit

## Scope

- Predecessor: `5b05f4b70dca888dda9ee665f6164345419c31c1` after the final central rebase.
- Requirements: `INV-005` command replay identity and `INV-006` stale/conflicting provider observation rejection.
- Allowed production path: `src/TerraScale.Orchestrator.ControlPlane/Operations/OperationEngine.cs`.
- Allowed test path: `tests/TerraScale.Orchestrator.ControlPlane.Tests/OperationWorkRequestContinuityCounterexampleTests.cs`.
- Allowed documentation paths: this manifest and `docs/work-packages/handoffs/phase1-operations-audit3.md`.

## Counterexample and acceptance

After a provider operation records an `InProgress` observation for work request `provider-work-1`,
the prior policy accepted a later success observation for `provider-work-2`. The accepted event could
therefore complete the frozen operation from a different provider request.

Once a non-null provider work-request identity is observed, later observations must retain it exactly.
A missing identity may remain missing or establish the first non-null identity. Exact observation replay
is evaluated first, observation-ID rebinding second, work-request continuity third, and prior-final
conflict fourth. Commands and journal replay use the same precedence and the existing
`ConflictingTerminalObservation` error.

## Boundaries

This package changes no public shape, enum, digest domain, solution/package file, registry, schema,
composition root, adapter, or external system. It performs no provider, NATS, filesystem mutation,
process-control, lab, VM, or deployment action. It does not claim provider adapter conformance, L0C,
mutation score, model completeness, or deployment qualification.

## Verification

- Release build with warnings as errors.
- Focused work-request regressions.
- Full ControlPlane suite and all five solution test suites.
- `git diff --check` and clean branch status.


---

# FILE: docs/work-packages/phase1-predeployment-evidence-core.md

# Phase 1 pre-deployment evidence core

## Predecessor

- Contract steward commit: `b9d493c` plus the reviewed observability pure-core commit.
- Production signing technology, CI identity/KMS custody, approval authority, coverage tooling, mutation tooling, NATS pin, and release thresholds beyond the frozen specification remain unresolved selections and must stay explicit inputs.

## Goal

Implement the canonical evidence manifest, exact-subject invalidation, policy decision, opaque-signature verification boundary, and deployment-gate verifier required by `ORCHESTRATOR.md:1114-1180`. This lane cannot mint production acceptance evidence or credentials.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Evidence/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Evidence*.cs`
- `docs/work-packages/handoffs/phase1-predeployment-evidence-core.md`

## Required behavior

- Immutable bounded tree/dependency-lock/schema/test-binary/architecture-artifact/trace/coverage/mutation/fuzz/model/corpus/L0C/analyzer/approver/signing-profile/signing-identity/evidence identities and canonical SHA-256 values; checked counts, percentages, durations, schedules, generations, and sequence values; closed lane/result/error/action catalogs.
- One canonical evidence subject binds the exact Git tree, dependency lock, generated schema digest, every test binary digest, linux-x64 and linux-arm64 single-file artifact digests, per-suite test counts, requirement trace digest/counts, branch coverage, mutation results, fuzz target/corpus/results, model schedules/seeds/corpus, NATS conformance result, analyzer/dependency/vulnerability/license/secret-scan results, pinned toolchain digest, and approver identity. No field can be omitted or substituted.
- Caller-supplied policy encodes feature/full lane, required domains, cold-run requirement, minimum test/branch/mutation/property/model/fuzz/flake thresholds, permitted exclusions, required architectures, and whether reuse is allowed. No threshold/default is invented. Safety/authorization/durability/deletion exclusions and surviving safety mutants are always rejected regardless of caller policy.
- Content-addressed shard reuse is accepted only when source, transitive contracts, tests, corpus, dependencies, generators, schemas, and toolchain digests are byte-identical and the policy permits reuse. Shared-contract/security/toolchain or cold-first-candidate changes force full execution.
- A signed envelope binds a canonical payload digest, signing profile, signing identity, signature identity, generation, and expiry sequence. Verification uses an injected opaque verifier outcome only; the core never accepts private keys, credentials, arbitrary signature algorithms, callback delegates, or self-attesting booleans. Verification failure/exception/unknown outcome is a typed hold/reject and never emits deployment authority.
- Exact-subject verification returns a closed allow-dependency-conformance / allow-L1S-credential-release / hold decision. Any source/dependency/schema/test/binary/evidence/signature/expiry mismatch invalidates it. L1S authority additionally requires a complete full deployment-bound lane and a verified signature; a feature shard can never release deployment credentials.
- Outputs expose only closed codes, numeric trace, exact digest subjects, and construction-closed decisions/intents. No report text, JSON blob, command, environment, process, filesystem, network, clock, CI/provider SDK, key material, credential, or deployment mutation.
- Defensive bounded copies; culture/permutation/replay; every field substitution; missing/duplicate domain; arithmetic overflow; threshold boundary; forbidden exclusion; surviving safety mutant; insufficient fuzz/model/property/flake evidence; invalid shard reuse; stale/future/expired envelope; verifier exception/unknown; x64/arm64 substitution; secret-safe and public-forgery tests.
- The handoff must state clearly that this is the pure manifest/policy/verification core. It does not claim an executed full L0/L0C run, production signer/KMS qualification, dual-architecture reproducibility result, or a deployable attestation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`


---

# FILE: docs/work-packages/phase1-protocol-command-receipt-audit3.md

# Phase 1 Protocol accepted-command receipt audit

## Scope and base

- Base: central `chore/phase0-bootstrap` at `8e90364c960cee44ebeacb4c8e0dbdfb5ac5da43`.
- Allowed paths: `src/TerraScale.Orchestrator.Protocol/CommandValidation.cs`, Protocol tests, and this work package.
- Pure in-memory command validation only. No serializer, NATS process, socket, filesystem, clock API, secret retrieval, VM, provider, or deployment operation is introduced.

## Proven gap

Before this audit, every accepted command returned the same complete public value: `CommandValidationResult { Error = None, IsValid = True }`. A valid protocol N command and a different valid N-1 command therefore produced equal accepted results even when their generations, operation identities, idempotency identities, and signatures differed. A durable caller could not persist which signed envelope validation accepted without rejoining the caller-controlled input.

## Contract correction

Successful validation now emits a construction-closed immutable `CommandAcceptance`. It retains the exact protocol revision, cell, aggregate, desired generation, writer epoch, operation, idempotency key, issued/expires times, delivery attempt, payload digest, signature, and explicit validation time. Its value equality makes identical replay equal and makes every retained-field substitution unequal.

The receipt deliberately does not retain the raw opaque payload. The accepted digest and signature bind that payload without encouraging a durable audit projection to duplicate possibly secret bytes. Receipt formatting redacts the digest and signature. The type exposes no public constructor, setter, deconstructor, clone, or public factory.

Every rejection and the default result retain `Acceptance = null`. The existing error numbers and exact precedence remain unchanged:

```text
InvalidValidationContext -> MalformedEnvelope -> UnsupportedProtocolVersion
-> InvalidValidityWindow -> NotYetValid -> Expired -> WrongCell
-> WrongAggregateIdentity -> StaleGeneration -> StaleWriterEpoch
-> PayloadDigestMismatch/VerificationFailed
-> InvalidSignature/SignatureVerificationFailed
```

Only the final valid-signature branch constructs the receipt.

## Evidence boundary

This is an accepted-envelope receipt. It is not a receipt for the digest/signature verifier implementation or for the complete validation-context policy. In particular, it does not retain the accepted-version set, minimum generation/epoch, allowed skew, or verifier identities. Callers that require complete authorization provenance must persist that policy evidence separately; this audit makes no wire-codec, serialization, canonical-byte, NATS-conformance, or deployment-readiness claim.

## Verification

The focused regression covers N versus N-1 output inequality, exact receipt fields, identical replay equality, per-field inequality, receipt absence on every generated rejection/default, construction closure, payload omission, and redacted formatting. Existing 1,000-case and 10,000-case validators now include input-sensitive accepted-result fingerprints and require acceptance scope to match success under multiple cultures.

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj -c Release --no-build --no-restore -- --no-progress
git diff --check
```

Recorded on this exact branch: Release solution build succeeded with zero warnings and zero errors; Protocol passed 70/70; all five repository executables passed 771/771 (ControlPlane 562, Contract 24, Model 38, Protocol 70, Scheduler 77).


---

# FILE: docs/work-packages/phase1-protocol-contract-completeness.md

# Phase 1 protocol contract-completeness property shard

## Scope and base

- Base: central `chore/phase0-bootstrap` at `7d960ecebb654a6fdcb4cc451e0bf98892097ba1`.
- Narrow production hardening is limited to accepted-version input capture and fatal-exception propagation in existing command-verifier and permission-policy wrappers.
- It starts no process, socket, NATS server, VM, container, systemd unit, cloud/provider operation, or deployment and makes no L0/L0C or production-readiness claim.

## Properties

- 1,000 materially distinct command-admission cases use exact independent error oracles, deterministic replay, culture changes, unique identities/generations/epochs/timestamps/payloads, and secret-safe result checks.
- 1,000 distinct unknown positive protocol revisions are rejected before digest or signature verification.
- 1,000 distinct envelopes prove every in-memory `CommandSignedMaterial` field remains bound to its source envelope.
- 1,000 distinct binary values prove defensive copy, equality, truncation/extension distinction, and redacted formatting without inventing a byte ceiling.
- 1,000 distinct Unicode subjects pin the accepted UTF-16 code-unit limit semantics and exact boundary behavior.
- 1,000 distinct corpus mutations cover oversize, truncation, malformed UTF-8, unknown and duplicate fields, unknown family/error vocabulary, invalid seed, and digest tampering.
- The embedded corpus is read from seekable or non-seekable streams within a byte bound, decoded as strict UTF-8, checked against a whole-file SHA-256 pin, and validated against closed family/error vocabularies.

## Proven production hardening

- `CommandValidationContext` now captures at most 4,096 caller items before deduplication. This public technical ceiling is intentionally far above the ordinary N/N-1 set; it is an acquisition/denial-of-service bound, not permission to accept 4,096 wire versions. The implementation checks maximum+1 after `MoveNext` and before the extra `Current`, ignores lying collection counts, snapshots defensively, bounds endless duplicate sequences, translates ordinary failures from every iterator phase to `ArgumentException` with no inner exception or iterator text, and propagates `OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException`.
- Command digest/signature verifier wrappers retain their existing typed failures for ordinary exceptions but propagate those three fatal runtime exceptions.
- Subject permission allow/deny enumeration retains the caller-supplied `MaximumPermissionPatternCount`; no second pattern business cap was invented. Ordinary acquisition failures remain `EnumerationFailed`, while fatal runtime failures now propagate from `GetEnumerator`, `MoveNext`, `Current`, and `Dispose`.

## Explicit deferred gaps

The accepted `phase1-protocol-fuzz-shard` and subject-grammar handoffs intentionally leave these transport decisions open. This shard does not silently close them:

- There is no public command/event/header/snapshot wire codec, canonical serialized form, schema conversion, or unknown-optional-field preservation surface. Therefore canonical encoding, serialized truncation, duplicate/unknown wire fields, malformed wire UTF-8, and N/N-1 schema round-trip remain unimplemented production requirements.
- Opaque payload, digest, signature, and command identifiers have no reviewed serialized byte ceilings. Selecting limits is an owner/API compatibility decision.
- Subject limits count .NET UTF-16 code units. A future transport adapter must separately bound encoded UTF-8 bytes.
- Subject-pattern count remains a caller-policy trust boundary: `SubjectGrammarLimits.MaximumPermissionPatternCount` must be selected by the caller before untrusted policy material is collected. This shard preserves that accepted contract and adds no global pattern-count policy.

These are audit findings, not acceptance claims. A future production work package must select compatibility behavior and add transport-byte/fuzz fixtures before any untrusted serialized input is admitted.

## Verification

```text
dotnet test tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj --no-restore --verbosity minimal
git diff --check
```


---

# FILE: docs/work-packages/phase1-protocol-fuzz-shard.md

# Phase 1 deterministic protocol fuzz shard

## Base

- `origin/chore/phase0-bootstrap`

## Allowed paths

- `tests/TerraScale.Orchestrator.Protocol.Tests/Fuzz/**`
- `tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj`
- `test-corpus/protocol/**`
- narrow review-approved expansion: `src/TerraScale.Orchestrator.Protocol/Subjects/SubjectPermissionPolicy.cs`
- this work package and `docs/work-packages/handoffs/phase1-protocol-fuzz-shard.md`

## Goal

Exercise every public parser and validator currently exposed by `TerraScale.Orchestrator.Protocol` with deterministic generated valid and malformed cases. Each target family executes at least 10,000 cases from an explicit seed and proves replay determinism, fail-closed output, enforcement of currently declared bounds, secret-safe diagnostics, and absence of forged accepted output.

The opaque payload, digest, and signature factories currently declare no maximum byte length. This shard samples deterministic lengths from 0 through 256 and proves copy, empty-input, truncation, extension, equality, and redaction behavior; it does not claim a production size ceiling. Selecting cryptographic and payload byte limits requires a separate caller-policy/API work package.

The shard uses no external fuzz package, random global, clock, filesystem mutation, network, process, NATS server, or adapter. Checked-in corpus resources are bounded, content-addressed, and loaded from embedded resources. This package does not claim the ORCHESTRATOR time-based fuzz budget, full fuzz evidence, L0C, or deployment qualification.

## Verification

```text
dotnet test tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj
```


---

# FILE: docs/work-packages/phase1-protocol-negotiation-completeness.md

# Phase 1 protocol-negotiation completeness audit

## Scope and base

- Base: central `chore/phase0-bootstrap` at `1eac098`.
- Pure N/N-1 compatibility policy and accepted-output evidence only.
- Allowed implementation paths: `src/TerraScale.Orchestrator.ControlPlane/Messaging/MessagingContracts.cs` and `MessagingPolicyEngine.cs`.
- Allowed evidence paths: the messaging/negotiation tests in `tests/TerraScale.Orchestrator.ControlPlane.Tests/**`, this work package, and its handoff.
- No serializer, wire codec, canonical byte representation, byte cap, signing algorithm, transport, network, process, NATS server, VM, container, provider, or deployment work is in scope.

## Proven defect and correction

`DecideCompatibility` already required the exact adjacent positive version window and the exhaustive four-feature by three-direction compatibility matrix. Its successful public output, however, contained only the generic `CompatibilityAccepted` trace. Compatibility for versions `2/1` and `1000/999` therefore produced identical complete public outputs, so a caller could not persist or audit which exact window and matrix had been accepted.

The accepted decision now carries a construction-closed `CompatibilityAcceptance`. It contains the exact current and previous versions plus a defensive, immutable matrix ordered by numeric feature and direction. Rejected compatibility decisions and all topology, replacement, and partition decisions carry no compatibility acceptance. Existing trace and enum values are unchanged.

## Deterministic properties

- 1,000 distinct positive adjacent windows include `long.MaxValue / (long.MaxValue - 1)` and prove exact receipt scope.
- Every accepted receipt contains exactly the closed four `CompatibilityFeature` values crossed with the three `CompatibilityPair` values, in numeric feature-then-pair order.
- Caller ordering, culture, and source-array mutation do not affect the receipt or output signature.
- 1,000 rejected cases cover non-positive and non-adjacent windows, the impossible `current=1` window, undefined/missing/duplicate/unavailable evidence, and incomplete/duplicate/undefined feature catalogs with exact existing error precedence. No rejection emits an acceptance.
- Reflection proves that the acceptance type is sealed and has no public constructor, setter, factory, deconstructor, or record clone.
- Existing 1,000-case topology, replacement, and partition properties prove their decisions remain compatibility-unscoped.

## Verification

```text
dotnet build tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-restore --verbosity minimal
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj --no-build
dotnet test --solution TerraScale.Orchestrator.slnx --no-build --output Normal
git diff --check
```

This pure audit is not NATS conformance, time-based fuzzing, mutation evidence, N/N-1 process interoperability, serialized schema compatibility, or deployment qualification.


---

# FILE: docs/work-packages/phase1-protocol-primitives.md

# Phase 1 protocol primitives

## Goal

Implement provider-neutral, immutable protocol value objects and command validation for `INV-005`, following the envelope at `ORCHESTRATOR.md:580`. This is a pure L0 tranche, not a frozen wire contract.

## Allowed paths

- `src/TerraScale.Orchestrator.Contracts/**`
- `src/TerraScale.Orchestrator.Protocol/**`
- `tests/TerraScale.Orchestrator.Protocol.Tests/**`
- `docs/work-packages/handoffs/phase1-protocol-primitives.md`

## Required behavior

- Strong non-empty identifiers for cell, aggregate, operation, and idempotency identity; positive generation/epoch/attempt types.
- An immutable command envelope carrying every field named by the specification, with payload and signature represented only as digests/opaque bytes and never rendered by `ToString`.
- A pure validator using an explicit validation context and supplied `now`; reject malformed, expired/not-yet-valid, wrong-cell, wrong-identity, stale generation, stale epoch, digest mismatch, and invalid signature. Return a typed closed error catalog, never exception text.
- Validation order must be deterministic and tests must cover boundaries, replay of an identical envelope, and secret-safe formatting.
- Do not choose signing algorithms, clock-skew tolerances, serialization formats, NATS subjects, or owner-decision defaults. These are caller inputs or remain absent.

## Verification

`dotnet test tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj`


---

# FILE: docs/work-packages/phase1-provider-create-observation-audit4.md

# Phase 1 provider create-observation audit 4

## Goal

Close the provider create-absence and resolved-observation replay path across regional authority scopes.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Providers/ProviderModels.cs`
- `src/TerraScale.Orchestrator.ControlPlane/Providers/ProviderOwnershipEngine.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/ProviderFourthAuditRegressionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/ProviderOwnershipTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/ProviderOwnershipCompletenessPropertyTests.cs`
- `docs/work-packages/phase1-provider-create-observation-audit4.md`
- `docs/work-packages/handoffs/phase1-provider-create-observation-audit4.md`

## Contract

Every provider create observation carries an exact cell and compartment. Authorization accepts an absent or resolved create observation only when that scope matches the operation context before generation and state can pass. Conflicting same-key observations remain ambiguous and fail closed. A resolved-create observation intent retains the exact observation-scope references.

## Compatibility

Requiring cell and compartment is an intentional breaking constructor correction within the draft pure provider contract. Decision codes, numerics, ordering, precedence, operation-context fingerprints, and action behavior do not change.

## Boundary

This is pure deterministic evidence-scope policy. It performs no provider call, cloud mutation, network, filesystem, process, VM, deployment, or external side effect.


---

# FILE: docs/work-packages/phase1-provider-ownership-completeness.md

# Phase 1 provider ownership completeness shard

## Goal

Adversarially complete the pure provider ownership and Pulumi handoff policy without invoking a provider, SDK, network, process, filesystem, or deployment lane.

## Scope

- Bind every provider call observation to the exact immutable operation context it attests.
- Bind Pulumi handoff acceptance to the caller-supplied current accepted bootstrap-generation high-water; reject only lower candidates while preserving equal retries and forward progress.
- Exercise 1,000 deterministic cases in each property family, rotating across every operation-fingerprint dimension, provider call lifecycle outcome, closed provider action, and handoff inventory/proof dimension.
- Preserve stable existing numeric trace IDs, typed-intent/output closure, response-lost idempotency, durable higher-epoch resume, defensive snapshot bounds, fatal exception propagation, and tag-not-authority boundary.
- Reuse the existing pinned provider replay corpus and enumerable-boundary shard; do not duplicate those fixtures or claim mutation, NATS, cloud, OCI, Pulumi, L0/L0C, L3S, L4, or deployment evidence.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Providers/**`
- provider call-site updates in existing tests
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/ProviderOwnershipCompletenessPropertyTests.cs`
- this work package and its handoff

## Verification

Run the focused completeness shard, the complete ControlPlane test executable, a warnings-as-errors Release build, and `git diff --check`.


---

# FILE: docs/work-packages/phase1-provider-ownership-core.md

# Phase 1 provider ownership and handoff decision core

## Predecessor

- Contract steward commit: `85db082`
- Draft Phase 1 contracts; OCI remains the first candidate adapter but this core is provider-neutral.

## Goal

Implement pure provider operation authorization and Pulumi-to-regional ownership handoff decisions from `ORCHESTRATOR.md:627-727`. The core emits typed intents only and never calls a provider.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Providers/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Provider*.cs`
- `docs/work-packages/handoffs/phase1-provider-ownership-core.md`

## Required behavior

- Immutable bounded provider/cell/compartment/resource/template/idempotency/work-request identities, positive generations/epochs, closed resource/action/terminal-state/approval/compensation catalogs, and explicit deadlines as caller evidence rather than wall-clock reads.
- A provider mutation context binds exact operation ID, regional authority, compartment, controller epoch, target provider ID or create key, expected observation/generation, desired terminal state, approvals, deadline evidence, idempotency key, and permitted compensations.
- Authorize only exact owned scope and current epoch/generation. Tags are typed inventory evidence and never sufficient authority. Mismatched, incomplete, stale, unknown, duplicate, or conflicting evidence holds/rejects before any intent.
- Once an irreversible provider step is durably authorized, a higher-epoch leader may resume/re-observe that same operation and terminal target but may not supersede it with a conflicting mutation or compensation.
- Model the bootstrap handoff receipt: exact inventory agreement, retain/unmanage proof, regional R3 journal receipt, provider/trust/backup readiness, and activated regional fence are all required before self-management. Historical resource adoption is unrepresentable.
- Emit only closed observe/read-work-request/create/start/stop/terminate/volume/backend/handoff typed intents with exact context and no arbitrary payload, callback, executable text, provider choice, SDK object, or I/O.
- Stable closed trace; defensive copies; culture/permutation determinism; tag-only denial; stale/future epoch/generation; duplicate/conflict; lost-response idempotency; late-call leader race; conflicting terminal target; exact handoff inventory; and secret-safe tests.
- No provider SDK, Pulumi runtime, NATS, files, clock, retries, provider selection, or policy defaults.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-reconciliation-core.md

# Phase 1 desired/observed reconciliation core

## Goal

Implement a pure deterministic desired/observed state engine and dependency planner for Phase 1. It emits typed adapter intents only and owns no domain-specific mutation policy.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Reconciliation/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Reconciliation*.cs`
- `docs/work-packages/handoffs/phase1-reconciliation-core.md`

## Required behavior

- Immutable bounded resource identity, kind, desired generation/digest/dependencies, observation generation/digest/freshness identity, and explicit caller policy.
- Validate unique resources, closed caller-supplied kind catalog, dependency existence, no self-edge/cycle, generation monotonicity, and exact identity pairing.
- Produce a deterministic topological plan independent of input order. A resource is converged only on exact desired generation/digest; stale/missing observations emit Observe, and eligible drift emits Reconcile intent only after dependencies converge.
- A newer-than-desired or conflicting same-generation observation holds fail-closed. Failed/held dependencies propagate a typed hold without hiding the root reason.
- Mutation intents contain desired identity/generation/digest, the exact validated observation proof that authorized drift repair, and sorted dependency proofs; they contain no callbacks, arbitrary payloads, executable data, policy snapshots, or infrastructure behavior.
- Complete stable reason trace, defensive copies, duplicate/permutation/cycle/missing/stale/future/conflict tests, 10k-resource deterministic benchmark-style test, and no mutation of inputs.
- No wall clock, NATS, files, provider/runtime choices, retries, or domain policy defaults.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`


---

# FILE: docs/work-packages/phase1-reconciliation-policy-provenance-audit.md

# Phase 1 reconciliation policy-provenance audit

- Exact audit base: `7cf23edbfef5d7fa3338be52325d6230667cd61d`
- Requirements: `REQ-O014`, `INV-005`
- Scope: pure reconciliation mutation output, independent L0 evidence, and this note
- External I/O or mutation: none

## Counterexample

Two distinct, valid caller-supplied reconciliation policies authorized the same
drift repair. They differed in allowed-kind and generation-floor collections,
resource/dependency bounds, and freshness floor, but the complete public
`ReconcileResourceIntent` and containing plan were identical. Before repair the
focused executable counterexample failed with both public fingerprints equal to:

```text
1:api:service:2:digest-api:api:service:1:old-api:observation-api:10:Ready::DriftEligible
```

The intent already retained the desired resource, exact target observation, and
exact converged dependency observations. It did not retain the policy that
authorized those observations to become a mutation.

## Narrow repair

`ReconcileResourceIntent.AcceptedPolicy` is a getter-only reference to the exact
`ReconciliationRequest.Policy` instance that passed validation and authorized
drift. The planner supplies it at the sole mutation-intent construction site.
Observe, hold, and converged outputs remain unchanged and expose no policy.

No policy default, boolean authorization alias, flattened duplicate DTO, public
factory, action, error, reason, trace, ordering rule, validation precedence, or
acceptance path changed. No adapter or side effect was introduced.

## Independent evidence

- Eligible mutation paths with zero, one, and two converged dependencies retain
  the exact policy reference; cloned intents retain the same reference.
- Converged, observe, and hold variants expose no policy property.
- Twelve independently admissible variants cover every policy scalar plus
  allowed-kind and generation-floor count/item/key/value sensitivity.
- Desired, observed, dependency, allowed-kind, and generation-floor permutations
  remain canonical across three cultures and exact replay.
- The existing 12-entry reconciliation replay corpus loads through its unchanged
  whole-file SHA-256 gate.
- Reflection closes the exported plan origin and inventories plan, step, base
  and concrete outputs, proofs, policy, request, collections, clones,
  constructors, properties, setters, and deconstruction.

## Requirement mapping and limits

This closes the `REQ-O014` native GitOps requirement that policy evaluation
precedes a recorded plan and the `INV-005` generation-bound crash/replay
boundary. It also satisfies the Phase 1 rule that adapters execute persisted
typed intents rather than reconstructing business authorization from unrelated
caller state.

The policy was already mandatory caller input. Retaining it does not choose an
owner question, provider behavior, retry policy, cost/storage/RPO/RTO target,
role catalog, or rollout default. This audit does not claim persistence, Git,
NATS, adapter, L0/L0C, VM, cloud, deployment, or production acceptance.


---

# FILE: docs/work-packages/phase1-reconciliation-property-shard.md

# Phase 1 reconciliation property/replay shard

## Goal

Exercise the existing pure desired/observed reconciliation engine with independent generated oracles and a strict deterministic replay corpus.

## Scope

- At least 1,000 materially distinct cases for deterministic dependency ordering and exact output subjects.
- At least 1,000 cases spanning exact, missing, stale, failed, held, future, conflicting, and drifted observations.
- At least 1,000 cases spanning missing dependencies, cycles, dependency holds, duplicate resources, and trace/root precedence.
- At least 1,000 cases covering every stable validation error with exact deterministic error tuples, fatal/non-fatal behavior, and side-effect exclusion.
- At least 1,000 adversarial precedence cases covering every reason, output variant, exact root/related resource, and exact seven-field authorizing observation proof.
- Closed inventories pin all 18 validation errors, 11 decision reasons, three defined observed conditions, four output variants, and undefined-condition rejection.
- Desired, observed, and dependency permutations replay identically across non-English cultures.
- A byte-bounded, whole-file SHA-256-pinned, strict-vocabulary, input-sensitive embedded replay corpus.

## Boundary and non-claims

This shard tests a pure decision engine. It performs no filesystem, network, process, NATS, provider, cloud, deployment, or sibling-repository operation and makes no L0/L0C or production-readiness claim. Caller-controlled collection acquisition hardening remains owned by the accepted-output construction-closure work because it is changing `ReconciliationContracts.cs` concurrently.


---

# FILE: docs/work-packages/phase1-reproducible-publish-audit3.md

# Phase 1 reproducible-publish provenance audit 3

## Boundary

- Audit the reproducible-publish tool's successful result construction and public API surface.
- Preserve the existing CLI arguments, canonical output, exit codes, deterministic/offline publish behavior, and
  public request and observation DTO compatibility.
- Perform no restore, publish, network, registry, signing, credential, deployment, VM, or cloud operation.

## Proven counterexample

`ReproduciblePublishResult` and `PublishArtifactResult` had nonpublic constructors, but the public
`PublishObservationVerifier.Evaluate` method was an alternate public result factory. A caller could construct public
request and observation DTOs containing invented successful process state, ELF headers, modes, lengths, and digests,
then receive a result whose `Successful` property was true without copying an input tree, invoking `dotnet publish`,
or observing an artifact.

The pure verifier correctly evaluates trusted observations produced inside the execution path. The defect was its
exported position at the artifact-evidence boundary, not its deterministic evaluation rules.

## Required correction

- Keep the pure observation verifier internal to the reproducible-publish assembly.
- Grant internal access only to the exact ContractTests assembly so offline fake coverage remains exhaustive.
- Keep observation DTOs public for compatibility, but expose no public synchronous or alternate factory returning a
  successful publish result.
- Make `ReproduciblePublisher.RunAsync` the only exported originating result factory; retain its exact asynchronous
  signature and the exact public `Program.Main` and `Program.TryParse` signatures. The sealed record's compiler
  clone is non-originating: it requires an already constructed result and cannot change any result property.
- Preserve failure precedence, catalogs, artifact validation, deterministic inputs, CLI behavior, and canonical
  serialization.

## Evidence

- Enumerate every declared public static and instance method, including property accessors, on every exported type
  and unwrap `Task<T>` return types.
- Require exactly one originating public `ReproduciblePublishResult` route: `ReproduciblePublisher.RunAsync`.
- Permit only the exact parameterless instance clone declared by the sealed result record as a non-originating
  return path, and prove that no result property has a public setter or init route.
- Prove there is no public synchronous or alternate originating result factory and no exported observation verifier.
- Pin nonpublic result constructors, public observation DTO compatibility, the single exact friend assembly, and the
  unchanged CLI/publisher signatures.
- Retain the existing offline pure-verifier matrix for paths, RIDs, ELF validation, output shape, process failures,
  digest replay, input copies, diagnostics, enumeration bounds, and symlink roots.

## Nonclaims

Internal caller-authored observations are trusted test/execution seams, not artifact evidence. A successful public
result proves only what `RunAsync` actually observed during its copied-tree and double-publish execution. It does not
establish ARM64 execution, signing, attestation, registry publication, deployment, L4 qualification, toolchain
provenance beyond the retained contract, or release approval.


---

# FILE: docs/work-packages/phase1-reproducible-publish.md

# Phase 1 reproducible dual-architecture publish

## Predecessor

- Contract steward commit: `4a36bc4`.
- ARM64 runtime qualification, host image, glibc/kernel, signing profile, package mirror, and release approval remain external or owner-controlled evidence.

## Goal

Implement and verify locked, deterministic, self-contained single-file publishes for linux-x64 and linux-arm64 as required by `ORCHESTRATOR.md:1114-1180,1496-1510`. This is build reproducibility evidence only; it never executes or qualifies the ARM64 artifact.

## Allowed paths

- `tools/reproducible-publish/**`
- `tests/TerraScale.Orchestrator.ContractTests/ReproduciblePublish*.cs`
- `tests/TerraScale.Orchestrator.ContractTests/TerraScale.Orchestrator.ContractTests.csproj`
- `src/TerraScale.Orchestrator/TerraScale.Orchestrator.csproj`
- `Directory.Build.props`
- `docs/work-packages/handoffs/phase1-reproducible-publish.md`

## Required behavior

- One reviewed non-shell .NET tool accepts explicit source root, already-restored locked tree, configuration, two isolated output roots, and expected RIDs. It performs no restore, network, Git, signing, credential, deployment, or source mutation.
- Publish linux-x64 and linux-arm64 twice from byte-identical inputs into distinct clean roots using deterministic/CI/path-map/source-date settings and self-contained single-file configuration. Reject an unexpected RID, missing/extra primary executable, multi-file payload where single-file is required, symbolic link, non-regular output, or output escaping its root.
- Verify both outputs are ELF and bind the correct machine type (x86-64 versus AArch64), are not scripts/text, and have distinct architecture artifact digests. Do not execute the cross-architecture artifact.
- Produce a canonical in-memory result with exact tree-input digest supplied by the caller, RID, byte length, SHA-256, repeat SHA-256, reproducibility status, and closed failure codes. Optional checked-in output is not authorized; callers may serialize elsewhere.
- Byte-identical repeat output is required. If .NET apphost/single-file tooling is not reproducible under the pinned toolchain, fail with exact evidence and fix deterministic inputs/configuration; never normalize or rewrite the produced binary after publish.
- Paths are canonicalized and confined beneath the supplied source/output roots. Reject traversal, aliases that collapse the two repeat roots, output inside source, source inside output, and pre-existing nonempty output roots.
- Tool subprocess invocation uses argument lists, fixed environment allowlist/overrides, explicit timeout/cancellation, captured bounded diagnostics represented only as closed codes/counts, and exact exit handling. No arbitrary command text or shell.
- Contract tests cover argument/path validation, symlink/escape, ELF parser truncation/class/endianness/machine, digest stability, output enumeration, timeout/nonzero exit classification, secret-safe results, and public-construction barriers where applicable. A slow opt-in or checked tool invocation performs the real two-RID double publish and reports actual digests; ordinary unit tests use deterministic fake process/file observations without weakening production logic.
- The handoff must distinguish cross-publish evidence from ARM64 execution, L4 qualification, signature, and pre-deployment attestation. Do not claim reproducibility unless the real double-publish command ran successfully for both RIDs.

## Verification

- `dotnet test tests/TerraScale.Orchestrator.ContractTests/TerraScale.Orchestrator.ContractTests.csproj`
- documented real locked double-publish command from the tool handoff


---

# FILE: docs/work-packages/phase1-resource-contracts.md

# Phase 1 resource contracts

## Goal

Implement the draft, provider-neutral common resource metadata and closed admitted-role model described at `ORCHESTRATOR.md:393-449`. This tranche does not freeze serialization or select unresolved runtime/observability/VPN implementations.

## Allowed paths

- `src/TerraScale.Orchestrator.Contracts/Resources/**`
- `tests/TerraScale.Orchestrator.ModelTests/**` except the project file and lock file
- `docs/work-packages/handoffs/phase1-resource-contracts.md`

## Required behavior

- Strong, bounded, canonical value objects for API version, stable resource ID, generation, resource version, ownership, creation actor, and audit correlation ID. Default values are invalid.
- Immutable common resource metadata with explicit validation and no silent defaults.
- A closed version-1 admitted-role discriminated catalog covering only the abstract first-party roles named in the document. Unresolved concrete metrics/VPN/runtime selections remain required descriptor inputs, not enum choices or defaults.
- Role descriptors expose only typed allowed runtimes, ports, capabilities, volume purposes, secret-profile references, health contracts, placement constraints, scaling-controller ownership, and resource bounds. No arbitrary executable, image pull tag, host path, unit text, privileged flag, Linux capability string, or NATS permission is representable.
- Defensive collection copying, duplicate rejection, stable ordering, deterministic structural equality/digest input projection, and fail-closed unknown enum/version behavior.
- Tests must prove every admitted role, every rejected unknown/default value, collection mutation isolation, duplicate handling, absence of dangerous fields/types, and deterministic output.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ModelTests/TerraScale.Orchestrator.ModelTests.csproj`


---

# FILE: docs/work-packages/phase1-resource-projection-audit3.md

# Phase 1 resource projection audit 3

## Goal

Close the draft read-only role-descriptor projection collision that discarded the exact owner-selected metrics, regional-telemetry, or VPN implementation.

## Allowed paths

- `tools/TerraScale.Orchestrator.SchemaGenerator/SchemaArtifacts.cs`
- `schemas/v1/role-descriptor.schema.json`
- `tests/TerraScale.Orchestrator.ContractTests/GeneratedSchemaTests.cs`
- `docs/work-packages/phase1-resource-projection-audit3.md`
- `docs/work-packages/handoffs/phase1-resource-projection-audit3.md`

## Contract

The generated read-only descriptor role is the same closed admitted-role shape without a redundant nested API version. Metrics-store, regional-telemetry-agent, and VPN-coordination-relay roles require their exact implementation domain and catalog-entry identifier. Ordinary roles forbid implementation provenance, and all roles reject unknown kinds and fields.

## Compatibility boundary

This is a breaking correction only to a draft internal read-only documentation projection whose serialization was explicitly not frozen. It does not change C# resource contracts, enum names or numerics, the standalone admitted-role artifact, a runtime wire format, manifest admission, or production behavior.


---

# FILE: docs/work-packages/phase1-runtime-observe-output-audit4.md

# Phase 1 runtime executor-observation output audit 4

## Goal

Close the proven accepted-output collision where response-lost lifecycle recovery discarded the validated executor node, fencing, generation, action, observation, admission, specification, inventory, and health scope.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Runtime/RuntimeModels.cs`
- `src/TerraScale.Orchestrator.ControlPlane/Runtime/RuntimeDecisionEngine.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/RuntimeFourthAuditRegressionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/RuntimeDecisionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/RuntimeLifecycleObservationPropertyTests.cs`
- `docs/work-packages/phase1-runtime-observe-output-audit4.md`
- `docs/work-packages/handoffs/phase1-runtime-observe-output-audit4.md`

## Contract

An authorized `ObserveExecutorIntent` retains the exact validated immutable `RuntimeLifecycleRequest`. Existing operation and allocation identity getters derive solely from that request. Construction remains internal; the existing immutable record-copy route is retained, and no public constructor, setter, deconstructor, flattened constructor, or factory is added. Authorization, traces, codes, numeric values, order, precedence, and every other intent remain unchanged.

## Boundary

The retained request is in-memory recovery provenance. It does not prove an executor query happened, identify a live PID/cgroup/unit invocation, recover a lost response, validate systemd/containerd behavior, authenticate an artifact, or qualify a deployment. This work performs no process, systemd, containerd, filesystem, network, provider, VM, cloud, deployment, or CI-dispatch operation.

## Review closure

Final adversarial review required independent sensitivity for every nested request leaf, real allocation and nested-evidence permutations, and union-output construction closure. The corrected tests share the production-subject fingerprint's conflict projection for single-leaf checks, reverse two inventory entries plus their port/volume and health order, and inventory every exported public method/accessor returning the exact intent, `RuntimeIntent`, or `RuntimeDecision`.


---

# FILE: docs/work-packages/phase1-runtime-selfupdate-core.md

# Phase 1 runtime lifecycle and self-update core

## Predecessor

- Contract steward commit: `5315e7d`
- Host image, systemd/container runtime versions, artifact signing technology, health timeouts, compatibility window, and rollback policy values remain explicit inputs.

## Goal

Implement pure admitted workload lifecycle decisions for native systemd/container runtimes plus orchestrator A/B self-update from `ORCHESTRATOR.md:359-390,843-879` and Phase 2/3 lifecycle requirements. It emits typed executor/bootstrap intents only.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Runtime/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Runtime*.cs`
- `docs/work-packages/handoffs/phase1-runtime-selfupdate-core.md`

## Required behavior

- Immutable bounded workload/allocation/node/artifact/digest/signature/config/secret-version/volume/port/health/release/slot/operation identities; positive generations/epochs/attempts; closed native/container runtime and lifecycle/action/error catalogs.
- Only the admitted role/runtime contract can produce an allocation. Native intents select reviewed artifact/unit descriptors; container intents select digest-pinned OCI artifact/runtime descriptors. Shell/unit text, privileged flags, arbitrary capabilities, host paths, mutable tags, and executable caller strings are unrepresentable.
- Lifecycle is restartable desired/observed progression: prepare artifacts/secrets/volumes/ports, stage config, start, distinguish liveness/readiness/dependency health, serve, drain, stop, and clean retained/ephemeral material by explicit policy. Exit zero alone is never readiness.
- Same operation/generation is idempotent; stale/lower epoch or generation rejects, future/conflicting observation holds, lost executor response re-observes, and no second start/stop is emitted without proof.
- Self-update verifies exact signed artifact/protocol/schema N/N-1 evidence and local forward+rollback availability, stages inactive A/B slot, switches once, proves new health, and either commits or deterministically rolls back. It never overwrites the active/only known-good slot or deletes rollback material early.
- Emit closed fetch/verify/stage/mount/start/health/drain/stop/cleanup/switch-slot/commit/rollback/hold intents with typed parameters and stable code/numeric trace; no process command/unit text/container spec blob/secret value/private key/callback/time read/filesystem/network/I/O.
- Defensive copies; culture/permutation/replay determinism; runtime admission matrix; port/volume conflicts; stale/future evidence; lost response; readiness dependency failure; A/B crash at every step; incompatible update; failed rollback; and forbidden-shape/secret-safe tests.
- No systemd/containerd/OCI/process/filesystem/network/clock package, retry/timeout/runtime/release default, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-scheduler-audit2.md

# Phase 1 scheduler capacity/completeness audit

## Goal

Adversarially audit the existing pure scheduler policy against the hard-resource,
quorum, disruption-budget, anti-affinity, topology-spread, reserve, deterministic
tie-break, and explainable-rejection requirements in `ORCHESTRATOR.md`.

## Allowed paths

- `src/TerraScale.Orchestrator.Scheduler/Availability/**`
- `tests/TerraScale.Orchestrator.Scheduler.Tests/**`
- `docs/work-packages/phase1-scheduler-audit2.md`
- `docs/work-packages/handoffs/phase1-scheduler-audit2.md`

## Required behavior

- Prove every accepted placement fits the caller-observed resources even when an
  explicitly supplied N+1 reserve may be consumed.
- Preserve the existing twenty availability trace rows and numeric reason IDs as an
  exact prefix, then append explicit capacity reasons for all eight resource
  dimensions.
- Keep reserve preservation independent from fundamental capacity admission:
  `MayConsume` disables only the reserve floor, never the capacity floor.
- Emit one stable, complete reason-code order for placement, maintenance, drain,
  invalid-target, and held-evidence paths.
- Exercise every closed caller-veto value, including volume-locality holds, and all
  eight capacity dimensions with deterministic 1,000-case properties.

## Boundaries

This lane changes no scheduler default, topology number, critical-service policy,
provider/runtime behavior, package, or external system. Caller-owned stateful vetoes,
product placement, and capacities/reservations remain outside the pure evaluator.

## Verification

Run locked restore, warnings-as-errors Release build, the focused scheduler suite,
the full solution suite, and `git diff --check` on the final rebased tree.


---

# FILE: docs/work-packages/phase1-scheduler-audit3.md

# Phase 1 scheduler observation-generation audit

## Goal

Close the availability evaluator's accepted-observation replay gap without changing
placement defaults or moving persistence into the pure scheduler. An authorization
must be bound to the exact generation of the observation snapshot already accepted
by its caller.

## Allowed paths

- `src/TerraScale.Orchestrator.Scheduler/Availability/**`
- `tests/TerraScale.Orchestrator.Scheduler.Tests/**`
- `docs/work-packages/phase1-scheduler-audit3.md`
- `docs/work-packages/handoffs/phase1-scheduler-audit3.md`

## Required behavior

- Require positive candidate and current-accepted observation generations on every
  availability evaluation request.
- Hold a lower candidate generation as rollback evidence and a higher candidate
  generation as not-yet-accepted evidence; equal generations preserve policy
  behavior and retry determinism.
- Preserve the existing reason IDs and trace rows 1 through 28 exactly, then append
  explicit rollback and future-generation reasons as numeric IDs 29 and 30.
- Let either generation hold participate in evidence precedence before target and
  policy evaluation even though the two compatibility rows are appended to the
  trace after the established 28-row prefix.
- Pin exact enum values, trace order, observed/required values, output signatures,
  constructor validation, and lower/equal/higher properties.

## Boundaries

This is a pure L0 policy correction. The caller remains responsible for accepting
and durably storing an observation generation. This lane adds no signature,
timestamp, persistence, NATS, provider, runtime, filesystem, process, or network
behavior and selects no topology or availability default.

## Verification

Run locked restore, warnings-as-errors Release build, focused scheduler tests, the
complete solution test set, and `git diff --check` on the final rebased tree.


---

# FILE: docs/work-packages/phase1-scheduler-availability-provenance-audit4.md

# Phase 1 scheduler availability authorization provenance audit

## Scope and base

- Base: central `chore/phase0-bootstrap` at `2c7015589841311a3e1027e81a1a78273cfc7967` after the required final rebase.
- Allowed paths: scheduler availability contracts/evaluator, scheduler tests, and this work package.
- Pure deterministic L0 policy only; no scheduler adapter, NATS, filesystem, process, network, systemd, container, VM, cloud/provider, credential, drain, maintenance, placement, or deployment side effect.

## Executable defect

Two valid placement requests with different replica, node, and failure-domain targets produced the same complete public admitted decision when their counts, resources, policy, and observations otherwise matched:

```text
A: replica-d -> node-d / fd-d
B: replica-e -> node-e / fd-e
```

Both exposed only `Admitted = true` plus the same thirty numeric trace rows. The accepted output therefore erased which exact change, service policy, observation generation/snapshot, and resource request had passed the pure availability gates. A persisted admission could be relabeled only by rejoining caller-controlled input.

## Correction

`AvailabilityDecision.AcceptedRequest` now retains the exact already validated immutable `AvailabilityEvaluationRequest` only when every trace row admits. `Admitted` is derived exclusively from `AcceptedRequest != null`; there is no independent admitted constructor parameter or state. Held and rejected decisions always contain a null request.

The evaluator does not flatten or clone the authorization subject. The retained request therefore preserves the exact policy and change object identities plus the request's defensive immutable observation snapshot and generation values. Existing trace construction, values, order, and semantics are unchanged.

Tests use a complete length/count-delimited canonical projection covering every service-policy field, all eight reserve dimensions, every placement/maintenance/drain change field and resource dimension, completeness, candidate/current observation generations, and every observation field. Observation entries are canonically ordered for semantic replay; equivalent permutations remain fingerprint-equal across cultures without claiming structural equality of separately constructed request objects. Every accepted change path retains its exact request. Every exercised held/rejected family and all 1,000 lower/equal/higher generation cases prove `Admitted` if and only if an accepted request exists.

The public type has no constructor, setter, or deconstructor. Assembly-wide inspection permits only `AvailabilityPolicyEvaluator.Evaluate` to originate decisions. The record's compiler-generated instance clone can copy an existing immutable decision but cannot create an admitted decision from nothing or attach a request to a denial.

## Compatibility, precedence, and corpus

No request, change, observation, policy, reason, outcome, resource, or generation enum/numeric value changed. The established thirty-row reason order and all held/rejected precedence remain unchanged. No scheduler selection, availability gate, topology rule, capacity/reserve arithmetic, or generation policy changed.

The existing scheduler replay corpus is byte-identical and retains its pinned schema/content address. Its historical outcome fingerprint covers the pre-existing result/trace surface and intentionally does not claim accepted-request identity. Audit4's dedicated complete projection supplies the new provenance evidence; silently versioning an unrelated historical corpus would overstate what its fixtures were designed to prove.

## Evidence boundary

The subject proves which caller-supplied immutable request the pure evaluator admitted. It is not proof that observations are authentic, current, durably accepted, or persisted; that caller-owned stateful safety is correct; or that an adapter performed placement, drain, or maintenance. It does not authorize product/database geography and does not prove provider, runtime, NATS, failure-domain, host, VM, or cloud behavior.

This audit makes no full-domain property, mutation, fuzz, model-schedule, L0C, L3S/L4, deployment-evidence, production-readiness, or production-qualification claim.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.Scheduler.Tests/TerraScale.Orchestrator.Scheduler.Tests.csproj -c Release --no-build --no-restore -- --no-progress
git diff --check
```

Recorded after the final rebase: Release solution build passed with zero warnings and errors; focused audit tests passed 7/7; Scheduler tests passed 84/84; all five executables passed 828/828 (ControlPlane 601, Contract 29, Model 44, Protocol 70, Scheduler 84).


---

# FILE: docs/work-packages/phase1-scheduler-availability.md

# Phase 1 scheduler availability policy

## Goal

Implement pure scheduler hard-policy evaluators for quorum floors, disruption budgets, critical replica anti-affinity/topology spread, and caller-supplied N+1 reserve from `ORCHESTRATOR.md:307-323,619`.

## Allowed paths

- `src/TerraScale.Orchestrator.Scheduler/Availability/**`
- `tests/TerraScale.Orchestrator.Scheduler.Tests/Availability*.cs`
- `docs/work-packages/handoffs/phase1-scheduler-availability.md`

## Required behavior

- Immutable service/replica/node/failure-domain identities and explicit policy inputs for desired/min-available/quorum/disruption counts, criticality, one-per-host, required distinct domains, and reserve resource vector.
- Evaluate placement, drain, and maintenance admission without choosing numeric defaults. Reject co-location/domain collapse, quorum/min-available violation, concurrent disruption over budget, and consumption of caller-supplied reserve.
- Quorum arithmetic is checked and exact; ambiguous/missing/duplicate observations hold. Never infer stateful move safety or project/database geography.
- Return closed reason codes and stable ordered traces without free-form caller text. Decisions must be invariant to input permutations and culture.
- Tests cover 3-node quorum, 2-of-3 loss, one-at-a-time maintenance, last failure-domain margin, zero/maximum/overflow counts, reserve exact boundary, duplicate/conflicting replicas, permutations, and secret-safe output.
- No runtime/provider/NATS/filesystem/time access and no SLO/topology/cost defaults.

## Verification

`dotnet test tests/TerraScale.Orchestrator.Scheduler.Tests/TerraScale.Orchestrator.Scheduler.Tests.csproj`


---

# FILE: docs/work-packages/phase1-scheduler-core.md

# Phase 1 deterministic scheduler core

## Goal

Implement a pure, deterministic constrained least-waste scheduler kernel from `ORCHESTRATOR.md:593-607`. It schedules only supplied candidates and constraints; it does not own product placement or stateful move safety.

## Allowed paths

- `src/TerraScale.Orchestrator.Scheduler/**`
- `tests/TerraScale.Orchestrator.Scheduler.Tests/**`
- `docs/work-packages/handoffs/phase1-scheduler-core.md`

## Required behavior

- Checked non-negative resource quantities for CPU, memory, block IO, ephemeral disk, bandwidth, PIDs, file descriptors, and huge pages; explicit port-set conflict checks.
- Immutable node/workload inputs including architecture, labels, trust/network/secret zones, failure domain, available capacity after caller-provided reservations/headroom, affinity/anti-affinity facts, and an optional caller-provided safety cap.
- Apply hard constraints before scoring. Never invent a pods-per-node limit and never infer project/database geography.
- Deterministic least-waste score and explicit stable tie-break independent of input enumeration order.
- A complete ordered reason trace for every rejected candidate and the selected candidate; no candidate returns typed unschedulable output.
- Tests for every resource boundary, port collision, zones/labels/architecture, anti-affinity, caller veto, stable tie, permutations, overflow, and no mutation of inputs.

## Verification

`dotnet test tests/TerraScale.Orchestrator.Scheduler.Tests/TerraScale.Orchestrator.Scheduler.Tests.csproj`


---

# FILE: docs/work-packages/phase1-scheduler-property-shard.md

# Phase 1 scheduler deterministic property/replay shard

## Goal

Exercise the existing scheduler and availability pure cores with deterministic generated valid and invalid inputs. This shard is scheduler-only test evidence; it does not change production behavior or select a property-testing package.

## Scope

- `DeterministicScheduler.Schedule`, all placement hard constraints, least-waste ranking, and the public constructors/checked arithmetic that validate scheduler inputs.
- `AvailabilityPolicyEvaluator.Evaluate`, placement/maintenance/drain evidence gates, quorum/minimum/disruption/topology/anti-affinity/reserve rules, and all availability input validators.
- Explicit deterministic seed ranges with at least 1,000 generated cases per property.
- A strict, bounded, content-addressed embedded JSON replay corpus containing minimal adversarial seeds for hard constraints, caller safety holds, availability floors, conflicting evidence, and reserve boundaries.

## Required properties

- Identical decisions and traces across replay, candidate/observation permutation, and `tr-TR`/`ar-SA` cultures.
- Checked resource and availability-count conservation, exact remaining capacity, and overflow/underflow rejection.
- Capacity, architecture, node class, labels, trust/network/secret zones, failure-domain, affinity, anti-affinity, ports, safety-cap, and caller-veto enforcement, with a scalar/BigInteger weighted-score/tuple oracle independent of production subtraction and explicit ordinal identity ties.
- Minimum availability, quorum, disruption budget, one-per-host, distinct failure-domain, and per-resource reserve enforcement.
- Incomplete, duplicate, or conflicting availability evidence holds before policy arithmetic. The placement core has no generation/epoch input; stateful stale/fencing rejection is therefore asserted only through its explicit closed caller veto boundary.
- Non-vacuous invalid-generator distribution across every enumerated validation family and every hard-constraint family.
- Construction-closed availability decisions/reasons and closed observable enum values.

## Boundaries

No filesystem, network, process, cloud, environment, wall clock, global randomness, or external property package is permitted. Seed generation is a small deterministic local sequence and corpus entries are fixed embedded resources.

The audit found unbounded caller enumeration in placement candidates, availability observations, and nested scheduler facts/ports/labels/score dimensions. The narrowly expanded production change adds shared maximum-plus-one technical snapshots with named public limits. These are denial-of-service/input-safety bounds, not business placement, replica, or allocation caps.

This feature shard does not claim full-domain property coverage, a full L0/L0C run, 100,000 full-lane cases, mutation score, fuzzing, model exploration, or deployment authority.


---

# FILE: docs/work-packages/phase1-security-authorization-output-audit3.md

# Phase 1 security authorization output audit 3

## Goal

Close the proven accepted-output collision where capability authorization intents discarded the selected principal evidence, matching grant, and accepted generation high-water provenance.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Security/SecurityModels.cs`
- `src/TerraScale.Orchestrator.ControlPlane/Security/SecurityDecisionEngine.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/SecurityThirdAuditRegressionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SecurityPolicyCompletenessPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SecurityCompletenessData.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SecurityPolicyReplayCorpus.v1.json`
- `docs/work-packages/phase1-security-authorization-output-audit3.md`
- `docs/work-packages/handoffs/phase1-security-authorization-output-audit3.md`

## Contract

An accepted `AuthorizeCapabilityIntent` retains the exact selected principal evidence and matching grant plus expected/current principal, policy/current-policy, and current-revocation generations. Existing operation, principal, capability, and resource projections remain. Denials retain only the hold intent. Error numerics, trace order, authorization policy, and precedence do not change.

## Boundary

This is a pure accepted-output provenance correction and adversarial test shard. It performs no cryptography, secret handling, certificate issuance, vault access, identity verification, process, network, NATS, VM, cloud, credential, or deployment operation.


---

# FILE: docs/work-packages/phase1-security-enrollment-generation-audit4.md

# Phase 1 security enrollment generation audit 4

## Goal

Close the proven enrollment replay gap where request-local principal, bootstrap, and attestation generations could agree coherently while all being stale or future relative to the current principal generation.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Security/SecurityModels.cs`
- `src/TerraScale.Orchestrator.ControlPlane/Security/SecurityDecisionEngine.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/SecurityFourthAuditRegressionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/SecurityDecisionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/IdentityNetworkPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/IdentityNetworkSnapshotTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SecurityAcceptedOutputGapTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SecurityCompletenessData.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SecurityPolicyCompletenessPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/SecurityPolicyReplayCorpus.v1.json`
- `docs/work-packages/phase1-security-enrollment-generation-audit4.md`
- `docs/work-packages/handoffs/phase1-security-enrollment-generation-audit4.md`

## Contract

Every `EnrollmentRequest` supplies a non-null `CurrentPrincipalGeneration`. Enrollment can issue or attest an identity only when the expected principal, selected bootstrap evidence, selected attestation evidence, and current-principal high-water agree exactly. A coherent lower or higher generation is rejected at the existing `GenerationCurrent` reason, including the missing-attestation branch. Accepted issue and attestation intents retain the exact request and current-principal generation object.

`SecurityDecisionCode.GenerationCurrent` remains numeric value 8 and keeps its existing trace position. Its observed value is the expected principal generation and its required value is the current-principal high-water. No generation arithmetic is introduced, including at `ulong.MaxValue`.

## Validation matrix

- Exact current generation with valid attestation: authorize `IssueIdentityIntent`.
- Exact current generation with missing attestation: authorize `AttestIdentityIntent`.
- Coherent lower generation with valid or missing attestation: reject and emit only `HoldSecurityOperationIntent`.
- Coherent future generation with valid attestation: reject and emit only `HoldSecurityOperationIntent`.
- Null current generation: construction fails.
- Public construction surface: exactly one ten-parameter constructor in the declared order, with no optional/default parameters or public static factory.
- `ulong.MaxValue` exact match: accepted without overflow.
- Repeated evaluation under `en-US`, `tr-TR`, `ar-SA`, and `ja-JP`: identical ordered trace.
- Completeness, construction-closure, strict corpus replay, and 1,000-case permutation properties remain green. The strict corpus saves coherent stale, coherent future, and stale missing-attestation failure seeds as variants 16, 17, and 18.

## Boundary

This is a deterministic in-memory authorization-contract correction. `SecurityGeneration` remains distinct from the deferred process-wide `SecurityEpoch`. The change does not prove external identity authenticity, attestation validity, persistence freshness, distributed replay prevention, or multi-writer ordering. It performs no cryptography, credential handling, KMS/Vault access, network, filesystem, cloud, deployment, or other external side effect.


---

# FILE: docs/work-packages/phase1-snapshot-core.md

# Phase 1 snapshot and restore core

## Goal

Implement the pure snapshot acceptance/restore decision core from `ORCHESTRATOR.md:545-550`: snapshots bind schema version, signed stream position, state digest, and fencing epoch; restore refuses rollback.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Snapshots/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Snapshot*.cs`
- `docs/work-packages/handoffs/phase1-snapshot-core.md`

## Required behavior

- Immutable bounded authority/stream/snapshot/schema/key identities; positive epoch/stream sequence/generation; opaque nonempty state digest/signature.
- Complete algorithm-neutral signed material and caller-supplied typed signature verification outcome; verifier exceptions become closed errors and never leak text.
- Pure create-material, validate, and restore-plan decisions using explicit current accepted epoch/stream position/schema compatibility and supplied signature verifier.
- Reject wrong authority/stream/key, malformed/unknown/incompatible schema, stale epoch, older/equal stream rollback where inappropriate, digest mismatch, invalid signature, and signature material field omission.
- A restore plan emits replay start after the exact snapshot position and expected restored digest/epoch; it never mutates state or performs I/O.
- Defensive byte copies, secret-safe formatting, invariant canonical material projection, overflow boundaries, tamper-one-field matrix, verifier failure, replay determinism, and restore anti-rollback tests.
- No signing algorithm, serializer, NATS, filesystem, time, or compatibility-window default.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`


---

# FILE: docs/work-packages/phase1-snapshot-evidence-property-shard.md

# Phase 1 snapshot and pre-deployment evidence property/replay shard

## Goal

Exercise the existing signed-snapshot restore and pre-deployment evidence pure cores with deterministic, independently checked generated cases and a strict replay corpus.

## Scope

- At least 1,000 cases per snapshot epoch/position freshness, signed-field corruption, deterministic restore replay, malformed/corrupt/overflow refusal, evidence generation/expiry freshness, and evidence permutation/culture property.
- Restore never moves over a newer accepted epoch or equal/older journal position; replay begins exactly after the authenticated snapshot position.
- Every signed scope/version/position/digest field remains bound by exact scope checks or the opaque signature verifier.
- Strict byte-bounded, whole-file SHA-256-pinned, closed-vocabulary, input-sensitive replay corpus.
- Construction-closed validation, restore-plan, and deployment-evidence authorization outputs.

## Boundary and non-claims

This shard is pure decision testing. It performs no filesystem, network, process, NATS, cloud/provider, deployment, or sibling-repository operation and makes no L0/L0C, cryptographic-algorithm, external-signature, snapshot persistence, deployment-authority, or production-readiness claim.


---

# FILE: docs/work-packages/phase1-snapshot-policy-completeness.md

# Phase 1 snapshot policy completeness

## Goal

Audit the pure signed-snapshot validator and restore planner against the snapshot/replay and anti-rollback requirements in `ORCHESTRATOR.md:538-550` and `ORCHESTRATOR.md:1120-1150`.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Snapshots/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Snapshot*.cs`
- `docs/work-packages/phase1-snapshot-policy-completeness.md`
- `docs/work-packages/handoffs/phase1-snapshot-policy-completeness.md`

## Required behavior

- A restore candidate must not carry a state generation lower than the current accepted generation, even when its signed stream position advances.
- Equal state generation remains valid when the signed stream position advances and every other validation gate passes; snapshots at multiple journal checkpoints may describe the same accepted state generation.
- Preserve validation precedence: scope, schema compatibility, epoch, stream position, generation, state digest, then signature outcome.
- Exercise exact plan projections, all defined and undefined dependency outcomes, every typed error catalog, invalid context fields, delegate call suppression, deterministic replay, cultures, construction closure, and overflow.

## Boundary

This package is pure decision code and tests. It performs no serialization, signing, hashing, persistence, NATS, filesystem, process, network, cloud/provider, VM, container, or deployment operation. It makes no L0, L0C, mutation-score, fuzz-budget, cryptographic, snapshot-persistence, or production-readiness claim.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore --nologo -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj -c Release --no-build --no-restore -- --treenode-filter '/*/*/Snapshot*/*' --no-progress
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj -c Release --no-build --no-restore -- --no-progress
dotnet test TerraScale.Orchestrator.slnx -c Release --no-build --no-restore -- --no-progress
git diff --check
```


---

# FILE: docs/work-packages/phase1-snapshot-restore-provenance-audit3.md

# Phase 1 snapshot restore provenance audit

## Scope and base

- Base: central `chore/phase0-bootstrap` at `619a60e8a6635971cac4eafcd8174fb1a80ab44f` after the required final rebase.
- Allowed paths: snapshot restore contracts, snapshot decision tests, and this work package.
- Pure deterministic decision work only; no snapshot serializer, persistence store, journal, NATS, filesystem, network, process, signing service, cloud/provider, VM, container, or deployment action.

## Executable defect

Two valid signed snapshots with different authorities, streams, schemas, signing keys, and signatures could produce the same complete public restore-plan projection when their snapshot ID, generation, epoch, stream position, and state digest matched:

```text
snapshot-42|3|7|102|73746174652D6469676573742D736563726574
```

The accepted output therefore erased the exact signed envelope that passed scope, schema, digest, freshness, and signature validation. A persisted plan could be relabeled across accepted authorities, streams, schemas, keys, or signatures without detection from the plan itself.

## Correction

`SnapshotRestorePlan` is now assembled internally only from the exact `SignedSnapshot` that passed validation plus its computed replay-start sequence. `AcceptedSnapshot` retains that immutable envelope. Existing snapshot ID, generation, expected epoch, and expected digest getters derive from its signed material, so independently mixed provenance cannot be constructed inside the planner.

The snapshot material, digest, and signature types already copy or retain immutable values. Tests prove exact snapshot/material/signature identity retention, source-buffer mutation safety, and a length-delimited complete test fingerprint over all nine authenticated material fields, the signature, and replay start. Each signed field and the signature is independently sensitive. Semantically identical replay is fingerprint-equal under multiple cultures; nominal snapshot objects are not claimed to have structural equality.

Every validation rejection and replay-start overflow retains `Plan = null`. Both accepted schema cases exercised by the pure contract—same current schema and a distinct schema classified `Compatible`—retain the exact envelope. Equal accepted generation at a later stream position remains valid. The plan exposes no public constructor, setter, deconstructor, clone, or forgeable plan-returning factory.

## Compatibility and precedence

No input DTO, enumeration, numeric value, validation error, plan error, validation result, or validation precedence changed. Existing plan projection getters remain source-compatible. Validation still checks context, snapshot shape, authority, stream, signing key, schema outcome, epoch, stream sequence, generation, digest, and signature in the existing order; replay-start overflow remains a post-validation planning error.

## Evidence boundary

The retained envelope proves only which caller-supplied immutable snapshot value the pure planner accepted under that invocation. It is not proof of snapshot content availability, digest computation, canonical serialization, signature authenticity, key custody, schema migration safety, durable accepted baselines, atomic persistence, restore execution, or journal replay correctness.

The validation context is deliberately not retained. In particular, the current accepted epoch/stream/generation baselines, expected digest, current schema, compatibility evaluator identity and policy, and signature-verifier identity and policy remain caller-owned authorization provenance that must be persisted separately when required. The plan also does not retain rejected candidates. This audit makes no cryptographic, persistence, NATS conformance, L0/L0C, recovery, deployment-readiness, or production-qualification claim.

## Verification

```text
dotnet restore TerraScale.Orchestrator.slnx --locked-mode
dotnet build TerraScale.Orchestrator.slnx -c Release --no-restore -warnaserror
dotnet run --project tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj -c Release --no-build --no-restore -- --no-progress
git diff --check
```

Recorded after the final rebase: Release solution build passed with zero warnings and errors; focused snapshot tests passed 46/46; all five executables passed 806/806 (ControlPlane 597, Contract 24, Model 38, Protocol 70, Scheduler 77).


---

# FILE: docs/work-packages/phase1-storage-compute-property-shard.md

# Phase 1 storage and compute deterministic property/replay shard

## Goal

Exercise the existing pure Storage and Compute control-plane cores with bounded deterministic generated cases and a fixed replay corpus. This shard strengthens test evidence only; it neither performs provider work nor claims deployment acceptance.

## Scope

- At least 1,000 explicit cases per property for storage capacity arithmetic, owner/generation/writer fencing, deletion authorization, deterministic replay, and culture stability.
- At least 1,000 explicit cases per property for compute capacity gates, generation/controller fencing, scale-in floors, survival-bundle permutation, deterministic replay, and culture stability.
- Independent expected-code and checked/subtraction oracles that do not call production decision helpers.
- Closed observable catalogs and construction-closed authorizing result surfaces.
- A strict bounded embedded JSON replay corpus with an exact SHA-256 content address and saved Storage/Compute safety failures.

## Narrow production hardening

`RegionalSurvivalBundle` previously used unbounded `ToArray()` over two public caller enumerables. The authorized change introduces named 4,096-item technical snapshot bounds for encrypted secret-version identities and node templates. Maximum+1 is detected before reading the extra `Current`; ordinary iterator failures are translated without their text; fatal runtime exceptions propagate; captured values are defensive against mutation during `Dispose`.

These are denial-of-service/input-safety limits, not node, secret, replica, region, or scaling business caps. Existing callers presenting more than 4,096 items now receive `ArgumentException` and must shard or reject that malformed bundle before evaluation.

## Boundaries and non-claims

No cloud/provider, NATS, network, process, filesystem, environment, wall-clock, or nondeterministic random operation occurs. This shard does not claim the 100,000-case full-domain threshold, coverage or mutation targets, adapter conformance, destructive acceptance, L0 completion, or deployment authority.


---

# FILE: docs/work-packages/phase1-storage-create-output-audit4.md

# Phase 1 storage create output audit 4

## Goal

Close the proven accepted-output collision where Storage validated creation and mount policy but discarded the encryption-key reference, placement, storage domain, and mount purpose from its intent subject.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Storage/StorageVolumeRecord.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/StorageFourthAuditRegressionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/StoragePlannerPropertyTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/StoragePlannerReplayCorpus.cs`
- `docs/work-packages/phase1-storage-create-output-audit4.md`
- `docs/work-packages/handoffs/phase1-storage-create-output-audit4.md`

## Contract

Every decision produced from a validated `StorageVolumeRecord` trace retains its exact immutable storage domain, encryption-key reference, placement, and mount purpose in the internal-only `StorageIntentScope`. Existing subject fields, actions, targets, codes, numeric values, validation, precedence, and planner behavior remain unchanged. The existing immutable record-copy routes remain the only non-planner copies; no public constructor, setter, deconstructor, or new factory is added.

## Boundary

These values are accepted in-memory policy provenance. Retention does not authenticate a key reference, authorize KMS use, prove encryption at rest, qualify a provider placement, execute a mount, verify a filesystem, or prove TerraBase/storage behavior. This work performs no filesystem, block-device, database, provider, network, signing, registry, VM, cloud, deployment, or CI-dispatch operation.


---

# FILE: docs/work-packages/phase1-storage-lifecycle-core.md

# Phase 1 storage lifecycle and expansion core

## Predecessor

- Contract steward commit: `a1ecba0`
- Filesystem, performance tier, thresholds, growth increment, lead time, SLO/RPO, and deletion policy values remain caller inputs.

## Goal

Implement the pure storage identity, single-writer, create/attach, expansion, and deletion authorization state machines from `ORCHESTRATOR.md:758-841`. It emits typed provider/guest/application intents only.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Storage/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Storage*.cs`
- `docs/work-packages/handoffs/phase1-storage-lifecycle-core.md`

## Required behavior

- Immutable bounded claim/provider-volume/attachment/node/workload/member/filesystem/operation/backup/fence identities; checked byte/performance/generation/epoch quantities; closed filesystem/layout/retention/action/observation catalogs.
- Exact volume ownership and identity bind provider ID, cell/workload/member/claim, domain, attachment, encryption-key reference, filesystem UUID/type/layout/mount purpose, observed/requested/provider/block/filesystem/used/free bytes, performance, retention, backup, generation, writer fence, and operation.
- New blank format is authorized only with exact provider/owner/blank proof/current fence. Recognized volumes never format. Single-writer read/write attachment cannot overlap; reattach requires stop proof, lease revocation, provider detachment convergence, new writer epoch, and health verification.
- Restartable expansion follows the documented irreversible sequence. Provider size alone is never success; a crash resumes at the first unproven step and never issues duplicate growth. Expansion never shrinks and serializes against all caller-declared conflicting operation classes.
- Permanent deletion is unrepresentable without every topology, quorum/replication, database-reference, backup/retention, owner/fence, quarantine/disposable, and post-delete audit proof. The core authorizes an exact deletion intent but never performs it.
- Emit closed observe/create/attach/classify/format/mount/rescan/extend/grow/verify/detach/delete/hold intents and stable code/numeric traces; no device path, mount command, shell text, secret, callback, SDK type, or I/O.
- Defensive copies; culture/permutation/replay determinism; wrong owner/fence; dual writer; recognized-format denial; crash at every expansion step; size disagreement; shrink/overflow; conflict serialization; permanent/elastic deletion proof matrices; and secret-safe tests.
- No storage/provider/filesystem API, process, wall clock, threshold/growth/default filesystem/performance value, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-storage-planner-property-shard.md

# Phase 1 storage planner property and replay shard

## Goal

Exercise the existing pure storage create, format, attachment, expansion, deletion, and crash-recovery planners with deterministic generated cases and a fixed replay corpus. This shard strengthens pure decision evidence only; it performs no provider, filesystem, process, network, or deployment operation.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/Storage/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/StoragePlanner*`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/StorageTestData.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`
- this work package

## Property evidence

- 1,000 materially distinct create and format cases cover every checkpoint and exact action, target, stable code, mutation classification, intent scope, and numeric trace field under culture changes and replay.
- 1,000 attachment cases cover zero, one, and conflicting writers; stop/lease/detach proof; exact new writer epoch; same-node health; permutation; and idempotent recovery.
- 1,000 expansion cases cover the first unproven irreversible step, provider convergence, guest/layout/filesystem/application/metrics recovery, conflict serialization, exact capacity/performance traces, and prevention of duplicate provider growth.
- 1,000 deletion cases cover permanent, quarantined elastic, and explicitly disposable retention precedence plus delete/provider-convergence/post-delete-audit recovery without duplicate deletion.
- 1,000 cross-planner authority and evidence-scope cases independently select provider, claim, cell, workload, member, fence, generation, epoch, or operation mismatch and require the exact fail-closed result.
- A strict, bounded, embedded JSON corpus is pinned by SHA-256. Its exact shape, closed vocabulary, family completeness, seed range, seed-sensitive expectations, byte bound, and fatal exception behavior are tested.

## Narrow production hardening

`StorageReattachEvidence` previously trusted its caller-provided `maximumWriterObservations` as the only acquisition limit. A caller could pass `int.MaxValue` and supply an endless or extremely large enumerable, and the former `foreach` read the maximum-plus-one `Current` before rejecting it.

The capture path now applies a named 4,096-item technical ceiling in addition to the caller's business limit, checks maximum-plus-one after `MoveNext` but before `Current`, returns secret-safe malformed evidence for ordinary iterator failures, and propagates `OutOfMemoryException`, `StackOverflowException`, and `AccessViolationException`. The ceiling is not storage topology policy: the planner's valid state admits at most one writer and rejects more than one as `DualWriter`, so 4,096 cannot exclude a planner-accepted topology. Null writer input retains its prior empty-snapshot behavior.

The compatibility change is intentionally limited to malformed evidence whose writer enumeration exceeds 4,096 while declaring a larger caller maximum; it now fails closed. Existing valid zero/one-writer evidence and caller maxima remain unchanged.

The exact intent-subject oracle also exposed that a successful reattach previously retained the old volume node in `StorageDecision.Scope` and discarded the requested target node. Attach decisions now override only the scope's node and authorized writer epoch with the requested values. Detach and every unrelated decision continue to identify the current volume node. This is an intentional accepted-output correctness change with no public signature change; consumers that incorrectly inferred the attach target was the old node now receive the actual requested target.

Deletion and reattachment also previously interpreted undefined proof enum values as an unproven step, which could emit `Delete` or `Detach`. After authority and evidence-scope validation, every reattach/deletion proof is now closed: undefined values produce `InvalidInput`, defined `Contradicted` values produce `StepContradicted`, and only `Unknown` advances the legitimate next-step state machine. Permanent-retention and wrong-scope precedence remain unchanged.

## Boundaries and non-claims

This shard neither selects unresolved storage SLO, retention, RPO/RTO, or owner decisions nor claims the 100,000-case full-domain threshold, mutation target, provider conformance, destructive storage acceptance, L0 completion, or deployment authority. It starts no storage, cloud, NATS, network, process, filesystem, or VM activity.


---

# FILE: docs/work-packages/phase1-structured-trace-foundation.md

# Phase 1 structured traceability foundation

## Predecessor and boundary

- Base branch: `origin/chore/phase0-bootstrap`.
- The Phase 0 lexical trace report is retained as a non-acceptance gap aid.
- No production, registry, build, package, solution, specification, or sibling-repository changes are authorized.
- `claimsAcceptanceEvidence` must remain false; this tranche cannot satisfy or promote any registry acceptance layer.

## Allowed paths

- `requirements/trace-links.yaml`
- `tools/traceability/**`
- `docs/audits/traceability/**`
- `docs/work-packages/phase1-structured-trace-foundation.md`
- `docs/work-packages/handoffs/phase1-structured-trace-foundation.md`

## Deliverable

Replace lexical-only traceability with a strict structured manifest and dependency-free validator. Every one of the 43 registry IDs has exactly one entry whose owner and ordered acceptance layers match the registry, whose status is exactly `gap` or `linked`, and whose production, test, and evidence links use closed typed shapes.

Gap entries are first-class and have no orphan links. Linked entries require all three link classes, but remain non-acceptance associations. Do not invent links for unimplemented or inadequately evidenced items.

The validator must reject missing, duplicate, or unknown IDs; owner/layer drift; unbounded or malformed input; unknown fields; path traversal, absolute paths, symlinks, non-regular or outside-root files; missing or ambiguous identifiers; comment/string-only C# references; test-only, production-only, or evidence-free promotion; duplicate/reused links; invalid evidence kinds/layers; identifier substitution; stale output; and any acceptance-evidence claim.

It emits a deterministic canonical report and input digest. The lexical report remains separate and explicitly cannot promote structured or acceptance status.

## Verification

```text
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- traceability-validate --check
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- traceability-generate --check
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
```

Run relevant registry/audit tests discovered in the repository. Pre-commit review is required.


---

# FILE: docs/work-packages/phase1-subject-grammar.md

# Phase 1 NATS subject grammar

## Goal

Implement infrastructure-free NATS subject and permission-pattern grammar used by future generated account policies. This validates syntax and matching only; it does not select account topology, subjects, or permissions.

## Allowed paths

- `src/TerraScale.Orchestrator.Protocol/Subjects/**`
- `tests/TerraScale.Orchestrator.Protocol.Tests/Subject*.cs`
- `docs/work-packages/handoffs/phase1-subject-grammar.md`

## Required behavior

- Concrete subjects are nonempty bounded dot-separated tokens and reject whitespace, empty tokens, control characters, `*`, and `>`.
- Permission patterns are separately typed; `*` occupies exactly one token and `>` is permitted only as the final whole token. Reject embedded/trailing injection and ambiguous spellings.
- Matching is deterministic, allocation-bounded, culture-invariant, and case-sensitive. It must not use regex constructed from input.
- Provide a typed permission decision over explicit allow and deny pattern sets. Deny wins; no match denies; empty allow denies. Return a stable reason code without echoing untrusted subject text.
- Defensive copies, duplicate rejection, canonical ordering, maximum token/count/length limits supplied as explicit validated policy (no production default), and adversarial tests including fuzz-like malformed corpus and boundary cases.
- Do not add NATS packages, fixed subject roots, account names, stream names, or owner-decision defaults.

## Verification

`dotnet test tests/TerraScale.Orchestrator.Protocol.Tests/TerraScale.Orchestrator.Protocol.Tests.csproj`


---

# FILE: docs/work-packages/phase1-terrabase-audit2.md

# Phase 1 TerraBase accepted-output audit 2

## Predecessor and scope

- Integration predecessor: `1eac098`.
- Allowed production paths: `src/TerraScale.Orchestrator.ControlPlane/TerraBase/**`.
- Allowed evidence paths: TerraBase tests under `tests/TerraScale.Orchestrator.ControlPlane.Tests/**`
  and this package/handoff.
- No database, process, filesystem, network, NATS, provider, sibling-repository, or deployment activity.

## Goal

Audit all seven public TerraBase decision entrypoints for malformed caller expectations, exact evidence scope,
topology replication safety, valid intent parameters, and ordered upgrade/rollback/restore evidence. Prove any
accepted-output defect with a failing pre-fix regression before changing production behavior.

## Required evidence

- All ten `TerraBaseEvidenceScope` validity dimensions and runtime-null expectations across all seven entrypoints.
- Valid-but-mismatched evidence remains distinct from malformed caller intent.
- Add/remove/catch-up/transfer/observe/verify transition and precedence coverage, including every replication state.
- Upgrade, rollback, and restore future-proof coherence for `Unknown`, `Proven`, and `Contradicted` checkpoints.
- Exact mutation subject and trace closure, 1,000 deterministic cases per new property family, and non-English culture replay.
- Focused, full control-plane, whole-solution build, and all executable test projects.

## Explicit exclusions

This audit does not invent absent bootstrap/join, elastic member ordering, multi-region replication placement,
restore-conflict, or terminal rollback-failure contracts. Those require a steward-owned compatible contract tranche.


---

# FILE: docs/work-packages/phase1-terrabase-audit3.md

# Phase 1 TerraBase accepted upgrade output audit 3

## Goal

Close the proven accepted-output collision where post-apply upgrade observation and completion decisions discarded the exact validated current and target release pair.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/TerraBase/TerraBaseLifecycle.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraBaseThirdAuditRegressionTests.cs`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/Properties/TerraBaseSecondAuditPropertyTests.cs`
- `docs/work-packages/phase1-terrabase-audit3.md`
- `docs/work-packages/handoffs/phase1-terrabase-audit3.md`

## Contract

Every non-hold upgrade decision retains the already validated `TerraBaseUpgradeIntentSubject`, including post-apply health observation and successful completion. Existing actions, targets, codes, traces, validation, and precedence remain unchanged. Hold decisions remain subject-free.

## Boundary

This is a pure accepted-output provenance correction and adversarial test shard. It performs no TerraBase administration, process, filesystem, network, NATS, VM, cloud, credential, or deployment operation.


---

# FILE: docs/work-packages/phase1-terrabase-core.md

# Phase 1 TerraBase topology and recovery core

## Predecessor

- Contract steward commit: `5315e7d`
- TerraBase release compatibility, replication/lag/backup SLO values, elastic-member policy, and storage thresholds remain explicit caller inputs.

## Goal

Implement pure TerraBase topology, member lifecycle, upgrade, autoscaling, backup, and restore decisions from `ORCHESTRATOR.md:1012-1042` and the TerraBase/storage acceptance gates. It emits typed administration intents only.

## Allowed paths

- `src/TerraScale.Orchestrator.ControlPlane/TerraBase/**`
- `tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraBase*.cs`
- `docs/work-packages/handoffs/phase1-terrabase-core.md`

## Required behavior

- Immutable bounded cell/database/member/node/volume/backup/restore/release/operation identities; positive generation/epoch/sequence/byte quantities; closed permanent/elastic, role, health, replication, backup, restore, upgrade, and action catalogs.
- Permanent `a/b/c` membership is explicit and cannot be scaled in or replaced by unnamed count arithmetic. One-node loss retains caller-supplied quorum/replication floors; no two topology mutations overlap.
- Member add/remove/replace binds exact database, node, retained volume, writer fence, replication position, backup/recovery proof, and authority epoch. A retained volume never starts on two members and a new member never adopts an old volume without exact identity/fence proof.
- Scale-out requires sustained caller evidence, placement/storage/budget authorization, unique member identity, catch-up and replication proof before readiness. Scale-in requires sustained low use, topology removal, zero database references, backup/retention, volume disposition, and post-change replication proof.
- Upgrade proceeds one member/failure domain at a time under explicit N/N-1 compatibility and rollback-material proof. Health/readiness, leadership transfer, and catch-up are distinct; process exit never means success.
- Backup acceptance binds exact database generation/topology, full/incremental chain, object digest/location reference, encryption-key reference, application-consistency and verification. Restore is side-by-side, rejects chain gaps/rollback, and requires digest/topology/query verification before promotion.
- Emit closed observe/add/catch-up/transfer/remove/start-with-retained-volume/backup/restore/upgrade/rollback/hold intents and stable code/numeric traces; no SQL/admin command, endpoint, credential, arbitrary payload, callback, SDK, or I/O.
- Defensive copies; culture/permutation/replay determinism; a/b/c protection; one/two loss; split-writer; stale/future/conflicting replication; add/remove crash steps; upgrade N/N-1; backup chain corruption; restore rollback; and secret-safe tests.
- No TerraBase client, network/filesystem/process/clock, topology/SLO/threshold/default release, or mutation.

## Verification

`dotnet test tests/TerraScale.Orchestrator.ControlPlane.Tests/TerraScale.Orchestrator.ControlPlane.Tests.csproj`



---

# FILE: docs/work-packages/phase1-terrabase-topology-provenance-audit4.md

# Phase 1 TerraBase topology provenance audit 4

## Basis and scope

- Exact central basis: `dc51519e35515b191cdbca039c5d20251e2353ec`.
- Bounded internal requirement: pure accepted topology output provenance for the existing add/remove contract.
- Excluded: active reconciliation policy; every previously integrated audit-4 domain; TerraBase clients, processes, storage, networks, NATS, VMs, cloud resources, deployment activity, and all external effects.

## Requirement mapping

- `ORCHESTRATOR.md:146-150`: one fenced, replay-safe TerraBase topology operation and protected permanent-member/scaling safety.
- `ORCHESTRATOR.md:1016-1033`: typed topology read-back, replication-aware add/remove, safe decommission, and the existing 3-to-10 policy boundary.
- `ORCHESTRATOR.md:1120-1152`: every branch and terminal result must be tested and pure methods must return typed decisions and intents.

## Proven counterexamples

Three executable tests failed before production changed:

- post-add and post-remove topology observations with the same scope and position produced equal decisions, erasing the semantic planner route;
- successful add decisions accepted different loss evidence but compared equal;
- successful remove decisions accepted different follower/leader-transfer evidence but compared equal.

All three used a generic scoped subject and discarded the accepted topology evidence.

## Narrow correction

`TerraBaseTopologyIntentSubject` now retains a fixed, non-unknown `TerraBaseTopologyPlanKind` (`Add` or `Remove`) and the exact accepted `TerraBaseTopologyEvidence` reference. Scope, member kind, and replication position are projections of that retained evidence. Every non-hold add/remove branch uses one such exact subject; action, target, code, trace, validation, and precedence remain unchanged. Every hold remains subject-free.

## Proof inventory

- Exact evidence reference and plan kind across all six successful add outcomes and all five successful remove outcomes.
- Cross-kind separation and all three original collision regressions.
- Independent sensitivity for all 10 evidence-scope leaves and all 20 remaining topology-evidence leaves.
- 1,000 unique culture-stable replay cases plus multiple real evaluation-order permutations of the complete successful branch inventory.
- Unchanged four-entry whole-file-pinned Delivery/TerraBase replay corpus compatibility.
- Exact allowlists for seven public decision origins and every decision/base/concrete-subject/evidence/scope/trace/collection return route, accessor, record clone, constructor boundary, default decision, value copy, and concrete topology-subject clone basis.

## Deferred owner and external boundaries

This correction does not invent the clean bootstrap/join, elastic tag/rank ordering, six-direction replication/placement, restore-conflict, or terminal rollback-failure contracts listed by the prior audit. Those require a steward-owned compatible contract tranche. Threshold/SLO and owner choices remain unresolved. Real TerraBase administration, systemd/container execution, storage recovery, L3S, L4, and production qualification require later adapters and real-system evidence.
