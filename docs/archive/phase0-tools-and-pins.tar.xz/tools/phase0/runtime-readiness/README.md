# ARM64 runtime readiness validator

Validate the checked-in proposal without contacting a network, starting a service,
or selecting a candidate:

```bash
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- runtime-readiness
dotnet run --project tools/TerraScale.Orchestrator.Tooling -- test
```

The validator fails if a host, kernel, filesystem, or runtime becomes selected;
if local x86_64 inspection is represented as ARM64 qualification; if L1R/L4 is
represented as run; if any of the four host-by-filesystem combinations is
missing; if required candidate classes disappear; or if evidence uses an
unknown/non-primary source. Adversarial overlays under `fixtures/` exercise
those fail-closed rules.
